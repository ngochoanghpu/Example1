using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Volo.Abp.Domain.Repositories;

namespace kitchen.SalesOrderDetailStatusHistories
{
    public interface ISalesOrderDetailStatusHistoryRepository : IRepository<SalesOrderDetailStatusHistory, Guid>
    {
        Task<List<SalesOrderDetailStatusHistory>> GetListAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            string salesOrderDetailStatus = null,
            string kitchenStatus = null,
            string notes = null,
            Guid? changedById = null,
            string changedByUserName = null,
            string changedByDateTime = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default
        );

        Task<long> GetCountAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            string salesOrderDetailStatus = null,
            string kitchenStatus = null,
            string notes = null,
            Guid? changedById = null,
            string changedByUserName = null,
            string changedByDateTime = null,
            CancellationToken cancellationToken = default);
    }
}