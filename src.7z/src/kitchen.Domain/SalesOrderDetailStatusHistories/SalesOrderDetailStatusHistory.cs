using System;
using Volo.Abp.Domain.Entities;
using Volo.Abp.Domain.Entities.Auditing;
using Volo.Abp.MultiTenancy;
using JetBrains.Annotations;
using Volo.Abp;

namespace kitchen.SalesOrderDetailStatusHistories
{
    public class SalesOrderDetailStatusHistory : FullAuditedAggregateRoot<Guid>, IMultiTenant
    {    
        public virtual Guid? TenantId { get; set; }
        
        public virtual Guid? SalesOrderId { get; set; }
        
        public virtual Guid? SalesOrderDetailId { get; set; }
        
        [CanBeNull]
        public virtual string SalesOrderDetailStatus { get; set; }
        
        [CanBeNull]
        public virtual string KitchenStatus { get; set; }
        
        [CanBeNull]
        public virtual string Notes { get; set; }
        
        public virtual Guid? ChangedById { get; set; }
        
        [CanBeNull]
        public virtual string ChangedByUserName { get; set; }
        
        [CanBeNull]
        public virtual string ChangedByDateTime { get; set; }



        public SalesOrderDetailStatusHistory()
        {

        }

        public SalesOrderDetailStatusHistory(Guid id, Guid? tenantId, string salesOrderDetailStatus, string kitchenStatus, string notes, Guid? changedById, string changedByUserName, string changedByDateTime, Guid? salesOrderId = null, Guid? salesOrderDetailId = null)
        {
            Id = id;
            TenantId = tenantId;
            SalesOrderDetailStatus = salesOrderDetailStatus;
            KitchenStatus = kitchenStatus;
            Notes = notes;
            ChangedById = changedById;
            ChangedByUserName = changedByUserName;
            ChangedByDateTime = changedByDateTime;
            SalesOrderId = salesOrderId;
            SalesOrderDetailId = salesOrderDetailId;

        }
    }
}