using System;
using Volo.Abp.Domain.Entities;
using Volo.Abp.Domain.Entities.Auditing;
using Volo.Abp.MultiTenancy;
using JetBrains.Annotations;
using Volo.Abp;
using System.Collections.Generic;
using kitchen.SalesOrderDetails;

namespace kitchen.SalesOrders
{
    public class SalesOrder : FullAuditedAggregateRoot<Guid>, IMultiTenant
    {

        
        public virtual Guid? TenantId { get; set; }
        
        public virtual Guid SalesOrderId { get; set; }
        
        [CanBeNull]
        public virtual string StoreCode { get; set; }
        
        [CanBeNull]
        public virtual string StoreName { get; set; }
        
        public virtual string EmployeeCode { get; set; }
        
        [CanBeNull]
        public virtual string EmployeeName { get; set; }
        
        [CanBeNull]
        public virtual string OrderNo { get; set; }
        
        [CanBeNull]
        public virtual string OrderType { get; set; }
        
        [CanBeNull]
        public virtual string OrderTypeName { get; set; }
        
        public virtual DateTime OrderDateTime { get; set; }
        
        [CanBeNull]
        public virtual string OrderStatus { get; set; }
        
        [CanBeNull]
        public virtual string OrderStatusName { get; set; }
        
        [CanBeNull]
        public virtual string SalesChannelCode { get; set; }
        
        [CanBeNull]
        public virtual string SalesChannelName { get; set; }
        
        public virtual bool HasDelivery { get; set; }
        
        [CanBeNull]
        public virtual string Notes { get; set; }
        
        [CanBeNull]
        public virtual string WaitingNumber { get; set; }
        
        public virtual DateTime? PickingTime { get; set; }
        
        public virtual DateTime? SnoozingTime { get; set; }
        
        public virtual DateTime? RecievedDateTime { get; set; }
        
        public virtual Guid? PerformedById { get; set; }
        
        [CanBeNull]
        public virtual string PerformedByName { get; set; }
        
        public virtual DateTime? PerformedDateTime { get; set; }
        
        [CanBeNull]
        public virtual string KitchenStatus { get; set; }

        [CanBeNull]
        public virtual string StoreBrand { get; set; }

        [CanBeNull]
        public virtual string StoreTypeCode { get; set; }

        [CanBeNull]
        public virtual string StoreTypeName { get; set; }

        public virtual Guid? TableId { get; set; }

        public virtual ICollection<SalesOrderDetail> SalesOrderDetails { get; set; }



        public SalesOrder()
        {

        }

        public SalesOrder(Guid id, Guid salesOrderId, string storeCode, string storeName, string employeeCode, string employeeName, string orderNo, string orderType, string orderTypeName, DateTime orderDateTime, string orderStatus, string orderStatusName, string salesChannelCode, string salesChannelName, bool hasDelivery, string notes, string waitingNumber, string performedByName, string kitchenStatus, DateTime? pickingTime = null, DateTime? snoozingTime = null, DateTime? recievedDateTime = null, Guid? performedById = null, DateTime? performedDateTime = null, string storeBrand = null,
                          string storeTypeCode = null, string storeTypeName = null, Guid? tableId = null)
        {
           Id = id;
            SalesOrderId = salesOrderId;
            StoreCode = storeCode;
            StoreName = storeName;
            EmployeeCode = employeeCode;
            EmployeeName = employeeName;
            OrderNo = orderNo;
            OrderType = orderType;
            OrderTypeName = orderTypeName;
            OrderDateTime = orderDateTime;
            OrderStatus = orderStatus;
            OrderStatusName = orderStatusName;
            SalesChannelCode = salesChannelCode;
            SalesChannelName = salesChannelName;
            HasDelivery = hasDelivery;
            Notes = notes;
            WaitingNumber = waitingNumber;
            PerformedByName = performedByName;
            KitchenStatus = kitchenStatus;
            PickingTime = pickingTime;
            SnoozingTime = snoozingTime;
            RecievedDateTime = recievedDateTime;
            PerformedById = performedById;
            PerformedDateTime = performedDateTime;
            StoreBrand = storeBrand;
            StoreTypeCode = storeTypeCode;
            StoreTypeName = storeTypeName;
            TableId = tableId;
        }
    }
}