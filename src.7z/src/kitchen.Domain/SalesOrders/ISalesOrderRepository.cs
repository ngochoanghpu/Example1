using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using Volo.Abp.Domain.Repositories;

namespace kitchen.SalesOrders
{
    public interface ISalesOrderRepository : IRepository<SalesOrder, Guid>
    {
        Task<List<SalesOrder>> GetListAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            string storeCode = null,
            string storeName = null,
            string employeeCode = null,
            string employeeName = null,
            string orderNo = null,
            string orderType = null,
            string orderTypeName = null,
            DateTime? orderDateTimeMin = null,
            DateTime? orderDateTimeMax = null,
            string orderStatus = null,
            string orderStatusName = null,
            string salesChannelCode = null,
            string salesChannelName = null,
            bool? hasDelivery = null,
            string notes = null,
            string waitingNumber = null,
            bool? isTakeAway = null,
            DateTime? pickingTimeMin = null,
            DateTime? pickingTimeMax = null,
            DateTime? snoozingTimeMin = null,
            DateTime? snoozingTimeMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string KitchenStatus = null,
            string storeBrand = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default
        );

        Task<long> GetCountAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            string storeCode = null,
            string storeName = null,
            string employeeCode = null,
            string employeeName = null,
            string orderNo = null,
            string orderType = null,
            string orderTypeName = null,
            DateTime? orderDateTimeMin = null,
            DateTime? orderDateTimeMax = null,
            string orderStatus = null,
            string orderStatusName = null,
            string salesChannelCode = null,
            string salesChannelName = null,
            bool? hasDelivery = null,
            string notes = null,
            string waitingNumber = null,
            bool? isTakeAway = null,
            DateTime? pickingTimeMin = null,
            DateTime? pickingTimeMax = null,
            DateTime? snoozingTimeMin = null,
            DateTime? snoozingTimeMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string KitchenStatus = null,
            string storeBrand = null,
            CancellationToken cancellationToken = default);

        Task<IQueryable<SalesOrder>> GetAsyncWithInclude(Expression<Func<SalesOrder, bool>> predicate, params Expression<Func<SalesOrder, object>>[] includeProperties);
    }
}