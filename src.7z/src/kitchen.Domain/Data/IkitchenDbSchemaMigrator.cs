﻿using System.Threading.Tasks;

namespace kitchen.Data
{
    public interface IkitchenDbSchemaMigrator
    {
        Task MigrateAsync();
    }
}