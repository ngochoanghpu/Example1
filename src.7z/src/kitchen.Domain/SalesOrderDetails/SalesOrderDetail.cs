using System;
using Volo.Abp.Domain.Entities;
using Volo.Abp.Domain.Entities.Auditing;
using Volo.Abp.MultiTenancy;
using JetBrains.Annotations;
using Volo.Abp;
using kitchen.SalesOrders;

namespace kitchen.SalesOrderDetails
{
    public class SalesOrderDetail : FullAuditedAggregateRoot<Guid>, IMultiTenant
    {

        
        public virtual Guid? TenantId { get; set; }
        
        public virtual Guid SalesOrderId { get; set; }
        
        public virtual Guid SalesOrderDetailId { get; set; }
        
        public virtual int SequentiaNumber { get; set; }
        
        [CanBeNull]
        public virtual string BarCode1 { get; set; }
        
        [CanBeNull]
        public virtual string BarCode2 { get; set; }
        
        [CanBeNull]
        public virtual string ItemCode { get; set; }
        
        [CanBeNull]
        public virtual string ProductName { get; set; }
        
        [CanBeNull]
        public virtual string SerialNumber { get; set; }
        
        [CanBeNull]
        public virtual string LotNumber { get; set; }
        
        [CanBeNull]
        public virtual string UOSCode { get; set; }
        
        [CanBeNull]
        public virtual string UOSName { get; set; }
        
        public virtual decimal UOSQuantity { get; set; }
        
        [CanBeNull]
        public virtual string UOMCode { get; set; }
        
        public virtual decimal UOMQuantity { get; set; }
        
        [CanBeNull]
        public virtual string Notes { get; set; }
        
        public virtual bool IsChild { get; set; }
        
        public virtual int IndexNumber { get; set; }
        
        [CanBeNull]
        public virtual string SalesOrderDetailStaus { get; set; }
        
        public virtual bool IsOptional { get; set; }
        
        public virtual DateTime? RecievedDateTime { get; set; }
        
        public virtual Guid? PerformedById { get; set; }
        
        [CanBeNull]
        public virtual string PerformedByName { get; set; }

        [CanBeNull]
        public virtual string ProductShortName { get; set; }

        [CanBeNull]
        public virtual string ProcductGroupName { get; set; }

        public virtual int ProducingTime { get; set; }

        public virtual int ServingTime { get; set; }

        public virtual bool MaintainQuantityRatio { get; set; }

        public virtual Guid? OriginalId { get; set; }

        public virtual DateTime? PerformedDateTime { get; set; }
        
        [CanBeNull]
        public virtual string KitchenStatus { get; set; }

        public virtual SalesOrder SalesOrder { get; set; }

        public virtual string ProductGroupCode { get; set; }

        public virtual int ProcductGroupIndex { get; set; }

        public SalesOrderDetail()
        {

        }

        public SalesOrderDetail(Guid id, Guid salesOrderId, Guid salesOrderDetailId, int sequentiaNumber, string barCode1, string barCode2, string itemCode, string productName, string serialNumber, string lotNumber, string uOSCode, string uOSName, decimal uOSQuantity, string uOMCode, decimal uOMQuantity, string notes, bool isChild, int indexNumber, string salesOrderDetailStaus, bool isOptional, string performedByName, string kitchenStatus, DateTime? recievedDateTime = null, Guid? performedById = null, DateTime? performedDateTime = null, string productGroupCode = null, int procductGroupIndex = 1,
                                string productShortName = "", string procductGroupName = "", 
                                int producingTime = 0, int servingTime = 0, 
                                bool maintainQuantityRatio = false, Guid? originalId = null)
        {
            ProductShortName = productShortName;
            ProcductGroupName = procductGroupName;
            ProducingTime = producingTime;
            ServingTime = servingTime;
            MaintainQuantityRatio = maintainQuantityRatio;
            OriginalId = originalId;

            Id = id;
            SalesOrderId = salesOrderId;
            SalesOrderDetailId = salesOrderDetailId;
            SequentiaNumber = sequentiaNumber;
            BarCode1 = barCode1;
            BarCode2 = barCode2;
            ItemCode = itemCode;
            ProductName = productName;
            SerialNumber = serialNumber;
            LotNumber = lotNumber;
            UOSCode = uOSCode;
            UOSName = uOSName;
            UOSQuantity = uOSQuantity;
            UOMCode = uOMCode;
            UOMQuantity = uOMQuantity;
            Notes = notes;
            IsChild = isChild;
            IndexNumber = indexNumber;
            SalesOrderDetailStaus = salesOrderDetailStaus;
            IsOptional = isOptional;
            PerformedByName = performedByName;
            KitchenStatus = kitchenStatus;
            RecievedDateTime = recievedDateTime;
            PerformedById = performedById;
            PerformedDateTime = performedDateTime;
            ProductGroupCode = productGroupCode;
            ProcductGroupIndex = procductGroupIndex;
        }
    }
}