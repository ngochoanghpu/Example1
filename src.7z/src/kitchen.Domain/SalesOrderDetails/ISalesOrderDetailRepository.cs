using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Volo.Abp.Domain.Repositories;

namespace kitchen.SalesOrderDetails
{
    public interface ISalesOrderDetailRepository : IRepository<SalesOrderDetail, Guid>
    {
        Task<List<SalesOrderDetail>> GetListAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            int? sequentiaNumberMin = null,
            int? sequentiaNumberMax = null,
            string barCode1 = null,
            string barCode2 = null,
            string itemCode = null,
            string productName = null,
            string serialNumber = null,
            string lotNumber = null,
            string uOSCode = null,
            string uOSName = null,
            decimal? uOSQuantityMin = null,
            decimal? uOSQuantityMax = null,
            string uOMCode = null,
            decimal? uOMQuantityMin = null,
            decimal? uOMQuantityMax = null,
            string notes = null,
            bool? isChild = null,
            int? indexNumberMin = null,
            int? indexNumberMax = null,
            string salesOrderDetailStaus = null,
            bool? isOptional = null,
            string productHierarchyCode = null,
            string productHierarchyName = null,
            int? productHierarchyOrderMin = null,
            int? productHierarchyOrderMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string kitchenStatus = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default
        );

        Task<long> GetCountAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            int? sequentiaNumberMin = null,
            int? sequentiaNumberMax = null,
            string barCode1 = null,
            string barCode2 = null,
            string itemCode = null,
            string productName = null,
            string serialNumber = null,
            string lotNumber = null,
            string uOSCode = null,
            string uOSName = null,
            decimal? uOSQuantityMin = null,
            decimal? uOSQuantityMax = null,
            string uOMCode = null,
            decimal? uOMQuantityMin = null,
            decimal? uOMQuantityMax = null,
            string notes = null,
            bool? isChild = null,
            int? indexNumberMin = null,
            int? indexNumberMax = null,
            string salesOrderDetailStaus = null,
            bool? isOptional = null,
            string productHierarchyCode = null,
            string productHierarchyName = null,
            int? productHierarchyOrderMin = null,
            int? productHierarchyOrderMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string kitchenStatus = null,
            CancellationToken cancellationToken = default);
    }
}