﻿namespace kitchen.Settings
{
    public static class kitchenSettings
    {
        private const string Prefix = "kitchen";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}