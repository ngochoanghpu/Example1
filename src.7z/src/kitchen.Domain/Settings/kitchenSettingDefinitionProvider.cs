﻿using Volo.Abp.Settings;

namespace kitchen.Settings
{
    public class kitchenSettingDefinitionProvider : SettingDefinitionProvider
    {
        public override void Define(ISettingDefinitionContext context)
        {
            //Define your own settings here. Example:
            //context.Add(new SettingDefinition(kitchenSettings.MySetting1));
        }
    }
}
