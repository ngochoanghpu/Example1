using System;
using Volo.Abp.Domain.Entities;
using Volo.Abp.Domain.Entities.Auditing;
using Volo.Abp.MultiTenancy;
using JetBrains.Annotations;
using Volo.Abp;

namespace kitchen.SalesOrderStatusHistories
{
    public class SalesOrderStatusHistory : FullAuditedAggregateRoot<Guid>, IMultiTenant
    {
        public virtual Guid? TenantId { get; set; }
        
        public virtual Guid? SalesOrderId { get; set; }
        
        [CanBeNull]
        public virtual string Status { get; set; }
        
        [CanBeNull]
        public virtual string KitchenStatus { get; set; }
        
        [CanBeNull]
        public virtual string Notes { get; set; }
        
        public virtual Guid? ChangedById { get; set; }
        
        [CanBeNull]
        public virtual string ChangedByUserName { get; set; }
        
        [CanBeNull]
        public virtual string ChangedByDateTime { get; set; }



        public SalesOrderStatusHistory()
        {

        }

        public SalesOrderStatusHistory(Guid id, Guid? tenantId,  string status, string kitchenStatus, string notes, Guid? changedById, string changedByUserName, string changedByDateTime, Guid? salesOrderId = null)
        {
            Id = id;
            TenantId = tenantId;
            Status = status;
            KitchenStatus = kitchenStatus;
            Notes = notes;
            ChangedById = changedById;
            ChangedByUserName = changedByUserName;
            ChangedByDateTime = changedByDateTime;
            SalesOrderId = salesOrderId;

        }
    }
}