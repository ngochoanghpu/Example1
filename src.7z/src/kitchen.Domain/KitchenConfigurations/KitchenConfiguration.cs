using System;
using Volo.Abp.Domain.Entities;
using Volo.Abp.Domain.Entities.Auditing;
using Volo.Abp.MultiTenancy;
using JetBrains.Annotations;
using Volo.Abp;

namespace kitchen.KitchenConfigurations
{
    public class KitchenConfiguration : FullAuditedAggregateRoot<Guid>, IMultiTenant
    {   
        public virtual Guid? TenantId { get; set; }
        
        [NotNull]
        public virtual string StoreCode { get; set; }
        
        public virtual int DisplayColumns { get; set; }
        
        public virtual int BillNoDisplayLength { get; set; }
        
        public virtual bool AutoPrintBill { get; set; }
        
        [CanBeNull]
        public virtual string ItemCheckBgColor { get; set; }
        
        [CanBeNull]
        public virtual string ItemCheckTextColor { get; set; }
        
        [CanBeNull]
        public virtual string BillCancelledBgColor { get; set; }
        
        public virtual int Threshold1Value { get; set; }
        
        [CanBeNull]
        public virtual string UnderThreshold1BgColor { get; set; }
        
        [CanBeNull]
        public virtual string UnderThreshold1TextColor { get; set; }
        
        public virtual int Threshold2Value { get; set; }
        
        [CanBeNull]
        public virtual string UnderThreshold2BgColor { get; set; }
        
        [CanBeNull]
        public virtual string UnderThreshold2TextColor { get; set; }
        
        [CanBeNull]
        public virtual string OverThreshold3BgColor { get; set; }
        
        [CanBeNull]
        public virtual string OverThreshold3TextColor { get; set; }

        [CanBeNull]
        public virtual string ItemLockBgColor { get; set; }

        [CanBeNull]
        public virtual string ItemLockTextColor { get; set; }



        public KitchenConfiguration()
        {

        }

        public KitchenConfiguration(Guid id, string storeCode, int displayColumns, int billNoDisplayLength, bool autoPrintBill, string itemCheckBgColor, string itemCheckTextColor, string billCancelledBgColor, int threshold1Value, string underThreshold1BgColor, string underThreshold1TextColor, string underThreshold2BgColor, string underThreshold2TextColor, string overThreshold3BgColor, string overThreshold3TextColor, int threshold2Value, string itemLockBgColor, string itemLockTextColor)
        {
           Id = id;
            Check.NotNull(storeCode, nameof(storeCode));
            Check.NotNull(itemCheckBgColor, nameof(itemCheckBgColor));
            Check.NotNull(itemCheckTextColor, nameof(itemCheckTextColor));
            Check.NotNull(billCancelledBgColor, nameof(billCancelledBgColor));
            Check.NotNull(underThreshold1BgColor, nameof(underThreshold1BgColor));
            Check.NotNull(underThreshold1TextColor, nameof(underThreshold1TextColor));
            Check.NotNull(underThreshold2BgColor, nameof(underThreshold2BgColor));
            Check.NotNull(underThreshold2TextColor, nameof(underThreshold2TextColor));
            Check.NotNull(overThreshold3BgColor, nameof(overThreshold3BgColor));
            Check.NotNull(overThreshold3TextColor, nameof(overThreshold3TextColor));
            Check.NotNull(overThreshold3BgColor, nameof(overThreshold3BgColor));
            Check.NotNull(itemLockBgColor, nameof(itemLockBgColor));
            Check.NotNull(itemLockTextColor, nameof(itemLockTextColor));
            StoreCode = storeCode;
            DisplayColumns = displayColumns;
            BillNoDisplayLength = billNoDisplayLength;
            AutoPrintBill = autoPrintBill;
            ItemCheckBgColor = itemCheckBgColor;
            ItemCheckTextColor = itemCheckTextColor;
            BillCancelledBgColor = billCancelledBgColor;
            Threshold1Value = threshold1Value;
            UnderThreshold1BgColor = underThreshold1BgColor;
            UnderThreshold1TextColor = underThreshold1TextColor;
            UnderThreshold2BgColor = underThreshold2BgColor;
            UnderThreshold2TextColor = underThreshold2TextColor;
            OverThreshold3BgColor = overThreshold3BgColor;
            OverThreshold3TextColor = overThreshold3TextColor;
            Threshold2Value = threshold2Value;
            ItemLockBgColor = itemLockBgColor;
            ItemLockTextColor = itemLockTextColor;
        }
    }
}