using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Volo.Abp.Domain.Repositories;

namespace kitchen.KitchenConfigurations
{
    public interface IKitchenConfigurationRepository : IRepository<KitchenConfiguration, Guid>
    {
        Task<List<KitchenConfiguration>> GetListAsync(
            string filterText = null,
            string storeCode = null,
            int? displayColumnsMin = null,
            int? displayColumnsMax = null,
            int? billNoDisplayLengthMin = null,
            int? billNoDisplayLengthMax = null,
            bool? autoPrintBill = null,
            string itemCheckBgColor = null,
            string ItemCheckTextColor = null,
            string billCancelledBgColor = null,
            int? threshold1ValueMin = null,
            int? threshold1ValueMax = null,
            string underThreshold1BgColor = null,
            string underThreshold1TextColor = null,
            int? threshold2ValueMin = null,
            int? threshold2ValueMax = null,
            string underThreshold2BgColor = null,
            string underThreshold2TextColor = null,
            string overThreshold3BgColor = null,
            string overThreshold3TextColor = null,
            string itemLockBgColor = null,
            string itemLockTextColor = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default
        );

        Task<long> GetCountAsync(
            string filterText = null,
            string storeCode = null,
            int? displayColumnsMin = null,
            int? displayColumnsMax = null,
            int? billNoDisplayLengthMin = null,
            int? billNoDisplayLengthMax = null,
            bool? autoPrintBill = null,
            string itemCheckBgColor = null,
            string ItemCheckTextColor = null,
            string billCancelledBgColor = null,
            int? threshold1ValueMin = null,
            int? threshold1ValueMax = null,
            string underThreshold1BgColor = null,
            string underThreshold1TextColor = null,
            int? threshold2ValueMin = null,
            int? threshold2ValueMax = null,
            string underThreshold2BgColor = null,
            string underThreshold2TextColor = null,
            string overThreshold3BgColor = null,
            string overThreshold3TextColor = null,
            string itemLockBgColor = null,
            string itemLockTextColor = null,
            CancellationToken cancellationToken = default);
    }
}