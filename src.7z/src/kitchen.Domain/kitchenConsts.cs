﻿using System;

namespace kitchen
{
    public static class kitchenConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
