using kitchen.SalesOrderDetailStatusHistories;
using kitchen.SalesOrderStatusHistories;
using kitchen.SalesOrderDetails;
using System;
using kitchen.Shared;
using kitchen.SalesOrders;
using kitchen.KitchenConfigurations;
using AutoMapper;

namespace kitchen
{
    public class kitchenApplicationAutoMapperProfile : Profile
    {
        public kitchenApplicationAutoMapperProfile()
        {
            /* You can configure your AutoMapper mapping configuration here.
             * Alternatively, you can split your mapping configurations
             * into multiple profile classes for a better organization. */
            CreateMap<SalesOrderCreateDto, SalesOrder>();
            CreateMap<SalesOrder, SalesOrderDto>();
            CreateMap<SalesOrderUpdateDto, SalesOrder>();
            CreateMap<SalesOrderDetailCreateDto, SalesOrderDetail>();
            CreateMap<SalesOrderDetail, SalesOrderDetailDto>();
            CreateMap<SalesOrderDetailUpdateDto, SalesOrderDetail>();
            CreateMap<KitchenConfigurationCreateDto, KitchenConfiguration>();
            CreateMap<KitchenConfiguration, KitchenConfigurationDto>();
            CreateMap<KitchenConfigurationUpdateDto, KitchenConfiguration>();

            CreateMap<SalesOrderDto, SalesOrder>();
            CreateMap<SalesOrderStatusHistoryCreateDto, SalesOrderStatusHistory>();
            CreateMap<SalesOrderStatusHistory, SalesOrderStatusHistoryDto>();
            CreateMap<SalesOrderStatusHistoryUpdateDto, SalesOrderStatusHistory>();
            CreateMap<SalesOrderDetailStatusHistoryCreateDto, SalesOrderDetailStatusHistory>();
            CreateMap<SalesOrderDetailStatusHistory, SalesOrderDetailStatusHistoryDto>();
            CreateMap<SalesOrderDetailStatusHistoryUpdateDto, SalesOrderDetailStatusHistory>();
        }
    }
}