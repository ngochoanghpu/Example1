using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using kitchen.Permissions;
using kitchen.KitchenConfigurations;

namespace kitchen.KitchenConfigurations
{
    [Authorize(kitchenPermissions.KitchenConfigurations.Default)]
    public class KitchenConfigurationAppService : ApplicationService, IKitchenConfigurationAppService
    {
        private readonly IKitchenConfigurationRepository _kitchenConfigurationRepository;

        public KitchenConfigurationAppService(IKitchenConfigurationRepository kitchenConfigurationRepository)
        {
            _kitchenConfigurationRepository = kitchenConfigurationRepository;

        }

        public virtual async Task<KitchenConfigShortDto> GetInforConfig(Guid? id = null)
        {
            if(id == null || id == Guid.Empty)
            {
                return null;
            }

            var configDto = _kitchenConfigurationRepository.Where(k => k.Id == id)
                                                              .Select(c => new KitchenConfigShortDto
                                                              {
                                                                  BillNoDisplayLength = c.BillNoDisplayLength,
                                                                  DisplayColumns = c.DisplayColumns,
                                                                  AutoPrintBill = c.AutoPrintBill,
                                                                  ItemCheckBgColor = c.ItemCheckBgColor,
                                                                  ItemCheckTextColor = c.ItemCheckTextColor,
                                                                  BillCancelledBgColor = c.BillCancelledBgColor,
                                                                  Threshold1Value = c.Threshold1Value,
                                                                  UnderThreshold1BgColor = c.UnderThreshold1BgColor,
                                                                  UnderThreshold1TextColor = c.UnderThreshold1TextColor,
                                                                  Threshold2Value = c.Threshold2Value,
                                                                  UnderThreshold2BgColor = c.UnderThreshold2BgColor,
                                                                  UnderThreshold2TextColor = c.UnderThreshold2TextColor,
                                                                  OverThreshold3BgColor = c.OverThreshold3BgColor,
                                                                  OverThreshold3TextColor = c.OverThreshold3TextColor,
                                                                  ItemLockBgColor = c.ItemLockBgColor,
                                                                  ItemLockTextColor = c.ItemLockTextColor
                                                              }).FirstOrDefault();

            if(configDto == null)
            {
                return null;
            }

            return await Task.Run(() => configDto);
        }

        public virtual async Task<PagedResultDto<KitchenConfigurationDto>> GetListAsync(GetKitchenConfigurationsInput input)
        {
            var totalCount = await _kitchenConfigurationRepository.GetCountAsync(input.FilterText, input.StoreCode, input.DisplayColumnsMin, input.DisplayColumnsMax, input.BillNoDisplayLengthMin, input.BillNoDisplayLengthMax, input.AutoPrintBill, input.ItemCheckBgColor, input.ItemCheckTextColor, input.BillCancelledBgColor, input.Threshold1ValueMin, input.Threshold1ValueMax, input.UnderThreshold1BgColor, input.UnderThreshold1TextColor, input.Threshold2ValueMin, input.Threshold2ValueMax, input.UnderThreshold2BgColor, input.UnderThreshold2TextColor, input.OverThreshold3BgColor, input.OverThreshold3TextColor, input.ItemLockBgColor, input.ItemLockTextColor);
            var items = await _kitchenConfigurationRepository.GetListAsync(input.FilterText, input.StoreCode, input.DisplayColumnsMin, input.DisplayColumnsMax, input.BillNoDisplayLengthMin, input.BillNoDisplayLengthMax, input.AutoPrintBill, input.ItemCheckBgColor, input.ItemCheckTextColor, input.BillCancelledBgColor, input.Threshold1ValueMin, input.Threshold1ValueMax, input.UnderThreshold1BgColor, input.UnderThreshold1TextColor, input.Threshold2ValueMin, input.Threshold2ValueMax, input.UnderThreshold2BgColor, input.UnderThreshold2TextColor, input.OverThreshold3BgColor, input.OverThreshold3TextColor, input.ItemLockBgColor, input.ItemLockTextColor, input.Sorting, input.MaxResultCount, input.SkipCount);

            return new PagedResultDto<KitchenConfigurationDto>
            {
                TotalCount = totalCount,
                Items = ObjectMapper.Map<List<KitchenConfiguration>, List<KitchenConfigurationDto>>(items)
            };
        }

        public virtual async Task<KitchenConfigurationDto> GetAsync(Guid id)
        {
            return ObjectMapper.Map<KitchenConfiguration, KitchenConfigurationDto>(await _kitchenConfigurationRepository.GetAsync(id));
        }

        [Authorize(kitchenPermissions.KitchenConfigurations.Delete)]
        public virtual async Task DeleteAsync(Guid id)
        {
            await _kitchenConfigurationRepository.DeleteAsync(id);
        }

        [Authorize(kitchenPermissions.KitchenConfigurations.Create)]
        public virtual async Task<KitchenConfigurationDto> CreateAsync(KitchenConfigurationCreateDto input)
        {
            var newKitchenConfiguration = ObjectMapper.Map<KitchenConfigurationCreateDto, KitchenConfiguration>(input);
            newKitchenConfiguration.TenantId = CurrentTenant.Id;
            var kitchenConfiguration = await _kitchenConfigurationRepository.InsertAsync(newKitchenConfiguration);
            await CurrentUnitOfWork.SaveChangesAsync();
            return ObjectMapper.Map<KitchenConfiguration, KitchenConfigurationDto>(kitchenConfiguration);
        }

        [Authorize(kitchenPermissions.KitchenConfigurations.Edit)]
        public virtual async Task<KitchenConfigurationDto> UpdateAsync(Guid id, KitchenConfigurationUpdateDto input)
        {
            var kitchenConfiguration = await _kitchenConfigurationRepository.GetAsync(id);
            ObjectMapper.Map(input, kitchenConfiguration);
            var updatedKitchenConfiguration = await _kitchenConfigurationRepository.UpdateAsync(kitchenConfiguration);
            return ObjectMapper.Map<KitchenConfiguration, KitchenConfigurationDto>(updatedKitchenConfiguration);
        }
    }
}