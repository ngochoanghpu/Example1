﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq.Dynamic.Core;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using kitchen.Shared;
using static kitchen.Shared.SalesOrderConsts;
using kitchen.SalesOrderDetails;
using kitchen.ServiceBusRabbitMQ.Service;
using kitchen.ServiceBusRabbitMQ.IService;
using Microsoft.AspNetCore.SignalR;
using kitchen.KitchenConfigurations;
using kitchen.SalesOrderStatusHistories;
using kitchen.SalesOrderDetailStatusHistories;
using Kitchen.ServiceBusRabbitMQ.Const;
using Kitchen.ServiceBusRabbitMQ.Service;
using Microsoft.AspNetCore.Mvc;

namespace kitchen.SalesOrders
{
    //[Authorize(kitchenPermissions.SalesOrders.Default)]
    public class SalesOrderAppService : ApplicationService, ISalesOrderAppService
    {
        private readonly ISalesOrderRepository _salesOrderRepository;
        private readonly ISalesOrderDetailRepository _salesOrderDetailRepository;
        private readonly ISalesOrderStatusHistoryRepository _salesOrderStatusHisRepository;
        private readonly ISalesOrderDetailStatusHistoryRepository _salesOrderDetailStatusRepository;
        private readonly ISendRequestService _sendRequestService;
        private readonly IKitchenConfigurationAppService _kitchenConfigurationAppService;
        private readonly IHubContext<SignalR_SO_Hub> _hubContext;

        public SalesOrderAppService(ISalesOrderRepository salesOrderRepository, 
                                    ISalesOrderDetailRepository salesOrderDetailRepository,
                                    ISalesOrderStatusHistoryRepository salesOrderStatusHisRepository,
                                    ISalesOrderDetailStatusHistoryRepository salesOrderDetailStatusRepository,
                                    IKitchenConfigurationAppService kitchenConfigurationAppService,
                                    IHubContext<SignalR_SO_Hub> hubContext,
                                    ISendRequestService sendRequestService)
        {
            _kitchenConfigurationAppService = kitchenConfigurationAppService;
            _salesOrderRepository = salesOrderRepository;
            _salesOrderDetailRepository = salesOrderDetailRepository;
            _salesOrderStatusHisRepository = salesOrderStatusHisRepository;
            _salesOrderDetailStatusRepository = salesOrderDetailStatusRepository;
            _sendRequestService = sendRequestService;
            _hubContext = hubContext;
        }

        public virtual async Task<PagedResultDto<SalesOrderDto>> GetListAsync(GetSalesOrdersInput input)
        {
            var totalCount = await _salesOrderRepository.GetCountAsync(input.FilterText, input.SalesOrderId, input.StoreCode, input.StoreName, input.EmployeeCode, input.EmployeeName, input.OrderNo, input.OrderType, input.OrderTypeName, input.OrderDateTimeMin, input.OrderDateTimeMax, input.OrderStatus, input.OrderStatusName, input.SalesChannelCode, input.SalesChannelName, input.HasDelivery, input.Notes, input.WaitingNumber, input.IsTakeAway, input.PickingTimeMin, input.PickingTimeMax, input.SnoozingTimeMin, input.SnoozingTimeMax, input.RecievedDateTimeMin, input.RecievedDateTimeMax, input.PerformedById, input.PerformedByName, input.PerformedDateTimeMin, input.PerformedDateTimeMax, input.KitchenStatus, input.StoreBrand);
            var items = await _salesOrderRepository.GetListAsync(input.FilterText, input.SalesOrderId, input.StoreCode, input.StoreName, input.EmployeeCode, input.EmployeeName, input.OrderNo, input.OrderType, input.OrderTypeName, input.OrderDateTimeMin, input.OrderDateTimeMax, input.OrderStatus, input.OrderStatusName, input.SalesChannelCode, input.SalesChannelName, input.HasDelivery, input.Notes, input.WaitingNumber, input.IsTakeAway, input.PickingTimeMin, input.PickingTimeMax, input.SnoozingTimeMin, input.SnoozingTimeMax, input.RecievedDateTimeMin, input.RecievedDateTimeMax, input.PerformedById, input.PerformedByName, input.PerformedDateTimeMin, input.PerformedDateTimeMax, input.KitchenStatus, input.StoreBrand, input.Sorting, input.MaxResultCount, input.SkipCount);

            return new PagedResultDto<SalesOrderDto>
            {
                TotalCount = totalCount,
                Items = ObjectMapper.Map<List<SalesOrder>, List<SalesOrderDto>>(items)
            };
        }

        public virtual async Task<SalesOrderDto> GetAsync(Guid id)
        {
            return ObjectMapper.Map<SalesOrder, SalesOrderDto>(await _salesOrderRepository.GetAsync(id));
        }

        //[Authorize(kitchenPermissions.SalesOrders.Delete)]
        public virtual async Task DeleteAsync(Guid id)
        {
            await _salesOrderRepository.DeleteAsync(id);
        }

       // [Authorize(kitchenPermissions.SalesOrders.Create)]
        public virtual async Task<SalesOrderDto> CreateAsync(SalesOrderCreateDto input)
        {
            input.RecievedDateTime = DateTime.Now;
            var newSalesOrder = ObjectMapper.Map<SalesOrderCreateDto, SalesOrder>(input);
            if(newSalesOrder.TenantId == null)
                newSalesOrder.TenantId = CurrentTenant.Id;
            var salesOrder = await _salesOrderRepository.InsertAsync(newSalesOrder);
            try
            {
                await CurrentUnitOfWork.SaveChangesAsync();
            }catch(Exception ex)
            {
                throw (ex);
            }
            
            return ObjectMapper.Map<SalesOrder, SalesOrderDto>(salesOrder);
        }

        //[Authorize(kitchenPermissions.SalesOrders.Edit)]
        public virtual async Task<SalesOrderDto> UpdateAsync(Guid id, SalesOrderUpdateDto input)
        {
            var salesOrder = await _salesOrderRepository.GetAsync(id);
            ObjectMapper.Map(input, salesOrder);
            var updatedSalesOrder = await _salesOrderRepository.UpdateAsync(salesOrder);
            return ObjectMapper.Map<SalesOrder, SalesOrderDto>(updatedSalesOrder);
        }

        public async Task<ModifiedResponseDto<Guid>> UpdateChangeStatusAsync(Guid id, string status)
        {
            var response = new ModifiedResponseDto<Guid>();

            var so = await UpdateKitchenStatus(id, status);

            if (so == null)
            {
                response.Message = "FailToUpdateSO";
                return response;
            }

            //Pulish message to queue để POS biết chuyển status từ “Gửi bếp bar” sang “Tiếp thực”
            if (status == KitchenStatus.Completed.ToString())
            {
                var message = new ConfirmOrderDto
                {
                    SalesOrderId = id,
                    OrderStatus = status.ToLower()
                };
                _sendRequestService.SendRequest(message, "kitchen.exchange", "kit.so.itemstatuschange").Wait();
            }
            else if(status == KitchenStatus.Cancelled.ToString())
            {
                Utf8JsonRabbitMqSerializer utf8JsonRabbitMq = new Utf8JsonRabbitMqSerializer();
                var data = new { SaleOrderId = id, OrderStatus = status };
                await _hubContext.Clients.All.SendAsync("SendBill", utf8JsonRabbitMq.SerializeToJson(data));
            }

            response.IsSuccess = true;
            return response;
        }

        public Task<List<SalesOrderListDto>> GetBillsTeaMilk(string storeCode)
        {
            var result = new List<SalesOrderListDto>();

            var kitchenConfig = _kitchenConfigurationAppService.GetInforConfig(Guid.Parse(KitchenConfigurationConsts.TeaMilkId)).Result;

            var cancelledStatus = KitchenStatus.Cancelled.ToString();
            var completedStatus = KitchenStatus.Completed.ToString();
            var cancelOrderStatus = OrderStatus.Cancelled.ToString();

            var saleOrders = _salesOrderRepository.GetAsyncWithInclude(s => s.OrderStatus != cancelOrderStatus &&
                                                                            s.StoreCode == storeCode &&
                                                                            s.KitchenStatus != cancelledStatus && s.KitchenStatus != completedStatus,
                                                                            s => s.SalesOrderDetails).Result
                                                                            .OrderBy(x => x.RecievedDateTime)
                                                                            .ToList();

            if (saleOrders.Any())
            {
                foreach (var data in saleOrders)
                {
                    var products = data.SalesOrderDetails.Where(sod => sod.KitchenStatus != cancelledStatus && sod.KitchenStatus != completedStatus)
                                                         .Select(sod => new SaleOrderDetailShortDto
                                                         {
                                                             SaleOrderDetailId = sod.Id,
                                                             Name = sod.ProductName,
                                                             Quantity = sod.UOSQuantity,
                                                             Notes = sod.Notes,
                                                             IsChild = sod.IsChild,
                                                             IsOptional = sod.IsOptional,
                                                             ProductGroup = sod.ProductGroupCode,
                                                             SequentiaNumber = sod.SequentiaNumber
                                                         }).OrderBy(sod => sod.SequentiaNumber)
                                                         .ToList();

                    var savors = products.Where(s => s.IsChild && s.IsOptional).ToList();
                    var toppingsInBeverage = products.Where(t => t.IsChild && !t.IsOptional).ToList(); //topping đi kèm đồ uống
                    var producItems = products.Where(t => !t.IsChild).ToList();

                    //Get danh sách đồ uống
                    var beverages = producItems.Where(p => p.ProductGroup == ProductGroup.PG_BEVERAGE.ToString())
                                               .Select(p => new SaleOrderDetailKitchenDto
                                               {
                                                   SaleOrderDetailId = p.SaleOrderDetailId,
                                                   Name = p.Name,
                                                   Quantity = p.Quantity,
                                                   Notes = p.Notes,
                                                   ProductGroupCode = p.ProductGroup,
                                                   Savor = savors.Select(s => s.Name).ToList(),
                                                   Toppings = toppingsInBeverage.Select(t => new Topping
                                                   {
                                                       Name = t.Name,
                                                       Quantity = t.Quantity
                                                   }).ToList()
                                               }).ToList();

                    //Get danh sách bánh
                    var cakes = producItems.Where(p => p.ProductGroup == ProductGroup.PG_CAKE.ToString())
                                           .Select(p => new SaleOrderDetailKitchenDto
                                           {
                                               SaleOrderDetailId = p.SaleOrderDetailId,
                                               Name = p.Name,
                                               Quantity = p.Quantity,
                                               Notes = p.Notes,
                                               ProductGroupCode = p.ProductGroup
                                           }).ToList();

                    //Get danh sách topping
                    var toppings = producItems.Where(p => p.ProductGroup == ProductGroup.PG_TOPPING.ToString())
                                              .Select(p => new SaleOrderDetailKitchenDto
                                              {
                                                  SaleOrderDetailId = p.SaleOrderDetailId,
                                                  Name = p.Name,
                                                  Quantity = p.Quantity,
                                                  Notes = p.Notes,
                                                  ProductGroupCode = p.ProductGroup
                                              }).ToList();

                    var kitchenData = new SalesOrderListDto()
                    {
                        SaleOrderId = data.Id,
                        SaleOrderNumber = !string.IsNullOrEmpty(data.OrderNo) ? data.OrderNo.Substring(data.OrderNo.Length - kitchenConfig.BillNoDisplayLength) : "",
                        WaitingNumber = data.WaitingNumber,
                        Notes = data.Notes,
                        TotalQuantityBeverage = beverages.Sum(b => b.Quantity),
                        TotalQuantityCake = cakes.Sum(c => c.Quantity),
                        TotalQuantityTopping = toppings.Sum(t => t.Quantity),
                        IsDelivery = data.HasDelivery,
                        RecievedDateTime = data.RecievedDateTime.HasValue ? data.RecievedDateTime.Value : DateTime.Now,
                        Beverages = beverages,
                        Cakes = cakes,
                        Toppings = toppings,
                        Configuration = kitchenConfig
                    };

                    result.Add(kitchenData);
                }
            }
            else
            {
                result.Add(new SalesOrderListDto
                {
                    Configuration = kitchenConfig,
                    Beverages = new List<SaleOrderDetailKitchenDto>(),
                    Cakes = new List<SaleOrderDetailKitchenDto>(),
                    Toppings = new List<SaleOrderDetailKitchenDto>(),
                });
            }

            return Task.Run(() => result);
        }

        public Task<List<SalesOrderListDto>> GetBillsRestaurant(string storeCode, string productGroupCodesString = "")
        {
            var productGroupCodes = productGroupCodesString.Split(",");
            var result = new List<SalesOrderListDto>();

            var kitchenConfig = _kitchenConfigurationAppService.GetInforConfig(Guid.Parse(KitchenConfigurationConsts.RestaurantId)).Result;

            var cancelledStatus = KitchenStatus.Cancelled.ToString();
            var completedStatus = KitchenStatus.Completed.ToString();
            var cancelOrderStatus = OrderStatus.Cancelled.ToString();

            var saleOrders = _salesOrderRepository.GetAsyncWithInclude(s => s.OrderStatus != cancelOrderStatus &&
                                                                            s.StoreCode == storeCode &&
                                                                            s.KitchenStatus != cancelledStatus && s.KitchenStatus != completedStatus,
                                                                            s => s.SalesOrderDetails).Result
                                                                            .OrderBy(x => x.RecievedDateTime)
                                                                            .ToList();

            if (saleOrders.Any())
            {
                foreach (var data in saleOrders)
                {
                    //TODO: Not filter productHierarchyCode
                    var products = data.SalesOrderDetails.Where(sod => productGroupCodes.Contains(sod.ProductGroupCode) &&
                                                                      sod.SalesOrderDetailStaus != cancelledStatus && sod.SalesOrderDetailStaus != completedStatus &&
                                                                      sod.KitchenStatus != cancelledStatus && sod.KitchenStatus != completedStatus
                                                               )
                                                         .Select(sod => new SaleOrderDetailShortDto
                                                         {
                                                             SaleOrderDetailId = sod.Id,
                                                             Name = sod.ProductName,
                                                             Quantity = sod.UOSQuantity,
                                                             Notes = sod.Notes,
                                                             ProductGroup = sod.ProductGroupCode,
                                                             IsChild = sod.IsChild,
                                                             IsOptional = sod.IsOptional,
                                                             SequentiaNumber = sod.SequentiaNumber
                                                         }).OrderBy(sod => sod.SequentiaNumber)
                                                         .ToList();

                    var savors = products.Where(s => s.IsChild && s.IsOptional).ToList();
                    var toppingsInBeverage = products.Where(t => t.IsChild && !t.IsOptional).ToList(); //topping đi kèm món ăn
                    var producItems = products.Where(t => !t.IsChild).ToList();

                    //Get danh sách món ăn
                    var beverages = producItems.Select(p => new SaleOrderDetailKitchenDto
                    {
                        SaleOrderDetailId = p.SaleOrderDetailId,
                        Name = p.Name,
                        Quantity = p.Quantity,
                        Notes = p.Notes,
                        ProductGroupCode = p.ProductGroup,
                        Savor = savors.Select(s => s.Name).ToList(),
                        Toppings = toppingsInBeverage.Select(t => new Topping
                        {
                            Name = t.Name,
                            Quantity = t.Quantity
                        }).ToList()
                    }).ToList();

                    var kitchenData = new SalesOrderListDto()
                    {
                        SaleOrderId = data.Id,
                        SaleOrderNumber = data.OrderNo.Substring(data.OrderNo.Length - kitchenConfig.BillNoDisplayLength),
                        WaitingNumber = data.WaitingNumber,
                        Notes = data.Notes,
                        IsDelivery = data.HasDelivery,
                        RecievedDateTime = data.RecievedDateTime.HasValue ? data.RecievedDateTime.Value : DateTime.Now,
                        Beverages = beverages,
                        Cakes = new List<SaleOrderDetailKitchenDto>(),
                        Toppings = new List<SaleOrderDetailKitchenDto>(),
                        Configuration = kitchenConfig
                    };

                    result.Add(kitchenData);
                }
            }
            else
            {
                result.Add(new SalesOrderListDto
                {
                    Configuration = kitchenConfig,
                    Beverages = new List<SaleOrderDetailKitchenDto>(),
                    Cakes = new List<SaleOrderDetailKitchenDto>(),
                    Toppings = new List<SaleOrderDetailKitchenDto>()
                });
            }

            return Task.Run(() => result);
        }

        #region Private methods
        private async Task<SalesOrder> UpdateKitchenStatus(Guid id, string status)
        {
            var saleOrderEntity = (await _salesOrderRepository.GetAsyncWithInclude(s => s.Id == id, s => s.SalesOrderDetails)).FirstOrDefault();
            if (saleOrderEntity != null)
            {
                if(status == KitchenStatus.Completed.ToString()) //Case complete bill from kitchen
                {
                    saleOrderEntity.KitchenStatus = status;
                    saleOrderEntity.PerformedDateTime = DateTime.UtcNow;
                    saleOrderEntity.LastModificationTime = DateTime.UtcNow;
                    saleOrderEntity.LastModifierId = CurrentUser.Id;

                    saleOrderEntity.SalesOrderDetails.ToList().ForEach(sod =>
                    {
                        sod.KitchenStatus = status;
                        sod.PerformedDateTime = DateTime.UtcNow;
                        sod.LastModificationTime = DateTime.UtcNow;
                        sod.LastModifierId = CurrentUser.Id;
                    });
                }
                else if(status == OrderStatus.Cancelled.ToString()) //Case cancel bill from POS
                {
                    saleOrderEntity.OrderStatus = status;
                }

                // Save history
                try
                {
                    var saleOrderStatusHistoryEntity = new SalesOrderStatusHistory(
                        Guid.NewGuid(),
                        saleOrderEntity.TenantId,
                        saleOrderEntity.OrderStatus,
                        status,
                        saleOrderEntity.Notes,
                        CurrentUser.Id,
                        CurrentUser.UserName,
                        DateTime.UtcNow.ToString(),
                        saleOrderEntity.Id
                    );

                    await _salesOrderStatusHisRepository.InsertAsync(saleOrderStatusHistoryEntity);
                }
                catch (Exception ex)
                {
                    var message = ex.Message;
                }
            }

            return saleOrderEntity;
        }

        public Task GetSignalR()
        {
            //var data = new
            //{
            //    Id = 1,
            //    Message = "test"
            //};

            //_hubContext.Clients.All.Send2("receiveBill", data);

            return Task.CompletedTask;
        }

        public async Task CreateSaleOrderAsync(SalesOrderDto input)
        {
            try
            {
                Utf8JsonRabbitMqSerializer utf8JsonRabbitMq = new Utf8JsonRabbitMqSerializer();
                //var data = ConvertDataToSaleOrderChefDto(input);
                // Send to front end by signalR
                //await _hubContext.Clients.All.SendBill(utf8JsonRabbitMq.SerializeToJson(input));
                //if (CurrentUser.UserName == "chef1")
                //{
                //    await _hubContext.Clients.All.SendAsync("NoodleDrink", utf8JsonRabbitMq.SerializeToJson(data));
                //}
                //if (CurrentUser.UserName == "chef2")
                //{
                //    await _hubContext.Clients.All.SendAsync("DimsumRoasted", utf8JsonRabbitMq.SerializeToJson(data));
                //}
                //if (CurrentUser.UserName == "chef3")
                //{
                //    await _hubContext.Clients.All.SendAsync("PanSoupPrepared", utf8JsonRabbitMq.SerializeToJson(data));
                //}

                //await _hubContext.Clients.All.SendAsync("SendBillRestaurant", utf8JsonRabbitMq.SerializeToJson(data));

                ConvertDataToSaleOrdeEntity(input);

                //Send bill to client
                var storeBrand = !string.IsNullOrEmpty(input.StoreBrand) && input.StoreBrand.Contains(StoreBrand.RESTAURANT.ToString()) 
                                 ? StoreBrand.RESTAURANT 
                                 : StoreBrand.BEVERAGE;

                var data = ConvertDataToSaleOrderDto(input, storeBrand);
                await _hubContext.Clients.All.SendAsync("SendBill", utf8JsonRabbitMq.SerializeToJson(data));

                var saleOrderId = input.Id == Guid.Empty ? Guid.NewGuid() : input.Id;

                var saleOrderEntity = new SalesOrder(saleOrderId, saleOrderId, input.StoreCode, input.StoreName, "", input.EmployeeName,
                    input.OrderNo, input.OrderType, input.OrderTypeName, DateTime.UtcNow, input.OrderStatus,
                    input.OrderStatusName, input.SalesChannelCode, input.SalesChannelName, input.HasDelivery ?? false, input.Notes,
                    input.WaitingNumber, input.PerformedByName, input.KitchenStatus, null, null, DateTime.Now, null,
                    null, input.StoreBrand);

                var saleOrderDetailEntities = new List<SalesOrderDetail>();
                foreach (var sod in input.SalesOrderDetails)
                {
                    var saleOrderDetailId = sod.Id.HasValue ? sod.Id.Value : Guid.NewGuid();
                    var saleOrderDetailEntity = new SalesOrderDetail(saleOrderDetailId, saleOrderId, Guid.NewGuid(), sod.SequentiaNumber ?? 0, sod.BarCode1,
                        sod.BarCode2, sod.ItemCode, sod.ProductName, sod.SerialNumber, sod.LotNumber, sod.UOSCode,
                        sod.UOSName, sod.UOSQuantity.Value, sod.UOMCode, sod.UOMDeltaQuantity, sod.Notes,
                        sod.IsChild ?? false, sod.IndexNumber ?? 0, sod.SalesOrderDetailStatus, sod.IsOptional ?? false,
                        null, sod.KitchenStatus, null, null, null, sod.ProductGroupCode, sod.ProductGroupIndex ?? 0,
                        sod.ProductShortName, sod.ProcductGroupName, sod.ProducingTime ?? 0, sod.ServingTime ?? 0, sod.MaintainQuantityRatio ?? false, sod.OriginalId);

                    saleOrderDetailEntities.Add(saleOrderDetailEntity);
                }

                if (saleOrderDetailEntities.Any())
                {
                    saleOrderEntity.SalesOrderDetails = saleOrderDetailEntities;
                }

                await _salesOrderRepository.InsertAsync(saleOrderEntity);
                await CurrentUnitOfWork.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                var message = ex.Message;
            }
            

            //return Task.CompletedTask;
        }

        private async Task<SalesOrderDetail> UpdateOrderDetailStatus(Guid id, string status)
        {
            var saleOrderDetailEntity = await _salesOrderDetailRepository.GetAsync(id);

            if (saleOrderDetailEntity != null)
            {
                saleOrderDetailEntity.SalesOrderDetailStaus = status;
                
                try
                {
                    var saleOrderDetailStatusHistoryEntity = new SalesOrderDetailStatusHistory(
                                                      Guid.NewGuid(),
                                                      saleOrderDetailEntity.TenantId,
                                                      status,
                                                      saleOrderDetailEntity.KitchenStatus,
                                                      saleOrderDetailEntity.Notes,
                                                      CurrentUser.Id,
                                                      CurrentUser.UserName,
                                                      DateTime.UtcNow.ToString(),
                                                      saleOrderDetailEntity.SalesOrderId,
                                                      saleOrderDetailEntity.Id
                                                      );

                    await _salesOrderDetailStatusRepository.InsertAsync(saleOrderDetailStatusHistoryEntity);
                }
                catch (Exception ex)
                {
                    var message = ex.Message;
                }
            }

            return saleOrderDetailEntity;
        }

        private SalesOrderListDto ConvertDataToSaleOrderDto(SalesOrderDto salesOrder, StoreBrand storeBrand = StoreBrand.BEVERAGE)
        {
            var products = salesOrder.SalesOrderDetails.Select(sod => new SaleOrderDetailShortDto
            {
                SaleOrderDetailId = sod.Id ?? Guid.NewGuid(),
                Name = sod.ProductName,
                Quantity = sod.UOSQuantity ?? 0,
                Notes = sod.Notes,
                IsChild = sod.IsChild ?? false,
                IsOptional = sod.IsOptional ?? false,
                ProductGroup = sod.ProductGroupCode,
                SequentiaNumber = sod.SequentiaNumber ?? 0
            }).OrderBy(sod => sod.SequentiaNumber)
            .ToList();

            var savors = products.Where(s => s.IsChild && s.IsOptional).ToList();
            var toppingsInBeverage = products.Where(t => t.IsChild && !t.IsOptional).ToList(); //topping đi kèm đồ uống
            var producItems = products.Where(t => !t.IsChild).ToList();

            //Get danh sách đồ uống //TODO
            var beverages = producItems.Where(p => (storeBrand == StoreBrand.BEVERAGE && p.ProductGroup == ProductGroup.PG_BEVERAGE.ToString()) || true)
                                       .Select(p => new SaleOrderDetailKitchenDto
                                       {
                                           SaleOrderDetailId = p.SaleOrderDetailId,
                                           Name = p.Name,
                                           Quantity = p.Quantity,
                                           Notes = p.Notes,
                                           Savor = savors.Select(s => s.Name).ToList(),
                                           ProductGroupCode = p.ProductGroup,
                                           Toppings = toppingsInBeverage.Select(t => new Topping
                                           {
                                               Name = t.Name,
                                               Quantity = t.Quantity
                                           }).ToList()
                                       }).ToList();

            //Get danh sách bánh
            var cakes = producItems.Where(p => storeBrand == StoreBrand.BEVERAGE && p.ProductGroup == ProductGroup.PG_CAKE.ToString())
                                   .Select(p => new SaleOrderDetailKitchenDto
                                   {
                                       SaleOrderDetailId = p.SaleOrderDetailId,
                                       Name = p.Name,
                                       Quantity = p.Quantity,
                                       Notes = p.Notes,
                                       ProductGroupCode = p.ProductGroup
                                   }).ToList();

            //Get danh sách topping
            var toppings = producItems.Where(p => storeBrand == StoreBrand.BEVERAGE && p.ProductGroup == ProductGroup.PG_TOPPING.ToString())
                                      .Select(p => new SaleOrderDetailKitchenDto
                                      {
                                          SaleOrderDetailId = p.SaleOrderDetailId,
                                          Name = p.Name,
                                          Quantity = p.Quantity,
                                          Notes = p.Notes,
                                          ProductGroupCode = p.ProductGroup
                                      }).ToList();

            var kitchenData = new SalesOrderListDto()
            {
                SaleOrderId = salesOrder.Id,
                SaleOrderNumber = salesOrder.OrderNo,
                WaitingNumber = salesOrder.WaitingNumber,
                Notes = salesOrder.Notes,
                TotalQuantityBeverage = beverages.Sum(b => b.Quantity),
                TotalQuantityCake = cakes.Sum(c => c.Quantity),
                TotalQuantityTopping = toppings.Sum(t => t.Quantity),
                IsDelivery = salesOrder.HasDelivery,
                Beverages = beverages,
                Cakes = cakes,
                Toppings = toppings
            };

            return kitchenData;
        }

        private SaleOrderChefListDto ConvertDataToSaleOrderChefDto(SalesOrderDto salesOrder)
        {
            var products = salesOrder.SalesOrderDetails.Select(sod => new SaleOrderDetailShortDto
            {
                SaleOrderDetailId = sod.Id ?? Guid.NewGuid(),
                Name = sod.ProductName,
                Quantity = sod.UOSQuantity ?? 0,
                SalesOrderDetailStatus = sod.SalesOrderDetailStatus,
                Notes = sod.Notes,
                IsChild = sod.IsChild ?? false,
                IsOptional = sod.IsOptional ?? false,
                ProductGroup = sod.ProductGroupCode,
                SequentiaNumber = sod.SequentiaNumber ?? 0
            }).OrderBy(sod => sod.SequentiaNumber)
                                                    .ToList();

            var savors = products.Where(s => s.IsChild && s.IsOptional).ToList();
            var toppingsInBeverage = products.Where(t => t.IsChild && !t.IsOptional).ToList(); //topping đi kèm đồ uống
            var producItems = products.Where(t => !t.IsChild).ToList();
            //List<SaleOrderDetailChefDto> menu = new List<SaleOrderDetailChefDto>();

            // Split SaleOrder to ProductHierachy/ProductGroup
            var chef1 = producItems.Where(p => p.ProductGroup == RestaurantProductGroup.Noodle.ToString() || p.ProductGroup == RestaurantProductGroup.Drink.ToString())
                                            .Select(p => new SaleOrderDetailChefDto
                                            {
                                                SaleOrderDetailId = p.SaleOrderDetailId,
                                                Name = p.Name,
                                                Quantity = p.Quantity,
                                                SalesOrderDetailStatus = p.SalesOrderDetailStatus,
                                                Notes = p.Notes,
                                                Savor = savors.Select(s => s.Name).ToList(),
                                                Toppings = toppingsInBeverage.Select(t => new SOTopping
                                                {
                                                    Name = t.Name,
                                                    Quantity = t.Quantity
                                                }).ToList()
                                            }).ToList();

            var chef2 = producItems.Where(p => p.ProductGroup == RestaurantProductGroup.Dimsum.ToString() || p.ProductGroup == RestaurantProductGroup.Roasted.ToString())
                                      .Select(p => new SaleOrderDetailChefDto
                                      {
                                          SaleOrderDetailId = p.SaleOrderDetailId,
                                          Name = p.Name,
                                          Quantity = p.Quantity,
                                          SalesOrderDetailStatus = p.SalesOrderDetailStatus,
                                          Notes = p.Notes
                                      }).ToList();

            var chef3 = producItems.Where(p => p.ProductGroup == RestaurantProductGroup.Pan.ToString() || p.ProductGroup == RestaurantProductGroup.Soup.ToString() || p.ProductGroup == RestaurantProductGroup.Prepared.ToString())
                                            .Select(p => new SaleOrderDetailChefDto
                                            {
                                                SaleOrderDetailId = p.SaleOrderDetailId,
                                                SalesOrderDetailStatus = p.SalesOrderDetailStatus,
                                                Name = p.Name,
                                                Quantity = p.Quantity,
                                                Notes = p.Notes
                                            }).ToList();

            var kitchenData = new SaleOrderChefListDto()
            {
                SaleOrderId = salesOrder.Id,
                SaleOrderNumber = salesOrder.OrderNo,
                WaitingNumber = salesOrder.WaitingNumber,
                OrderStatus = salesOrder.OrderStatus,
                Notes = salesOrder.Notes,
                TotalQuantityChef1 = chef1.Sum(b => b.Quantity),
                TotalQuantityChef2 = chef2.Sum(b => b.Quantity),
                TotalQuantityChef3 = chef3.Sum(b => b.Quantity),
                IsDelivery = salesOrder.HasDelivery,
                Chef1 = chef1,
                Chef2 = chef2,
                Chef3 = chef3,
            };

            return kitchenData;
        }

        private void ConvertDataToSaleOrdeEntity(SalesOrderDto salesOrder)
        {
            var childSalesOrderDetails = new List<SalesOrderDetailShortDto>();

            if (salesOrder.SalesOrderDetails != null && salesOrder.SalesOrderDetails.Any())
            {
                foreach (var sd in salesOrder.SalesOrderDetails)
                {
                    if (sd.ChildSalesOrderDetails != null)
                    {
                        foreach (var item in sd.ChildSalesOrderDetails)
                        {
                            item.IsChild = true;
                            item.IsOptional = false;
                            item.SequentiaNumber = sd.SequentiaNumber;
                            item.ProductGroupCode = sd.ProductGroupCode;
                            childSalesOrderDetails.Add(item);
                        }

                        sd.IsChild = false;
                        sd.IsOptional = false;
                        sd.ChildSalesOrderDetails = null;
                    }

                    if (sd.OptionSalesOrderDetails != null)
                    {
                        foreach (var item in sd.OptionSalesOrderDetails)
                        {
                            item.IsChild = true;
                            item.IsOptional = true;
                            item.SequentiaNumber = sd.SequentiaNumber;
                            item.ProductGroupCode = sd.ProductGroupCode;
                            childSalesOrderDetails.Add(item);
                        }

                        sd.IsChild = false;
                        sd.IsOptional = false;
                        sd.OptionSalesOrderDetails = null;
                    }

                }

                salesOrder.SalesOrderDetails.AddRange(childSalesOrderDetails);
            }
        }
        #endregion
    }
}
