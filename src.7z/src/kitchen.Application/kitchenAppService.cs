﻿using kitchen.Localization;
using Volo.Abp.Application.Services;

namespace kitchen
{
    /* Inherit your application services from this class.
     */
    public abstract class kitchenAppService : ApplicationService
    {
        protected kitchenAppService()
        {
            LocalizationResource = typeof(kitchenResource);
        }
    }
}
