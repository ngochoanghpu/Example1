using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using kitchen.Permissions;
using kitchen.SalesOrderDetails;
using kitchen.Shared;
using kitchen.SalesOrderDetailStatusHistories;

namespace kitchen.SalesOrderDetails
{
   // [Authorize(kitchenPermissions.SalesOrderDetails.Default)]
    public class SalesOrderDetailAppService : ApplicationService, ISalesOrderDetailAppService
    {
        private readonly ISalesOrderDetailRepository _salesOrderDetailRepository;

        private readonly ISalesOrderDetailStatusHistoryRepository _salesOrderDetailStatusRepository;

        public SalesOrderDetailAppService(ISalesOrderDetailRepository salesOrderDetailRepository,
                                          ISalesOrderDetailStatusHistoryRepository salesOrderDetailStatusRepository)
        {
            _salesOrderDetailRepository = salesOrderDetailRepository;
            _salesOrderDetailStatusRepository = salesOrderDetailStatusRepository;
        }

        public virtual async Task<PagedResultDto<SalesOrderDetailDto>> GetListAsync(GetSalesOrderDetailsInput input)
        {
            var totalCount = await _salesOrderDetailRepository.GetCountAsync(input.FilterText, input.SalesOrderId, input.SalesOrderDetailId, input.SequentiaNumberMin, input.SequentiaNumberMax, input.BarCode1, input.BarCode2, input.ItemCode, input.ProductName, input.SerialNumber, input.LotNumber, input.UOSCode, input.UOSName, input.UOSQuantityMin, input.UOSQuantityMax, input.UOMCode, input.UOMQuantityMin, input.UOMQuantityMax, input.Notes, input.IsChild, input.IndexNumberMin, input.IndexNumberMax, input.SalesOrderDetailStaus, input.IsOptional, input.ProductHierarchyCode, input.ProductHierarchyName, input.ProductHierarchyOrderMin, input.ProductHierarchyOrderMax, input.RecievedDateTimeMin, input.RecievedDateTimeMax, input.PerformedById, input.PerformedByName, input.PerformedDateTimeMin, input.PerformedDateTimeMax, input.kitchenStatus);
            var items = await _salesOrderDetailRepository.GetListAsync(input.FilterText, input.SalesOrderId, input.SalesOrderDetailId, input.SequentiaNumberMin, input.SequentiaNumberMax, input.BarCode1, input.BarCode2, input.ItemCode, input.ProductName, input.SerialNumber, input.LotNumber, input.UOSCode, input.UOSName, input.UOSQuantityMin, input.UOSQuantityMax, input.UOMCode, input.UOMQuantityMin, input.UOMQuantityMax, input.Notes, input.IsChild, input.IndexNumberMin, input.IndexNumberMax, input.SalesOrderDetailStaus, input.IsOptional, input.ProductHierarchyCode, input.ProductHierarchyName, input.ProductHierarchyOrderMin, input.ProductHierarchyOrderMax, input.RecievedDateTimeMin, input.RecievedDateTimeMax, input.PerformedById, input.PerformedByName, input.PerformedDateTimeMin, input.PerformedDateTimeMax, input.kitchenStatus, input.Sorting, input.MaxResultCount, input.SkipCount);

            return new PagedResultDto<SalesOrderDetailDto>
            {
                TotalCount = totalCount,
                Items = ObjectMapper.Map<List<SalesOrderDetail>, List<SalesOrderDetailDto>>(items)
            };
        }

        public virtual async Task<SalesOrderDetailDto> GetAsync(Guid id)
        {
            return ObjectMapper.Map<SalesOrderDetail, SalesOrderDetailDto>(await _salesOrderDetailRepository.GetAsync(id));
        }

        //[Authorize(kitchenPermissions.SalesOrderDetails.Delete)]
        public virtual async Task DeleteAsync(Guid id)
        {
            await _salesOrderDetailRepository.DeleteAsync(id);
        }

       // [Authorize(kitchenPermissions.SalesOrderDetails.Create)]
        public virtual async Task<SalesOrderDetailDto> CreateAsync(SalesOrderDetailCreateDto input)
        {
            var newSalesOrderDetail = ObjectMapper.Map<SalesOrderDetailCreateDto, SalesOrderDetail>(input);
            newSalesOrderDetail.TenantId = CurrentTenant.Id;
            var salesOrderDetail = await _salesOrderDetailRepository.InsertAsync(newSalesOrderDetail);
            await CurrentUnitOfWork.SaveChangesAsync();
            return ObjectMapper.Map<SalesOrderDetail, SalesOrderDetailDto>(salesOrderDetail);
        }

        //[Authorize(kitchenPermissions.SalesOrderDetails.Edit)]
        public virtual async Task<SalesOrderDetailDto> UpdateAsync(Guid id, SalesOrderDetailUpdateDto input)
        {
            var salesOrderDetail = await _salesOrderDetailRepository.GetAsync(id);
            ObjectMapper.Map(input, salesOrderDetail);
            var updatedSalesOrderDetail = await _salesOrderDetailRepository.UpdateAsync(salesOrderDetail);
            return ObjectMapper.Map<SalesOrderDetail, SalesOrderDetailDto>(updatedSalesOrderDetail);
        }

        public async Task<ModifiedResponseDto<Guid>> UpdateChangeStatusAsync(Guid id, string status)
        {
            var response = new ModifiedResponseDto<Guid>();

            var so = await UpdateOrderDetailStatus(id, status);

            if (so == null)
            {
                response.Message = "FailToUpdateSOD";
                return response;
            }

            response.IsSuccess = true;
            return response;
        }

        #region Private Methods
        private async Task<SalesOrderDetail> UpdateOrderDetailStatus(Guid id, string status)
        {
            var saleOrderDetailEntity = await _salesOrderDetailRepository.GetAsync(id);

            if (saleOrderDetailEntity != null)
            {
                saleOrderDetailEntity.SalesOrderDetailStaus = status;

                try
                {
                    var saleOrderDetailStatusHistoryEntity = new SalesOrderDetailStatusHistory(
                                                      Guid.NewGuid(),
                                                      saleOrderDetailEntity.TenantId,
                                                      status,
                                                      saleOrderDetailEntity.KitchenStatus,
                                                      saleOrderDetailEntity.Notes,
                                                      CurrentUser.Id,
                                                      CurrentUser.UserName,
                                                      DateTime.UtcNow.ToString(),
                                                      saleOrderDetailEntity.SalesOrderId,
                                                      saleOrderDetailEntity.Id
                                                      );

                    await _salesOrderDetailStatusRepository.InsertAsync(saleOrderDetailStatusHistoryEntity);
                }
                catch (Exception ex)
                {
                    var message = ex.Message;
                }
            }

            return saleOrderDetailEntity;
        }

        #endregion
    }
}