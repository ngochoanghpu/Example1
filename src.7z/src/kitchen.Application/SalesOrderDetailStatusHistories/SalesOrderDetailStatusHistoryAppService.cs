using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using kitchen.Permissions;
using kitchen.SalesOrderDetailStatusHistories;

namespace kitchen.SalesOrderDetailStatusHistories
{
    [RemoteService(IsEnabled = false)]
    [Authorize(kitchenPermissions.SalesOrderDetailStatusHistories.Default)]
    public class SalesOrderDetailStatusHistoryAppService : ApplicationService, ISalesOrderDetailStatusHistoryAppService
    {
        private readonly ISalesOrderDetailStatusHistoryRepository _salesOrderDetailStatusHistoryRepository;

        public SalesOrderDetailStatusHistoryAppService(ISalesOrderDetailStatusHistoryRepository salesOrderDetailStatusHistoryRepository)
        {
            _salesOrderDetailStatusHistoryRepository = salesOrderDetailStatusHistoryRepository;

        }

        public virtual async Task<PagedResultDto<SalesOrderDetailStatusHistoryDto>> GetListAsync(GetSalesOrderDetailStatusHistoriesInput input)
        {
            var totalCount = await _salesOrderDetailStatusHistoryRepository.GetCountAsync(input.FilterText, input.SalesOrderId, input.SalesOrderDetailId, input.SalesOrderDetailStatus, input.KitchenStatus, input.Notes, input.ChangedById, input.ChangedByUserName, input.ChangedByDateTime);
            var items = await _salesOrderDetailStatusHistoryRepository.GetListAsync(input.FilterText, input.SalesOrderId, input.SalesOrderDetailId, input.SalesOrderDetailStatus, input.KitchenStatus, input.Notes, input.ChangedById, input.ChangedByUserName, input.ChangedByDateTime, input.Sorting, input.MaxResultCount, input.SkipCount);

            return new PagedResultDto<SalesOrderDetailStatusHistoryDto>
            {
                TotalCount = totalCount,
                Items = ObjectMapper.Map<List<SalesOrderDetailStatusHistory>, List<SalesOrderDetailStatusHistoryDto>>(items)
            };
        }

        public virtual async Task<SalesOrderDetailStatusHistoryDto> GetAsync(Guid id)
        {
            return ObjectMapper.Map<SalesOrderDetailStatusHistory, SalesOrderDetailStatusHistoryDto>(await _salesOrderDetailStatusHistoryRepository.GetAsync(id));
        }

        [Authorize(kitchenPermissions.SalesOrderDetailStatusHistories.Delete)]
        public virtual async Task DeleteAsync(Guid id)
        {
            await _salesOrderDetailStatusHistoryRepository.DeleteAsync(id);
        }

        [Authorize(kitchenPermissions.SalesOrderDetailStatusHistories.Create)]
        public virtual async Task<SalesOrderDetailStatusHistoryDto> CreateAsync(SalesOrderDetailStatusHistoryCreateDto input)
        {
            var newSalesOrderDetailStatusHistory = ObjectMapper.Map<SalesOrderDetailStatusHistoryCreateDto, SalesOrderDetailStatusHistory>(input);
            newSalesOrderDetailStatusHistory.TenantId = CurrentTenant.Id;
            var salesOrderDetailStatusHistory = await _salesOrderDetailStatusHistoryRepository.InsertAsync(newSalesOrderDetailStatusHistory);
            await CurrentUnitOfWork.SaveChangesAsync();
            return ObjectMapper.Map<SalesOrderDetailStatusHistory, SalesOrderDetailStatusHistoryDto>(salesOrderDetailStatusHistory);
        }

        [Authorize(kitchenPermissions.SalesOrderDetailStatusHistories.Edit)]
        public virtual async Task<SalesOrderDetailStatusHistoryDto> UpdateAsync(Guid id, SalesOrderDetailStatusHistoryUpdateDto input)
        {
            var salesOrderDetailStatusHistory = await _salesOrderDetailStatusHistoryRepository.GetAsync(id);
            ObjectMapper.Map(input, salesOrderDetailStatusHistory);
            var updatedSalesOrderDetailStatusHistory = await _salesOrderDetailStatusHistoryRepository.UpdateAsync(salesOrderDetailStatusHistory);
            return ObjectMapper.Map<SalesOrderDetailStatusHistory, SalesOrderDetailStatusHistoryDto>(updatedSalesOrderDetailStatusHistory);
        }
    }
}