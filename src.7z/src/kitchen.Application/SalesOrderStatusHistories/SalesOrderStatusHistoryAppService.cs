using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using Volo.Abp;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;
using Volo.Abp.Domain.Repositories;
using kitchen.Permissions;
using kitchen.SalesOrderStatusHistories;

namespace kitchen.SalesOrderStatusHistories
{
    [RemoteService(IsEnabled = false)]
    [Authorize(kitchenPermissions.SalesOrderStatusHistories.Default)]
    public class SalesOrderStatusHistoryAppService : ApplicationService, ISalesOrderStatusHistoryAppService
    {
        private readonly ISalesOrderStatusHistoryRepository _salesOrderStatusHistoryRepository;

        public SalesOrderStatusHistoryAppService(ISalesOrderStatusHistoryRepository salesOrderStatusHistoryRepository)
        {
            _salesOrderStatusHistoryRepository = salesOrderStatusHistoryRepository;

        }

        public virtual async Task<PagedResultDto<SalesOrderStatusHistoryDto>> GetListAsync(GetSalesOrderStatusHistoriesInput input)
        {
            var totalCount = await _salesOrderStatusHistoryRepository.GetCountAsync(input.FilterText, input.SalesOrderId, input.Status, input.KitchenStatus, input.Notes, input.ChangedById, input.ChangedByUserName, input.ChangedByDateTime);
            var items = await _salesOrderStatusHistoryRepository.GetListAsync(input.FilterText, input.SalesOrderId, input.Status, input.KitchenStatus, input.Notes, input.ChangedById, input.ChangedByUserName, input.ChangedByDateTime, input.Sorting, input.MaxResultCount, input.SkipCount);

            return new PagedResultDto<SalesOrderStatusHistoryDto>
            {
                TotalCount = totalCount,
                Items = ObjectMapper.Map<List<SalesOrderStatusHistory>, List<SalesOrderStatusHistoryDto>>(items)
            };
        }

        public virtual async Task<SalesOrderStatusHistoryDto> GetAsync(Guid id)
        {
            return ObjectMapper.Map<SalesOrderStatusHistory, SalesOrderStatusHistoryDto>(await _salesOrderStatusHistoryRepository.GetAsync(id));
        }

        [Authorize(kitchenPermissions.SalesOrderStatusHistories.Delete)]
        public virtual async Task DeleteAsync(Guid id)
        {
            await _salesOrderStatusHistoryRepository.DeleteAsync(id);
        }

        [Authorize(kitchenPermissions.SalesOrderStatusHistories.Create)]
        public virtual async Task<SalesOrderStatusHistoryDto> CreateAsync(SalesOrderStatusHistoryCreateDto input)
        {
            var newSalesOrderStatusHistory = ObjectMapper.Map<SalesOrderStatusHistoryCreateDto, SalesOrderStatusHistory>(input);
            newSalesOrderStatusHistory.TenantId = CurrentTenant.Id;
            var salesOrderStatusHistory = await _salesOrderStatusHistoryRepository.InsertAsync(newSalesOrderStatusHistory);
            await CurrentUnitOfWork.SaveChangesAsync();
            return ObjectMapper.Map<SalesOrderStatusHistory, SalesOrderStatusHistoryDto>(salesOrderStatusHistory);
        }

        [Authorize(kitchenPermissions.SalesOrderStatusHistories.Edit)]
        public virtual async Task<SalesOrderStatusHistoryDto> UpdateAsync(Guid id, SalesOrderStatusHistoryUpdateDto input)
        {
            var salesOrderStatusHistory = await _salesOrderStatusHistoryRepository.GetAsync(id);
            ObjectMapper.Map(input, salesOrderStatusHistory);
            var updatedSalesOrderStatusHistory = await _salesOrderStatusHistoryRepository.UpdateAsync(salesOrderStatusHistory);
            return ObjectMapper.Map<SalesOrderStatusHistory, SalesOrderStatusHistoryDto>(updatedSalesOrderStatusHistory);
        }
    }
}