using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.Application.Dtos;
using kitchen.KitchenConfigurations;
using System.Collections.Generic;

namespace kitchen.Controllers.KitchenConfigurations
{
    [RemoteService]
    [Area("app")]
    [ControllerName("KitchenConfiguration")]
    [Route("api/kitchenConfiguration")]
    public class KitchenConfigurationController : AbpController, IKitchenConfigurationAppService
    {
        private readonly IKitchenConfigurationAppService _kitchenConfigurationAppService;

        public KitchenConfigurationController(IKitchenConfigurationAppService kitchenConfigurationAppService)
        {
            _kitchenConfigurationAppService = kitchenConfigurationAppService;
        }

        [HttpGet]
        public virtual Task<PagedResultDto<KitchenConfigurationDto>> GetListAsync(GetKitchenConfigurationsInput input)
        {
            return _kitchenConfigurationAppService.GetListAsync(input);
        }

        [HttpGet]
        [Route("GetInforConfig")]
        public virtual Task<KitchenConfigShortDto> GetInforConfig(Guid? id = null)
        {
            return _kitchenConfigurationAppService.GetInforConfig(id);
        }

        [HttpGet]
        [Route("{id}")]
        public virtual Task<KitchenConfigurationDto> GetAsync(Guid id)
        {
            return _kitchenConfigurationAppService.GetAsync(id);
        }

        [HttpPost]
        public virtual Task<KitchenConfigurationDto> CreateAsync(KitchenConfigurationCreateDto input)
        {
            return _kitchenConfigurationAppService.CreateAsync(input);
        }

        [HttpPut]
        [Route("{id}")]
        public virtual Task<KitchenConfigurationDto> UpdateAsync(Guid id, KitchenConfigurationUpdateDto input)
        {
            return _kitchenConfigurationAppService.UpdateAsync(id, input);
        }

        [HttpDelete]
        [Route("{id}")]
        public virtual Task DeleteAsync(Guid id)
        {
            return _kitchenConfigurationAppService.DeleteAsync(id);
        }
    }
}