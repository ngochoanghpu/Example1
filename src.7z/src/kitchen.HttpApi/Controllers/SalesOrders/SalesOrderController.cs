using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.Application.Dtos;
using kitchen.SalesOrders;
using kitchen.Shared;
using System.Collections.Generic;

namespace kitchen.Controllers.SalesOrders
{
    [RemoteService]
    [Area("app")]
    [ControllerName("SalesOrder")]
    [Route("api/salesOrder")]
    public class SalesOrderController : AbpController, ISalesOrderAppService
    {
        private readonly ISalesOrderAppService _salesOrderAppService;

        public SalesOrderController(ISalesOrderAppService salesOrderAppService)
        {
            _salesOrderAppService = salesOrderAppService;
        }

        [HttpGet]
        public virtual Task<PagedResultDto<SalesOrderDto>> GetListAsync(GetSalesOrdersInput input)
        {
            return _salesOrderAppService.GetListAsync(input);
        }

        [HttpGet]
        [Route("{id}")]
        public virtual Task<SalesOrderDto> GetAsync(Guid id)
        {
            return _salesOrderAppService.GetAsync(id);
        }

        [HttpPost]
        public virtual Task<SalesOrderDto> CreateAsync(SalesOrderCreateDto input)
        {
            return _salesOrderAppService.CreateAsync(input);
        }

        [HttpPut]
        [Route("{id}")]
        public virtual Task<SalesOrderDto> UpdateAsync(Guid id, SalesOrderUpdateDto input)
        {
            return _salesOrderAppService.UpdateAsync(id, input);
        }

        [HttpDelete]
        [Route("{id}")]
        public virtual Task DeleteAsync(Guid id)
        {
            return _salesOrderAppService.DeleteAsync(id);
        }

        [HttpPut]
        [Route("{id}/changeKitchenStatus")]
        public Task<ModifiedResponseDto<Guid>> UpdateChangeStatusAsync(Guid id, string status)
        {
            return _salesOrderAppService.UpdateChangeStatusAsync(id, status);
        }

        [HttpGet]
        [Route("billsTeaMilk")]
        public Task<List<SalesOrderListDto>> GetBillsTeaMilk(string storeCode)
        {
            return _salesOrderAppService.GetBillsTeaMilk(storeCode);
        }

        [HttpGet]
        [Route("billsRestaurant")]
        public Task<List<SalesOrderListDto>> GetBillsRestaurant(string storeCode, string productGroupCodesString = "")
        {
            return _salesOrderAppService.GetBillsRestaurant(storeCode, productGroupCodesString);
        }

        [HttpPost]
        [Route("createSaleOrder")]
        public Task CreateSaleOrderAsync(SalesOrderDto input)
        {
            return _salesOrderAppService.CreateSaleOrderAsync(input);
        }

    }
}