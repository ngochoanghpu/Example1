using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.Application.Dtos;
using kitchen.SalesOrderDetails;
using kitchen.Shared;

namespace kitchen.Controllers.SalesOrderDetails
{
    [RemoteService]
    [Area("app")]
    [ControllerName("SalesOrderDetail")]
    [Route("api/salesOrderDetail")]
    public class SalesOrderDetailController : AbpController, ISalesOrderDetailAppService
    {
        private readonly ISalesOrderDetailAppService _salesOrderDetailAppService;

        public SalesOrderDetailController(ISalesOrderDetailAppService salesOrderDetailAppService)
        {
            _salesOrderDetailAppService = salesOrderDetailAppService;
        }

        [HttpGet]
        public virtual Task<PagedResultDto<SalesOrderDetailDto>> GetListAsync(GetSalesOrderDetailsInput input)
        {
            return _salesOrderDetailAppService.GetListAsync(input);
        }

        [HttpGet]
        [Route("{id}")]
        public virtual Task<SalesOrderDetailDto> GetAsync(Guid id)
        {
            return _salesOrderDetailAppService.GetAsync(id);
        }

        [HttpPost]
        public virtual Task<SalesOrderDetailDto> CreateAsync(SalesOrderDetailCreateDto input)
        {
            return _salesOrderDetailAppService.CreateAsync(input);
        }

        [HttpPut]
        [Route("{id}")]
        public virtual Task<SalesOrderDetailDto> UpdateAsync(Guid id, SalesOrderDetailUpdateDto input)
        {
            return _salesOrderDetailAppService.UpdateAsync(id, input);
        }

        [HttpDelete]
        [Route("{id}")]
        public virtual Task DeleteAsync(Guid id)
        {
            return _salesOrderDetailAppService.DeleteAsync(id);
        }

        [HttpPut]
        [Route("{id}/changeOrderDetailStatus")]
        public Task<ModifiedResponseDto<Guid>> UpdateChangeStatusAsync(Guid id, string status)
        {
            return _salesOrderDetailAppService.UpdateChangeStatusAsync(id, status);
        }
    }
}