using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.Application.Dtos;
using kitchen.SalesOrderDetailStatusHistories;

namespace kitchen.Controllers.SalesOrderDetailStatusHistories
{
    [RemoteService]
    [Area("app")]
    [ControllerName("SalesOrderDetailStatusHistory")]
    [Route("api/app/salesOrderDetailStatusHistory")]
    public class SalesOrderDetailStatusHistoryController : AbpController, ISalesOrderDetailStatusHistoryAppService
    {
        private readonly ISalesOrderDetailStatusHistoryAppService _salesOrderDetailStatusHistoryAppService;

        public SalesOrderDetailStatusHistoryController(ISalesOrderDetailStatusHistoryAppService salesOrderDetailStatusHistoryAppService)
        {
            _salesOrderDetailStatusHistoryAppService = salesOrderDetailStatusHistoryAppService;
        }

        [HttpGet]
        public virtual Task<PagedResultDto<SalesOrderDetailStatusHistoryDto>> GetListAsync(GetSalesOrderDetailStatusHistoriesInput input)
        {
            return _salesOrderDetailStatusHistoryAppService.GetListAsync(input);
        }

        [HttpGet]
        [Route("{id}")]
        public virtual Task<SalesOrderDetailStatusHistoryDto> GetAsync(Guid id)
        {
            return _salesOrderDetailStatusHistoryAppService.GetAsync(id);
        }

        [HttpPost]
        public virtual Task<SalesOrderDetailStatusHistoryDto> CreateAsync(SalesOrderDetailStatusHistoryCreateDto input)
        {
            return _salesOrderDetailStatusHistoryAppService.CreateAsync(input);
        }

        [HttpPut]
        [Route("{id}")]
        public virtual Task<SalesOrderDetailStatusHistoryDto> UpdateAsync(Guid id, SalesOrderDetailStatusHistoryUpdateDto input)
        {
            return _salesOrderDetailStatusHistoryAppService.UpdateAsync(id, input);
        }

        [HttpDelete]
        [Route("{id}")]
        public virtual Task DeleteAsync(Guid id)
        {
            return _salesOrderDetailStatusHistoryAppService.DeleteAsync(id);
        }
    }
}