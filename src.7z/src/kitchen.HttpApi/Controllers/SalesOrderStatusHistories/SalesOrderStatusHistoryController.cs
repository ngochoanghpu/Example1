using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.Application.Dtos;
using kitchen.SalesOrderStatusHistories;

namespace kitchen.Controllers.SalesOrderStatusHistories
{
    [RemoteService]
    [Area("app")]
    [ControllerName("SalesOrderStatusHistory")]
    [Route("api/app/salesOrderStatusHistory")]
    public class SalesOrderStatusHistoryController : AbpController, ISalesOrderStatusHistoryAppService
    {
        private readonly ISalesOrderStatusHistoryAppService _salesOrderStatusHistoryAppService;

        public SalesOrderStatusHistoryController(ISalesOrderStatusHistoryAppService salesOrderStatusHistoryAppService)
        {
            _salesOrderStatusHistoryAppService = salesOrderStatusHistoryAppService;
        }

        [HttpGet]
        public virtual Task<PagedResultDto<SalesOrderStatusHistoryDto>> GetListAsync(GetSalesOrderStatusHistoriesInput input)
        {
            return _salesOrderStatusHistoryAppService.GetListAsync(input);
        }

        [HttpGet]
        [Route("{id}")]
        public virtual Task<SalesOrderStatusHistoryDto> GetAsync(Guid id)
        {
            return _salesOrderStatusHistoryAppService.GetAsync(id);
        }

        [HttpPost]
        public virtual Task<SalesOrderStatusHistoryDto> CreateAsync(SalesOrderStatusHistoryCreateDto input)
        {
            return _salesOrderStatusHistoryAppService.CreateAsync(input);
        }

        [HttpPut]
        [Route("{id}")]
        public virtual Task<SalesOrderStatusHistoryDto> UpdateAsync(Guid id, SalesOrderStatusHistoryUpdateDto input)
        {
            return _salesOrderStatusHistoryAppService.UpdateAsync(id, input);
        }

        [HttpDelete]
        [Route("{id}")]
        public virtual Task DeleteAsync(Guid id)
        {
            return _salesOrderStatusHistoryAppService.DeleteAsync(id);
        }
    }
}