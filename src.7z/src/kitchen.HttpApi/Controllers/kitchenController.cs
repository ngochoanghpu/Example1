﻿using kitchen.Localization;
using Volo.Abp.AspNetCore.Mvc;

namespace kitchen.Controllers
{
    /* Inherit your controllers from this class.
     */
    public abstract class kitchenController : AbpController
    {
        protected kitchenController()
        {
            LocalizationResource = typeof(kitchenResource);
        }
    }
}