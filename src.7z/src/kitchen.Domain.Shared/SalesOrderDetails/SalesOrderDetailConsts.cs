namespace kitchen.SalesOrderDetails
{
    public static class SalesOrderDetailConsts
    {
        public const string DefaultSorting = "SalesOrderId asc";

    }
}