﻿using Volo.Abp.Localization;

namespace kitchen.Localization
{
    [LocalizationResourceName("kitchen")]
    public class kitchenResource
    {

    }
}