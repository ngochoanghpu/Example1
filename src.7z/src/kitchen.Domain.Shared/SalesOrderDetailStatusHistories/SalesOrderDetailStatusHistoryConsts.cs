namespace kitchen.SalesOrderDetailStatusHistories
{
    public static class SalesOrderDetailStatusHistoryConsts
    {
        public const string DefaultSorting = "SalesOrderId asc";

    }
}