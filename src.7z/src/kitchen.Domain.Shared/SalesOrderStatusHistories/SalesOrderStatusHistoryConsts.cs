namespace kitchen.SalesOrderStatusHistories
{
    public static class SalesOrderStatusHistoryConsts
    {
        public const string DefaultSorting = "SalesOrderId asc";

    }
}