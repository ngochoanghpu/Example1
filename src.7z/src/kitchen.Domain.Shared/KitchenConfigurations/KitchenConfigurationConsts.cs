using System;

namespace kitchen.KitchenConfigurations
{
    public static class KitchenConfigurationConsts
    {
        public const string DefaultSorting = "StoreCode asc";

        public const string TeaMilkId = "132e6d7a-aec0-11ea-9497-fcaa14401d81";

        public const string RestaurantId = "132e6d7a-aec0-11ea-9497-fcaa14401d82";

    }
}