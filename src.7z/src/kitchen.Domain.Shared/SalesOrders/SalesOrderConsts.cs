namespace kitchen.SalesOrders
{
    public static class SalesOrderConsts
    {
        public const string DefaultSorting = "SalesOrderId asc";
    }
}