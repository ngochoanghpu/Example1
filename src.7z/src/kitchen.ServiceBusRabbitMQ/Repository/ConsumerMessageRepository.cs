﻿using kitchen.ServiceBusRabbitMQ.IRepository;
using kitchen.ServiceBusRabbitMQ.Models;

namespace kitchen.ServiceBusRabbitMQ.Repository
{
    public class ConsumerMessageRepository : BaseRepository<EventLogDbContext, EventConsumerLog>, IConsumerMessageRepository
    {

    }
}
