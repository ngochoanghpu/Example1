﻿using kitchen.ServiceBusRabbitMQ.IRepository;
using kitchen.ServiceBusRabbitMQ.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.ServiceBusRabbitMQ.Repository
{
    public static class RepositoryFactory
    {
        public static TRepository Create<TRepository>(EventContextType ctype) where TRepository : class
        {
            switch (ctype)
            {
                case EventContextType.consumerMessage:
                    if (typeof(TRepository) == typeof(IConsumerMessageRepository))
                    {
                        return new ConsumerMessageRepository() as TRepository;
                    }
                    return null;
                case EventContextType.sendMessage:
                    if (typeof(TRepository) == typeof(ISendRequestRepository))
                    {
                        return new SendRequestRepository() as TRepository;
                    }
                    return null;
                default:
                    return null;
            }
        }
    }
}
