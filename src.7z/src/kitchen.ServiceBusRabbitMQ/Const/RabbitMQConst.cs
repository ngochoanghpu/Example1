﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kitchen.ServiceBusRabbitMQ.Const
{
    public class RabbitMQConst
    {
        //SaleOrder Configs
        public const string ExchangeName = "kitchen.exchange";
        public const string RoutingKey = "kit.so.itemstatuschange";
    }
}
