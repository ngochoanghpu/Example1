﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kitchen.ServiceBusRabbitMQ.Const
{
    public class SignalRConstant
    {
        public const string SignalRHubUrl = "/GetAsynSignalR";
        public const string BroadcastName = "updateSaleOrderStatus";
    }
}
