﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace kitchen.ServiceBusRabbitMQ.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EventConsumerLogs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    EventName = table.Column<string>(nullable: false),
                    Content = table.Column<string>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    Exceptions = table.Column<string>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    TimeReceived = table.Column<DateTime>(nullable: false),
                    TryReceived = table.Column<int>(nullable: false),
                    LastedReceived = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventConsumerLogs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EventSentLogs",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    EventName = table.Column<string>(nullable: false),
                    Content = table.Column<string>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    Exceptions = table.Column<string>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    TimeSent = table.Column<DateTime>(nullable: false),
                    TrySent = table.Column<int>(nullable: false),
                    LastedSent = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EventSentLogs", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EventConsumerLogs_Id",
                table: "EventConsumerLogs",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_EventSentLogs_Id",
                table: "EventSentLogs",
                column: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EventConsumerLogs");

            migrationBuilder.DropTable(
                name: "EventSentLogs");
        }
    }
}
