﻿using Newtonsoft.Json;
using kitchen.SalesOrders;
using kitchen.ServiceBusRabbitMQ.IService;
using System;
using System.Text;
using Volo.Abp.DependencyInjection;
using Newtonsoft.Json.Serialization;

namespace kitchen.ServiceBusRabbitMQ.Service
{
    public class Utf8JsonRabbitMqSerializer : IRabbitMqSerializer, ITransientDependency
    {
        public byte[] Serialize(object obj)
        {
            var value = JsonConvert.SerializeObject(obj, Formatting.None);
            return Encoding.UTF8.GetBytes(value);
        }
        public string SerializeToJson(object obj)
        {
            var settings = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                NullValueHandling = NullValueHandling.Ignore,
                ReferenceLoopHandling = ReferenceLoopHandling.Serialize
            };
            return JsonConvert.SerializeObject(obj, settings);
        }

        public SaleOrderConsumerDto Deserialize_InforSalesOrder(ReadOnlyMemory<byte> value)
        {
            return JsonConvert.DeserializeObject<SaleOrderConsumerDto>(Encoding.UTF8.GetString(value.ToArray()));
        }

        public SalesOrderDto Deserialize_SalesOrder(ReadOnlyMemory<byte> value)
        {
            return JsonConvert.DeserializeObject<SalesOrderDto>(Encoding.UTF8.GetString(value.ToArray()));
        }
    }
}
