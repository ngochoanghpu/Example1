﻿using Microsoft.AspNetCore.SignalR;
using Volo.Abp.AspNetCore.SignalR;

namespace Kitchen.ServiceBusRabbitMQ.Service
{
    public class SignalR_SO_Hub : AbpHub<IHubClients>
    {
     
    }
}
