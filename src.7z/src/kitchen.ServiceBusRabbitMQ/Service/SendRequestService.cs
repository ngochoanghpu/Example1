﻿using kitchen.ServiceBusRabbitMQ.IService;
using kitchen.ServiceBusRabbitMQ.Models;
using Microsoft.Extensions.ObjectPool;
using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Text;
using System.Threading.Tasks;

namespace kitchen.ServiceBusRabbitMQ.Service
{
    public class SendRequestService : ISendRequestService
    {
        private readonly DefaultObjectPool<IModel> _objectPool;

        public SendRequestService(IPooledObjectPolicy<IModel> objectPolicy)
        {
            _objectPool = new DefaultObjectPool<IModel>(objectPolicy, Environment.ProcessorCount * 2);
        }

        public async Task<bool> SendRequest<T>(T message, string exchangeName, string routeKey)
            where T : class
        {
            bool rs = false;
            if (message == null)
                return rs;

            var channel = _objectPool.Get();
            HandleMessageService handleMessagesv = new HandleMessageService();

            try
            {
                var sendBytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));

                var properties = channel.CreateBasicProperties();
                properties.Persistent = true;
                handleMessagesv.SendMessage(message.ToString(), exchangeName, routeKey, EnumStateType.Published, "").Wait();
                channel.BasicPublish(exchangeName, routeKey, properties, sendBytes);
                rs = true;
            }
            catch (Exception ex)
            {
                handleMessagesv.SendMessage(message.ToString(), exchangeName, routeKey, EnumStateType.NotPublish, ex.ToString()).Wait();
                rs = false;
            }
            return rs;
        }
    }
}
