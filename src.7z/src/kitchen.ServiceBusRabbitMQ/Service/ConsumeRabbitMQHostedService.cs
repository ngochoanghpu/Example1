﻿using kitchen.SalesOrders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.ObjectPool;
using kitchen.ServiceBusRabbitMQ.Models;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static kitchen.Shared.SalesOrderConsts;
using Microsoft.AspNetCore.SignalR;
using Newtonsoft.Json;
using Microsoft.Extensions.Options;
using Kitchen.ServiceBusRabbitMQ.Models;
using Kitchen.ServiceBusRabbitMQ.Service;

namespace kitchen.ServiceBusRabbitMQ.Service
{
    public class ConsumeRabbitMQHostedService : BackgroundService
    {
        private IModel _channel;
        private readonly DefaultObjectPool<IModel> _objectPool;
        private readonly QueueOptions _queueOptions;
        public MessageReceiver _messageReceiver;
        private readonly ISalesOrderAppService _salesOrderAppService;
        private readonly IHubContext<SignalR_SO_Hub> _hubContext;

        public ConsumeRabbitMQHostedService(IPooledObjectPolicy<IModel> objectPolicy,
                                            ISalesOrderAppService salesOrderAppService,
                                            IHubContext<SignalR_SO_Hub> hubContext,
                                            IOptions<QueueOptions> queueOptions)
        {
            _hubContext = hubContext;
            _queueOptions = queueOptions.Value;
            _objectPool = new DefaultObjectPool<IModel>(objectPolicy, Environment.ProcessorCount * 2);
            _salesOrderAppService = salesOrderAppService;
            InitRabbitMQ().Wait();
        }

        private async Task InitRabbitMQ()
        {
            _channel = _objectPool.Get();
            _channel.BasicQos(0, 10, false);
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            stoppingToken.ThrowIfCancellationRequested();
            Utf8JsonRabbitMqSerializer utf8JsonRabbitMq = new Utf8JsonRabbitMqSerializer();
            var consumer = new EventingBasicConsumer(_channel);
            consumer.Received += (ch, ea) =>
            {
                //received message
                var content = Encoding.UTF8.GetString(ea.Body.ToArray());
                
                // handle the received message  
                HandleMessageService handleMessagesv = new HandleMessageService();
                try
                {
                    //transform raw data before push to client and insert DB
                    var saleOrder = JsonConvert.DeserializeObject<SalesOrderDto>(content);
                    var routingKey = ea.RoutingKey;

                    if (routingKey == "pos.saleorders")
                    {
                        
                        var isCancelBill = saleOrder.OrderStatus == OrderStatus.Cancelled.ToString();
                        var isInformCancelBill = saleOrder.OrderStatus == OrderStatus.InformCancelled.ToString();

                        if (isCancelBill) //Hủy bill từ nhân viên thu nhân POS
                        { 
                          //Update OrderStatus of bill to Cancelled
                            _salesOrderAppService.UpdateChangeStatusAsync(saleOrder.Id, OrderStatus.Cancelled.ToString()).Wait();
                        }
                        else if (isInformCancelBill) //Hủy bill từ khách hàng trên app loyalty
                        {
                            //Update OrderStatus of bill to Cancelled
                            _salesOrderAppService.UpdateChangeStatusAsync(saleOrder.Id, OrderStatus.InformCancelled.ToString()).Wait();
                        }
                        else
                        {
                            //insert saleOrder to database
                            _salesOrderAppService.CreateSaleOrderAsync(saleOrder).Wait();
                        }
                    }
                    else if(routingKey == "pos.so.update")
                    {
                        _hubContext.Clients.All.SendAsync("SendBill", utf8JsonRabbitMq.SerializeToJson(saleOrder)).Wait();
                    }

                    //write log when received message from rabbitmq
                    handleMessagesv.ConsumingMessage(Encoding.UTF8.GetString(ea.Body.ToArray()), ea.Exchange, ea.RoutingKey, EnumStateType.Received, "").Wait();

                    _channel.BasicAck(ea.DeliveryTag, false);
                }
                catch(Exception ex)
                {
                    handleMessagesv.ConsumingMessage(Encoding.UTF8.GetString(ea.Body.ToArray()), ea.Exchange, ea.RoutingKey, EnumStateType.ReceivedFailed, ex.ToString())
                    .Wait();
                }
            };

            consumer.Shutdown += OnConsumerShutdown;
            consumer.Registered += OnConsumerRegistered;
            consumer.Unregistered += OnConsumerUnregistered;
            consumer.ConsumerCancelled += OnConsumerConsumerCancelled;
            //_channel.BasicConsume(_queueOptions.QueueName, false, consumer);
            _channel.BasicConsume("pos.saleorders.queue", false, consumer);
            _channel.BasicConsume("pos.so.update.queue", false, consumer);

            return Task.CompletedTask;
        }

        private void OnConsumerConsumerCancelled(object sender, ConsumerEventArgs e) { }
        private void OnConsumerUnregistered(object sender, ConsumerEventArgs e) { }
        private void OnConsumerRegistered(object sender, ConsumerEventArgs e) { }
        private void OnConsumerShutdown(object sender, ShutdownEventArgs e) { }
        private void RabbitMQ_ConnectionShutdown(object sender, ShutdownEventArgs e) { }

        public override void Dispose()
        {
            _channel.Close();
            base.Dispose();
        }

        
    }
}
