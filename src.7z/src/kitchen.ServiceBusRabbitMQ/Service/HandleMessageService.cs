﻿using kitchen.ServiceBusRabbitMQ.IRepository;
using kitchen.ServiceBusRabbitMQ.IService;
using kitchen.ServiceBusRabbitMQ.Models;
using kitchen.ServiceBusRabbitMQ.Repository;
using System;
using System.Threading.Tasks;

namespace kitchen.ServiceBusRabbitMQ.Service
{
    public class HandleMessageService : IHandleMessageService
    {
        public async Task SendMessage(string content, string exchange, string routingKey, EnumStateType status, string exception)
        {
            var eventSentLogs = RepositoryFactory.Create<ISendRequestRepository>(EventContextType.sendMessage);
            EventSentLogs eventLogs = new EventSentLogs();
            eventLogs.EventName = exchange + ": " + routingKey;
            eventLogs.Content = content;
            eventLogs.Status = status;
            eventLogs.TimeSent = DateTime.Now;
            eventLogs.CreationTime = DateTime.Now;
            eventLogs.LastedSent = DateTime.Now;
            eventLogs.Exceptions = exception;
            eventSentLogs.Insert(eventLogs);
        }

        public async Task ConsumingMessage(string content, string exchange, string routingKey, EnumStateType status, string exception)
        {
            var eventReceiverLogs = RepositoryFactory.Create<IConsumerMessageRepository>(EventContextType.consumerMessage);
            EventConsumerLog eventLogs = new EventConsumerLog();
            eventLogs.EventName = exchange + ": " + routingKey;
            eventLogs.Content = content;
            eventLogs.Status = status;
            eventLogs.TimeReceived = DateTime.Now;
            eventLogs.CreationTime = DateTime.Now;
            eventLogs.LastedReceived = DateTime.Now;
            eventLogs.Exceptions = exception;
            eventReceiverLogs.Insert(eventLogs);
        }
    }
}
