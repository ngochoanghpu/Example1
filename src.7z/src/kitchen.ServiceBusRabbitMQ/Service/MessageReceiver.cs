﻿using kitchen.ServiceBusRabbitMQ.Models;
using RabbitMQ.Client;
using System;
using System.Text;

namespace kitchen.ServiceBusRabbitMQ.Service
{
    public class MessageReceiver : DefaultBasicConsumer
    {
        private readonly IModel _channel;

        public MessageReceiver(IModel channel)
        {
            _channel = channel;
        }

        public override void HandleBasicDeliver(string consumerTag, ulong deliveryTag, bool redelivered, string exchange, string routingKey, IBasicProperties properties, ReadOnlyMemory<byte> body)
        {
            HandleMessageService handleMessageService = new HandleMessageService();
            try
            {
                handleMessageService.ConsumingMessage(Encoding.UTF8.GetString(body.ToArray()), exchange, routingKey, EnumStateType.Received, "").Wait();
                _channel.BasicAck(deliveryTag, false);
            }
            catch(Exception ex) {
                handleMessageService.ConsumingMessage(Encoding.UTF8.GetString(body.ToArray()), exchange, routingKey, EnumStateType.ReceivedFailed, ex.ToString()).Wait();
            }
        }
    }
}
