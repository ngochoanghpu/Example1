﻿namespace kitchen.ServiceBusRabbitMQ.Models
{
    public enum EventMessageType
    {
        AddEvent,
        SubEvent,
        AddBookEvent,
        SubBookEvent,
        AddInstransitEvent,
        SubInstransitEvent,

    }
}
