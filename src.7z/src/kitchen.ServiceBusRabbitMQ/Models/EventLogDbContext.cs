﻿using Microsoft.EntityFrameworkCore;

namespace kitchen.ServiceBusRabbitMQ.Models
{
    public partial class EventLogDbContext : DbContext
    {
        public EventLogDbContext()
        {

        }

        public EventLogDbContext(DbContextOptions<EventLogDbContext> options) : base(options)
        {

        }

        public virtual DbSet<EventSentLogs> EventSentLogs { get; set; }

        public virtual DbSet<EventConsumerLog> EventConsumerLogs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseMySql("Server=localhost; Port=3306; Database=kitchen.RabbitMq; UID=root; pwd=123456;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.2-servicing-10034");

            modelBuilder.Entity<EventSentLogs>(entity =>
            {
                entity.HasIndex(e => e.Id);
                entity.Property(e => e.EventName).IsRequired();
                entity.Property(e => e.Content).IsRequired();
                entity.Property(e => e.Status).IsRequired();
                entity.Property(e => e.Exceptions);
                entity.Property(e => e.CreationTime);
                entity.Property(e => e.TimeSent);
                entity.Property(e => e.TrySent);
            });

            modelBuilder.Entity<EventConsumerLog>(entity =>
            {
                entity.HasIndex(e => e.Id);
                entity.Property(e => e.EventName).IsRequired();
                entity.Property(e => e.Content).IsRequired();
                entity.Property(e => e.Status).IsRequired();
                entity.Property(e => e.Exceptions);
                entity.Property(e => e.CreationTime);
                entity.Property(e => e.TimeReceived);
                entity.Property(e => e.TryReceived);
            });
        }
    }
}