﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kitchen.ServiceBusRabbitMQ.Models
{
    public class MessageConsuming
    {
        public string message { get; set; }
    }
}
