﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace kitchen.ServiceBusRabbitMQ.Models
{
    public partial class EventConsumerLog : IEntity
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }
        [Required]
        public string EventName { get; set; }
        [Required]
        public string Content { get; set; }
        [Required]
        public EnumStateType Status { get; set; }
        public string Exceptions { get; set; }
        public DateTime CreationTime { get; set; }
        public DateTime TimeReceived { get; set; }
        public int TryReceived { get; set; }
        public DateTime LastedReceived { get; set; }
    }
}
