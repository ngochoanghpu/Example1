﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace kitchen.ServiceBusRabbitMQ.Models
{
    public partial class EventSentLogs : IEntity
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }
        [Required]
        public string EventName { get; set; }
        [Required]
        public string Content { get; set; }
        [Required]
        public EnumStateType Status { get; set; }
        public string Exceptions { get; set; }
        public DateTime CreationTime { get; set; }
        public DateTime TimeSent { get; set; }
        public int TrySent { get; set; }
        public DateTime LastedSent { get; set; }
    }
}
