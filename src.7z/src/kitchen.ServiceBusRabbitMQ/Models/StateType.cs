﻿namespace kitchen.ServiceBusRabbitMQ.Models
{
    public enum EnumStateType
    {
        NotPublish,
        InProgress,
        Published,
        PublishedFailed,
        Received,
        ReceivedFailed,
    }
}
