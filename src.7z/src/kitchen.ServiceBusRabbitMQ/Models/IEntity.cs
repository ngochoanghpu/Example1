﻿using System;

namespace kitchen.ServiceBusRabbitMQ.Models
{
    public interface IEntity
    {
        int Id { get; }
    }
}
