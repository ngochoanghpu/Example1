﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kitchen.ServiceBusRabbitMQ.Models
{
    public class QueueOptions
    {
        public string QueueName { get; set; }
        public string RoutingKey { get; set; }
    }
}
