﻿namespace kitchen.ServiceBusRabbitMQ.Models
{
    public enum EventContextType
    {
        sendMessage,
        consumerMessage
    }
}
