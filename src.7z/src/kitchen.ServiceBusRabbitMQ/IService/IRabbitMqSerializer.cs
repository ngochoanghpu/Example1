﻿using kitchen.SalesOrders;
using System;

namespace kitchen.ServiceBusRabbitMQ.IService
{
    public interface IRabbitMqSerializer
    {
        byte[] Serialize(object obj);
        string SerializeToJson(object obj);
        SalesOrderDto Deserialize_SalesOrder(ReadOnlyMemory<byte> value);
        SaleOrderConsumerDto Deserialize_InforSalesOrder(ReadOnlyMemory<byte> value);
    }
}
