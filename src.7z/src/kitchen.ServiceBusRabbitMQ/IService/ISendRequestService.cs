﻿using System.Threading.Tasks;

namespace kitchen.ServiceBusRabbitMQ.IService
{
    public interface ISendRequestService
    {
        Task<bool> SendRequest<T>(T message, string exchangeName, string routeKey) where T : class;
    }

}
