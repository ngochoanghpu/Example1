﻿using System.Threading.Tasks;

namespace kitchen.ServiceBusRabbitMQ.IService
{
    public interface ILogsService
    {
        Task ConsumingMessageLogs(string content, string exchange);
        Task SentMessageLogs(string content, string exchange, string routing);
    }
}
