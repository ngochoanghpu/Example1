﻿using kitchen.ServiceBusRabbitMQ.Models;
using System.Threading.Tasks;

namespace kitchen.ServiceBusRabbitMQ.IService
{
    public interface IHandleMessageService
    {
        Task SendMessage(string content, string exchange, string routingKey, EnumStateType status, string exception);
        Task ConsumingMessage(string content, string exchange, string routingKey, EnumStateType status, string exception);
    }
}
