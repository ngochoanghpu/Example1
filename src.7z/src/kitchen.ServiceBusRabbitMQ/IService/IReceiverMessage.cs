﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.ServiceBusRabbitMQ.IService
{
    public interface IReceiverMessage
    {
        void ReceiverMessage(string exchangeName, string exchangeType, string routeKey);
    }
}
