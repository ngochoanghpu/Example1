﻿using RabbitMQ.Client;

namespace kitchen.ServiceBusRabbitMQ.IService
{
    public interface IConnectionService
    {
        IConnection CreateConnection();

    }
}
