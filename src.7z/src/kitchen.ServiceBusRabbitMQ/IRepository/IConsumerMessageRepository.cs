﻿using kitchen.ServiceBusRabbitMQ.Models;

namespace kitchen.ServiceBusRabbitMQ.IRepository
{
    public interface IConsumerMessageRepository : IBaseRepository<EventConsumerLog>
    {
    }
}
