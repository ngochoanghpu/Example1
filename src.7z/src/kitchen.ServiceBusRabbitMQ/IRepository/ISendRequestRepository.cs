﻿using kitchen.ServiceBusRabbitMQ.Models;

namespace kitchen.ServiceBusRabbitMQ.IRepository
{
    public interface ISendRequestRepository : IBaseRepository<EventSentLogs>
    {
    }
}
