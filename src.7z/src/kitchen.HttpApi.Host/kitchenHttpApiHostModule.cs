using System;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using kitchen.EntityFrameworkCore;
using kitchen.MultiTenancy;
using StackExchange.Redis;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Swagger;
using Volo.Abp;
using Volo.Abp.AspNetCore.Mvc;
using Volo.Abp.AspNetCore.Mvc.UI.MultiTenancy;
using Volo.Abp.AspNetCore.Mvc.UI.Theme.Shared;
using Volo.Abp.Autofac;
using Volo.Abp.Caching;
using Volo.Abp.Modularity;
using Volo.Abp.VirtualFileSystem;
using kitchen.ServiceBusRabbitMQ.Models;
using Microsoft.Extensions.ObjectPool;
using kitchen.ServiceBusRabbitMQ.Service;
using kitchen.ServiceBusRabbitMQ.IService;
using RabbitMQ.Client;
using Kitchen.ServiceBusRabbitMQ.Models;
using Kitchen.ServiceBusRabbitMQ.Service;
using Kitchen.ServiceBusRabbitMQ.Const;
using Volo.Abp.AspNetCore.SignalR;

namespace kitchen
{
    [DependsOn(
        typeof(kitchenHttpApiModule),
        typeof(AbpAutofacModule),
        typeof(AbpAspNetCoreMvcUiMultiTenancyModule),
        typeof(kitchenApplicationModule),
        typeof(kitchenEntityFrameworkCoreDbMigrationsModule)
        )]
    public class kitchenHttpApiHostModule : AbpModule
    {
        private const string DefaultCorsPolicyName = "Default";

        public override void ConfigureServices(ServiceConfigurationContext context)
        {
            var configuration = context.Services.GetConfiguration();
            var hostingEnvironment = context.Services.GetHostingEnvironment();

            ConfigureConventionalControllers();
            ConfigureAuthentication(context, configuration);
            ConfigureSwagger(context);
            ConfigureCache(configuration);
            ConfigureVirtualFileSystem(context);
            ConfigureRedis(context, configuration, hostingEnvironment);
            ConfigureCors(context, configuration);
            ConfigureRabitMQ(context, configuration);
            ConfigureSignalR(context);
        }

        private static void ConfigureSignalR(ServiceConfigurationContext context)
        {
            context.Services.AddSignalR();
            //context.Services.Configure<AbpSignalROptions>(options =>
            //{
            //    options.Hubs.Add(
            //        new HubConfig(
            //            typeof(SignalR_SO_Hub), //Hub type
            //            SignalRConstant.SignalRHubUrl, //Hub route (URL)
            //            //hubOptions =>
            //            //{
            //            //    //Additional options
            //            //    //hubOptions.LongPolling.PollTimeout = TimeSpan.FromSeconds(30);
            //            //}
            //        )
            //    );
            //});
            context.Services.AddAlwaysAllowAuthorization();
        }

        private void ConfigureCache(IConfiguration configuration)
        {
            Configure<AbpDistributedCacheOptions>(options =>
            {
                options.KeyPrefix = "kitchen:";
            });
        }

        private void ConfigureVirtualFileSystem(ServiceConfigurationContext context)
        {
            var hostingEnvironment = context.Services.GetHostingEnvironment();

            if (hostingEnvironment.IsDevelopment())
            {
                Configure<AbpVirtualFileSystemOptions>(options =>
                {
                    options.FileSets.ReplaceEmbeddedByPhysical<kitchenDomainSharedModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}kitchen.Domain.Shared", Path.DirectorySeparatorChar)));
                    options.FileSets.ReplaceEmbeddedByPhysical<kitchenDomainModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}kitchen.Domain", Path.DirectorySeparatorChar)));
                    options.FileSets.ReplaceEmbeddedByPhysical<kitchenApplicationContractsModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}kitchen.Application.Contracts", Path.DirectorySeparatorChar)));
                    options.FileSets.ReplaceEmbeddedByPhysical<kitchenApplicationModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}kitchen.Application", Path.DirectorySeparatorChar)));
                    options.FileSets.ReplaceEmbeddedByPhysical<kitchenHttpApiModule>(Path.Combine(hostingEnvironment.ContentRootPath, string.Format("..{0}..{0}src{0}kitchen.HttpApi", Path.DirectorySeparatorChar)));
                });
            }
        }

        private void ConfigureConventionalControllers()
        {
            Configure<AbpAspNetCoreMvcOptions>(options =>
            {
                options.ConventionalControllers.Create(typeof(kitchenApplicationModule).Assembly);
            });
        }

        private void ConfigureAuthentication(ServiceConfigurationContext context, IConfiguration configuration)
        {
            context.Services.AddAuthentication("Bearer")
                .AddIdentityServerAuthentication(options =>
                {
                    options.Authority = configuration["AuthServer:Authority"];
                    options.RequireHttpsMetadata = options.Authority.StartsWith("https://");
                    options.ApiName = "kitchen";
                });
        }

        private static void ConfigureSwagger(ServiceConfigurationContext context)
        {
            context.Services.AddSwaggerGen(
                options =>
                {
                    options.SwaggerDoc("v1", new OpenApiInfo {Title = "kitchen API", Version = "v1"});
                    options.DocInclusionPredicate((docName, description) => true);
                });
        }

        private void ConfigureRedis(
            ServiceConfigurationContext context,
            IConfiguration configuration,
            IWebHostEnvironment hostingEnvironment)
        {
            context.Services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = configuration["Redis:Configuration"];
            });

            if (!hostingEnvironment.IsDevelopment())
            {
                var redis = ConnectionMultiplexer.Connect(configuration["Redis:Configuration"]);
                context.Services
                    .AddDataProtection()
                    .PersistKeysToStackExchangeRedis(redis, "kitchen-Protection-Keys");
            }
        }

        private void ConfigureCors(ServiceConfigurationContext context, IConfiguration configuration)
        {
            context.Services.AddCors(options =>
            {
                options.AddPolicy(DefaultCorsPolicyName, builder =>
                {
                    builder
                        .WithOrigins(
                            configuration["App:CorsOrigins"]
                                .Split(",", StringSplitOptions.RemoveEmptyEntries)
                                .Select(o => o.RemovePostFix("/"))
                                .ToArray()
                        )
                        .WithAbpExposedHeaders()
                        .SetIsOriginAllowedToAllowWildcardSubdomains()
                        .AllowAnyHeader()
                        .AllowAnyMethod()
                        .AllowCredentials();
                });
            });
        }

        private static void ConfigureRabitMQ(ServiceConfigurationContext context, IConfiguration configuration)
        {
            var rabbitConfig = configuration.GetSection("rabbitdev");
            context.Services.Configure<RabbitOptions>(rabbitConfig);
            context.Services.AddSingleton<ObjectPoolProvider, DefaultObjectPoolProvider>();
            context.Services.AddSingleton<IPooledObjectPolicy<IModel>, ConnectionService>();

            context.Services.AddSingleton<ISendRequestService, SendRequestService>();
            //context.Services.AddSingleton<IConsumingMessageService, ConsumeRabbitMQService>();
            //var consumingQueue = configuration.GetSection("pos_exchange");
            //context.Services.Configure<QueueOptions>(consumingQueue);
            context.Services.AddHostedService<ConsumeRabbitMQHostedService>();
            //Consuming Messages from Pos Exchange
            //context.Services.AddHostedService<SO_Consume_RabbitMQ_Hosted>();
            context.Services.AddAlwaysAllowAuthorization();
        }

        public override void OnApplicationInitialization(ApplicationInitializationContext context)
        {
            var app = context.GetApplicationBuilder();
            var env = context.GetEnvironment();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseErrorPage();
            }

            app.UseCors(DefaultCorsPolicyName);

            app.UseVirtualFiles();
            app.UseRouting();
            app.UseAuthentication();

            if (MultiTenancyConsts.IsEnabled)
            {
                app.UseMultiTenancy();
            }
            
            app.UseAbpRequestLocalization();
            app.UseAuthorization();
            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
               options.SwaggerEndpoint("/swagger/v1/swagger.json", "kitchen API");
            });
            app.UseAuditing();

            app.UseConfiguredEndpoints(endpoints =>
            {
                endpoints.MapHub<SignalR_SO_Hub>(SignalRConstant.SignalRHubUrl);
                //endpoints.MapHub<SignalR_SO_Hub>(SignalRConstant.SignalRHubUrl, options =>
                //{
                //    options.LongPolling.PollTimeout = TimeSpan.FromSeconds(30);
                //});
            });

        }
    }
}
