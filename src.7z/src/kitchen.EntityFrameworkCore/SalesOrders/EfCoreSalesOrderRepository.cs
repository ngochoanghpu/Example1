using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Volo.Abp.Domain.Repositories.EntityFrameworkCore;
using Volo.Abp.EntityFrameworkCore;
using kitchen.EntityFrameworkCore;
using System.Linq.Expressions;
using Kitchen.Extensions;

namespace kitchen.SalesOrders
{
    public class EfCoreSalesOrderRepository : EfCoreRepository<kitchenDbContext, SalesOrder, Guid>, ISalesOrderRepository
    {
        public EfCoreSalesOrderRepository(IDbContextProvider<kitchenDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        public async Task<List<SalesOrder>> GetListAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            string storeCode = null,
            string storeName = null,
            string employeeCode = null,
            string employeeName = null,
            string orderNo = null,
            string orderType = null,
            string orderTypeName = null,
            DateTime? orderDateTimeMin = null,
            DateTime? orderDateTimeMax = null,
            string orderStatus = null,
            string orderStatusName = null,
            string salesChannelCode = null,
            string salesChannelName = null,
            bool? hasDelivery = null,
            string notes = null,
            string waitingNumber = null,
            bool? isTakeAway = null,
            DateTime? pickingTimeMin = null,
            DateTime? pickingTimeMax = null,
            DateTime? snoozingTimeMin = null,
            DateTime? snoozingTimeMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string KitchenStatus = null,
            string storeBrand = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, salesOrderId, storeCode, storeName, employeeCode, employeeName, orderNo, orderType, orderTypeName, orderDateTimeMin, orderDateTimeMax, orderStatus, orderStatusName, salesChannelCode, salesChannelName, hasDelivery, notes, waitingNumber, isTakeAway, pickingTimeMin, pickingTimeMax, snoozingTimeMin, snoozingTimeMax, recievedDateTimeMin, recievedDateTimeMax, performedById, performedByName, performedDateTimeMin, performedDateTimeMax, KitchenStatus, storeBrand);
            query = query.OrderBy(string.IsNullOrWhiteSpace(sorting) ? SalesOrderConsts.DefaultSorting : sorting);
            return await query.PageBy(skipCount, maxResultCount).ToListAsync(cancellationToken);
        }

        public async Task<long> GetCountAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            string storeCode = null,
            string storeName = null,
            string employeeCode = null,
            string employeeName = null,
            string orderNo = null,
            string orderType = null,
            string orderTypeName = null,
            DateTime? orderDateTimeMin = null,
            DateTime? orderDateTimeMax = null,
            string orderStatus = null,
            string orderStatusName = null,
            string salesChannelCode = null,
            string salesChannelName = null,
            bool? hasDelivery = null,
            string notes = null,
            string waitingNumber = null,
            bool? isTakeAway = null,
            DateTime? pickingTimeMin = null,
            DateTime? pickingTimeMax = null,
            DateTime? snoozingTimeMin = null,
            DateTime? snoozingTimeMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string KitchenStatus = null,
            string storeBrand = null,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, salesOrderId, storeCode, storeName, employeeCode, employeeName, orderNo, orderType, orderTypeName, orderDateTimeMin, orderDateTimeMax, orderStatus, orderStatusName, salesChannelCode, salesChannelName, hasDelivery, notes, waitingNumber, isTakeAway, pickingTimeMin, pickingTimeMax, snoozingTimeMin, snoozingTimeMax, recievedDateTimeMin, recievedDateTimeMax, performedById, performedByName, performedDateTimeMin, performedDateTimeMax, KitchenStatus, storeBrand);
            return await query.LongCountAsync(GetCancellationToken(cancellationToken));
        }

        protected virtual IQueryable<SalesOrder> ApplyFilter(
            IQueryable<SalesOrder> query,
            string filterText,
            Guid? salesOrderId = null,
            string storeCode = null,
            string storeName = null,
            string employeeCode = null,
            string employeeName = null,
            string orderNo = null,
            string orderType = null,
            string orderTypeName = null,
            DateTime? orderDateTimeMin = null,
            DateTime? orderDateTimeMax = null,
            string orderStatus = null,
            string orderStatusName = null,
            string salesChannelCode = null,
            string salesChannelName = null,
            bool? hasDelivery = null,
            string notes = null,
            string waitingNumber = null,
            bool? isTakeAway = null,
            DateTime? pickingTimeMin = null,
            DateTime? pickingTimeMax = null,
            DateTime? snoozingTimeMin = null,
            DateTime? snoozingTimeMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string KitchenStatus = null,
            string storeBrand = null)
        {
            return query
                    .WhereIf(!string.IsNullOrWhiteSpace(filterText), e => e.StoreCode.Contains(filterText) || e.StoreName.Contains(filterText) || e.EmployeeName.Contains(filterText) || e.OrderNo.Contains(filterText) || e.OrderType.Contains(filterText) || e.OrderTypeName.Contains(filterText) || e.OrderStatus.Contains(filterText) || e.OrderStatusName.Contains(filterText) || e.SalesChannelCode.Contains(filterText) || e.SalesChannelName.Contains(filterText) || e.Notes.Contains(filterText) || e.WaitingNumber.Contains(filterText) || e.PerformedByName.Contains(filterText) || e.KitchenStatus.Contains(filterText))
                    .WhereIf(salesOrderId.HasValue, e => e.SalesOrderId == salesOrderId)
                    .WhereIf(!string.IsNullOrWhiteSpace(storeCode), e => e.StoreCode.Contains(storeCode))
                    .WhereIf(!string.IsNullOrWhiteSpace(storeName), e => e.StoreName.Contains(storeName))
                    .WhereIf(!string.IsNullOrWhiteSpace(employeeName), e => e.EmployeeName.Contains(employeeName))
                    .WhereIf(!string.IsNullOrWhiteSpace(orderNo), e => e.OrderNo.Contains(orderNo))
                    .WhereIf(!string.IsNullOrWhiteSpace(orderType), e => e.OrderType.Contains(orderType))
                    .WhereIf(!string.IsNullOrWhiteSpace(orderTypeName), e => e.OrderTypeName.Contains(orderTypeName))
                    .WhereIf(orderDateTimeMin.HasValue, e => e.OrderDateTime >= orderDateTimeMin.Value)
                    .WhereIf(orderDateTimeMax.HasValue, e => e.OrderDateTime <= orderDateTimeMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(orderStatus), e => e.OrderStatus.Contains(orderStatus))
                    .WhereIf(!string.IsNullOrWhiteSpace(orderStatusName), e => e.OrderStatusName.Contains(orderStatusName))
                    .WhereIf(!string.IsNullOrWhiteSpace(salesChannelCode), e => e.SalesChannelCode.Contains(salesChannelCode))
                    .WhereIf(!string.IsNullOrWhiteSpace(salesChannelName), e => e.SalesChannelName.Contains(salesChannelName))
                    .WhereIf(hasDelivery.HasValue, e => e.HasDelivery == hasDelivery)
                    .WhereIf(!string.IsNullOrWhiteSpace(notes), e => e.Notes.Contains(notes))
                    .WhereIf(!string.IsNullOrWhiteSpace(waitingNumber), e => e.WaitingNumber.Contains(waitingNumber))
                    .WhereIf(pickingTimeMin.HasValue, e => e.PickingTime >= pickingTimeMin.Value)
                    .WhereIf(pickingTimeMax.HasValue, e => e.PickingTime <= pickingTimeMax.Value)
                    .WhereIf(snoozingTimeMin.HasValue, e => e.SnoozingTime >= snoozingTimeMin.Value)
                    .WhereIf(snoozingTimeMax.HasValue, e => e.SnoozingTime <= snoozingTimeMax.Value)
                    .WhereIf(recievedDateTimeMin.HasValue, e => e.RecievedDateTime >= recievedDateTimeMin.Value)
                    .WhereIf(recievedDateTimeMax.HasValue, e => e.RecievedDateTime <= recievedDateTimeMax.Value)
                    .WhereIf(performedById.HasValue, e => e.PerformedById == performedById)
                    .WhereIf(!string.IsNullOrWhiteSpace(performedByName), e => e.PerformedByName.Contains(performedByName))
                    .WhereIf(performedDateTimeMin.HasValue, e => e.PerformedDateTime >= performedDateTimeMin.Value)
                    .WhereIf(performedDateTimeMax.HasValue, e => e.PerformedDateTime <= performedDateTimeMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(KitchenStatus), e => e.KitchenStatus.Contains(KitchenStatus))
                    .WhereIf(!string.IsNullOrWhiteSpace(storeBrand), e => e.StoreBrand.Contains(storeBrand));
        }
       
        public async Task<IQueryable<SalesOrder>> GetAsyncWithInclude(Expression<Func<SalesOrder, bool>> predicate, params Expression<Func<SalesOrder, object>>[] includeProperties)
        {
            var saleOrder = await Task.Run(() => DbSet.Where(predicate));
            saleOrder = saleOrder.Expand(includeProperties);

            return saleOrder;
        }
    }
}