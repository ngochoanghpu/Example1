using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Volo.Abp.Domain.Repositories.EntityFrameworkCore;
using Volo.Abp.EntityFrameworkCore;
using kitchen.EntityFrameworkCore;

namespace kitchen.KitchenConfigurations
{
    public class EfCoreKitchenConfigurationRepository : EfCoreRepository<kitchenDbContext, KitchenConfiguration, Guid>, IKitchenConfigurationRepository
    {
        public EfCoreKitchenConfigurationRepository(IDbContextProvider<kitchenDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        public async Task<List<KitchenConfiguration>> GetListAsync(
            string filterText = null,
            string storeCode = null,
            int? displayColumnsMin = null,
            int? displayColumnsMax = null,
            int? billNoDisplayLengthMin = null,
            int? billNoDisplayLengthMax = null,
            bool? autoPrintBill = null,
            string itemCheckBgColor = null,
            string ItemCheckTextColor = null,
            string billCancelledBgColor = null,
            int? threshold1ValueMin = null,
            int? threshold1ValueMax = null,
            string underThreshold1BgColor = null,
            string underThreshold1TextColor = null,
            int? threshold2ValueMin = null,
            int? threshold2ValueMax = null,
            string underThreshold2BgColor = null,
            string underThreshold2TextColor = null,
            string overThreshold3BgColor = null,
            string overThreshold3TextColor = null,
            string itemLockBgColor = null,
            string itemLockTextColor = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, storeCode, displayColumnsMin, displayColumnsMax, billNoDisplayLengthMin, billNoDisplayLengthMax, autoPrintBill, itemCheckBgColor, ItemCheckTextColor, billCancelledBgColor, threshold1ValueMin, threshold1ValueMax, underThreshold1BgColor, underThreshold1TextColor, threshold2ValueMin, threshold2ValueMax, underThreshold2BgColor, underThreshold2TextColor, overThreshold3BgColor, overThreshold3TextColor, itemLockBgColor, itemLockTextColor);
            query = query.OrderBy(string.IsNullOrWhiteSpace(sorting) ? KitchenConfigurationConsts.DefaultSorting : sorting);
            return await query.PageBy(skipCount, maxResultCount).ToListAsync(cancellationToken);
        }

        public async Task<long> GetCountAsync(
            string filterText = null,
            string storeCode = null,
            int? displayColumnsMin = null,
            int? displayColumnsMax = null,
            int? billNoDisplayLengthMin = null,
            int? billNoDisplayLengthMax = null,
            bool? autoPrintBill = null,
            string itemCheckBgColor = null,
            string ItemCheckTextColor = null,
            string billCancelledBgColor = null,
            int? threshold1ValueMin = null,
            int? threshold1ValueMax = null,
            string underThreshold1BgColor = null,
            string underThreshold1TextColor = null,
            int? threshold2ValueMin = null,
            int? threshold2ValueMax = null,
            string underThreshold2BgColor = null,
            string underThreshold2TextColor = null,
            string overThreshold3BgColor = null,
            string overThreshold3TextColor = null,
            string itemLockBgColor = null,
            string itemLockTextColor = null,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, storeCode, displayColumnsMin, displayColumnsMax, billNoDisplayLengthMin, billNoDisplayLengthMax, autoPrintBill, itemCheckBgColor, ItemCheckTextColor, billCancelledBgColor, threshold1ValueMin, threshold1ValueMax, underThreshold1BgColor, underThreshold1TextColor, threshold2ValueMin, threshold2ValueMax, underThreshold2BgColor, underThreshold2TextColor, overThreshold3BgColor, overThreshold3TextColor, itemLockBgColor, itemLockTextColor);
            return await query.LongCountAsync(GetCancellationToken(cancellationToken));
        }

        protected virtual IQueryable<KitchenConfiguration> ApplyFilter(
            IQueryable<KitchenConfiguration> query,
            string filterText,
            string storeCode = null,
            int? displayColumnsMin = null,
            int? displayColumnsMax = null,
            int? billNoDisplayLengthMin = null,
            int? billNoDisplayLengthMax = null,
            bool? autoPrintBill = null,
            string itemCheckBgColor = null,
            string ItemCheckTextColor = null,
            string billCancelledBgColor = null,
            int? threshold1ValueMin = null,
            int? threshold1ValueMax = null,
            string underThreshold1BgColor = null,
            string underThreshold1TextColor = null,
            int? threshold2ValueMin = null,
            int? threshold2ValueMax = null,
            string underThreshold2BgColor = null,
            string underThreshold2TextColor = null,
            string overThreshold3BgColor = null,
            string overThreshold3TextColor = null,
            string itemLockBgColor = null,
            string itemLockTextColor = null)
        {
            return query
                    .WhereIf(!string.IsNullOrWhiteSpace(filterText), e => e.StoreCode.Contains(filterText) || e.ItemCheckBgColor.Contains(filterText) || e.ItemCheckTextColor.Contains(filterText) || e.BillCancelledBgColor.Contains(filterText) || e.UnderThreshold1BgColor.Contains(filterText) || e.UnderThreshold1TextColor.Contains(filterText) || e.UnderThreshold2BgColor.Contains(filterText) || e.UnderThreshold2TextColor.Contains(filterText) || e.OverThreshold3BgColor.Contains(filterText) || e.OverThreshold3TextColor.Contains(filterText))
                    .WhereIf(!string.IsNullOrWhiteSpace(storeCode), e => e.StoreCode.Contains(storeCode))
                    .WhereIf(displayColumnsMin.HasValue, e => e.DisplayColumns >= displayColumnsMin.Value)
                    .WhereIf(displayColumnsMax.HasValue, e => e.DisplayColumns <= displayColumnsMax.Value)
                    .WhereIf(billNoDisplayLengthMin.HasValue, e => e.BillNoDisplayLength >= billNoDisplayLengthMin.Value)
                    .WhereIf(billNoDisplayLengthMax.HasValue, e => e.BillNoDisplayLength <= billNoDisplayLengthMax.Value)
                    .WhereIf(autoPrintBill.HasValue, e => e.AutoPrintBill == autoPrintBill)
                    .WhereIf(!string.IsNullOrWhiteSpace(itemCheckBgColor), e => e.ItemCheckBgColor.Contains(itemCheckBgColor))
                    .WhereIf(!string.IsNullOrWhiteSpace(ItemCheckTextColor), e => e.ItemCheckTextColor.Contains(ItemCheckTextColor))
                    .WhereIf(!string.IsNullOrWhiteSpace(billCancelledBgColor), e => e.BillCancelledBgColor.Contains(billCancelledBgColor))
                    .WhereIf(threshold1ValueMin.HasValue, e => e.Threshold1Value >= threshold1ValueMin.Value)
                    .WhereIf(threshold1ValueMax.HasValue, e => e.Threshold1Value <= threshold1ValueMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(underThreshold1BgColor), e => e.UnderThreshold1BgColor.Contains(underThreshold1BgColor))
                    .WhereIf(!string.IsNullOrWhiteSpace(underThreshold1TextColor), e => e.UnderThreshold1TextColor.Contains(underThreshold1TextColor))
                    .WhereIf(threshold2ValueMin.HasValue, e => e.Threshold2Value >= threshold2ValueMin.Value)
                    .WhereIf(threshold2ValueMax.HasValue, e => e.Threshold2Value <= threshold2ValueMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(underThreshold2BgColor), e => e.UnderThreshold2BgColor.Contains(underThreshold2BgColor))
                    .WhereIf(!string.IsNullOrWhiteSpace(underThreshold2TextColor), e => e.UnderThreshold2TextColor.Contains(underThreshold2TextColor))
                    .WhereIf(!string.IsNullOrWhiteSpace(overThreshold3BgColor), e => e.OverThreshold3BgColor.Contains(overThreshold3BgColor))
                    .WhereIf(!string.IsNullOrWhiteSpace(overThreshold3TextColor), e => e.OverThreshold3TextColor.Contains(overThreshold3TextColor))
                    .WhereIf(!string.IsNullOrWhiteSpace(itemLockBgColor), e => e.ItemLockBgColor.Contains(itemLockBgColor))
                    .WhereIf(!string.IsNullOrWhiteSpace(itemLockTextColor), e => e.OverThreshold3TextColor.Contains(itemLockTextColor));
        }
    }
}