using kitchen.SalesOrderDetailStatusHistories;
using kitchen.SalesOrderStatusHistories;
using kitchen.SalesOrderDetails;
using Volo.Abp.EntityFrameworkCore.Modeling;
using kitchen.SalesOrders;
using kitchen.KitchenConfigurations;
using Microsoft.EntityFrameworkCore;
using Volo.Abp;

namespace kitchen.EntityFrameworkCore
{
    public static class kitchenDbContextModelCreatingExtensions
    {
        public static void Configurekitchen(this ModelBuilder builder)
        {
            Check.NotNull(builder, nameof(builder));

            /* Configure your own tables/entities inside here */

            //builder.Entity<YourEntity>(b =>
            //{
            //    b.ToTable(kitchenConsts.DbTablePrefix + "YourEntities", kitchenConsts.DbSchema);

            //    //...
            //});

            builder.Entity<KitchenConfiguration>(b =>
            {
                b.ToTable(kitchenConsts.DbTablePrefix + "KitchenConfigurations", kitchenConsts.DbSchema);
                b.ConfigureByConvention();

                b.Property(x => x.TenantId).HasColumnName(nameof(KitchenConfiguration.TenantId));
                b.Property(x => x.StoreCode).HasColumnName(nameof(KitchenConfiguration.StoreCode)).IsRequired();
                b.Property(x => x.DisplayColumns).HasColumnName(nameof(KitchenConfiguration.DisplayColumns)).IsRequired();
                b.Property(x => x.BillNoDisplayLength).HasColumnName(nameof(KitchenConfiguration.BillNoDisplayLength)).IsRequired();
                b.Property(x => x.AutoPrintBill).HasColumnName(nameof(KitchenConfiguration.AutoPrintBill)).IsRequired();
                b.Property(x => x.ItemCheckBgColor).HasColumnName(nameof(KitchenConfiguration.ItemCheckBgColor)).IsRequired();
                b.Property(x => x.ItemCheckTextColor).HasColumnName(nameof(KitchenConfiguration.ItemCheckTextColor)).IsRequired();
                b.Property(x => x.BillCancelledBgColor).HasColumnName(nameof(KitchenConfiguration.BillCancelledBgColor)).IsRequired();
                b.Property(x => x.Threshold1Value).HasColumnName(nameof(KitchenConfiguration.Threshold1Value)).IsRequired();
                b.Property(x => x.UnderThreshold1BgColor).HasColumnName(nameof(KitchenConfiguration.UnderThreshold1BgColor)).IsRequired();
                b.Property(x => x.UnderThreshold1TextColor).HasColumnName(nameof(KitchenConfiguration.UnderThreshold1TextColor)).IsRequired();
                b.Property(x => x.Threshold2Value).HasColumnName(nameof(KitchenConfiguration.Threshold2Value));
                b.Property(x => x.UnderThreshold2BgColor).HasColumnName(nameof(KitchenConfiguration.UnderThreshold2BgColor)).IsRequired();
                b.Property(x => x.UnderThreshold2TextColor).HasColumnName(nameof(KitchenConfiguration.UnderThreshold2TextColor)).IsRequired();
                b.Property(x => x.OverThreshold3BgColor).HasColumnName(nameof(KitchenConfiguration.OverThreshold3BgColor)).IsRequired();
                b.Property(x => x.OverThreshold3TextColor).HasColumnName(nameof(KitchenConfiguration.OverThreshold3TextColor)).IsRequired();
                b.Property(x => x.ItemLockBgColor).HasColumnName(nameof(KitchenConfiguration.ItemLockBgColor)).IsRequired();
                b.Property(x => x.ItemLockTextColor).HasColumnName(nameof(KitchenConfiguration.ItemLockTextColor)).IsRequired();

            });

            builder.Entity<SalesOrder>(b =>
            {
                b.ToTable(kitchenConsts.DbTablePrefix + "SalesOrders", kitchenConsts.DbSchema);
                b.ConfigureByConvention();

                b.Property(x => x.TenantId).HasColumnName(nameof(SalesOrder.TenantId));
                b.Property(x => x.SalesOrderId).HasColumnName(nameof(SalesOrder.SalesOrderId));
                b.Property(x => x.StoreCode).HasColumnName(nameof(SalesOrder.StoreCode));
                b.Property(x => x.StoreName).HasColumnName(nameof(SalesOrder.StoreName));
                b.Property(x => x.EmployeeCode).HasColumnName(nameof(SalesOrder.EmployeeCode));
                b.Property(x => x.EmployeeName).HasColumnName(nameof(SalesOrder.EmployeeName));
                b.Property(x => x.OrderNo).HasColumnName(nameof(SalesOrder.OrderNo));
                b.Property(x => x.OrderType).HasColumnName(nameof(SalesOrder.OrderType));
                b.Property(x => x.OrderTypeName).HasColumnName(nameof(SalesOrder.OrderTypeName));
                b.Property(x => x.OrderDateTime).HasColumnName(nameof(SalesOrder.OrderDateTime));
                b.Property(x => x.OrderStatus).HasColumnName(nameof(SalesOrder.OrderStatus));
                b.Property(x => x.OrderStatusName).HasColumnName(nameof(SalesOrder.OrderStatusName));
                b.Property(x => x.SalesChannelCode).HasColumnName(nameof(SalesOrder.SalesChannelCode));
                b.Property(x => x.SalesChannelName).HasColumnName(nameof(SalesOrder.SalesChannelName));
                b.Property(x => x.HasDelivery).HasColumnName(nameof(SalesOrder.HasDelivery));
                b.Property(x => x.Notes).HasColumnName(nameof(SalesOrder.Notes));
                b.Property(x => x.WaitingNumber).HasColumnName(nameof(SalesOrder.WaitingNumber));
                b.Property(x => x.PickingTime).HasColumnName(nameof(SalesOrder.PickingTime));
                b.Property(x => x.SnoozingTime).HasColumnName(nameof(SalesOrder.SnoozingTime));
                b.Property(x => x.RecievedDateTime).HasColumnName(nameof(SalesOrder.RecievedDateTime));
                b.Property(x => x.PerformedById).HasColumnName(nameof(SalesOrder.PerformedById));
                b.Property(x => x.PerformedByName).HasColumnName(nameof(SalesOrder.PerformedByName));
                b.Property(x => x.PerformedDateTime).HasColumnName(nameof(SalesOrder.PerformedDateTime));
                b.Property(x => x.StoreBrand).HasColumnName(nameof(SalesOrder.StoreBrand));
                b.Property(x => x.KitchenStatus).HasColumnName(nameof(SalesOrder.KitchenStatus));

            });

            builder.Entity<SalesOrderDetail>(b =>
            {
                b.ToTable(kitchenConsts.DbTablePrefix + "SalesOrderDetails", kitchenConsts.DbSchema);
                b.ConfigureByConvention();

                b.HasOne(r => r.SalesOrder).WithMany(r => r.SalesOrderDetails).HasForeignKey(r => r.SalesOrderId);
                b.Property(x => x.TenantId).HasColumnName(nameof(SalesOrderDetail.TenantId));
                b.Property(x => x.SalesOrderId).HasColumnName(nameof(SalesOrderDetail.SalesOrderId));
                b.Property(x => x.SalesOrderDetailId).HasColumnName(nameof(SalesOrderDetail.SalesOrderDetailId));
                b.Property(x => x.SequentiaNumber).HasColumnName(nameof(SalesOrderDetail.SequentiaNumber));
                b.Property(x => x.BarCode1).HasColumnName(nameof(SalesOrderDetail.BarCode1));
                b.Property(x => x.BarCode2).HasColumnName(nameof(SalesOrderDetail.BarCode2));
                b.Property(x => x.ItemCode).HasColumnName(nameof(SalesOrderDetail.ItemCode));
                b.Property(x => x.ProductName).HasColumnName(nameof(SalesOrderDetail.ProductName));
                b.Property(x => x.SerialNumber).HasColumnName(nameof(SalesOrderDetail.SerialNumber));
                b.Property(x => x.LotNumber).HasColumnName(nameof(SalesOrderDetail.LotNumber));
                b.Property(x => x.UOSCode).HasColumnName(nameof(SalesOrderDetail.UOSCode));
                b.Property(x => x.UOSName).HasColumnName(nameof(SalesOrderDetail.UOSName));
                b.Property(x => x.UOSQuantity).HasColumnName(nameof(SalesOrderDetail.UOSQuantity));
                b.Property(x => x.UOMCode).HasColumnName(nameof(SalesOrderDetail.UOMCode));
                b.Property(x => x.UOMQuantity).HasColumnName(nameof(SalesOrderDetail.UOMQuantity));
                b.Property(x => x.Notes).HasColumnName(nameof(SalesOrderDetail.Notes));
                b.Property(x => x.IsChild).HasColumnName(nameof(SalesOrderDetail.IsChild));
                b.Property(x => x.IndexNumber).HasColumnName(nameof(SalesOrderDetail.IndexNumber));
                b.Property(x => x.SalesOrderDetailStaus).HasColumnName(nameof(SalesOrderDetail.SalesOrderDetailStaus));
                b.Property(x => x.IsOptional).HasColumnName(nameof(SalesOrderDetail.IsOptional));
                b.Property(x => x.RecievedDateTime).HasColumnName(nameof(SalesOrderDetail.RecievedDateTime));
                b.Property(x => x.PerformedById).HasColumnName(nameof(SalesOrderDetail.PerformedById));
                b.Property(x => x.PerformedByName).HasColumnName(nameof(SalesOrderDetail.PerformedByName));
                b.Property(x => x.PerformedDateTime).HasColumnName(nameof(SalesOrderDetail.PerformedDateTime));
                b.Property(x => x.KitchenStatus).HasColumnName(nameof(SalesOrderDetail.KitchenStatus));
                b.Property(x => x.ProductGroupCode).HasColumnName(nameof(SalesOrderDetail.ProductGroupCode));
                b.Property(x => x.ProcductGroupIndex).HasColumnName(nameof(SalesOrderDetail.ProcductGroupIndex));
            });

            builder.Entity<SalesOrderDetailStatusHistory>(b =>
            {
                b.ToTable(kitchenConsts.DbTablePrefix + "SalesOrderDetailStatusHistories", kitchenConsts.DbSchema);
                b.ConfigureByConvention();

                b.Property(x => x.TenantId).HasColumnName(nameof(SalesOrderDetailStatusHistory.TenantId));
                b.Property(x => x.SalesOrderId).HasColumnName(nameof(SalesOrderDetailStatusHistory.SalesOrderId));
                b.Property(x => x.SalesOrderDetailId).HasColumnName(nameof(SalesOrderDetailStatusHistory.SalesOrderDetailId));
                b.Property(x => x.SalesOrderDetailStatus).HasColumnName(nameof(SalesOrderDetailStatusHistory.SalesOrderDetailStatus));
                b.Property(x => x.KitchenStatus).HasColumnName(nameof(SalesOrderDetailStatusHistory.KitchenStatus));
                b.Property(x => x.Notes).HasColumnName(nameof(SalesOrderDetailStatusHistory.Notes));
                b.Property(x => x.ChangedById).HasColumnName(nameof(SalesOrderDetailStatusHistory.ChangedById));
                b.Property(x => x.ChangedByUserName).HasColumnName(nameof(SalesOrderDetailStatusHistory.ChangedByUserName));
                b.Property(x => x.ChangedByDateTime).HasColumnName(nameof(SalesOrderDetailStatusHistory.ChangedByDateTime));

            });

            builder.Entity<SalesOrderStatusHistory>(b =>
            {
                b.ToTable(kitchenConsts.DbTablePrefix + "SalesOrderStatusHistories", kitchenConsts.DbSchema);
                b.ConfigureByConvention();

                b.Property(x => x.TenantId).HasColumnName(nameof(SalesOrderStatusHistory.TenantId));
                b.Property(x => x.SalesOrderId).HasColumnName(nameof(SalesOrderStatusHistory.SalesOrderId));
                b.Property(x => x.Status).HasColumnName(nameof(SalesOrderStatusHistory.Status));
                b.Property(x => x.KitchenStatus).HasColumnName(nameof(SalesOrderStatusHistory.KitchenStatus));
                b.Property(x => x.Notes).HasColumnName(nameof(SalesOrderStatusHistory.Notes));
                b.Property(x => x.ChangedById).HasColumnName(nameof(SalesOrderStatusHistory.ChangedById));
                b.Property(x => x.ChangedByUserName).HasColumnName(nameof(SalesOrderStatusHistory.ChangedByUserName));
                b.Property(x => x.ChangedByDateTime).HasColumnName(nameof(SalesOrderStatusHistory.ChangedByDateTime));

            });
        }
    }
}