using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Volo.Abp.Domain.Repositories.EntityFrameworkCore;
using Volo.Abp.EntityFrameworkCore;
using kitchen.EntityFrameworkCore;

namespace kitchen.SalesOrderDetailStatusHistories
{
    public class EfCoreSalesOrderDetailStatusHistoryRepository : EfCoreRepository<kitchenDbContext, SalesOrderDetailStatusHistory, Guid>, ISalesOrderDetailStatusHistoryRepository
    {
        public EfCoreSalesOrderDetailStatusHistoryRepository(IDbContextProvider<kitchenDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        public async Task<List<SalesOrderDetailStatusHistory>> GetListAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            string salesOrderDetailStatus = null,
            string kitchenStatus = null,
            string notes = null,
            Guid? changedById = null,
            string changedByUserName = null,
            string changedByDateTime = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, salesOrderId, salesOrderDetailId, salesOrderDetailStatus, kitchenStatus, notes, changedById, changedByUserName, changedByDateTime);
            query = query.OrderBy(string.IsNullOrWhiteSpace(sorting) ? SalesOrderDetailStatusHistoryConsts.DefaultSorting : sorting);
            return await query.PageBy(skipCount, maxResultCount).ToListAsync(cancellationToken);
        }

        public async Task<long> GetCountAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            string salesOrderDetailStatus = null,
            string kitchenStatus = null,
            string notes = null,
            Guid? changedById = null,
            string changedByUserName = null,
            string changedByDateTime = null,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, salesOrderId, salesOrderDetailId, salesOrderDetailStatus, kitchenStatus, notes, changedById, changedByUserName, changedByDateTime);
            return await query.LongCountAsync(GetCancellationToken(cancellationToken));
        }

        protected virtual IQueryable<SalesOrderDetailStatusHistory> ApplyFilter(
            IQueryable<SalesOrderDetailStatusHistory> query,
            string filterText,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            string salesOrderDetailStatus = null,
            string kitchenStatus = null,
            string notes = null,
            Guid? changedById = null,
            string changedByUserName = null,
            string changedByDateTime = null)
        {
            return query
                    .WhereIf(!string.IsNullOrWhiteSpace(filterText), e => e.SalesOrderDetailStatus.Contains(filterText) || e.KitchenStatus.Contains(filterText) || e.Notes.Contains(filterText) || e.ChangedByUserName.Contains(filterText) || e.ChangedByDateTime.Contains(filterText))
                    .WhereIf(salesOrderId.HasValue, e => e.SalesOrderId == salesOrderId)
                    .WhereIf(salesOrderDetailId.HasValue, e => e.SalesOrderDetailId == salesOrderDetailId)
                    .WhereIf(!string.IsNullOrWhiteSpace(salesOrderDetailStatus), e => e.SalesOrderDetailStatus.Contains(salesOrderDetailStatus))
                    .WhereIf(!string.IsNullOrWhiteSpace(kitchenStatus), e => e.KitchenStatus.Contains(kitchenStatus))
                    .WhereIf(!string.IsNullOrWhiteSpace(notes), e => e.Notes.Contains(notes))
                    .WhereIf(changedById.HasValue, e => e.ChangedById == changedById)
                    .WhereIf(!string.IsNullOrWhiteSpace(changedByUserName), e => e.ChangedByUserName.Contains(changedByUserName))
                    .WhereIf(!string.IsNullOrWhiteSpace(changedByDateTime), e => e.ChangedByDateTime.Contains(changedByDateTime));
        }
    }
}