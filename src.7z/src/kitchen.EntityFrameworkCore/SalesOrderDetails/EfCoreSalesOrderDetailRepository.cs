using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Volo.Abp.Domain.Repositories.EntityFrameworkCore;
using Volo.Abp.EntityFrameworkCore;
using kitchen.EntityFrameworkCore;

namespace kitchen.SalesOrderDetails
{
    public class EfCoreSalesOrderDetailRepository : EfCoreRepository<kitchenDbContext, SalesOrderDetail, Guid>, ISalesOrderDetailRepository
    {
        public EfCoreSalesOrderDetailRepository(IDbContextProvider<kitchenDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        public async Task<List<SalesOrderDetail>> GetListAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            int? sequentiaNumberMin = null,
            int? sequentiaNumberMax = null,
            string barCode1 = null,
            string barCode2 = null,
            string itemCode = null,
            string productName = null,
            string serialNumber = null,
            string lotNumber = null,
            string uOSCode = null,
            string uOSName = null,
            decimal? uOSQuantityMin = null,
            decimal? uOSQuantityMax = null,
            string uOMCode = null,
            decimal? uOMQuantityMin = null,
            decimal? uOMQuantityMax = null,
            string notes = null,
            bool? isChild = null,
            int? indexNumberMin = null,
            int? indexNumberMax = null,
            string salesOrderDetailStaus = null,
            bool? isOptional = null,
            string productHierarchyCode = null,
            string productHierarchyName = null,
            int? productHierarchyOrderMin = null,
            int? productHierarchyOrderMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string kitchenStatus = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, salesOrderId, salesOrderDetailId, sequentiaNumberMin, sequentiaNumberMax, barCode1, barCode2, itemCode, productName, serialNumber, lotNumber, uOSCode, uOSName, uOSQuantityMin, uOSQuantityMax, uOMCode, uOMQuantityMin, uOMQuantityMax, notes, isChild, indexNumberMin, indexNumberMax, salesOrderDetailStaus, isOptional, productHierarchyCode, productHierarchyName, productHierarchyOrderMin, productHierarchyOrderMax, recievedDateTimeMin, recievedDateTimeMax, performedById, performedByName, performedDateTimeMin, performedDateTimeMax, kitchenStatus);
            query = query.OrderBy(string.IsNullOrWhiteSpace(sorting) ? SalesOrderDetailConsts.DefaultSorting : sorting);
            return await query.PageBy(skipCount, maxResultCount).ToListAsync(cancellationToken);
        }

        public async Task<long> GetCountAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            int? sequentiaNumberMin = null,
            int? sequentiaNumberMax = null,
            string barCode1 = null,
            string barCode2 = null,
            string itemCode = null,
            string productName = null,
            string serialNumber = null,
            string lotNumber = null,
            string uOSCode = null,
            string uOSName = null,
            decimal? uOSQuantityMin = null,
            decimal? uOSQuantityMax = null,
            string uOMCode = null,
            decimal? uOMQuantityMin = null,
            decimal? uOMQuantityMax = null,
            string notes = null,
            bool? isChild = null,
            int? indexNumberMin = null,
            int? indexNumberMax = null,
            string salesOrderDetailStaus = null,
            bool? isOptional = null,
            string productHierarchyCode = null,
            string productHierarchyName = null,
            int? productHierarchyOrderMin = null,
            int? productHierarchyOrderMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string kitchenStatus = null,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, salesOrderId, salesOrderDetailId, sequentiaNumberMin, sequentiaNumberMax, barCode1, barCode2, itemCode, productName, serialNumber, lotNumber, uOSCode, uOSName, uOSQuantityMin, uOSQuantityMax, uOMCode, uOMQuantityMin, uOMQuantityMax, notes, isChild, indexNumberMin, indexNumberMax, salesOrderDetailStaus, isOptional, productHierarchyCode, productHierarchyName, productHierarchyOrderMin, productHierarchyOrderMax, recievedDateTimeMin, recievedDateTimeMax, performedById, performedByName, performedDateTimeMin, performedDateTimeMax, kitchenStatus);
            return await query.LongCountAsync(GetCancellationToken(cancellationToken));
        }

        protected virtual IQueryable<SalesOrderDetail> ApplyFilter(
            IQueryable<SalesOrderDetail> query,
            string filterText,
            Guid? salesOrderId = null,
            Guid? salesOrderDetailId = null,
            int? sequentiaNumberMin = null,
            int? sequentiaNumberMax = null,
            string barCode1 = null,
            string barCode2 = null,
            string itemCode = null,
            string productName = null,
            string serialNumber = null,
            string lotNumber = null,
            string uOSCode = null,
            string uOSName = null,
            decimal? uOSQuantityMin = null,
            decimal? uOSQuantityMax = null,
            string uOMCode = null,
            decimal? uOMQuantityMin = null,
            decimal? uOMQuantityMax = null,
            string notes = null,
            bool? isChild = null,
            int? indexNumberMin = null,
            int? indexNumberMax = null,
            string salesOrderDetailStaus = null,
            bool? isOptional = null,
            string productHierarchyCode = null,
            string productHierarchyName = null,
            int? productHierarchyOrderMin = null,
            int? productHierarchyOrderMax = null,
            DateTime? recievedDateTimeMin = null,
            DateTime? recievedDateTimeMax = null,
            Guid? performedById = null,
            string performedByName = null,
            DateTime? performedDateTimeMin = null,
            DateTime? performedDateTimeMax = null,
            string kitchenStatus = null)
        {
            return query
                    .WhereIf(!string.IsNullOrWhiteSpace(filterText), e => e.BarCode1.Contains(filterText) || e.BarCode2.Contains(filterText) || e.ItemCode.Contains(filterText) || e.ProductName.Contains(filterText) || e.SerialNumber.Contains(filterText) || e.LotNumber.Contains(filterText) || e.UOSCode.Contains(filterText) || e.UOSName.Contains(filterText) || e.UOMCode.Contains(filterText) || e.Notes.Contains(filterText) || e.SalesOrderDetailStaus.Contains(filterText) || e.PerformedByName.Contains(filterText) || e.KitchenStatus.Contains(filterText))
                    .WhereIf(salesOrderId.HasValue, e => e.SalesOrderId == salesOrderId)
                    .WhereIf(salesOrderDetailId.HasValue, e => e.SalesOrderDetailId == salesOrderDetailId)
                    .WhereIf(sequentiaNumberMin.HasValue, e => e.SequentiaNumber >= sequentiaNumberMin.Value)
                    .WhereIf(sequentiaNumberMax.HasValue, e => e.SequentiaNumber <= sequentiaNumberMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(barCode1), e => e.BarCode1.Contains(barCode1))
                    .WhereIf(!string.IsNullOrWhiteSpace(barCode2), e => e.BarCode2.Contains(barCode2))
                    .WhereIf(!string.IsNullOrWhiteSpace(itemCode), e => e.ItemCode.Contains(itemCode))
                    .WhereIf(!string.IsNullOrWhiteSpace(productName), e => e.ProductName.Contains(productName))
                    .WhereIf(!string.IsNullOrWhiteSpace(serialNumber), e => e.SerialNumber.Contains(serialNumber))
                    .WhereIf(!string.IsNullOrWhiteSpace(lotNumber), e => e.LotNumber.Contains(lotNumber))
                    .WhereIf(!string.IsNullOrWhiteSpace(uOSCode), e => e.UOSCode.Contains(uOSCode))
                    .WhereIf(!string.IsNullOrWhiteSpace(uOSName), e => e.UOSName.Contains(uOSName))
                    .WhereIf(uOSQuantityMin.HasValue, e => e.UOSQuantity >= uOSQuantityMin.Value)
                    .WhereIf(uOSQuantityMax.HasValue, e => e.UOSQuantity <= uOSQuantityMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(uOMCode), e => e.UOMCode.Contains(uOMCode))
                    .WhereIf(uOMQuantityMin.HasValue, e => e.UOMQuantity >= uOMQuantityMin.Value)
                    .WhereIf(uOMQuantityMax.HasValue, e => e.UOMQuantity <= uOMQuantityMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(notes), e => e.Notes.Contains(notes))
                    .WhereIf(isChild.HasValue, e => e.IsChild == isChild)
                    .WhereIf(indexNumberMin.HasValue, e => e.IndexNumber >= indexNumberMin.Value)
                    .WhereIf(indexNumberMax.HasValue, e => e.IndexNumber <= indexNumberMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(salesOrderDetailStaus), e => e.SalesOrderDetailStaus.Contains(salesOrderDetailStaus))
                    .WhereIf(isOptional.HasValue, e => e.IsOptional == isOptional)
                    .WhereIf(recievedDateTimeMin.HasValue, e => e.RecievedDateTime >= recievedDateTimeMin.Value)
                    .WhereIf(recievedDateTimeMax.HasValue, e => e.RecievedDateTime <= recievedDateTimeMax.Value)
                    .WhereIf(performedById.HasValue, e => e.PerformedById == performedById)
                    .WhereIf(!string.IsNullOrWhiteSpace(performedByName), e => e.PerformedByName.Contains(performedByName))
                    .WhereIf(performedDateTimeMin.HasValue, e => e.PerformedDateTime >= performedDateTimeMin.Value)
                    .WhereIf(performedDateTimeMax.HasValue, e => e.PerformedDateTime <= performedDateTimeMax.Value)
                    .WhereIf(!string.IsNullOrWhiteSpace(kitchenStatus), e => e.KitchenStatus.Contains(kitchenStatus));
        }
    }
}