using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Volo.Abp.Domain.Repositories.EntityFrameworkCore;
using Volo.Abp.EntityFrameworkCore;
using kitchen.EntityFrameworkCore;

namespace kitchen.SalesOrderStatusHistories
{
    public class EfCoreSalesOrderStatusHistoryRepository : EfCoreRepository<kitchenDbContext, SalesOrderStatusHistory, Guid>, ISalesOrderStatusHistoryRepository
    {
        public EfCoreSalesOrderStatusHistoryRepository(IDbContextProvider<kitchenDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        public async Task<List<SalesOrderStatusHistory>> GetListAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            string status = null,
            string kitchenStatus = null,
            string notes = null,
            Guid? changedById = null,
            string changedByUserName = null,
            string changedByDateTime = null,
            string sorting = null,
            int maxResultCount = int.MaxValue,
            int skipCount = 0,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, salesOrderId, status, kitchenStatus, notes, changedById, changedByUserName, changedByDateTime);
            query = query.OrderBy(string.IsNullOrWhiteSpace(sorting) ? SalesOrderStatusHistoryConsts.DefaultSorting : sorting);
            return await query.PageBy(skipCount, maxResultCount).ToListAsync(cancellationToken);
        }

        public async Task<long> GetCountAsync(
            string filterText = null,
            Guid? salesOrderId = null,
            string status = null,
            string kitchenStatus = null,
            string notes = null,
            Guid? changedById = null,
            string changedByUserName = null,
            string changedByDateTime = null,
            CancellationToken cancellationToken = default)
        {
            var query = ApplyFilter(DbSet, filterText, salesOrderId, status, kitchenStatus, notes, changedById, changedByUserName, changedByDateTime);
            return await query.LongCountAsync(GetCancellationToken(cancellationToken));
        }

        protected virtual IQueryable<SalesOrderStatusHistory> ApplyFilter(
            IQueryable<SalesOrderStatusHistory> query,
            string filterText,
            Guid? salesOrderId = null,
            string status = null,
            string kitchenStatus = null,
            string notes = null,
            Guid? changedById = null,
            string changedByUserName = null,
            string changedByDateTime = null)
        {
            return query
                    .WhereIf(!string.IsNullOrWhiteSpace(filterText), e => e.Status.Contains(filterText) || e.KitchenStatus.Contains(filterText) || e.Notes.Contains(filterText) || e.ChangedByUserName.Contains(filterText) || e.ChangedByDateTime.Contains(filterText))
                    .WhereIf(salesOrderId.HasValue, e => e.SalesOrderId == salesOrderId)
                    .WhereIf(!string.IsNullOrWhiteSpace(status), e => e.Status.Contains(status))
                    .WhereIf(!string.IsNullOrWhiteSpace(kitchenStatus), e => e.KitchenStatus.Contains(kitchenStatus))
                    .WhereIf(!string.IsNullOrWhiteSpace(notes), e => e.Notes.Contains(notes))
                    .WhereIf(changedById.HasValue, e => e.ChangedById == changedById)
                    .WhereIf(!string.IsNullOrWhiteSpace(changedByUserName), e => e.ChangedByUserName.Contains(changedByUserName))
                    .WhereIf(!string.IsNullOrWhiteSpace(changedByDateTime), e => e.ChangedByDateTime.Contains(changedByDateTime));
        }
    }
}