﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace Kitchen.Extensions
{
	public static class IQueryableExtension
	{
		public static IQueryable<TEntity> Expand<TEntity>(this IQueryable<TEntity> queryable, params Expression<Func<TEntity, object>>[] includes) where TEntity : class
		{
			if (includes != null)
			{
				queryable = includes.Aggregate(queryable, (current, include) => current.Include(include));
			}

			return queryable;
		}
	}
}
