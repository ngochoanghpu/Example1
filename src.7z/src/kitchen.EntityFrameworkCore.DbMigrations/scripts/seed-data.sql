﻿-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: kitchen
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appkitchenconfigurations`
--

DROP TABLE IF EXISTS `appkitchenconfigurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appkitchenconfigurations` (
  `Id` char(36) NOT NULL,
  `ExtraProperties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `CreationTime` datetime(6) NOT NULL,
  `CreatorId` char(36) DEFAULT NULL,
  `LastModificationTime` datetime(6) DEFAULT NULL,
  `LastModifierId` char(36) DEFAULT NULL,
  `IsDeleted` tinyint(1) NOT NULL DEFAULT '0',
  `DeleterId` char(36) DEFAULT NULL,
  `DeletionTime` datetime(6) DEFAULT NULL,
  `TenantId` char(36) DEFAULT NULL,
  `StoreCode` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DisplayColumns` int(11) NOT NULL,
  `BillNoDisplayLength` int(11) NOT NULL,
  `AutoPrintBill` tinyint(1) NOT NULL,
  `ItemCheckBgColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ItemCheckTextColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `BillCancelledBgColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Threshold1Value` int(11) NOT NULL,
  `UnderThreshold1BgColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `UnderThreshold1TextColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Threshold2Value` int(11) NOT NULL,
  `UnderThreshold2BgColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `UnderThreshold2TextColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `OverThreshold3BgColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `OverThreshold3TextColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ItemLockBgColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ItemLockTextColor` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appkitchenconfigurations`
--

LOCK TABLES `appkitchenconfigurations` WRITE;
/*!40000 ALTER TABLE `appkitchenconfigurations` DISABLE KEYS */;
INSERT INTO `appkitchenconfigurations` VALUES ('132e6d7a-aec0-11ea-9497-fcaa14401d81',NULL,NULL,'2020-10-20 00:00:00.000000',NULL,NULL,NULL,0,NULL,NULL,NULL,'Store0011',4,4,1,'#c3e8e8','#0000FF','#F4DBDB',5,'#3FBB4A','#0000FF',10,'#feba57','#FFFF00','#FF2000','#FF0000','#F4DBDB','#FF0000');
INSERT INTO `appkitchenconfigurations` VALUES ('132e6d7a-aec0-11ea-9497-fcaa14401d82',NULL,NULL,'2020-10-20 00:00:00.000000',NULL,NULL,NULL,0,NULL,NULL,NULL,'Store0012',4,4,1,'#c3e8e8','#0000FF','#F4DBDB',5,'#3FBB4A','#0000FF',10,'#feba57','#FFFF00','#FF2000','#FF0000','#F4DBDB','#FF0000');
/*!40000 ALTER TABLE `appkitchenconfigurations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-23 16:08:37
