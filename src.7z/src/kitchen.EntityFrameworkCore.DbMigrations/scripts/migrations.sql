﻿CREATE TABLE IF NOT EXISTS `__EFMigrationsHistory` (
    `MigrationId` varchar(95) NOT NULL,
    `ProductVersion` varchar(32) NOT NULL,
    CONSTRAINT `PK___EFMigrationsHistory` PRIMARY KEY (`MigrationId`)
);


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200701031643_InitialCreate') THEN

    CREATE TABLE `AppKitchenConfigurations` (
        `Id` char(36) NOT NULL,
        `ExtraProperties` longtext CHARACTER SET utf8mb4 NULL,
        `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 NULL,
        `CreationTime` datetime(6) NOT NULL,
        `CreatorId` char(36) NULL,
        `LastModificationTime` datetime(6) NULL,
        `LastModifierId` char(36) NULL,
        `IsDeleted` tinyint(1) NOT NULL DEFAULT FALSE,
        `DeleterId` char(36) NULL,
        `DeletionTime` datetime(6) NULL,
        `TenantId` char(36) NULL,
        `StoreCode` longtext CHARACTER SET utf8mb4 NOT NULL,
        `DisplayColumns` int NOT NULL,
        `BillNoDisplayLength` int NOT NULL,
        `AutoPrintBill` tinyint(1) NOT NULL,
        `ItemCheckBgColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `ItemCheckTextColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `BillCancelledBgColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `Threshold1Value` int NOT NULL,
        `UnderThreshold1BgColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `UnderThreshold1TextColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `Threshold2Value` int NOT NULL,
        `UnderThreshold2BgColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `UnderThreshold2TextColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `OverThreshold3BgColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `OverThreshold3TextColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `ItemLockBgColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        `ItemLockTextColor` longtext CHARACTER SET utf8mb4 NOT NULL,
        CONSTRAINT `PK_AppKitchenConfigurations` PRIMARY KEY (`Id`)
    );

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200701031643_InitialCreate') THEN

    CREATE TABLE `AppSalesOrderDetailStatusHistories` (
        `Id` char(36) NOT NULL,
        `ExtraProperties` longtext CHARACTER SET utf8mb4 NULL,
        `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 NULL,
        `CreationTime` datetime(6) NOT NULL,
        `CreatorId` char(36) NULL,
        `LastModificationTime` datetime(6) NULL,
        `LastModifierId` char(36) NULL,
        `IsDeleted` tinyint(1) NOT NULL DEFAULT FALSE,
        `DeleterId` char(36) NULL,
        `DeletionTime` datetime(6) NULL,
        `TenantId` char(36) NULL,
        `SalesOrderId` char(36) NULL,
        `SalesOrderDetailId` char(36) NULL,
        `SalesOrderDetailStatus` longtext CHARACTER SET utf8mb4 NULL,
        `KitchenStatus` longtext CHARACTER SET utf8mb4 NULL,
        `Notes` longtext CHARACTER SET utf8mb4 NULL,
        `ChangedById` char(36) NULL,
        `ChangedByUserName` longtext CHARACTER SET utf8mb4 NULL,
        `ChangedByDateTime` longtext CHARACTER SET utf8mb4 NULL,
        CONSTRAINT `PK_AppSalesOrderDetailStatusHistories` PRIMARY KEY (`Id`)
    );

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200701031643_InitialCreate') THEN

    CREATE TABLE `AppSalesOrders` (
        `Id` char(36) NOT NULL,
        `ExtraProperties` longtext CHARACTER SET utf8mb4 NULL,
        `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 NULL,
        `CreationTime` datetime(6) NOT NULL,
        `CreatorId` char(36) NULL,
        `LastModificationTime` datetime(6) NULL,
        `LastModifierId` char(36) NULL,
        `IsDeleted` tinyint(1) NOT NULL DEFAULT FALSE,
        `DeleterId` char(36) NULL,
        `DeletionTime` datetime(6) NULL,
        `TenantId` char(36) NULL,
        `SalesOrderId` char(36) NOT NULL,
        `StoreCode` longtext CHARACTER SET utf8mb4 NULL,
        `StoreName` longtext CHARACTER SET utf8mb4 NULL,
        `EmployeeCode` longtext CHARACTER SET utf8mb4 NULL,
        `EmployeeName` longtext CHARACTER SET utf8mb4 NULL,
        `OrderNo` longtext CHARACTER SET utf8mb4 NULL,
        `OrderType` longtext CHARACTER SET utf8mb4 NULL,
        `OrderTypeName` longtext CHARACTER SET utf8mb4 NULL,
        `OrderDateTime` datetime(6) NOT NULL,
        `OrderStatus` longtext CHARACTER SET utf8mb4 NULL,
        `OrderStatusName` longtext CHARACTER SET utf8mb4 NULL,
        `SalesChannelCode` longtext CHARACTER SET utf8mb4 NULL,
        `SalesChannelName` longtext CHARACTER SET utf8mb4 NULL,
        `HasDelivery` tinyint(1) NOT NULL,
        `Notes` longtext CHARACTER SET utf8mb4 NULL,
        `WaitingNumber` longtext CHARACTER SET utf8mb4 NULL,
        `IsTakeAway` tinyint(1) NOT NULL,
        `PickingTime` datetime(6) NULL,
        `SnoozingTime` datetime(6) NULL,
        `RecievedDateTime` datetime(6) NULL,
        `PerformedById` char(36) NULL,
        `PerformedByName` longtext CHARACTER SET utf8mb4 NULL,
        `PerformedDateTime` datetime(6) NULL,
        `KitchenStatus` longtext CHARACTER SET utf8mb4 NULL,
        `StoreBrand` longtext CHARACTER SET utf8mb4 NULL,
        CONSTRAINT `PK_AppSalesOrders` PRIMARY KEY (`Id`)
    );

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200701031643_InitialCreate') THEN

    CREATE TABLE `AppSalesOrderStatusHistories` (
        `Id` char(36) NOT NULL,
        `ExtraProperties` longtext CHARACTER SET utf8mb4 NULL,
        `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 NULL,
        `CreationTime` datetime(6) NOT NULL,
        `CreatorId` char(36) NULL,
        `LastModificationTime` datetime(6) NULL,
        `LastModifierId` char(36) NULL,
        `IsDeleted` tinyint(1) NOT NULL DEFAULT FALSE,
        `DeleterId` char(36) NULL,
        `DeletionTime` datetime(6) NULL,
        `TenantId` char(36) NULL,
        `SalesOrderId` char(36) NULL,
        `Status` longtext CHARACTER SET utf8mb4 NULL,
        `KitchenStatus` longtext CHARACTER SET utf8mb4 NULL,
        `Notes` longtext CHARACTER SET utf8mb4 NULL,
        `ChangedById` char(36) NULL,
        `ChangedByUserName` longtext CHARACTER SET utf8mb4 NULL,
        `ChangedByDateTime` longtext CHARACTER SET utf8mb4 NULL,
        CONSTRAINT `PK_AppSalesOrderStatusHistories` PRIMARY KEY (`Id`)
    );

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200701031643_InitialCreate') THEN

    CREATE TABLE `AppSalesOrderDetails` (
        `Id` char(36) NOT NULL,
        `ExtraProperties` longtext CHARACTER SET utf8mb4 NULL,
        `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 NULL,
        `CreationTime` datetime(6) NOT NULL,
        `CreatorId` char(36) NULL,
        `LastModificationTime` datetime(6) NULL,
        `LastModifierId` char(36) NULL,
        `IsDeleted` tinyint(1) NOT NULL DEFAULT FALSE,
        `DeleterId` char(36) NULL,
        `DeletionTime` datetime(6) NULL,
        `TenantId` char(36) NULL,
        `SalesOrderId` char(36) NOT NULL,
        `SalesOrderDetailId` char(36) NOT NULL,
        `SequentiaNumber` int NOT NULL,
        `BarCode1` longtext CHARACTER SET utf8mb4 NULL,
        `BarCode2` longtext CHARACTER SET utf8mb4 NULL,
        `ItemCode` longtext CHARACTER SET utf8mb4 NULL,
        `ProductName` longtext CHARACTER SET utf8mb4 NULL,
        `SerialNumber` longtext CHARACTER SET utf8mb4 NULL,
        `LotNumber` longtext CHARACTER SET utf8mb4 NULL,
        `UOSCode` longtext CHARACTER SET utf8mb4 NULL,
        `UOSName` longtext CHARACTER SET utf8mb4 NULL,
        `UOSQuantity` decimal(65,30) NOT NULL,
        `UOMCode` longtext CHARACTER SET utf8mb4 NULL,
        `UOMQuantity` decimal(65,30) NOT NULL,
        `Notes` longtext CHARACTER SET utf8mb4 NULL,
        `IsChild` tinyint(1) NOT NULL,
        `IndexNumber` int NOT NULL,
        `SalesOrderDetailStaus` longtext CHARACTER SET utf8mb4 NULL,
        `IsOptional` tinyint(1) NOT NULL,
        `ProductHierarchyCode` longtext CHARACTER SET utf8mb4 NULL,
        `ProductHierarchyName` longtext CHARACTER SET utf8mb4 NULL,
        `ProductHierarchyOrder` int NOT NULL,
        `RecievedDateTime` datetime(6) NULL,
        `PerformedById` char(36) NULL,
        `PerformedByName` longtext CHARACTER SET utf8mb4 NULL,
        `PerformedDateTime` datetime(6) NULL,
        `KitchenStatus` longtext CHARACTER SET utf8mb4 NULL,
        `ProductGroupCode` longtext CHARACTER SET utf8mb4 NULL,
        `ProcductGroupIndex` int NOT NULL,
        CONSTRAINT `PK_AppSalesOrderDetails` PRIMARY KEY (`Id`),
        CONSTRAINT `FK_AppSalesOrderDetails_AppSalesOrders_SalesOrderId` FOREIGN KEY (`SalesOrderId`) REFERENCES `AppSalesOrders` (`Id`) ON DELETE CASCADE
    );

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200701031643_InitialCreate') THEN

    CREATE INDEX `IX_AppSalesOrderDetails_SalesOrderId` ON `AppSalesOrderDetails` (`SalesOrderId`);

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200701031643_InitialCreate') THEN

    INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
    VALUES ('20200701031643_InitialCreate', '3.1.4');

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrders` DROP COLUMN `IsTakeAway`;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` DROP COLUMN `ProductHierarchyCode`;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` DROP COLUMN `ProductHierarchyName`;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` DROP COLUMN `ProductHierarchyOrder`;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrders` ADD `StoreTypeCode` longtext CHARACTER SET utf8mb4 NULL;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrders` ADD `StoreTypeName` longtext CHARACTER SET utf8mb4 NULL;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrders` ADD `TableId` char(36) NULL;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` ADD `MaintainQuantityRatio` tinyint(1) NOT NULL DEFAULT FALSE;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` ADD `OriginalId` char(36) NULL;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` ADD `ProcductGroupName` longtext CHARACTER SET utf8mb4 NULL;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` ADD `ProducingTime` int NOT NULL DEFAULT 0;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` ADD `ProductShortName` longtext CHARACTER SET utf8mb4 NULL;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    ALTER TABLE `AppSalesOrderDetails` ADD `ServingTime` int NOT NULL DEFAULT 0;

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;


DROP PROCEDURE IF EXISTS MigrationsScript;
DELIMITER //
CREATE PROCEDURE MigrationsScript()
BEGIN
    IF NOT EXISTS(SELECT 1 FROM `__EFMigrationsHistory` WHERE `MigrationId` = '20200702060738_update_saleOrder_saleOrderDetail_tables') THEN

    INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
    VALUES ('20200702060738_update_saleOrder_saleOrderDetail_tables', '3.1.4');

    END IF;
END //
DELIMITER ;
CALL MigrationsScript();
DROP PROCEDURE MigrationsScript;

