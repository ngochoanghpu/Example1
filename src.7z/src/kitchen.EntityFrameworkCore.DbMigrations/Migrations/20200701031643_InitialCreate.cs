﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace kitchen.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AppKitchenConfigurations",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ExtraProperties = table.Column<string>(nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorId = table.Column<Guid>(nullable: true),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    LastModifierId = table.Column<Guid>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false, defaultValue: false),
                    DeleterId = table.Column<Guid>(nullable: true),
                    DeletionTime = table.Column<DateTime>(nullable: true),
                    TenantId = table.Column<Guid>(nullable: true),
                    StoreCode = table.Column<string>(nullable: false),
                    DisplayColumns = table.Column<int>(nullable: false),
                    BillNoDisplayLength = table.Column<int>(nullable: false),
                    AutoPrintBill = table.Column<bool>(nullable: false),
                    ItemCheckBgColor = table.Column<string>(nullable: false),
                    ItemCheckTextColor = table.Column<string>(nullable: false),
                    BillCancelledBgColor = table.Column<string>(nullable: false),
                    Threshold1Value = table.Column<int>(nullable: false),
                    UnderThreshold1BgColor = table.Column<string>(nullable: false),
                    UnderThreshold1TextColor = table.Column<string>(nullable: false),
                    Threshold2Value = table.Column<int>(nullable: false),
                    UnderThreshold2BgColor = table.Column<string>(nullable: false),
                    UnderThreshold2TextColor = table.Column<string>(nullable: false),
                    OverThreshold3BgColor = table.Column<string>(nullable: false),
                    OverThreshold3TextColor = table.Column<string>(nullable: false),
                    ItemLockBgColor = table.Column<string>(nullable: false),
                    ItemLockTextColor = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppKitchenConfigurations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AppSalesOrderDetailStatusHistories",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ExtraProperties = table.Column<string>(nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorId = table.Column<Guid>(nullable: true),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    LastModifierId = table.Column<Guid>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false, defaultValue: false),
                    DeleterId = table.Column<Guid>(nullable: true),
                    DeletionTime = table.Column<DateTime>(nullable: true),
                    TenantId = table.Column<Guid>(nullable: true),
                    SalesOrderId = table.Column<Guid>(nullable: true),
                    SalesOrderDetailId = table.Column<Guid>(nullable: true),
                    SalesOrderDetailStatus = table.Column<string>(nullable: true),
                    KitchenStatus = table.Column<string>(nullable: true),
                    Notes = table.Column<string>(nullable: true),
                    ChangedById = table.Column<Guid>(nullable: true),
                    ChangedByUserName = table.Column<string>(nullable: true),
                    ChangedByDateTime = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppSalesOrderDetailStatusHistories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AppSalesOrders",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ExtraProperties = table.Column<string>(nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorId = table.Column<Guid>(nullable: true),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    LastModifierId = table.Column<Guid>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false, defaultValue: false),
                    DeleterId = table.Column<Guid>(nullable: true),
                    DeletionTime = table.Column<DateTime>(nullable: true),
                    TenantId = table.Column<Guid>(nullable: true),
                    SalesOrderId = table.Column<Guid>(nullable: false),
                    StoreCode = table.Column<string>(nullable: true),
                    StoreName = table.Column<string>(nullable: true),
                    EmployeeCode = table.Column<string>(nullable: true),
                    EmployeeName = table.Column<string>(nullable: true),
                    OrderNo = table.Column<string>(nullable: true),
                    OrderType = table.Column<string>(nullable: true),
                    OrderTypeName = table.Column<string>(nullable: true),
                    OrderDateTime = table.Column<DateTime>(nullable: false),
                    OrderStatus = table.Column<string>(nullable: true),
                    OrderStatusName = table.Column<string>(nullable: true),
                    SalesChannelCode = table.Column<string>(nullable: true),
                    SalesChannelName = table.Column<string>(nullable: true),
                    HasDelivery = table.Column<bool>(nullable: false),
                    Notes = table.Column<string>(nullable: true),
                    WaitingNumber = table.Column<string>(nullable: true),
                    IsTakeAway = table.Column<bool>(nullable: false),
                    PickingTime = table.Column<DateTime>(nullable: true),
                    SnoozingTime = table.Column<DateTime>(nullable: true),
                    RecievedDateTime = table.Column<DateTime>(nullable: true),
                    PerformedById = table.Column<Guid>(nullable: true),
                    PerformedByName = table.Column<string>(nullable: true),
                    PerformedDateTime = table.Column<DateTime>(nullable: true),
                    KitchenStatus = table.Column<string>(nullable: true),
                    StoreBrand = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppSalesOrders", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AppSalesOrderStatusHistories",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ExtraProperties = table.Column<string>(nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorId = table.Column<Guid>(nullable: true),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    LastModifierId = table.Column<Guid>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false, defaultValue: false),
                    DeleterId = table.Column<Guid>(nullable: true),
                    DeletionTime = table.Column<DateTime>(nullable: true),
                    TenantId = table.Column<Guid>(nullable: true),
                    SalesOrderId = table.Column<Guid>(nullable: true),
                    Status = table.Column<string>(nullable: true),
                    KitchenStatus = table.Column<string>(nullable: true),
                    Notes = table.Column<string>(nullable: true),
                    ChangedById = table.Column<Guid>(nullable: true),
                    ChangedByUserName = table.Column<string>(nullable: true),
                    ChangedByDateTime = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppSalesOrderStatusHistories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AppSalesOrderDetails",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    ExtraProperties = table.Column<string>(nullable: true),
                    ConcurrencyStamp = table.Column<string>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorId = table.Column<Guid>(nullable: true),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    LastModifierId = table.Column<Guid>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false, defaultValue: false),
                    DeleterId = table.Column<Guid>(nullable: true),
                    DeletionTime = table.Column<DateTime>(nullable: true),
                    TenantId = table.Column<Guid>(nullable: true),
                    SalesOrderId = table.Column<Guid>(nullable: false),
                    SalesOrderDetailId = table.Column<Guid>(nullable: false),
                    SequentiaNumber = table.Column<int>(nullable: false),
                    BarCode1 = table.Column<string>(nullable: true),
                    BarCode2 = table.Column<string>(nullable: true),
                    ItemCode = table.Column<string>(nullable: true),
                    ProductName = table.Column<string>(nullable: true),
                    SerialNumber = table.Column<string>(nullable: true),
                    LotNumber = table.Column<string>(nullable: true),
                    UOSCode = table.Column<string>(nullable: true),
                    UOSName = table.Column<string>(nullable: true),
                    UOSQuantity = table.Column<decimal>(nullable: false),
                    UOMCode = table.Column<string>(nullable: true),
                    UOMQuantity = table.Column<decimal>(nullable: false),
                    Notes = table.Column<string>(nullable: true),
                    IsChild = table.Column<bool>(nullable: false),
                    IndexNumber = table.Column<int>(nullable: false),
                    SalesOrderDetailStaus = table.Column<string>(nullable: true),
                    IsOptional = table.Column<bool>(nullable: false),
                    ProductHierarchyCode = table.Column<string>(nullable: true),
                    ProductHierarchyName = table.Column<string>(nullable: true),
                    ProductHierarchyOrder = table.Column<int>(nullable: false),
                    RecievedDateTime = table.Column<DateTime>(nullable: true),
                    PerformedById = table.Column<Guid>(nullable: true),
                    PerformedByName = table.Column<string>(nullable: true),
                    PerformedDateTime = table.Column<DateTime>(nullable: true),
                    KitchenStatus = table.Column<string>(nullable: true),
                    ProductGroupCode = table.Column<string>(nullable: true),
                    ProcductGroupIndex = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppSalesOrderDetails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AppSalesOrderDetails_AppSalesOrders_SalesOrderId",
                        column: x => x.SalesOrderId,
                        principalTable: "AppSalesOrders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AppSalesOrderDetails_SalesOrderId",
                table: "AppSalesOrderDetails",
                column: "SalesOrderId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AppKitchenConfigurations");

            migrationBuilder.DropTable(
                name: "AppSalesOrderDetails");

            migrationBuilder.DropTable(
                name: "AppSalesOrderDetailStatusHistories");

            migrationBuilder.DropTable(
                name: "AppSalesOrderStatusHistories");

            migrationBuilder.DropTable(
                name: "AppSalesOrders");
        }
    }
}
