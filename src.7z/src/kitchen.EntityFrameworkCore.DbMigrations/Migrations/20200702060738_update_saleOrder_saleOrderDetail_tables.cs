﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace kitchen.Migrations
{
    public partial class update_saleOrder_saleOrderDetail_tables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsTakeAway",
                table: "AppSalesOrders");

            migrationBuilder.DropColumn(
                name: "ProductHierarchyCode",
                table: "AppSalesOrderDetails");

            migrationBuilder.DropColumn(
                name: "ProductHierarchyName",
                table: "AppSalesOrderDetails");

            migrationBuilder.DropColumn(
                name: "ProductHierarchyOrder",
                table: "AppSalesOrderDetails");

            migrationBuilder.AddColumn<string>(
                name: "StoreTypeCode",
                table: "AppSalesOrders",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "StoreTypeName",
                table: "AppSalesOrders",
                nullable: true);

            migrationBuilder.AddColumn<Guid>(
                name: "TableId",
                table: "AppSalesOrders",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "MaintainQuantityRatio",
                table: "AppSalesOrderDetails",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<Guid>(
                name: "OriginalId",
                table: "AppSalesOrderDetails",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProcductGroupName",
                table: "AppSalesOrderDetails",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProducingTime",
                table: "AppSalesOrderDetails",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "ProductShortName",
                table: "AppSalesOrderDetails",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ServingTime",
                table: "AppSalesOrderDetails",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "StoreTypeCode",
                table: "AppSalesOrders");

            migrationBuilder.DropColumn(
                name: "StoreTypeName",
                table: "AppSalesOrders");

            migrationBuilder.DropColumn(
                name: "TableId",
                table: "AppSalesOrders");

            migrationBuilder.DropColumn(
                name: "MaintainQuantityRatio",
                table: "AppSalesOrderDetails");

            migrationBuilder.DropColumn(
                name: "OriginalId",
                table: "AppSalesOrderDetails");

            migrationBuilder.DropColumn(
                name: "ProcductGroupName",
                table: "AppSalesOrderDetails");

            migrationBuilder.DropColumn(
                name: "ProducingTime",
                table: "AppSalesOrderDetails");

            migrationBuilder.DropColumn(
                name: "ProductShortName",
                table: "AppSalesOrderDetails");

            migrationBuilder.DropColumn(
                name: "ServingTime",
                table: "AppSalesOrderDetails");

            migrationBuilder.AddColumn<bool>(
                name: "IsTakeAway",
                table: "AppSalesOrders",
                type: "tinyint(1)",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "ProductHierarchyCode",
                table: "AppSalesOrderDetails",
                type: "longtext CHARACTER SET utf8mb4",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductHierarchyName",
                table: "AppSalesOrderDetails",
                type: "longtext CHARACTER SET utf8mb4",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductHierarchyOrder",
                table: "AppSalesOrderDetails",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
