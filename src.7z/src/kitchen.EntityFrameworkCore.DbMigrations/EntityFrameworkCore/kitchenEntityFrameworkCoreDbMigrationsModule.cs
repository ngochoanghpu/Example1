﻿using Microsoft.Extensions.DependencyInjection;
using Volo.Abp.Modularity;

namespace kitchen.EntityFrameworkCore
{
    [DependsOn(
        typeof(kitchenEntityFrameworkCoreModule)
    )]
    public class kitchenEntityFrameworkCoreDbMigrationsModule : AbpModule
    {
        public override void ConfigureServices(ServiceConfigurationContext context)
        {
            context.Services.AddAbpDbContext<kitchenMigrationsDbContext>();
        }
    }
}