using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

namespace kitchen.KitchenConfigurations
{
    public interface IKitchenConfigurationAppService : IApplicationService
    {
        Task<PagedResultDto<KitchenConfigurationDto>> GetListAsync(GetKitchenConfigurationsInput input);

        Task<KitchenConfigShortDto> GetInforConfig(Guid? id = null);

        Task<KitchenConfigurationDto> GetAsync(Guid id);

        Task DeleteAsync(Guid id);

        Task<KitchenConfigurationDto> CreateAsync(KitchenConfigurationCreateDto input);

        Task<KitchenConfigurationDto> UpdateAsync(Guid id, KitchenConfigurationUpdateDto input);
    }
}