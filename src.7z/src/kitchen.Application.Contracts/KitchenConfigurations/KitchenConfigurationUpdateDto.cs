using System;
using System.ComponentModel.DataAnnotations;

namespace kitchen.KitchenConfigurations
{
    public class KitchenConfigurationUpdateDto
    {

        [Required]
        public string StoreCode { get; set; }

        [Required]
        public int DisplayColumns { get; set; }

        [Required]
        public int BillNoDisplayLength { get; set; }

        [Required]
        public bool AutoPrintBill { get; set; }

        [Required]
        public string ItemCheckBgColor { get; set; }

        [Required]
        public string ItemCheckTextColor { get; set; }

        [Required]
        public string BillCancelledBgColor { get; set; }

        [Required]
        public int Threshold1Value { get; set; }

        [Required]
        public string UnderThreshold1BgColor { get; set; }

        [Required]
        public string UnderThreshold1TextColor { get; set; }

        public int? Threshold2Value { get; set; }

        [Required]
        public string UnderThreshold2BgColor { get; set; }

        [Required]
        public string UnderThreshold2TextColor { get; set; }

        [Required]
        public string OverThreshold3BgColor { get; set; }

        [Required]
        public string OverThreshold3TextColor { get; set; }

        [Required]
        public string ItemLockBgColor { get; set; }

        [Required]
        public string ItemLockTextColor { get; set; }

    }
}