using Volo.Abp.Application.Dtos;
using System;

namespace kitchen.KitchenConfigurations
{
    public class GetKitchenConfigurationsInput : PagedAndSortedResultRequestDto
    {
        public string FilterText { get; set; }

        public string StoreCode { get; set; }
        public int? DisplayColumnsMin { get; set; }
        public int? DisplayColumnsMax { get; set; }
        public int? BillNoDisplayLengthMin { get; set; }
        public int? BillNoDisplayLengthMax { get; set; }
        public bool? AutoPrintBill { get; set; }
        public string ItemCheckBgColor { get; set; }
        public string ItemCheckTextColor { get; set; }
        public string BillCancelledBgColor { get; set; }
        public int? Threshold1ValueMin { get; set; }
        public int? Threshold1ValueMax { get; set; }
        public string UnderThreshold1BgColor { get; set; }
        public string UnderThreshold1TextColor { get; set; }
        public int? Threshold2ValueMin { get; set; }
        public int? Threshold2ValueMax { get; set; }
        public string UnderThreshold2BgColor { get; set; }
        public string UnderThreshold2TextColor { get; set; }
        public string OverThreshold3BgColor { get; set; }
        public string OverThreshold3TextColor { get; set; }

        public string ItemLockBgColor { get; set; }
        public string ItemLockTextColor { get; set; }

        public GetKitchenConfigurationsInput()
        {

        }
    }
}