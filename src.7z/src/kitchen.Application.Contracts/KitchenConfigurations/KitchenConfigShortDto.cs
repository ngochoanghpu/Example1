﻿namespace kitchen.KitchenConfigurations
{
    public class KitchenConfigShortDto
    {
        public int DisplayColumns { get; set; }

        public int BillNoDisplayLength { get; set; }

        public bool AutoPrintBill { get; set; }

        public string ItemCheckBgColor { get; set; }

        public string ItemCheckTextColor { get; set; }

        public string BillCancelledBgColor { get; set; }

        public int Threshold1Value { get; set; }

        public string UnderThreshold1BgColor { get; set; }

        public string UnderThreshold1TextColor { get; set; }

        public int Threshold2Value { get; set; }

        public string UnderThreshold2BgColor { get; set; }

        public string UnderThreshold2TextColor { get; set; }

        public string OverThreshold3BgColor { get; set; }

        public string OverThreshold3TextColor { get; set; }

        public string ItemLockBgColor { get; set; }

        public string ItemLockTextColor { get; set; }

    }
}
