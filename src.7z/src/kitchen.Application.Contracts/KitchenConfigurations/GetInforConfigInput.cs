﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.KitchenConfigurations
{
    public class GetInforConfigInput
    {
        public string StoreCode { get; set; }
    }
}
