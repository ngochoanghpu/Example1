using System;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

namespace kitchen.SalesOrderStatusHistories
{
    public interface ISalesOrderStatusHistoryAppService : IApplicationService
    {
        Task<PagedResultDto<SalesOrderStatusHistoryDto>> GetListAsync(GetSalesOrderStatusHistoriesInput input);

        Task<SalesOrderStatusHistoryDto> GetAsync(Guid id);

        Task DeleteAsync(Guid id);

        Task<SalesOrderStatusHistoryDto> CreateAsync(SalesOrderStatusHistoryCreateDto input);

        Task<SalesOrderStatusHistoryDto> UpdateAsync(Guid id, SalesOrderStatusHistoryUpdateDto input);
    }
}