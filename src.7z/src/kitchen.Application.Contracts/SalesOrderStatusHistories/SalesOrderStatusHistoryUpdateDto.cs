using System;
using System.ComponentModel.DataAnnotations;

namespace kitchen.SalesOrderStatusHistories
{
    public class SalesOrderStatusHistoryUpdateDto
    {

        public Guid? SalesOrderId { get; set; }

        public string Status { get; set; }

        public string KitchenStatus { get; set; }

        public string Notes { get; set; }

        public Guid ChangedById { get; set; }

        public string ChangedByUserName { get; set; }

        public string ChangedByDateTime { get; set; }

    }
}