using Volo.Abp.Application.Dtos;
using System;

namespace kitchen.SalesOrderStatusHistories
{
    public class GetSalesOrderStatusHistoriesInput : PagedAndSortedResultRequestDto
    {
        public string FilterText { get; set; }

        public Guid? SalesOrderId { get; set; }
        public string Status { get; set; }
        public string KitchenStatus { get; set; }
        public string Notes { get; set; }
        public Guid? ChangedById { get; set; }
        public string ChangedByUserName { get; set; }
        public string ChangedByDateTime { get; set; }

        public GetSalesOrderStatusHistoriesInput()
        {

        }
    }
}