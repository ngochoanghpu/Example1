using Volo.Abp.Application.Dtos;
using System;

namespace kitchen.SalesOrderDetailStatusHistories
{
    public class GetSalesOrderDetailStatusHistoriesInput : PagedAndSortedResultRequestDto
    {
        public string FilterText { get; set; }

        public Guid? SalesOrderId { get; set; }
        public Guid? SalesOrderDetailId { get; set; }
        public string SalesOrderDetailStatus { get; set; }
        public string KitchenStatus { get; set; }
        public string Notes { get; set; }
        public Guid? ChangedById { get; set; }
        public string ChangedByUserName { get; set; }
        public string ChangedByDateTime { get; set; }

        public GetSalesOrderDetailStatusHistoriesInput()
        {

        }
    }
}