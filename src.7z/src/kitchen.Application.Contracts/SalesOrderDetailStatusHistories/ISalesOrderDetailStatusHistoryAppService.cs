using System;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

namespace kitchen.SalesOrderDetailStatusHistories
{
    public interface ISalesOrderDetailStatusHistoryAppService : IApplicationService
    {
        Task<PagedResultDto<SalesOrderDetailStatusHistoryDto>> GetListAsync(GetSalesOrderDetailStatusHistoriesInput input);

        Task<SalesOrderDetailStatusHistoryDto> GetAsync(Guid id);

        Task DeleteAsync(Guid id);

        Task<SalesOrderDetailStatusHistoryDto> CreateAsync(SalesOrderDetailStatusHistoryCreateDto input);

        Task<SalesOrderDetailStatusHistoryDto> UpdateAsync(Guid id, SalesOrderDetailStatusHistoryUpdateDto input);
    }
}