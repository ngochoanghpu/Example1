using System;
using Volo.Abp.Application.Dtos;

namespace kitchen.SalesOrderDetailStatusHistories
{
    public class SalesOrderDetailStatusHistoryDto : FullAuditedEntityDto<Guid>
    {

        public Guid? SalesOrderId { get; set; }

        public Guid? SalesOrderDetailId { get; set; }

        public string SalesOrderDetailStatus { get; set; }

        public string KitchenStatus { get; set; }

        public string Notes { get; set; }

        public Guid ChangedById { get; set; }

        public string ChangedByUserName { get; set; }

        public string ChangedByDateTime { get; set; }

    }
}