﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.SignalRs
{
    public class SaleOrderMessages
    {
        public string Action { get; set; }
        public string Body { get; set; }
    }
}
