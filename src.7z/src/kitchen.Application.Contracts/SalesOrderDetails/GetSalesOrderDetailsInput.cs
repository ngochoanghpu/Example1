using Volo.Abp.Application.Dtos;
using System;

namespace kitchen.SalesOrderDetails
{
    public class GetSalesOrderDetailsInput : PagedAndSortedResultRequestDto
    {
        public string FilterText { get; set; }

        public Guid? SalesOrderId { get; set; }
        public Guid? SalesOrderDetailId { get; set; }
        public int? SequentiaNumberMin { get; set; }
        public int? SequentiaNumberMax { get; set; }
        public string BarCode1 { get; set; }
        public string BarCode2 { get; set; }
        public string ItemCode { get; set; }
        public string ProductName { get; set; }
        public string SerialNumber { get; set; }
        public string LotNumber { get; set; }
        public string UOSCode { get; set; }
        public string UOSName { get; set; }
        public decimal? UOSQuantityMin { get; set; }
        public decimal? UOSQuantityMax { get; set; }
        public string UOMCode { get; set; }
        public decimal? UOMQuantityMin { get; set; }
        public decimal? UOMQuantityMax { get; set; }
        public string Notes { get; set; }
        public bool? IsChild { get; set; }
        public int? IndexNumberMin { get; set; }
        public int? IndexNumberMax { get; set; }
        public string SalesOrderDetailStaus { get; set; }
        public bool? IsOptional { get; set; }
        public string ProductHierarchyCode { get; set; }
        public string ProductHierarchyName { get; set; }
        public int? ProductHierarchyOrderMin { get; set; }
        public int? ProductHierarchyOrderMax { get; set; }
        public DateTime? RecievedDateTimeMin { get; set; }
        public DateTime? RecievedDateTimeMax { get; set; }
        public Guid? PerformedById { get; set; }
        public string PerformedByName { get; set; }
        public DateTime? PerformedDateTimeMin { get; set; }
        public DateTime? PerformedDateTimeMax { get; set; }
        public string kitchenStatus { get; set; }

        public GetSalesOrderDetailsInput()
        {

        }
    }
}