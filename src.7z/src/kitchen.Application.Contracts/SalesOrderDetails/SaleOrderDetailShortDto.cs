﻿using System;

namespace kitchen.SalesOrderDetails
{
    public class SaleOrderDetailShortDto
    {
        public Guid SaleOrderDetailId { get; set; }

        public string Name { get; set; }

        public decimal Quantity { get; set; }

        public string SalesOrderDetailStatus { get; set; }

        public string Notes { get; set; }

        public  bool IsChild { get; set; }

        public bool IsOptional { get; set; }

        public string ProductGroup { get; set; }

        public int ProcductGroupIndex { get; set; }

        public int SequentiaNumber { get; set; }
    }
}
