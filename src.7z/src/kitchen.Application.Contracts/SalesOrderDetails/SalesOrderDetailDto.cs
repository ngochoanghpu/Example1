using System;
using System.Collections.Generic;
using Volo.Abp.Application.Dtos;

namespace kitchen.SalesOrderDetails
{
    public class SalesOrderDetailDto : FullAuditedEntityDto<Guid>
    {

        public Guid? SalesOrderId { get; set; }

        public Guid? SalesOrderDetailId { get; set; }

        public int? SequentiaNumber { get; set; }

        public string BarCode1 { get; set; }

        public string BarCode2 { get; set; }

        public string ItemCode { get; set; }

        public string ProductName { get; set; }

        public string SerialNumber { get; set; }

        public string LotNumber { get; set; }

        public string UOSCode { get; set; }

        public string UOSName { get; set; }

        public decimal? UOSQuantity { get; set; }

        public string UOMCode { get; set; }

        public decimal? UOMQuantity { get; set; }

        public string Notes { get; set; }

        public bool? IsChild { get; set; }

        public int? IndexNumber { get; set; }

        public string SalesOrderDetailStaus { get; set; }

        public bool? IsOptional { get; set; }

        public string ProductHierarchyCode { get; set; }

        public string ProductHierarchyName { get; set; }

        public int? ProductHierarchyOrder { get; set; }

        public DateTime? RecievedDateTime { get; set; }

        public Guid? PerformedById { get; set; }

        public string PerformedByName { get; set; }

        public DateTime? PerformedDateTime { get; set; }

        public string kitchenStatus { get; set; }
        
        public string ProductGroupCode { get; set; }

        public int? ProcductGroupIndex { get; set; }

        public List<SalesOrderDetailDto> SalesOrderDetails { get; set; }

    }
}