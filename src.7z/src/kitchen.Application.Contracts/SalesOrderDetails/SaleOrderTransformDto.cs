﻿using kitchen.SalesOrders;
using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.SalesOrderDetails
{
    
        public class SalesOrderUpdateDto2
        {
            public Guid Id { get; set; }

            public string StoreCode { get; set; }

            public string StoreBrand { get; set; }

            public string StoreName { get; set; }

            public string InvoideCode { get; set; }

            public string OrderNo { get; set; }

            public string OrderType { get; set; }

            public string OrderTypeName { get; set; }

            public DateTime? OrderDateTime { get; set; }

            public string OrderStatus { get; set; }

            public string OrderStatusName { get; set; }

            public string SalesChannelCode { get; set; }

            public string SalesChannelName { get; set; }

            public bool? HasDelivery { get; set; }

            public decimal? TotalAmount { get; set; }

            public decimal? EarnedPoint { get; set; }

            public decimal? TotalPromotionAmount { get; set; }

            public decimal? TotalVoucherAmount { get; set; }

            public decimal? TotalSurchargeAmount { get; set; }

            public decimal? TotalRedeemedPoint { get; set; }

            public decimal? TotalRedeemedAmount { get; set; }

            public decimal? NeedToPayAmount { get; set; }

            public decimal? PaidAmount { get; set; }

            public decimal? PaidAmountOnDelivery { get; set; }

            public decimal? ExcessCash { get; set; }

            public decimal? TaxAmount { get; set; }

            public string WaitingNumber { get; set; }

            public string Notes { get; set; }

            public string OriginalOrderNo { get; set; }

            public string OriginalInvoideCode { get; set; }

            public bool? IsSchedule { get; set; }

            public DateTime? PickingTime { get; set; }

            public DateTime? SnoozingTime { get; set; }

            public DateTime? AdjustedPickingTime { get; set; }

            public string KitchenStatus { get; set; }

            public virtual string CreatorUsername { get; set; }

            public virtual string CreatorFullname { get; set; }

            public List<SalesOrderDto> SalesOrderDetails { get; set; }

            //public List<SalesOrderSurchargeUpdateDto> SalesOrderSurcharges { get; set; }

            //public List<SalesOrderSupporterUpdateDto> SalesOrderSupporters { get; set; }

            //public List<SalesOrderDeliveryUpdateDto> SalesOrderDeliveries { get; set; }

            //public List<SalesOrderPromotionUpdateDto> SalesOrderPromotions { get; set; }

            //public List<SalesOrderVoucherUpdateDto> SalesOrderVouchers { get; set; }

            //public List<SalesOrderPaymentUpdateDto> SalesOrderPayments { get; set; }

            //public List<SalesOrderCustomerUpdateDto> SalesOrderCustomers { get; set; }

        }
}
