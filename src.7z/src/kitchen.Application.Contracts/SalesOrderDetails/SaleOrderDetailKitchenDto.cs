﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.SalesOrderDetails
{
    public class SaleOrderDetailKitchenDto2
    {
        public Guid Id { get; set; }

        public string StoreCode { get; set; }

        public string StoreName { get; set; }

        public string EmployeeCode { get; set; }

        public List<SalesOrderDetailDto> ChildSalesOrderDetails { get; set; }

        public List<SalesOrderDetailDto> OptionSalesOrderDetails { get; set; }
    }
}
