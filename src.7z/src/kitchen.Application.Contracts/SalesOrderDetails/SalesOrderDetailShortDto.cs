﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.SalesOrderDetails
{
    public class SalesOrderDetailShortDto
    {
        public Guid? Id { get; set; }

        public Guid? SalesOrderId { get; set; }

        public int? SequentiaNumber { get; set; }

        public string SalesType { get; set; }

        public string SalesTypeName { get; set; }

        public Guid? TenantId { get; set; }

        public string BarCode1 { get; set; }

        public string BarCode2 { get; set; }

        public string ItemCode { get; set; }

        public string ProductName { get; set; }

        public string SerialNumber { get; set; }

        public string LotNumber { get; set; }

        public string UOSCode { get; set; }

        public string UOSName { get; set; }

        public decimal? UOSQuantity { get; set; }

        public string UOMCode { get; set; }

        public decimal? UOMQuantity { get; set; }

        public decimal? UnitPrice { get; set; }

        public decimal? DiscountPrice { get; set; }

        public decimal? AdjustedPrice { get; set; }

        public decimal? Amount { get; set; }

        public string Notes { get; set; }

        public Guid? InventoryDetailId { get; set; }

        public bool? IsSerialControl { get; set; }

        public bool? IsLotControl { get; set; }

        public decimal? TaxPercent { get; set; }

        public bool? ExtractFromPrice { get; set; }

        public decimal UOMDeltaQuantity { get; set; }

        public virtual bool? IsChild { get; set; }

        public int? IndexNumber { get; set; }

        public string SalesOrderDetailStatus { get; set; }

        public bool? IsOptional { get; set; }

        public decimal? RedeemedPoint { get; set; }

        public decimal? ActualAmount { get; set; }

        public string ProductHierarchyCode { get; set; }

        public string ProductHierarchyName { get; set; }

        public int? ProductHierarchyOrder { get; set; }

        public bool? SentToKitchen { get; set; }

        public string KitchenStatus { get; set; }

        public string ProductGroupCode { get; set; }

        public int? ProductGroupIndex { get; set; }

        public string ProductShortName { get; set; }

        public string ProcductGroupName { get; set; }

        public int? ProducingTime { get; set; }

        public int? ServingTime { get; set; }

        public bool? MaintainQuantityRatio { get; set; }

        public Guid? OriginalId { get; set; }


        public List<SalesOrderDetailShortDto> ChildSalesOrderDetails { get; set; }

        public List<SalesOrderDetailShortDto> OptionSalesOrderDetails { get; set; }
    }
}
