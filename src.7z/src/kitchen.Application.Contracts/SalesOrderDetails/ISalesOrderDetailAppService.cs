using kitchen.SalesOrders;
using kitchen.Shared;
using System;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

namespace kitchen.SalesOrderDetails
{
    public interface ISalesOrderDetailAppService : IApplicationService
    {
        Task<PagedResultDto<SalesOrderDetailDto>> GetListAsync(GetSalesOrderDetailsInput input);

        Task<SalesOrderDetailDto> GetAsync(Guid id);

        Task DeleteAsync(Guid id);

        Task<SalesOrderDetailDto> CreateAsync(SalesOrderDetailCreateDto input);

        Task<SalesOrderDetailDto> UpdateAsync(Guid id, SalesOrderDetailUpdateDto input);

        Task<ModifiedResponseDto<Guid>> UpdateChangeStatusAsync(Guid id, string status);

    }
}