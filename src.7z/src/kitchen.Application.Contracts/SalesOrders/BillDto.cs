﻿using kitchen.SalesOrderDetails;
using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.SalesOrders
{
    public class BillDto
    {
        public SaleOrderShortDto SaleOrder { get; set; }

        public List<SaleOrderDetailShortDto> SaleOrderDetails { get; set; }
    }
}
