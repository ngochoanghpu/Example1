﻿using System;

namespace kitchen.SalesOrders
{
    public class SaleOrderShortDto
    {
        public Guid Id { get; set; }

        public string OrderNo { get; set; }

        public string Notes { get; set; }

        public bool HasDelivery { get; set; }
    }
}
