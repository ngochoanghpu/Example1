using kitchen.Shared;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Application.Services;

namespace kitchen.SalesOrders
{
    public interface ISalesOrderAppService : IApplicationService
    {
        Task<PagedResultDto<SalesOrderDto>> GetListAsync(GetSalesOrdersInput input);

        Task<SalesOrderDto> GetAsync(Guid id);

        Task DeleteAsync(Guid id);

        Task<SalesOrderDto> CreateAsync(SalesOrderCreateDto input);

        Task<SalesOrderDto> UpdateAsync(Guid id, SalesOrderUpdateDto input);

        Task<ModifiedResponseDto<Guid>> UpdateChangeStatusAsync(Guid id, string status);

        Task<List<SalesOrderListDto>> GetBillsRestaurant(string storeCode, string productGroupCodesString = "");

        Task<List<SalesOrderListDto>> GetBillsTeaMilk(string storeCode);

        Task CreateSaleOrderAsync(SalesOrderDto input);
    }
}