﻿using System;
using System.Collections.Generic;
using System.Text;
using Volo.Abp.Application.Dtos;

namespace kitchen.SalesOrders
{
    public class SalesOrderConsumerDetailDto : FullAuditedEntityDto<Guid>
    {
        public Guid? SalesOrderId { get; set; }
        public Guid? SalesOrderDetailId { get; set; }

        public int SequentiaNumber { get; set; }

        public string SalesType { get; set; }

        public string SalesTypeName { get; set; }

        public Guid? TenantId { get; set; }

        public string BarCode1 { get; set; }

        public string BarCode2 { get; set; }

        public string ItemCode { get; set; }

        public string ProductName { get; set; }

        public string SerialNumber { get; set; }

        public string LotNumber { get; set; }

        public string UOSCode { get; set; }

        public string UOSName { get; set; }

        public decimal? UOSQuantity { get; set; }

        public string UOMCode { get; set; }

        public decimal? UOMQuantity { get; set; }

        public decimal? UnitPrice { get; set; }

        public decimal? DiscountPrice { get; set; }

        public decimal? AdjustedPrice { get; set; }

        public decimal? Amount { get; set; }

        public string Notes { get; set; }

        public Guid? InventoryDetailId { get; set; }

        public bool IsSerialControl { get; set; }

        public bool IsLotControl { get; set; }

        public decimal? TaxPercent { get; set; }

        public bool? ExtractFromPrice { get; set; }

        public decimal UOMDeltaQuantity { get; set; }

        public virtual bool IsChild { get; set; }

        public int IndexNumber { get; set; }

        public string SalesOrderDetailStatus { get; set; }

        public bool IsOptional { get; set; }

        public decimal? RedeemedPoint { get; set; }

        public decimal? ActualAmount { get; set; }

        public string ProductHierarchyCode { get; set; }

        public string ProductHierarchyName { get; set; }

        public int ProductHierarchyOrder { get; set; }

        public bool SentToKitchen { get; set; }

        public string KitchenStatus { get; set; }

        public string ProductGroupCode { get; set; }

        public string ProductGroupName { get; set; }

        public int ProcductGroupIndex { get; set; }

        public string AssociateCode { get; set; }

        public string AssociateName { get; set; }

        public List<SalesOrderConsumerDetailDto> ChildSalesOrderDetails { get; set; }

        public List<SalesOrderConsumerDetailDto> OptionSalesOrderDetails { get; set; }
    }
}
