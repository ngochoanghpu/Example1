﻿using kitchen.KitchenConfigurations;
using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.SalesOrders
{
    public class SalesOrderListDto
    {
        public Guid SaleOrderId { get; set; }

        public string SaleOrderNumber { get; set; }

        public string WaitingNumber { get; set; }

        public decimal? TotalQuantityBeverage { get; set; } //Tổng số đồ uống

        public decimal? TotalQuantityCake { get; set; } //Tổng số bánh

        public decimal? TotalQuantityTopping { get; set; } //Tổng số topping

        public bool? IsDelivery { get; set; }

        public string Notes { get; set; }

        public DateTime? RecievedDateTime { get; set; }

        public List<SaleOrderDetailKitchenDto> Beverages { get; set; } //Danh sách đồ uống

        public List<SaleOrderDetailKitchenDto> Cakes { get; set; } //Danh sách bánh

        public List<SaleOrderDetailKitchenDto> Toppings { get; set; } //Danh sách bánh

        public KitchenConfigShortDto Configuration { get; set; }
    }

    public class SaleOrderDetailKitchenDto
    {
        public Guid? SaleOrderDetailId { get; set; }

        public string Name { get; set; }

        public decimal? Quantity { get; set; }

        public List<Topping> Toppings { get; set; }

        public List<string> Savor { get; set; } //Mùi vị

        public string Notes { get; set; }

        public string ProductGroupCode { get; set; }
    }

    public class Topping
    {
        public string Name { get; set; }

        public decimal? Quantity { get; set; }
    }
}
