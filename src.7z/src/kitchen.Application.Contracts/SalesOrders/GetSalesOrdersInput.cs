using Volo.Abp.Application.Dtos;
using System;

namespace kitchen.SalesOrders
{
    public class GetSalesOrdersInput : PagedAndSortedResultRequestDto
    {
        public string FilterText { get; set; }

        public Guid? SalesOrderId { get; set; }
        public string StoreCode { get; set; }
        public string StoreName { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string OrderNo { get; set; }
        public string OrderType { get; set; }
        public string OrderTypeName { get; set; }
        public DateTime? OrderDateTimeMin { get; set; }
        public DateTime? OrderDateTimeMax { get; set; }
        public string OrderStatus { get; set; }
        public string OrderStatusName { get; set; }
        public string SalesChannelCode { get; set; }
        public string SalesChannelName { get; set; }
        public bool? HasDelivery { get; set; }
        public string Notes { get; set; }
        public string WaitingNumber { get; set; }
        public bool? IsTakeAway { get; set; }
        public DateTime? PickingTimeMin { get; set; }
        public DateTime? PickingTimeMax { get; set; }
        public DateTime? SnoozingTimeMin { get; set; }
        public DateTime? SnoozingTimeMax { get; set; }
        public DateTime? RecievedDateTimeMin { get; set; }
        public DateTime? RecievedDateTimeMax { get; set; }
        public Guid? PerformedById { get; set; }
        public string PerformedByName { get; set; }
        public DateTime? PerformedDateTimeMin { get; set; }
        public DateTime? PerformedDateTimeMax { get; set; }
        public string KitchenStatus { get; set; }

        public string StoreBrand { get; set; }

        public GetSalesOrdersInput()
        {

        }
    }
}