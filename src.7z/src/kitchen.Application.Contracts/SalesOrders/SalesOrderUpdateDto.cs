using kitchen.SalesOrderDetails;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace kitchen.SalesOrders
{
    public class SalesOrderUpdateDto
    {
        public Guid Id { get; set; }

        public Guid SalesOrderId { get; set; }

        public string StoreCode { get; set; }

        public string StoreName { get; set; }

        public string EmployeeCode { get; set; }

        public string EmployeeName { get; set; }

        public string OrderNo { get; set; }

        public string OrderType { get; set; }

        public string OrderTypeName { get; set; }

        public DateTime OrderDateTime { get; set; }

        public string OrderStatus { get; set; }

        public string OrderStatusName { get; set; }

        public string SalesChannelCode { get; set; }

        public string SalesChannelName { get; set; }

        public bool HasDelivery { get; set; }

        public string Notes { get; set; }

        public string WaitingNumber { get; set; }

        public bool IsTakeAway { get; set; }

        public DateTime? PickingTime { get; set; }

        public DateTime? SnoozingTime { get; set; }

        public DateTime? RecievedDateTime { get; set; }

        public Guid? PerformedById { get; set; }

        public string PerformedByName { get; set; }

        public DateTime? PerformedDateTime { get; set; }

        public string KitchenStatus { get; set; }

        public string StoreBrand { get; set; }

        public List<SalesOrderDetailUpdateDto> SalesOrderDetails { get; set; }

    }
}