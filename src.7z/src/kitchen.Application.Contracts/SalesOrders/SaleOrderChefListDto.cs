﻿using kitchen.KitchenConfigurations;
using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.SalesOrders
{
    public class SaleOrderChefListDto
    {
        public Guid SaleOrderId { get; set; }

        public string SaleOrderNumber { get; set; }

        public string WaitingNumber { get; set; }

        public decimal? TotalQuantityChef1 { get; set; } //Tổng số món
        public decimal? TotalQuantityChef2 { get; set; } //Tổng số món
        public decimal? TotalQuantityChef3 { get; set; } //Tổng số món

        public bool? IsDelivery { get; set; }

        public string OrderStatus { get; set; }

        public string Notes { get; set; }
        public string ProductGroup { get; set; }

        public DateTime? RecievedDateTime { get; set; }

        public List<SaleOrderDetailChefDto> Chef1 { get; set; } //Danh sách đồ uống
        public List<SaleOrderDetailChefDto> Chef2 { get; set; } //Danh sách đồ uống
        public List<SaleOrderDetailChefDto> Chef3 { get; set; } //Danh sách đồ uống

        public KitchenConfigShortDto Configuration { get; set; }
    }

    public class SaleOrderDetailChefDto
    {
        public Guid? SaleOrderDetailId { get; set; }

        public string Name { get; set; }

        public decimal? Quantity { get; set; }
        public string SalesOrderDetailStatus { get; set; }

        public List<SOTopping> Toppings { get; set; }

        public List<string> Savor { get; set; } //Mùi vị

        public string Notes { get; set; }
    }

    public class SOTopping
    {
        public string Name { get; set; }

        public decimal? Quantity { get; set; }
    }
}
