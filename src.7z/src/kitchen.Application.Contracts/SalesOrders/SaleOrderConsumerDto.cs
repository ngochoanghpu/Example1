﻿using kitchen.SalesOrderDetails;
using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.SalesOrders
{
    public class SaleOrderConsumerDto
    {
        public Guid TenantId { get; set; }
        public Guid Id { get; set; }

        public string StoreCode { get; set; }

        public string StoreName { get; set; }

        public int EmployeeCode { get; set; }
        public string EmployeeName { get; set; }

        public string OrderNo { get; set; }

        public string OrderType { get; set; }

        public string OrderTypeName { get; set; }

        public DateTime? OrderDateTime { get; set; }

        public string OrderStatus { get; set; }

        public string OrderStatusName { get; set; }

        public string SalesChannelCode { get; set; }

        public string SalesChannelName { get; set; }

        public bool? HasDelivery { get; set; }

        public string WaitingNumber { get; set; }

        public string Notes { get; set; }

        public bool IsTakeAway { get; set; }

        public DateTime PickingTime { get; set; }

        public DateTime SnoozingTime { get; set; }

        public string KitchenStatus { get; set; }

        public List<SalesOrderConsumerDetailDto> SalesOrderDetails { get; set; }
    }
}
