﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.Shared
{
    public class ConfirmOrderDto
    {
        public Guid SalesOrderId { get; set; }
        public string OrderStatus { get; set; }
    }
}
