using Volo.Abp.Application.Dtos;

namespace kitchen.Shared
{
    public class LookupRequestDto : PagedResultRequestDto
    {
        public string Filter { get; set; }
    }
}