﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.Shared
{
    public class ModifiedResponseDto
    {
        public bool IsSuccess { get; set; }

        public string Message { get; set; }
    }

    public class ModifiedResponseDto<T> : ModifiedResponseDto
    {
        public T Data { get; set; }

        public List<ErrorMessageResponse> Messages { get; set; }
    }

    public class ErrorMessageResponse
    {
        public string Key { get; set; }

        public string Value { get; set; }
    }
}
