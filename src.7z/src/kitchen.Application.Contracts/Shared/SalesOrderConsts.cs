﻿using System;
using System.Collections.Generic;
using System.Text;

namespace kitchen.Shared
{
    public static class SalesOrderConsts
    {
        public enum KitchenStatus 
        {
            Inprogress,
            Completed,
            Cancelled
        }

        public enum OrderStatus
        {
            Cancelled,
            InformCancelled
        }

        public enum StoreBrand
        {
            BEVERAGE,
            RESTAURANT,
            BAKERY
        }

        public enum StoreTypeCode
        {
            BEVERAGE,
            RESTAURANT,
            BAKERY
        }

        public enum ProductGroup
        {
            PG_BEVERAGE,
            PG_CAKE,
            PG_TOPPING
        }
        public class RestaurantProductGroup
        {
            public const string Noodle = "Noodle";
            public const string Drink = "PR.Nuoc";
            public const string Dimsum = "PR.Dimsum";
            public const string Roasted = "PR.Quay";
            public const string Pan = "PR.Chao";
            public const string Soup = "PR.Saladsoup";
            public const string Prepared = "PR.Dubi";
        }
    }
}
