using kitchen.Localization;
using Volo.Abp.Authorization.Permissions;
using Volo.Abp.Localization;
using Volo.Abp.MultiTenancy;

namespace kitchen.Permissions
{
    public class kitchenPermissionDefinitionProvider : PermissionDefinitionProvider
    {
        public override void Define(IPermissionDefinitionContext context)
        {
            var myGroup = context.AddGroup(kitchenPermissions.GroupName);

            myGroup.AddPermission(kitchenPermissions.Dashboard.Host, L("Permission:Dashboard"), MultiTenancySides.Host);
            myGroup.AddPermission(kitchenPermissions.Dashboard.Tenant, L("Permission:Dashboard"), MultiTenancySides.Tenant);

            //Define your own permissions here. Example:
            //myGroup.AddPermission(kitchenPermissions.MyPermission1, L("Permission:MyPermission1"));

            var salesOrderPermission = myGroup.AddPermission(kitchenPermissions.SalesOrders.Default, L("Permission:SalesOrders"));
            salesOrderPermission.AddChild(kitchenPermissions.SalesOrders.Create, L("Permission:Create"));
            salesOrderPermission.AddChild(kitchenPermissions.SalesOrders.Edit, L("Permission:Edit"));
            salesOrderPermission.AddChild(kitchenPermissions.SalesOrders.Delete, L("Permission:Delete"));

            var salesOrderDetailPermission = myGroup.AddPermission(kitchenPermissions.SalesOrderDetails.Default, L("Permission:SalesOrderDetails"));
            salesOrderDetailPermission.AddChild(kitchenPermissions.SalesOrderDetails.Create, L("Permission:Create"));
            salesOrderDetailPermission.AddChild(kitchenPermissions.SalesOrderDetails.Edit, L("Permission:Edit"));
            salesOrderDetailPermission.AddChild(kitchenPermissions.SalesOrderDetails.Delete, L("Permission:Delete"));

            var kitchenConfigurationPermission = myGroup.AddPermission(kitchenPermissions.KitchenConfigurations.Default, L("Permission:KitchenConfigurations"));
            kitchenConfigurationPermission.AddChild(kitchenPermissions.KitchenConfigurations.Create, L("Permission:Create"));
            kitchenConfigurationPermission.AddChild(kitchenPermissions.KitchenConfigurations.Edit, L("Permission:Edit"));
            kitchenConfigurationPermission.AddChild(kitchenPermissions.KitchenConfigurations.Delete, L("Permission:Delete"));

            var salesOrderStatusHistoryPermission = myGroup.AddPermission(kitchenPermissions.SalesOrderStatusHistories.Default, L("Permission:SalesOrderStatusHistories"));
            salesOrderStatusHistoryPermission.AddChild(kitchenPermissions.SalesOrderStatusHistories.Create, L("Permission:Create"));
            salesOrderStatusHistoryPermission.AddChild(kitchenPermissions.SalesOrderStatusHistories.Edit, L("Permission:Edit"));
            salesOrderStatusHistoryPermission.AddChild(kitchenPermissions.SalesOrderStatusHistories.Delete, L("Permission:Delete"));

            var salesOrderDetailStatusHistoryPermission = myGroup.AddPermission(kitchenPermissions.SalesOrderDetailStatusHistories.Default, L("Permission:SalesOrderDetailStatusHistories"));
            salesOrderDetailStatusHistoryPermission.AddChild(kitchenPermissions.SalesOrderDetailStatusHistories.Create, L("Permission:Create"));
            salesOrderDetailStatusHistoryPermission.AddChild(kitchenPermissions.SalesOrderDetailStatusHistories.Edit, L("Permission:Edit"));
            salesOrderDetailStatusHistoryPermission.AddChild(kitchenPermissions.SalesOrderDetailStatusHistories.Delete, L("Permission:Delete"));
        }

        private static LocalizableString L(string name)
        {
            return LocalizableString.Create<kitchenResource>(name);
        }
    }
}