namespace kitchen.Permissions
{
    public static class kitchenPermissions
    {
        public const string GroupName = "kitchen";

        public static class Dashboard
        {
            public const string DashboardGroup = GroupName + ".Dashboard";
            public const string Host = DashboardGroup + ".Host";
            public const string Tenant = GroupName + ".Tenant";
        }

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";

        public class SalesOrders
        {
            public const string Default = GroupName + ".SalesOrders";
            public const string Edit = Default + ".Edit";
            public const string Create = Default + ".Create";
            public const string Delete = Default + ".Delete";
        }

        public class SalesOrderDetails
        {
            public const string Default = GroupName + ".SalesOrderDetails";
            public const string Edit = Default + ".Edit";
            public const string Create = Default + ".Create";
            public const string Delete = Default + ".Delete";
        }

        public class KitchenConfigurations
        {
            public const string Default = GroupName + ".KitchenConfigurations";
            public const string Edit = Default + ".Edit";
            public const string Create = Default + ".Create";
            public const string Delete = Default + ".Delete";
        }

        public class SalesOrderStatusHistories
        {
            public const string Default = GroupName + ".SalesOrderStatusHistories";
            public const string Edit = Default + ".Edit";
            public const string Create = Default + ".Create";
            public const string Delete = Default + ".Delete";
        }

        public class SalesOrderDetailStatusHistories
        {
            public const string Default = GroupName + ".SalesOrderDetailStatusHistories";
            public const string Edit = Default + ".Edit";
            public const string Create = Default + ".Create";
            public const string Delete = Default + ".Delete";
        }
    }
}