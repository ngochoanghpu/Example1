import { Injectable } from '@angular/core';

// tslint:disable-next-line:no-shadowed-variable
// import { ConfigModel } from '../core/interfaces/config';

// tslint:disable-next-line:no-shadowed-variable
@Injectable()
export class MenuConfig {
	public config: any = {};

	constructor() {
		this.config = {
			header: {
				self: {},
				items: [
					{

					},
				]
			},
			aside: {
				self: {},
				items: [
					{
						title: 'Dashboard',
						desc: 'Some description goes here',
						root: true,
						icon: 'flaticon-line-graph',
						code: null,
						page: '/',
						badge: { type: 'm-badge--danger', value: '2' },
						translate: 'MENU.DASHBOARD'
					},
					{
						title: 'Vehicles',
						desc: 'Some description goes here',
						root: true,
						icon: 'flaticon-truck',
						permission: { canRead: true },
						code: 'VEH',
						page: '/vehicles',
						translate: 'MENU.VEHICLE'
					},
					{
						title: 'Driver',
						desc: 'Some description goes here',
						root: true,
						bullet: 'dot',
						icon: 'dnf-ic-driver',
						permission: { canRead: true },
						code: 'DRI',
						translate: 'MENU.DRIVER',
						submenu: [
							{
								title: 'Driver List',
								icon: 'flaticon-users',
								page: '/drivers/driver-list',
								translate: 'MENU.DRIVER_LIST',
							},
							{
								title: 'Registration List',
								icon: 'flaticon-edit-1',
								page: '/drivers/registration-list',
								translate: 'MENU.DRIVER_REGISTRATION_LIST',
							}
						]
					},
					{
						title: 'Passengers',
						desc: 'Some description goes here',
						root: true,
						icon: 'flaticon-customer',
						permission: { canRead: true },
						code: 'PAS',
						page: '/passengers',
						translate: 'MENU.PASSENGERS',
						// submenu: []
					},
					{
						title: 'Trips',
						desc: 'Some description goes here',
						root: true,
						icon: 'flaticon-map-location',
						permission: { canRead: true },
						code: 'TRI',
						page: '/trips',
						translate: 'MENU.TRIPS',
						// submenu: []
					},
					{
						title: 'Fares',
						desc: 'Some description goes here',
						root: true,
						icon: 'flaticon-notepad',
						permission: { canRead: true },
						code: 'FAR',
						page: '/fares',
						translate: 'MENU.FARES',
						// submenu: []
					},
					{
						title: 'Settings',
						desc: '',
						root: true,
						icon: 'flaticon-settings',
						position: 'bottom-1',
						submenu: [
							{
								title: 'General',
								page: '/settings',
								icon: 'flaticon-signs-1',
								translate: 'MENU.SETTING_GENERAL',
							},
							{
								title: 'Admin User',
								page: '/users',
								icon: 'flaticon-user',
								translate: 'MENU.USER',
							},
							{
								title: 'Roles and Permissions',
								code: '',
								page: '/roles',
								icon: 'flaticon-users',
								translate: 'MENU.ROLE',
							},
							{
								title: 'Email Templates',
								page: '/email',
								icon: 'flaticon-multimedia-2',
								translate: 'MENU.EMAIL_TEMPLATES',
							},
							{
								title: 'SMS Templates',
								page: '/sms',
								icon: 'flaticon-comment',
								translate: 'MENU.SMS_TEMPLATES',
							},
							{
								title: 'App Language Labels',
								page: '/languages',
								icon: 'flaticon-earth-globe',
								translate: 'MENU.APP_LANGUAGE_LABELS',
							}
						]
					}
				]
			}
		};
	}
}
