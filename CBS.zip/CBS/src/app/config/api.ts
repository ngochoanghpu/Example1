export const ApiConfig = {
  AUTH: {
    LOGIN: '/auth/login',
    LOGOUT: '/auth/logout',
    FORGOT_PASSWORD: '/auth/forgot-password',
    RESET_PASSWORD: '/auth/reset-password',
    CHANGE_PASSWORD: '/auth/password',
  },
  USER: {
    GET_PROFILE: '/user/profile',
    GET_USERS: '/user',
    CREATE_USER: '/user',
    UPDATE_USER: '/user',
    DELETE_USER: '/user',
  },
  ROLE: {
    GET_ALL: '/role/all',
    GET_ROLES: '/role',
    GET_ROLE_DETAIL: '/role',
    CREATE_ROLE: '/role',
    UPDATE_ROLE: '/role',
    DELETE_ROLE: '/role',
  },
  FEATURE: {
    GET_ALL: '/feature/all'
  },
  FARE: {
    GET: '/fare',
    UPDATE_FARE: '/fare',
    DELETE_FARE: '/fare',
    CREATE_FARE: '/fare'
  },
  TRIP: {
    GET: '/trip'
  },  
  PASSENGER: {
    GET: '/passenger',
    UPDATE_PASSENGER: '/passenger'
  }, 
  CONFIG: {
    GENERAL: '/globalConfig/general',
    BOOKING_IN_NOW: '/globalConfig/bookingInNow',
    SCHEDULED_BOOKING: '/globalConfig/scheduledBooking',
    SETTINGS_BY_COUNTRIES: '/globalConfig/settingsByCountries'
  },
  DRIVER: {
    GET: '/driver',
    UPDATE: '/driver',
    CREATE: '/driver',
    AVAILABLE: '/driver/available',
    RELEASE_VEHICLE: '/driver/{id}/release',
    ASSIGN_VEHICLE: '/driver/{id}/assign',
    GET_REGISTRATION: '/driverRegistration',
    REJECT_REGISTRATION: '/driverRegistration/{id}/reject',
    APPROVE_REGISTRATION: '/driverRegistration/{id}/approve',
  },  
  VEHICLE: {
    GET: '/vehicle',
    GET_ALL: '/vehicle',
    GET_AVAILABLE: '/vehicle/available',
    UPDATE_VEHICLE: '/vehicle',
    CREATE_VEHICLE: '/vehicle',    
    RELEASE_DRIVER: '/vehicle/{id}/release',
    ASSIGN_DRIVER: '/vehicle/{id}/assign',
    UPDATE_STATUS: '/vehicle/updateStatus',
    DELETE_VEHICLE: '/vehicle',    
  },
  COUNTRY: {
    GET: '/country',
  },
  DOCUMENT: {
    UPLOAD: '/document/draft',
    DELETE_DRAFT_IMAGES: '/document/draft',
  }
};
