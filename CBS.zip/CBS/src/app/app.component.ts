import { Component, ChangeDetectionStrategy, OnInit, ChangeDetectorRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { CONSTANTS } from '@app/shared/constant';
import { LoaderService } from '@app/services/loader.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'body[dnf-root]',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit {
  title = 'DnF Theme';  
  showLoader: boolean;

  constructor(
    translate: TranslateService, 
    private cdr: ChangeDetectorRef,
    private router: Router, 
    private loaderService: LoaderService
    ) {
    translate.setDefaultLang('en');
    translate.use('en');
  }

  ngOnInit(): void {
    if (!localStorage.getItem(CONSTANTS.LOCAL_STORAGE.USER_PROFILE)) {
      this.router.navigate(['login']);
    }

    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
      this.cdr.markForCheck(); 
    });
  }
}
