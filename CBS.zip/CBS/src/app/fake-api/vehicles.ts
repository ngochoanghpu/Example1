import { Vehicle } from '@app/services/models/vehicle.model';

export const VEHICLES: any[] = [
  {
    id: 1,
    model: 'Mazda',
    driver: {
      'name': 'Khoa Nguyen',
      'avatar': 'user-avatar.jpg',
      'mobilePhone': '0965-465-883'
    },
    numberPlate: '1111',
    isPreminum: true,
    seats: 2,
    status: 0,
    vin: 'Toyota Tarago 14',
    year: '01-Feb-2019',
    regoRenewalDate: '04-Jul-2019',
    validUntil: '28-Jan-2019',
    currentKms: 12,
    kmsBeforeService: 123,
    lastServiceKms: '1234567',
    nextServiceKms: '324555',
    insuranceExpiryDate: '01-Jan-2019',
    etagNumber: 'Toyota 1212-7',
    iserviceMessageSent: true
  },
  {
    id: 2,
    model: 'Toyota',
    driver: {
      'name': 'Khoa Nguyen',
      'avatar': 'user-avatar.jpg',
      'mobilePhone': '0965-465-883'
    },
    numberPlate: '2222',
    premium: true,
    passengerSeats: 4,
    passengerSeatsId: '2',
    status: 1,
    vin: 'Toyota Tarago 14',
    year: '01-Dec-2019',
    regoRenewalDate: '05-Jul-2019',
    validUntil: '28-Jan-2019',
    lastServiceKms: '1234567',
    nextServiceKms: '324555',
    insuranceExpiryDate: '01-Jan-2019',
    etagNumber: 'Toyota 1212-7',
    serviceMessageSent: true
  },
  {
    id: 3,
    model: 'Honda',
    driver: null,
    numberPlate: '3333',
    premium: false,
    passengerSeats: 2,
    passengerSeatsId: '1',
    status: 0,
    vin: 'Toyota Tarago 14',
    year: '01-Jan-2019',
    regoRenewalDate: '08-Jul-2019',
    validUntil: '28-Jan-2019',
    lastServiceKms: '1234567',
    nextServiceKms: '324555',
    insuranceExpiryDate: '01-Jan-2019',
    etagNumber: 'Toyota 1212-7',
    serviceMessageSent: true
  },
  {
    id: 4,
    model: 'Mercedes',
    driver: {
      'name': 'Khoa Nguyen',
      'avatar': 'user-avatar.jpg',
      'mobilePhone': '0965-465-883'
    },
    numberPlate: '4444',
    premium: true,
    passengerSeats: 7,
    passengerSeatsId: '3',
    status: 1,
    vin: 'Toyota Tarago 14',
    year: '01-Jan-2019',
    regoRenewalDate: '20-Jul-2019',
    validUntil: '28-Jan-2019',
    lastServiceKms: '1234567',
    nextServiceKms: '324555',
    insuranceExpiryDate: '01-Jan-2019',
    etagNumber: 'Toyota 1212-7',
    serviceMessageSent: true
  },
  {
    id: 5,
    model: 'Mazda',
    driver: {
      'name': 'Khoa Nguyen',
      'avatar': 'user-avatar.jpg',
      'mobilePhone': '0965-465-883'
    },
    numberPlate: '5555',
    premium: false,
    passengerSeats: 2,
    passengerSeatsId: '1',
    status: 1,
    vin: 'Toyota Tarago 14',
    year: '01-Jan-2019',
    regoRenewalDate: '10-Jul-2019',
    validUntil: '28-Jan-2019',
    lastServiceKms: '1234567',
    nextServiceKms: '324555',
    insuranceExpiryDate: '01-Jan-2019',
    etagNumber: 'Toyota 1212-7',
    serviceMessageSent: true
  },
  {
    id: 6,
    model: 'Ferrari',
    driver: {
      'name': 'Khoa Nguyen',
      'avatar': 'user-avatar.jpg',
      'mobilePhone': '0965-465-883'
    },
    numberPlate: '6666',
    premium: false,
    passengerSeats: 2,
    passengerSeatsId: '1',
    status: 1,
    vin: 'Toyota Tarago 14',
    year: '01-Jan-2019',
    regoRenewalDate: '11-Jul-2019',
    validUntil: '28-Jan-2019',
    lastServiceKms: '1234567',
    nextServiceKms: '324555',
    insuranceExpiryDate: '01-Jan-2019',
    etagNumber: 'Toyota 1212-7',
    serviceMessageSent: true
  }
];
