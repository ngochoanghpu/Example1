import { DriverModel } from '@app/services/models/driver.model';

export const DRIVERDETAILS: any[] = [
    {
        id: 1,
        firstName: 'Huy',
        lastName: 'Ly',
        profileImage: 'user-1.jpg',
        phoneCode: '+84',
        phoneNumber: '092309230',
        rating: 3,
        email: '123@demo.com',
        countryId: 1,
        dob: 739299600000,
        address: '123 Phạm Văn Chí, Phường 7, Quận 6, TP Hồ Chí Minh',
        startDate: 1517418000000,
        endDate: 1549040400000,
        vehicleId: 1,
        status: 1,
        workingCalendar: {
            workingDays: {
                mon: true,
                tue: true,
                wed: false,
                thu: true,
                fri: false,
                sat: true,
                sun: false,
            },
            holidays: [
                {
                    fromDate: 1554310800000,
                    toDate: 1555520400000
                }
            ]
        },
        documents: {
        driverLicense: [
            'driverLicense_1.png',
            'driverLicense_2.png',
        ],
        proofOfId: [
            'proofOfId.png'
        ],
        vehicleInsuranceCert: [
            'vehicleInsuranceCert_1.png',
            'vehicleInsuranceCert_2.png'
        ],
        drivingRecord: [
            'drivingRecord.png'
        ],
        criminalBackgroundCheck: [
            'criminalBackgroundCheck1.png'
        ],
        certOfRegistration: [
            'certOfRegistration.png'
        ],
        other: [
            'no_file.png'
        ]
        },
        bankInformation: {
            bankAccName: 'HuyL6',
            bankName: 'Huy Ly',
            bankAccNo: 'TP1239239',
            bankBsbNo: 1234,
            bankAbn: 323
        }
    },
];

