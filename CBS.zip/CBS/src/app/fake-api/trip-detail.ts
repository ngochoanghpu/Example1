import { TripDetailsModel } from '@app/services/models/trip-details.model';

export const TRIPDETAIL: TripDetailsModel[] = [
    {
        id: 123,
        date: '02-May-2017',
        fare: 459,
        tollFee: 10.25,
        airport: 210,
        earning: 190,
        commission: 20,
        hdGst: 8,
        balance: 300,
        totalGst: 100,
        status: 1
    },
    {
        id: 123,
        date: '02-May-2017',
        fare: 459,
        tollFee: 10.25,
        airport: 210,
        earning: 190,
        commission: 20,
        hdGst: 8,
        balance: 300,
        totalGst: 100,
        status: 1
    },
    {
        id: 123,
        date: '02-May-2017',
        fare: 459,
        tollFee: 10.25,
        airport: 210,
        earning: 190,
        commission: 20,
        hdGst: 8,
        balance: 300,
        totalGst: 100,
        status: 0
    },
    {
        id: 123,
        date: '02-May-2017',
        fare: 459,
        tollFee: 10.25,
        airport: 210,
        earning: 190,
        commission: 20,
        hdGst: 8,
        balance: 300,
        totalGst: 100,
        status: 0
    }
];
