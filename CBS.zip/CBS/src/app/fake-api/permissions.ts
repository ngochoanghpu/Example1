import { PermissionsModel } from '@app/services/models/permissions.model';

export const PERMISSIONS: PermissionsModel[] = [
    {
        id: 1,
        name: 'Dashboard',
        actions: {
            canRead: false,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    },
    {
        id: 2,
        name: 'Vehicles',
        actions: {
            canRead: false,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    },
    {
        id: 3,
        name: 'Driver',
        actions: {
            canRead: false,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    },
    {
        id: 4,
        name: 'Passengers',
        actions: {
            canRead: false,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    },
    {
        id: 5,
        name: 'Trips',
        actions: {
            canRead: false,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    },
    {
        id: 6,
        name: 'Fares',
        actions: {
            canRead: false,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    },
    {
        id: 7,
        name: 'Settings',
        actions: {
            canRead: false,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    },
    {
        id: 8,
        name: 'Report',
        actions: {
            canRead: false,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    }
];
