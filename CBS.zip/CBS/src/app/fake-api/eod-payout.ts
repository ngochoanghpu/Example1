import { EODPayoutModel } from '@app/services/models/eod-payout.model';
import { DRIVERS } from './drivers';

export const EODPAYOUT: EODPayoutModel[] = [
  {
    id: 1,
    driver: DRIVERS[0],
    date: '02-May-2017',
    payAmount: 400,
    payDate: '02-May-2017',
    paymentStatus: 1,
    status: 1
  },
  {
    id: 2,
    driver: DRIVERS[1],
    date: '02-May-2017',
    payAmount: 400,
    payDate: '02-May-2017',
    paymentStatus: 1,
    status: 1
  },
  {
    id: 3,
    driver: DRIVERS[0],
    date: '02-May-2017',
    payAmount: 400,
    payDate: '02-May-2017',
    paymentStatus: 0,
    status: 0
  }
];
