export const DRIVER_REGISTRATION: any = [
  {
    id: 1,
    firstName: 'Huy',
    lastName: 'Ly',
    avatar: 'user-1.jpg',
    phoneCode: '+84',
    mobilePhone: '092309230',
    homePhone: '8589433',
    rating: 3,
    email: '123@demo.com',
    country: 'Vietnam',
    dob: 739299600000,
    address: '123 Phạm Văn Chí, Phường 7, Quận 6, TP Hồ Chí Minh',
    registrationDate: '01-Jan-2018',
    startDate: 1517418000000,
    endDate: 1549040400000,
    license: 132312323,
    licenseExpiryDate: 1654362000000,
    typeOfService: ['Car'],
    availableCar: 'Toyota Brand new 7',
    cardAuthorityNo: 14141423232,
    cardExpiryDate: 1725814800000,
    depositAmount: 459.25,
    commission: 12,
    status: 1,
    model: 'Toyota',
    numberPlate: '1111',
    passengerSeats: 2,
    vin: 'Toyota Tarago 14',
    year: '01-Feb-2019',
    regoRenewalDate: '04-Jul-2019',
    currentKms: 12,
    kmsBeforeService: 123,
    lastServiceKms: '1234567',
    nextServiceKms: '324555',
    insuranceRenewalDate: '01-Jan-2020',
    etagNumber: 'Toyota Tarago 14',
    accountName: 'Huy Ly',
    accountNumber: '7946312321',
    bankName: 'TP Bank',
    bsbNumber: 'G7897',
    abn: '1234597',
    note: 'Nam incididunt aliquip, mauris officiis magna natus dolores augue optio facilis nostrud, quo quisquam, leo, dolorem! Nam sapiente placeat aute',
    driverLicense: [
      'driverLicense_1.png',
      'driverLicense_2.png',
    ],
    proofOfId: [
      'proofOfId.png'
    ],
    vehicleInsuranceCert: [
      'vehicleInsuranceCert_1.png',
      'vehicleInsuranceCert_2.png'
    ],
    drivingRecord: [
      'drivingRecord.png'
    ],
    criminalBackgroundCheck: [
      'criminalBackgroundCheck1.png'
    ],
    certOfRegistration: [
      'certOfRegistration.png'
    ],
    other: [
      'no_file.png'
    ],
    workingCalendar: [
      'Mon',
      'Tue',
      '',
      '',
      'Fri',
      'Sat',
      'Sun',
    ]
  },
  {
    id: 2,
    firstName: 'Phat',
    lastName: 'Le',
    avatar: 'user-avatar.jpg',
    phoneCode: '+84',
    mobilePhone: '192309230',
    homePhone: '8589433',
    rating: 3,
    email: '123@demo.com',
    country: 'Vietnam',
    dob: 739299600000,
    address: '123 Phạm Văn Chí, Phường 7, Quận 6, TP Hồ Chí Minh',
    registrationDate: '01-Dec-2017',
    startDate: 1517418000000,
    endDate: 1549040400000,
    license: 132312323,
    licenseExpiryDate: 1654362000000,
    typeOfService: ['Car', 'Airport', 'Cruise', 'Other'],
    availableCar: 'BMW i8',
    cardAuthorityNo: 14141423232,
    cardExpiryDate: 1725814800000,
    depositAmount: 459.25,
    commission: 12,
    status: 0,
    model: 'BMW',
    numberPlate: '2222',
    passengerSeats: 4,
    vin: 'BMW i8',
    year: '01-Dec-2019',
    regoRenewalDate: '05-Jul-2019',
    lastServiceKms: '1234567',
    nextServiceKms: '324555',
    insuranceRenewalDate: '01-Jan-2020',
    etagNumber: 'Toyota 1212-7',
    accountName: 'Phat Le Tan',
    accountNumber: '1321546789',
    bankName: 'Shinghan',
    bsbNumber: 'T7897',
    abn: '7986465',
    note: 'Nam incididunt aliquip, mauris officiis magna natus dolores augue optio facilis nostrud, quo quisquam, leo, dolorem! Nam sapiente placeat aute',
    driverLicense: [
      'driverLicense_1.png',
      'driverLicense_2.png',
    ],
    proofOfId: [
      'proofOfId.png'
    ],
    vehicleInsuranceCert: [
      'vehicleInsuranceCert_1.png',
      'vehicleInsuranceCert_2.png'
    ],
    drivingRecord: [
      'drivingRecord.png'
    ],
    criminalBackgroundCheck: [
      'criminalBackgroundCheck1.png'
    ],
    certOfRegistration: [
      'certOfRegistration.png'
    ],
    other: [
      'no_file.png'
    ],
    workingCalendar: [
      'Mon',
      'Tue',
      'Wed',
      'Thu',
      '',
      '',
      '',
    ]
  },
];
