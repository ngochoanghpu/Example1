export const GeneralSettings = {
  autoRefreshTime: 30,
  smsEmail: 'no-reply@carbookingsolutions.app',
  landingPageUrl: 'https://carbookingsolutions.app'
};

export const BookingInNowSettings = {
  receiveBookingRequestTime: 30,
  bookingInNowRadius1st: 5,
  bookingInNowRadius2nd: 15,
  bookingInNowTime1st: 5,
  bookingInNowTime2nd: 25
};

export const ScheduledBookingSettings = {
  receivingBookingRequestTime: 30,
  scheduledBookingRadius1st: 2,
  scheduledBookingRadius2nd: 20,
  scheduledBookingAirportRadius1st: 10,
  scheduledBookingAirportRadius2nd: 10,
  scheduledBookingTime1st: 100,
  scheduledBookingTime2nd: 100,
  allowedTimeForCreatingBooking1st: 10,
  allowedTimeForCreatingBooking2nd: 100,
  reminderTime1st: 10,
  reminderTime2nd: 100,
  cancellationFeePeriod1st: 100,
  cancellationFeePeriod2nd: 100,
  cancellationFee1st: 100,
  cancellationFee2nd: 100,
  allowedTimeForMakingContact1st: 10,
  allowedTimeForMakingContact2nd: 10,
  timeoutForMigration1st: 10,
  timeoutForMigration2nd: 100
};

export const SettingsByCountries = {
  countryName: 'VietNam',
  cancellationFee: 20,
  gst: 20,
  warningLimit: 10,
  depositLockCash: 10,
  warningLimitSendSMS: true,
  depositLockCashSendSMS: false
};

export const TermsOfUse = {
  content: "<b>Lorem Ipsum</b> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
};
