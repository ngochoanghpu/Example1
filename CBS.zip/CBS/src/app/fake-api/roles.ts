import { RoleModel } from '@app/services/models/role.model';
import { PERMISSIONS } from './permissions';

export const ROLES: any[] = [
  {
    id: 1,
    name: 'Admin',
    dec: 'Admin App',
    permission: [
      {
        id: 1,
        name: 'Dashboard',
        actions: {
          canRead: true,
          canCreate: true,
          canUpdate: true,
          canDelete: true,
        }
      },
      {
        id: 2,
        name: 'Vehicles',
        actions: {
          canRead: true,
          canCreate: true,
          canUpdate: false,
          canDelete: false,
        }
      },
      {
        id: 3,
        name: 'Driver',
        actions: {
          canRead: true,
          canCreate: true,
          canUpdate: false,
          canDelete: false,
        }
      },
      {
        id: 4,
        name: 'Passengers',
        actions: {
          canRead: true,
          canCreate: false,
          canUpdate: false,
          canDelete: false,
        }
      },
      {
        id: 5,
        name: 'Trips',
        actions: {
          canRead: true,
          canCreate: false,
          canUpdate: false,
          canDelete: false,
        }
      },
      {
        id: 6,
        name: 'Fares',
        actions: {
          canRead: true,
          canCreate: false,
          canUpdate: false,
          canDelete: false,
        }
      }
    ]
  },
  {
    id: 2,
    name: 'System Admin',
    description: 'Admin System',
    permission: [
      {
        id: 7,
        name: 'Settings',
        actions: {
            canRead: true,
            canCreate: true,
            canUpdate: true,
            canDelete: true,
        }
    },
    {
        id: 8,
        name: 'Report',
        actions: {
            canRead: true,
            canCreate: false,
            canUpdate: false,
            canDelete: false,
        }
    }
    ]
  }
];
