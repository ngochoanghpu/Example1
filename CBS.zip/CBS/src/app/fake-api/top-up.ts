import { TopUpModel } from '@app/services/models/top-up.model';
import { DRIVERS } from './drivers';

export const TOPUP: TopUpModel[] = [
  {
    id: 1,
    driver: DRIVERS[0],
    date: '02-Apr-2019',
    topupAmount: 50,
    topupType: 459.25,
    paymentStatus: 1,
    status: 1
  },
  {
    id: 2,
    driver: DRIVERS[1],
    date: '02-Apr-2019',
    topupAmount: 50,
    topupType: 459.25,
    paymentStatus: 1,
    status: 1
  },
  {
    id: 3,
    driver: DRIVERS[0],
    date: '02-Apr-2019',
    topupAmount: 50,
    topupType: 459.25,
    paymentStatus: 0,
    status: 0
  }
];
