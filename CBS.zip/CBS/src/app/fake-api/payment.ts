import { PaymentModel } from '@app/services/models/payment.model';
import { DRIVERS } from './drivers';

export const PAYMENT: PaymentModel[] = [
    {
        id: 123,
        driver: DRIVERS[0],
        startDateTime: '01-April-2019',
        tripId: 321,
        paymentMethod: 'Cash',
        preCollect: 50,
        fare: 459.25,
        hdGst: 379.25,
        driverGst: 10,
        commission: 20
    },
    {
        id: 123,
        driver: DRIVERS[1],
        startDateTime: '01-April-2019',
        tripId: 321,
        paymentMethod: 'Cash',
        preCollect: 50,
        fare: 459.25,
        hdGst: 379.25,
        driverGst: 10,
        commission: 20
    },
    {
        id: 123,
        driver: DRIVERS[0],
        startDateTime: '01-April-2019',
        tripId: 321,
        paymentMethod: 'Cash',
        preCollect: 50,
        fare: 459.25,
        hdGst: 379.25,
        driverGst: 10,
        commission: 20
    },
    {
        id: 123,
        driver: DRIVERS[1],
        startDateTime: '01-April-2019',
        tripId: 321,
        paymentMethod: 'Cash',
        preCollect: 50,
        fare: 459.25,
        hdGst: 379.25,
        driverGst: 10,
        commission: 20
    },
    {
        id: 123,
        driver: DRIVERS[0],
        startDateTime: '01-April-2019',
        tripId: 321,
        paymentMethod: 'Cash',
        preCollect: 50,
        fare: 459.25,
        hdGst: 379.25,
        driverGst: 10,
        commission: 20
    },
];
