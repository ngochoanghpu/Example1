export const TypeOfServices: any = [
  {
    id: 1,
    name: 'Car'
  }
];
