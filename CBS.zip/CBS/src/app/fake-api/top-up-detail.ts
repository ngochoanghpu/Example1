import { TopUpDetailModel } from '@app/services/models/top-up-detail.model';

export const TOPUPDETAIL: TopUpDetailModel[] = [
    {
      id: 1,
      date: '02-Apr-2019',
      topupAmount: 50,
      topupType: 459.25,
      paymentStatus: 1
    },
    {
      id: 2,
      date: '01-Apr-2019',
      topupAmount: 50,
      topupType: 459.25,
      paymentStatus: 1
    },
    {
      id: 3,
      date: '31-Mar-2019',
      topupAmount: 50,
      topupType: 459.25,
      paymentStatus: 0
    }
  ];
