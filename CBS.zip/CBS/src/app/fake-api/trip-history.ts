import { TripHistoryModel } from '@app/services/models/trip-history.model';

export const TRIP_HISTORY: TripHistoryModel[] = [
  {
    id: 1,
    driver: 'Driver 1',
    passenger: 'Passenger 1',
    passengerAvt: 'user-1.jpg',
    driverAvt: 'user-2.png',
    pickUp: '124 Đường Số 49, P. Hiệp Bình phước, Q. thủ đức, TP.HCM',
    endDateTime: '02-May-2017',
    dropOff: '123 Phạm Văn Chí, P.5, Q.6, TP.HCM',
    totalFare: 400,
    rating: 3,
    comment: 'Ptos interdum torquent',
  },
  {
    id: 2,
    driver: 'Driver 2',
    passenger: 'Passenger 2',
    passengerAvt: 'user-1.jpg',
    driverAvt: 'user-2.png',
    pickUp: '124 Đường Số 49, P. Hiệp Bình phước, Q. thủ đức, TP.HCM',
    endDateTime: '02-May-2017',
    dropOff: '123 Phạm Văn Chí, P.5, Q.6, TP.HCM',
    totalFare: 400,
    rating: 3,
    comment: 'Ptos interdum torquent, mus culpa, minim nullam risus ultrices',
  },
];
