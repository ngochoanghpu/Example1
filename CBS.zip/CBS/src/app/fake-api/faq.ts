import { FAQCategoryModel } from '@app/services/models/faq.model';
import { FAQDETAILS } from './faq-details';

export const FAQ: FAQCategoryModel[] = [
    {
        id: 1,
        title: 'Frequently Asked Questions',
        subTitle: 'Frequently Asked Questions',
        icon: 'flaticon-lifebuoy',
        iconColor: '#ffb822',
        details: FAQDETAILS
    },
    {
        id: 2,
        title: 'What service CBS',
        subTitle: 'Frequently Asked Questions',
        icon: 'flaticon-coins',
        iconColor: '#36a3f7',
        details: FAQDETAILS
    },
    {
        id: 3,
        title: 'How do I know CBS is Installed?',
        subTitle: 'Frequently Asked Questions',
        icon: 'flaticon-lock',
        iconColor: '#f4516c',
        details: FAQDETAILS
    },
    {
        id: 4,
        title: 'General App CBS',
        subTitle: 'Frequently Asked Questions',
        icon: 'flaticon-support',
        iconColor: '#34bfa3',
        details: FAQDETAILS
    },
    {
        id: 5,
        title: 'Frequently Asked Questions',
        subTitle: 'Frequently Asked Questions',
        icon: 'flaticon-file',
        iconColor: '#6610f2',
        details: FAQDETAILS
    }
];
