export const TypeOfVehicleFare: any = [
    {    
      id: 1,
      name: 'Toyota Vios'
    }
  ];