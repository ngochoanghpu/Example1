export const COUNTRIES: any = [
  {
    id: '1',
    code: 'VN',
    name: 'Viet Nam',
    flag: 'vn.svg',
    currency: 'VND'
  },
  {
    id: '2',
    code: 'US',
    name: 'United State',
    flag: 'us.svg',
    currency: 'USD'
  }
];
