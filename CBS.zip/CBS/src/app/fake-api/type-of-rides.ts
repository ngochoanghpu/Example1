export const TypeOfRides: any = [
  {
    id: 1,
    name: 'Vehicle'
  }
];
