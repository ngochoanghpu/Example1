export const TypeOfVehicles: any = [
  {    
    id: '2',
    name: '2'
  },
  {
    id: '4',
    name: '4'
  },
  {
    id: '7',
    name: '7'
  }
];
