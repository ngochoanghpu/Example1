export const BADGE_TYPE = {
  INFO: 'info',
  DEFAULT: 'default',
  SUCCESS: 'success',
  WARNING: 'warning',
  DANGER: 'danger'
};

export const STATUS_LABEL = {
  ACTIVE: 'LBL_STATUS_ACTIVE',
  INACTIVE: 'LBL_STATUS_INACTIVE',

  NEW: 'LBL_STATUS_NEW',
  IN_PROGRESS: 'LBL_STATUS_IN_PROGRESS',
  COMPLETED: 'LBL_STATUS_COMPLETED',

  OPEN: 'LBL_STATUS_OPEN',
  CANCELLED: 'LBL_STATUS_CANCELLED',
  CLOSED: 'LBL_STATUS_CLOSED',

  PAID: 'LBL_STATUS_PAID',
  UNPAID: 'LBL_STATUS_UNPAID',

  PENDDING: 'LBL_STATUS_PENDING',
  REJECTED: 'LBL_STATUS_REJECTED',
  ONTRIP: 'LBL_STATUS_CLOSED',
  PICKING_UP: 'LBL_STATUS_PICKING_UP'
};

export const STATUS = {
  DEFAULT: {
    0: { style: BADGE_TYPE.DEFAULT, text: STATUS_LABEL.INACTIVE },
    1: { style: BADGE_TYPE.SUCCESS, text: STATUS_LABEL.ACTIVE },
    2: { style: BADGE_TYPE.WARNING, text: STATUS_LABEL.INACTIVE},
    3: { style: BADGE_TYPE.DANGER, text: STATUS_LABEL.CANCELLED},
  },

  REGISTRATION: {
    0: { style: BADGE_TYPE.WARNING, text: STATUS_LABEL.PENDDING },
    1: { style: BADGE_TYPE.SUCCESS, text: STATUS_LABEL.ACTIVE },
    2: { style: BADGE_TYPE.DANGER, text: STATUS_LABEL.REJECTED }
  },

  PAYMENT: {
    0: { style: BADGE_TYPE.DEFAULT, text: STATUS_LABEL.UNPAID },
    1: { style: BADGE_TYPE.SUCCESS, text: STATUS_LABEL.PAID }
  },

  TRIP: {
    0: { style: BADGE_TYPE.SUCCESS, text: STATUS_LABEL.OPEN },
    1: { style: BADGE_TYPE.DANGER, text: STATUS_LABEL.PICKING_UP },
    2: { style: BADGE_TYPE.DEFAULT, text: STATUS_LABEL.ONTRIP },
    3: { style: BADGE_TYPE.DANGER, text: STATUS_LABEL.CANCELLED },
    4: { style: BADGE_TYPE.SUCCESS, text: STATUS_LABEL.COMPLETED }
  }
};

export const DATETIME_FORMAT = {
  SHORT_DATE: 'DD-MMM-YYYY',
  LONG_DATE: 'DD-MMM-YYYY hh:mm',
  SHORT_TIME: 'hh:mm',
  LONG_TIME: 'hh:mm:ss',
  STORE_DATETIME: 'MM/DD/YYYY hh:mm:ss',
  DEFAULT_DATE: 'MM/DD/YYYY'
};

export const AVATAR = {
  DEFAULT: 'assets/img/ava.png',
  SIZE: {
    DEFAULT: 'dnf-avatar--size-default',
    MEDIUM: 'dnf-avatar--size-medium',
    LARGE: 'dnf-avatar--size-large'
  }
};

export const REGEX_PATTERN = {
  PASSWORD: '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])[a-zA-Z0-9#?!@$%^&*-~\.]{8,20}$',
  EMAIL: '[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}',
  NUMBER: '^[0-9]*$',
  DECIMAL_WITH_TWO_NUMBER: '[0-9]+(.[0-9]{1,2})?$',
  RANGE_0_TO_10000:
    '([0-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|10000)',
  RANGE_0_TO_9999: '^\\d{1,4}$',
  RANGE_0_TO_9999999: '^\\d{1,7}$',
  URL: '(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-=#_?$!+@%&-]*/?',
  ZIPCODE: '^[0-9]{5,6}$',
  STR_WITHOUT_SPECIAL_CHAR: '^[a-zA-Z0-9]+$',
  PHONE: '^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$'
};

export const CONSTANTS = {
  LOCAL_STORAGE: {
    USER_PROFILE: 'userProfile',
  },
  ACTIONS: {
    READ: 'canRead',
    UPDATE: 'canUpdate',
    CREATE: 'canCreate',
    DELETE: 'canDelete',
  },
  FEATURES_CODE: {
    VEHICLE: 'VEH',
    DRIVER: 'DRI',
    PASSENGER: 'PAS',
    TRIP: 'TRI',
    FARE: 'FAR',
    USER: 'USER',
  }
};


export enum PAYMENT_METHOD {
  Cash = 0,
  IB = 1,
  'Visa/Master' = 2
}

export enum STATUS_ENUM {
  INACTIVE = 0,
  ACTIVE = 1
}

export enum SETTINGS {
  General,
  BookingInNow,
  ScheduledBooking,
  SettingByCountries
}

export enum ACTIONS {
  canRead = 0,
  canCreate = 1,
  canUpdate = 2,
  canDelete = 3
}

export enum MENU {
  Settings = 'Settings'
}

export const DAYS_OF_WEEK = ['LBL_MON', 'LBL_TUE', 'LBL_WED', 'LBL_THU', 'LBL_FRI', 'LBL_SAT', 'LBL_SUN'];

export enum TYPE_OF_SERVICES {
  'Car' = 1
}

export enum TYPE_OF_RIDES {
  'Vehicle' = 1
}

export enum TYPE_OF_VEHICLES {
  'Toyota Vios' = 1
}

export const DRIVER_DOCUMENTS = ['driverLicense', 'proofOfId', 'vehicleInsuranceCert', 'drivingRecord', 'criminalBackgroundCheck', 'certOfRegistration', 'other'];
