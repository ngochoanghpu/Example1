export const CURRENCY = {
  US: {
    symbol: '$',
    formatString: '$0,0',
    locale: 'us',
    delimiters: {
      thousands: ',',
      decimal: '.'
    }
  },
  VN: {
    symbol: 'VND',
    formatString: '0,0 $',
    locale: 'vn',
    delimiters: {
      thousands: '.'
    }
  },
  EU: {
    symbol: '€',
    formatString: '$0,0',
    locale: 'eu',
    delimiters: {
      thousands: '.',
      decimal: ','
    }
  }
};

export const CURRENCY_DEFAULT = CURRENCY.US;
