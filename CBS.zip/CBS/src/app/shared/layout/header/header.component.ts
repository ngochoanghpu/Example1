import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { MatDialog } from '@angular/material';
import { EditProfileDialogComponent } from './components/edit-profile-dialog/edit-profile-dialog.component';
import { ChangePasswordDialogComponent } from './components/change-password-dialog/change-password-dialog.component';
import { CONSTANTS } from '@app/shared/constant';
import { ProfileNoticeService } from '@app/core/profile/profile-notice.service';
import { AuthService } from '@app/services/auth.service';
import { LoaderService } from '@app/services/loader.service';
import { Router } from '@angular/router';

@Component({
  selector: 'dnf-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  profile: any;

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private router: Router,
    public dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    private authService: AuthService,
    private loaderService: LoaderService,
    private profileNoticeService: ProfileNoticeService
  ) { }

  ngOnInit() {
    this.profile = JSON.parse(localStorage.getItem(CONSTANTS.LOCAL_STORAGE.USER_PROFILE));

    this.profileNoticeService.onNoticeChanged$.subscribe((profile: any) => {
      if(profile){
        this.profile = profile;
        this.cdr.markForCheck();
      }      
    });
  }

  clickTopbarToggle(event: Event): void {
    this.document.body.classList.toggle('m-topbar--on');
  }

  private _initDialog(component: any, dialogSize: string, callbackFunction: Function) {
    const dialogRef = this.dialog.open(component, {
      width: dialogSize
    });

    dialogRef.afterClosed().subscribe(result => {
      callbackFunction();
    });
  }

  showEditProfile(): void {
    this._initDialog(EditProfileDialogComponent, DIALOG_SIZE.medium, () => {
      console.log('close modal after edit profile');
    });
  }

  showChangePasswordModal(): void {
    this._initDialog(ChangePasswordDialogComponent, DIALOG_SIZE.medium, () => {
      console.log('close modal after change password');
    });
  }

  logout(){
    this.loaderService.show();
    this.authService.logout().subscribe(res => {
      if (res) {
        localStorage.removeItem(CONSTANTS.LOCAL_STORAGE.USER_PROFILE);        
        this.loaderService.hide();
        this.router.navigate(['login']);
      }
    });
  }
}
