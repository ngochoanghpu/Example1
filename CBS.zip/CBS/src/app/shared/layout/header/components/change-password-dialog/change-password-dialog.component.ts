import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { CONSTANTS } from '@app/shared/constant';
import { AuthService } from '@app/services/auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { REGEX_PATTERN } from '@app/shared/constant';
import { ErrorStateMatcher } from '@angular/material/core';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl): boolean {
    let confirmNewPassword = control.parent.get('confirmNewPassword');
    if(confirmNewPassword.touched && (confirmNewPassword.hasError("required") || confirmNewPassword.hasError("pattern"))){
      return true;
    }

    let newPassword = control.parent.get('newPassword');
    return (confirmNewPassword.value && newPassword.value !== confirmNewPassword.value && control.dirty)
  }
}

@Component({
  selector: 'dnf-change-password-dialog',
  templateUrl: './change-password-dialog.component.html',
  styleUrls: ['./change-password-dialog.component.scss']
})
export class ChangePasswordDialogComponent implements OnInit {
  form: FormGroup;
  profile: any;
  matcher = new MyErrorStateMatcher();

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private toastr: ToastrService,
    private translate: TranslateService,
    public dialogRef: MatDialogRef<ChangePasswordDialogComponent>) { }

  ngOnInit() {
    this.form = this.fb.group({
      currentPassword: null,
      newPassword: [null, Validators.pattern(REGEX_PATTERN.PASSWORD)],
      confirmNewPassword: [null, Validators.pattern(REGEX_PATTERN.PASSWORD)],
    },{ validator: this.checkPasswords });

    this.profile = JSON.parse(localStorage.getItem(CONSTANTS.LOCAL_STORAGE.USER_PROFILE));
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  save(): void {
    this.authService.changePassword({
      currentPassword: this.form.value.currentPassword,
      newPassword: this.form.value.newPassword,
    }).subscribe(() => {
      this.toastr.success(
        this.translate.instant('MSG_SUCCESSFULLY', {
          item: this.translate.instant('LBL_PASSWORD'),
          action: this.translate.instant('ACTION_UPDATED'),
        })
      );
      this.dialogRef.close();
      this.router.navigate(['/login']);
    });
  }

  checkPasswords(group: FormGroup) {
    let newPassword = group.controls.newPassword.value;
    let confirmNewPassword = group.controls.confirmNewPassword.value;
    return newPassword == confirmNewPassword ? null : { notMatch: true };
  }
}