import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CountriesService } from '@app/services/countries.service';
import { CountryModel } from '@app/services/models/country.model';
import { UsersService } from '@app/services/users.service';
import { CONSTANTS, REGEX_PATTERN } from '@app/shared/constant';
import _ from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import moment from 'moment';
import { DATETIME_FORMAT } from '@app/shared/constant';
import { ProfileNoticeService } from '@app/core/profile/profile-notice.service';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-edit-profile-dialog',
  templateUrl: './edit-profile-dialog.component.html',
  styleUrls: ['./edit-profile-dialog.component.scss']
})
export class EditProfileDialogComponent implements OnInit {
  profile: any;
  form: FormGroup;
  countries: Array<CountryModel>;
  imgPath: any;
  isRemovedAvatar = false;

  constructor(
    private fb: FormBuilder,
    private userService: UsersService,
    private countryService: CountriesService,
    private toastr: ToastrService,
    private translate: TranslateService,
    private loaderService: LoaderService,
    private profileNoticeService: ProfileNoticeService,
    public dialogRef: MatDialogRef<EditProfileDialogComponent>
  ) { }

  ngOnInit() {
    this.profile = JSON.parse(localStorage.getItem(CONSTANTS.LOCAL_STORAGE.USER_PROFILE));
    this._buildForm(this.profile);

    this.userService.getProfile().subscribe((profile) => {
      this._buildForm(profile);
      this.profile = profile;
      this.imgPath = profile.profileImage;
    });

    this._triggerUploadFileInput();
    this._getCountries();
  }

  _buildForm(profile: any) {
    this.form = this.fb.group({
      firstName: profile.firstName,
      lastName: profile.lastName,
      email: [profile.email, Validators.pattern(REGEX_PATTERN.EMAIL)],
      phoneCode: profile.phoneCode,
      phoneNumber: profile.phoneNumber,
      dob: profile.dob,
      countryId: profile.countryId,
      address: profile.address,
    });
  }

  _getCountries(): void {
    this.countryService.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  }

  deleteAvatar(image){
    this.imgPath = null;    
    $('#upload-avt-input').val(null);
  }

  _triggerUploadFileInput() {
    $('#upload-avt').click(function () {
      $('#upload-avt-input').click();
    });
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  save(): void {
    this.loaderService.show();
    if ($('#upload-avt-input').val()) {
      this.form.value.avatar = this.imgPath;
    }
    else if(!this.imgPath) {
      this.form.value.avatar = null;
    }

    this.form.value.dob = moment(this.form.value.dob).format(DATETIME_FORMAT.DEFAULT_DATE);

    this.userService.updateUser(this.profile.id,
      _.omit(this.form.value, ['email']),
    ).subscribe(data => {     
      localStorage.setItem(CONSTANTS.LOCAL_STORAGE.USER_PROFILE, JSON.stringify(data));
      this.profileNoticeService.setNotice(data);
      this.toastr.success(
        this.translate.instant('MSG_SUCCESSFULLY', {
          item: this.translate.instant('LBL_USER'),
          action: this.translate.instant('ACTION_UPDATED'),
        })
      );
      this.loaderService.hide();
      this.dialogRef.close(true);
    });
  }

  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = _event => {
        this.imgPath = reader.result;
      };
    }
  }
}
