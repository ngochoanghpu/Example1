import { Component, OnInit, ChangeDetectionStrategy, AfterViewInit, HostBinding, ElementRef } from '@angular/core';
import { MenuHorizontalOffcanvasDirective } from '@app/core/directives/menu-horizontal-offcanvas.directive';
import { MenuHorizontalDirective } from '@app/core/directives/menu-horizontal.directive';
import { PermissionService } from '@app/services/permission.service';

@Component({
  selector: 'dnf-menu-horizontal',
  templateUrl: './menu-horizontal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MenuHorizontalComponent implements OnInit, AfterViewInit {
  featureCode = 'REP';
  permission = {
    canRead: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false
  };
  @HostBinding('id') id = 'm_header_menu';
  @HostBinding('attr.dnfMenuHorizontalOffcanvas') mMenuHorOffcanvas: MenuHorizontalOffcanvasDirective;
  @HostBinding('attr.dnfMenuHorizontal') mMenuHorizontal: MenuHorizontalDirective;

  constructor(private el: ElementRef, private permissionService: PermissionService) { }

  ngOnInit() {
    this.permission = this.permissionService._getFeaturePermission(this.featureCode);
  }

  ngAfterViewInit(): void {
    Promise.resolve(null).then(() => {
      this.mMenuHorOffcanvas = new MenuHorizontalOffcanvasDirective(this.el);
      this.mMenuHorOffcanvas.ngAfterViewInit();

      this.mMenuHorizontal = new MenuHorizontalDirective(this.el);
      this.mMenuHorizontal.ngAfterViewInit();
    });
  }

}
