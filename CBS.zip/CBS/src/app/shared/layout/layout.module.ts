import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CoreModule } from '@app/core';
import { DesignModule } from '../design/design.module';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AsideComponent } from './aside/aside.component';
import { MenuHorizontalComponent } from './header/menu-horizontal/menu-horizontal.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { EditProfileDialogComponent } from './header/components/edit-profile-dialog/edit-profile-dialog.component';
import { ChangePasswordDialogComponent } from './header/components/change-password-dialog/change-password-dialog.component';

@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    AsideComponent,
    MenuHorizontalComponent,
    SpinnerComponent,
    EditProfileDialogComponent,
    ChangePasswordDialogComponent
  ],
  imports: [CommonModule, RouterModule, CoreModule, DesignModule],
  exports: [
    HeaderComponent,
    FooterComponent,
    AsideComponent,
    MenuHorizontalComponent,
    SpinnerComponent,
    EditProfileDialogComponent
  ],
  entryComponents: [EditProfileDialogComponent, ChangePasswordDialogComponent]
})
export class LayoutModule {}
