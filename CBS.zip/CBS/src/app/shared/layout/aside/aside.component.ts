import { Component, OnInit, ChangeDetectionStrategy, AfterViewInit, HostBinding, ElementRef } from '@angular/core';
import { MenuAsideOffcanvasDirective } from '@app/core/directives/menu-aside-offcanvas.directive';
import { Router } from '@angular/router';
import { MenuConfig } from '@app/config/menu';
import { MENU } from '@app/shared/constant';
import _ from 'lodash';

@Component({
  selector: 'dnf-aside',
  templateUrl: './aside.component.html',
  styleUrls: ['./aside.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AsideComponent implements OnInit, AfterViewInit {

  @HostBinding('id') id = 'm_aside_left';
  @HostBinding('attr.mMenuAsideOffcanvas') mMenuAsideOffcanvas: MenuAsideOffcanvasDirective;

  currentRouteUrl: string;
  menus: any;

  constructor(
    private el: ElementRef,
    private router: Router) {
    this.showMenu();

  }

  ngOnInit(): void {
    this._getMenuPermission();
    this.currentRouteUrl = this.router.url.split(/[?#]/)[0];
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.mMenuAsideOffcanvas = new MenuAsideOffcanvasDirective(this.el);
      // manually call the directives' lifecycle hook method
      this.mMenuAsideOffcanvas.ngAfterViewInit();
    });
  }

  showMenu() {
    this.menus = new MenuConfig().config.aside;
    if (!this.isSuperAdmin()) {
      // TODO: show menu base on role & permissions

      // Hide Settings menu
      this.menus.items = _.filter(this.menus.items, function(item) {
        return item.title.toLowerCase() !== MENU.Settings.toLowerCase();
      });
    }
  }

  isSuperAdmin() {
    const userProfile = JSON.parse(localStorage.getItem('userProfile'));
    if (userProfile) {
      return userProfile.isSuperAdmin;
    }

    return false;
  }

  isMenuItemIsActive(menu: any): boolean {
    if (menu.submenu) {
        return this.isMenuRootItemIsActive(menu);
    }

    if (!menu.page) {
      return false;
    }

    // dashboard
    if (menu.page !== '/' && this.currentRouteUrl.startsWith(menu.page)) {
      return true;
    }
    return this.currentRouteUrl === menu.page;
  }

  isMenuRootItemIsActive(item): boolean {
    let result = false;

    for (const subItem of item.submenu) {
      result = this.isMenuItemIsActive(subItem);
      if (result) {
        return true;
      }
    }

    return false;
  }

  setPositionOfMenuItem(menu): string {
    if (!menu.position) {
      return '';
    }
    return 'm-menu__item--' + menu.position;
  }

  navigate(page: any) {
    this.currentRouteUrl = page;
    this.router.navigate([page]);
  }

  _getMenuPermission() {
    const currentUserProfile = JSON.parse(localStorage.getItem('userProfile'));
    for (let i = 0; i < this.menus.items.length; i++) {
      const permissions = this.menus.items[i].permission;
      if (this.menus.items[i].page === '/') {
        this.menus.items[i].display = true;
      }
      if (currentUserProfile && currentUserProfile.permissions) {
        const userPermissions = currentUserProfile.permissions.filter(p => p.code === this.menus.items[i].code);

        let isCanRead = true;
        if (typeof userPermissions[0] !== 'undefined') {
          isCanRead = permissions.canRead === userPermissions[0].actions.canRead;
        }

        this.menus.items[i].display = isCanRead;
      } else {
        this.menus.items[i].display = false;
      }
    }
  }
}
