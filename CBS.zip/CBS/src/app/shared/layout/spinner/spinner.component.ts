import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dnf-spinner',
  templateUrl: './spinner.component.html'
})
export class SpinnerComponent implements OnInit {
  @Input() overlay: boolean;
  @Input() loadInChild: Boolean;

  constructor() {}

  ngOnInit() {}
}
