import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'dnf-dropdown',
  templateUrl: './dropdown.component.html'
})
export class DropdownComponent implements OnInit, OnChanges {
  @Input() options: any; // Required
  @Input() text: any; // Required
  @Input() value: any; // Required
  @Input() selected: any; // Optional
  @Input() firstOption: { text: any; value: any }; // Optional
  constructor() {}

  ngOnInit() {
    this.selected = this.selected ? this.selected : '';
  }

  ngOnChanges() {
    if (typeof this.options !== 'undefined') {
      this._convertToDropdownFormat();
    }
  }

  _convertToDropdownFormat() {
    this.options = this.options.map(val => ({
      text: val[this.text],
      value: val[this.value]
    }));
  }
}
