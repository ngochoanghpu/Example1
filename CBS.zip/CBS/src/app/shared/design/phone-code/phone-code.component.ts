import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Select2OptionData, Select2TemplateFunction } from 'ng2-select2';

@Component({
    selector: 'dnf-phone-code',
    templateUrl: './phone-code.component.html',
    styleUrls: ['./phone-code.component.scss']
  })
  export class PhoneCodeComponent implements OnInit { 
  
    constructor(){

    }
    
    @Input() currentPhoneCode: string;
    @Output() callbackFunction = new EventEmitter<any>();
    phoneCodes: Array<Select2OptionData> = [];
    options: Select2Options;
    tmpPhoneCode: string;

    ngOnInit(){
        this.options = {
            templateResult: this.phoneCodeTemplate,
            templateSelection: this.phoneCodeSelection,
            placeholder: { id: '', text: 'Select Phone Code' },
            allowClear: true,
            width: '100%'
        };

        this.phoneCodes = this._initPhoneCodes();

        this.tmpPhoneCode = this.currentPhoneCode;
    }

    _initPhoneCodes() {
        return [
          {
            id: '+84',
            text: 'Viet Nam',
            additional: {
                image: 'assets/img/flags/1x1/vn.svg',
            }
          },          
          {
            id: '+93',
            text: 'Afghanistan',
            additional: {
                image: 'assets/img/flags/1x1/af.svg',
            }
          },
          {
            id: '+355',
            text: 'Albania',
            additional: {
                image: 'assets/img/flags/1x1/al.svg',
            }
          },
          {
            id: '+213',
            text: 'Algeria',
            additional: {
                image: 'assets/img/flags/1x1/dz.svg',
            }
          },
          {
            id: '+1684',
            text: 'American Samoa',
            additional: {
                image: 'assets/img/flags/1x1/as.svg',
            }
          },
          {
            id: '+376',
            text: 'Andorra',
            additional: {
                image: 'assets/img/flags/1x1/ad.svg',
            }
          }, 
          {
            id: '+244',
            text: 'Angola',
            additional: {
                image: 'assets/img/flags/1x1/ao.svg',
            }
          },
          {
            id: '+1264',
            text: 'Anguilla',
            additional: {
                image: 'assets/img/flags/1x1/ai.svg',
            }
          },
          {
            id: '+672',
            text: 'Antarctica',
            additional: {
                image: 'assets/img/flags/1x1/aq.svg',
            }
          },
          {
            id: '+1268',
            text: 'Antigua and Barbuda',
            additional: {
                image: 'assets/img/flags/1x1/ag.svg',
            }
          },
          {
            id: '+54',
            text: 'Argentina',
            additional: {
                image: 'assets/img/flags/1x1/ar.svg',
            }
          },
          {
            id: '+374',
            text: 'Armenia',
            additional: {
                image: 'assets/img/flags/1x1/am.svg',
            }
          },
          {
            id: '+297',
            text: 'Aruba',
            additional: {
                image: 'assets/img/flags/1x1/aw.svg',
            }
          },
          {
            id: '+61',
            text: 'Australia',
            additional: {
                image: 'assets/img/flags/1x1/au.svg',
            }
          },
          {
            id: '+43',
            text: 'Austria',
            additional: {
                image: 'assets/img/flags/1x1/at.svg',
            }
          },
          {
            id: '+994',
            text: 'Azerbaijan',
            additional: {
                image: 'assets/img/flags/1x1/az.svg',
            }
          },
          {
            id: '+1242',
            text: 'Bahamas',
            additional: {
                image: 'assets/img/flags/1x1/bs.svg',
            }
          },
          {
            id: '+973',
            text: 'Bahrain',
            additional: {
                image: 'assets/img/flags/1x1/bh.svg',
            }
          },
          {
            id: '+880',
            text: 'Bangladesh',
            additional: {
                image: 'assets/img/flags/1x1/bd.svg',
            }
          },
          {
            id: '+1246',
            text: 'Barbados',
            additional: {
                image: 'assets/img/flags/1x1/bb.svg',
            }
          },
          {
            id: '+375',
            text: 'Belarus',
            additional: {
                image: 'assets/img/flags/1x1/by.svg',
            }
          },
          {
            id: '+32',
            text: 'Belgium',
            additional: {
                image: 'assets/img/flags/1x1/be.svg',
            }
          },
          {
            id: '+501',
            text: 'Belize',
            additional: {
                image: 'assets/img/flags/1x1/bz.svg',
            }
          },
          {
            id: '+229',
            text: 'Benin',
            additional: {
                image: 'assets/img/flags/1x1/bj.svg',
            }
          },
          {
            id: '+1441',
            text: 'Bermuda',
            additional: {
                image: 'assets/img/flags/1x1/bm.svg',
            }
          },
          {
            id: '+975',
            text: 'Bhutan',
            additional: {
                image: 'assets/img/flags/1x1/bt.svg',
            }
          },
          {
            id: '+591',
            text: 'Bolivia',
            additional: {
                image: 'assets/img/flags/1x1/bo.svg',
            }
          },
          {
            id: '+387',
            text: 'Bosnia and Herzegovina',
            additional: {
                image: 'assets/img/flags/1x1/ba.svg',
            }
          },
          {
            id: '+267',
            text: 'Botswana',
            additional: {
                image: 'assets/img/flags/1x1/bw.svg',
            }
          },
          {
            id: '+55',
            text: 'Brazil',
            additional: {
                image: 'assets/img/flags/1x1/br.svg',
            }
          },
          {
            id: '+246',
            text: 'British Indian Ocean Territory',
            additional: {
                image: 'assets/img/flags/1x1/io.svg',
            }
          },
          {
            id: '+1284',
            text: 'British Virgin Islands',
            additional: {
                image: 'assets/img/flags/1x1/vg.svg',
            }
          },
          {
            id: '+673',
            text: 'Brunei',
            additional: {
                image: 'assets/img/flags/1x1/bn.svg',
            }
          },
          {
            id: '+359',
            text: 'Bulgaria',
            additional: {
                image: 'assets/img/flags/1x1/bg.svg',
            }
          },
          {
            id: '+226',
            text: 'Burkina Faso',
            additional: {
                image: 'assets/img/flags/1x1/bf.svg',
            }
          },
          {
            id: '+257',
            text: 'Burundi',
            additional: {
                image: 'assets/img/flags/1x1/bi.svg',
            }
          },
          {
            id: '+855',
            text: 'Cambodia',
            additional: {
                image: 'assets/img/flags/1x1/kh.svg',
            }
          },
          {
            id: '+237',
            text: 'Cameroon',
            additional: {
                image: 'assets/img/flags/1x1/cm.svg',
            }
          },
          {
            id: '+1',
            text: 'Canada',
            additional: {
                image: 'assets/img/flags/1x1/ca.svg',
            }
          },
          {
            id: '+238',
            text: 'Cape Verde',
            additional: {
                image: 'assets/img/flags/1x1/cv.svg',
            }
          },
          {
            id: '+1345',
            text: 'Cayman Islands',
            additional: {
                image: 'assets/img/flags/1x1/ky.svg',
            }
          },
          {
            id: '+236',
            text: 'Central African Republic',
            additional: {
                image: 'assets/img/flags/1x1/cf.svg',
            }
          },
          {
            id: '+235',
            text: 'Chad',
            additional: {
                image: 'assets/img/flags/1x1/td.svg',
            }
          },
          {
            id: '+56',
            text: 'Chile',
            additional: {
                image: 'assets/img/flags/1x1/cl.svg',
            }
          },
          {
            id: '+86',
            text: 'China',
            additional: {
                image: 'assets/img/flags/1x1/cn.svg',
            }
          },
          {
            id: '+61',
            text: 'Christmas Island',
            additional: {
                image: 'assets/img/flags/1x1/cx.svg',
            }
          },
          {
            id: '+61',
            text: 'Cocos Islands',
            additional: {
                image: 'assets/img/flags/1x1/cc.svg',
            }
          },
          {
            id: '+57',
            text: 'Colombia',
            additional: {
                image: 'assets/img/flags/1x1/co.svg',
            }
          },
          {
            id: '+269',
            text: 'Comoros',
            additional: {
                image: 'assets/img/flags/1x1/km.svg',
            }
          },
          {
            id: '+682',
            text: 'Cook Islands',
            additional: {
                image: 'assets/img/flags/1x1/ck.svg',
            }
          },
          {
            id: '+506',
            text: 'Costa Rica',
            additional: {
                image: 'assets/img/flags/1x1/cr.svg',
            }
          },
          {
            id: '+385',
            text: 'Croatia',
            additional: {
                image: 'assets/img/flags/1x1/hr.svg',
            }
          },
          {
            id: '+53',
            text: 'Cuba',
            additional: {
                image: 'assets/img/flags/1x1/cu.svg',
            }
          },
          {
            id: '+599',
            text: 'Curacao',
            additional: {
                image: 'assets/img/flags/1x1/cw.svg',
            }
          },
          {
            id: '+357',
            text: 'Cyprus',
            additional: {
                image: 'assets/img/flags/1x1/cy.svg',
            }
          },
          {
            id: '+420',
            text: 'Czech Republic',
            additional: {
                image: 'assets/img/flags/1x1/cz.svg',
            }
          },
          {
            id: '+243',
            text: 'Democratic Republic of the Congo',
            additional: {
                image: 'assets/img/flags/1x1/cd.svg',
            }
          },
          {
            id: '+45',
            text: 'Denmark',
            additional: {
                image: 'assets/img/flags/1x1/dk.svg',
            }
          },
          {
            id: '+253',
            text: 'Djibouti',
            additional: {
                image: 'assets/img/flags/1x1/dj.svg',
            }
          },
          {
            id: '+1767',
            text: 'Dominica',
            additional: {
                image: 'assets/img/flags/1x1/dm.svg',
            }
          },
          {
            id: '+670',
            text: 'East Timor',
            additional: {
                image: 'assets/img/flags/1x1/tl.svg',
            }
          },
          {
            id: '+593',
            text: 'Ecuador',
            additional: {
                image: 'assets/img/flags/1x1/ec.svg',
            }
          },
          {
            id: '+20',
            text: 'Egypt',
            additional: {
                image: 'assets/img/flags/1x1/eg.svg',
            }
          },
          {
            id: '+503',
            text: 'El Salvador',
            additional: {
                image: 'assets/img/flags/1x1/sv.svg',
            }
          },
          {
            id: '+240',
            text: 'Equatorial Guinea',
            additional: {
                image: 'assets/img/flags/1x1/gq.svg',
            }
          },
          {
            id: '+291',
            text: 'Eritrea',
            additional: {
                image: 'assets/img/flags/1x1/er.svg',
            }
          },
          {
            id: '+372',
            text: 'Estonia',
            additional: {
                image: 'assets/img/flags/1x1/ee.svg',
            }
          },
          {
            id: '+251',
            text: 'Ethiopia',
            additional: {
                image: 'assets/img/flags/1x1/et.svg',
            }
          },
          {
            id: '+500',
            text: 'Falkland Islands',
            additional: {
                image: 'assets/img/flags/1x1/fk.svg',
            }
          },
          {
            id: '+298',
            text: 'Faroe Islands',
            additional: {
                image: 'assets/img/flags/1x1/fo.svg',
            }
          },
          {
            id: '+679',
            text: 'Fiji',
            additional: {
                image: 'assets/img/flags/1x1/fj.svg',
            }
          },
          {
            id: '+358',
            text: 'Finland',
            additional: {
                image: 'assets/img/flags/1x1/fi.svg',
            }
          },
          {
            id: '+33',
            text: 'France',
            additional: {
                image: 'assets/img/flags/1x1/fr.svg',
            }
          },
          {
            id: '+689',
            text: 'French Polynesia',
            additional: {
                image: 'assets/img/flags/1x1/pf.svg',
            }
          },
          {
            id: '+241',
            text: 'Gabon',
            additional: {
                image: 'assets/img/flags/1x1/ga.svg',
            }
          },
          {
            id: '+220',
            text: 'Gambia',
            additional: {
                image: 'assets/img/flags/1x1/gm.svg',
            }
          },
          {
            id: '+995',
            text: 'Georgia',
            additional: {
                image: 'assets/img/flags/1x1/ge.svg',
            }
          },
          {
            id: '+49',
            text: 'Germany',
            additional: {
                image: 'assets/img/flags/1x1/de.svg',
            }
          },
          {
            id: '+233',
            text: 'Ghana',
            additional: {
                image: 'assets/img/flags/1x1/gh.svg',
            }
          },
          {
            id: '+350',
            text: 'Gibraltar',
            additional: {
                image: 'assets/img/flags/1x1/gi.svg',
            }
          },
          {
            id: '+30',
            text: 'Greece',
            additional: {
                image: 'assets/img/flags/1x1/gr.svg',
            }
          },
          {
            id: '+299',
            text: 'Greenland',
            additional: {
                image: 'assets/img/flags/1x1/gl.svg',
            }
          },
          {
            id: '+1473',
            text: 'Grenada',
            additional: {
                image: 'assets/img/flags/1x1/gd.svg',
            }
          },
          {
            id: '+1671',
            text: 'Guam',
            additional: {
                image: 'assets/img/flags/1x1/gu.svg',
            }
          },
          {
            id: '+502',
            text: 'Guatemala',
            additional: {
                image: 'assets/img/flags/1x1/gt.svg',
            }
          },
          {
            id: '+441481',
            text: 'Guernsey',
            additional: {
                image: 'assets/img/flags/1x1/gg.svg',
            }
          },
          {
            id: '+224',
            text: 'Guinea',
            additional: {
                image: 'assets/img/flags/1x1/gn.svg',
            }
          },
          {
            id: '+245',
            text: 'Guinea-Bissau',
            additional: {
                image: 'assets/img/flags/1x1/gw.svg',
            }
          },
          {
            id: '+592',
            text: 'Guyana',
            additional: {
                image: 'assets/img/flags/1x1/gy.svg',
            }
          },
          {
            id: '+509',
            text: 'Haiti',
            additional: {
                image: 'assets/img/flags/1x1/ht.svg',
            }
          },
          {
            id: '+504',
            text: 'Honduras',
            additional: {
                image: 'assets/img/flags/1x1/hn.svg',
            }
          },
          {
            id: '+852',
            text: 'Hong Kong',
            additional: {
                image: 'assets/img/flags/1x1/hk.svg',
            }
          },
          {
            id: '+36',
            text: 'Hungary',
            additional: {
                image: 'assets/img/flags/1x1/hu.svg',
            }
          },
          {
            id: '+354',
            text: 'Iceland',
            additional: {
                image: 'assets/img/flags/1x1/is.svg',
            }
          },
          {
            id: '+91',
            text: 'India',
            additional: {
                image: 'assets/img/flags/1x1/in.svg',
            }
          },
          {
            id: '+62',
            text: 'Indonesia',
            additional: {
                image: 'assets/img/flags/1x1/id.svg',
            }
          },
          {
            id: '+98',
            text: 'Iran',
            additional: {
                image: 'assets/img/flags/1x1/ir.svg',
            }
          },
          {
            id: '+964',
            text: 'Iraq',
            additional: {
                image: 'assets/img/flags/1x1/iq.svg',
            }
          },
          {
            id: '+353',
            text: 'Ireland',
            additional: {
                image: 'assets/img/flags/1x1/ie.svg',
            }
          },
          {
            id: '+441624',
            text: 'Isle of Man',
            additional: {
                image: 'assets/img/flags/1x1/im.svg',
            }
          },
          {
            id: '+972',
            text: 'Israel',
            additional: {
                image: 'assets/img/flags/1x1/il.svg',
            }
          },
          {
            id: '+39',
            text: 'Italy',
            additional: {
                image: 'assets/img/flags/1x1/it.svg',
            }
          },
          {
            id: '+225',
            text: 'Ivory Coast',
            additional: {
                image: 'assets/img/flags/1x1/ci.svg',
            }
          },
          {
            id: '+1876',
            text: 'Jamaica',
            additional: {
                image: 'assets/img/flags/1x1/jm.svg',
            }
          },
          {
            id: '+81',
            text: 'Japan',
            additional: {
                image: 'assets/img/flags/1x1/jp.svg',
            }
          },
          {
            id: '+441534',
            text: 'Jersey',
            additional: {
                image: 'assets/img/flags/1x1/je.svg',
            }
          },
          {
            id: '+962',
            text: 'Jordan',
            additional: {
                image: 'assets/img/flags/1x1/jo.svg',
            }
          },
          {
            id: '+7',
            text: 'Kazakhstan',
            additional: {
                image: 'assets/img/flags/1x1/kz.svg',
            }
          },
          {
            id: '+254',
            text: 'Kenya',
            additional: {
                image: 'assets/img/flags/1x1/ke.svg',
            }
          },
          {
            id: '+686',
            text: 'Kiribati',
            additional: {
                image: 'assets/img/flags/1x1/ki.svg',
            }
          },
          {
            id: '+383',
            text: 'Kosovo',
            additional: {
                image: 'assets/img/flags/1x1/xk.svg',
            }
          },
          {
            id: '+965',
            text: 'Kuwait',
            additional: {
                image: 'assets/img/flags/1x1/kw.svg',
            }
          },
          {
            id: '+996',
            text: 'Kyrgyzstan',
            additional: {
                image: 'assets/img/flags/1x1/kg.svg',
            }
          },
          {
            id: '+856',
            text: 'Laos',
            additional: {
                image: 'assets/img/flags/1x1/la.svg',
            }
          },
          {
            id: '+371',
            text: 'Latvia',
            additional: {
                image: 'assets/img/flags/1x1/lv.svg',
            }
          },
          {
            id: '+961',
            text: 'Lebanon',
            additional: {
                image: 'assets/img/flags/1x1/lb.svg',
            }
          },
          {
            id: '+266',
            text: 'Lesotho',
            additional: {
                image: 'assets/img/flags/1x1/ls.svg',
            }
          },
          {
            id: '+231',
            text: 'Liberia',
            additional: {
                image: 'assets/img/flags/1x1/lr.svg',
            }
          },
          {
            id: '+218',
            text: 'Libya',
            additional: {
                image: 'assets/img/flags/1x1/ly.svg',
            }
          },
          {
            id: '+423',
            text: 'Liechtenstein',
            additional: {
                image: 'assets/img/flags/1x1/li.svg',
            }
          },
          {
            id: '+370',
            text: 'Lithuania',
            additional: {
                image: 'assets/img/flags/1x1/lt.svg',
            }
          },
          {
            id: '+352',
            text: 'Luxembourg',
            additional: {
                image: 'assets/img/flags/1x1/lu.svg',
            }
          },
          {
            id: '+853',
            text: 'Macau',
            additional: {
                image: 'assets/img/flags/1x1/mo.svg',
            }
          },
          {
            id: '+389',
            text: 'Macedonia',
            additional: {
                image: 'assets/img/flags/1x1/mk.svg',
            }
          },
          {
            id: '+261',
            text: 'Madagascar',
            additional: {
                image: 'assets/img/flags/1x1/mg.svg',
            }
          },
          {
            id: '+265',
            text: 'Malawi',
            additional: {
                image: 'assets/img/flags/1x1/mw.svg',
            }
          },
          {
            id: '+60',
            text: 'Malaysia',
            additional: {
                image: 'assets/img/flags/1x1/my.svg',
            }
          },
          {
            id: '+960',
            text: 'Maldives',
            additional: {
                image: 'assets/img/flags/1x1/mv.svg',
            }
          },
          {
            id: '+223',
            text: 'Mali',
            additional: {
                image: 'assets/img/flags/1x1/ml.svg',
            }
          },
          {
            id: '+356',
            text: 'Malta',
            additional: {
                image: 'assets/img/flags/1x1/mt.svg',
            }
          },
          {
            id: '+692',
            text: 'Marshall Islands',
            additional: {
                image: 'assets/img/flags/1x1/mh.svg',
            }
          },
          {
            id: '+222',
            text: 'Mauritania',
            additional: {
                image: 'assets/img/flags/1x1/mr.svg',
            }
          },
          {
            id: '+230',
            text: 'Mauritius',
            additional: {
                image: 'assets/img/flags/1x1/mu.svg',
            }
          },
          {
            id: '+262',
            text: 'Mayotte',
            additional: {
                image: 'assets/img/flags/1x1/yt.svg',
            }
          },
          {
            id: '+52',
            text: 'Mexico',
            additional: {
                image: 'assets/img/flags/1x1/mx.svg',
            }
          },
          {
            id: '+691',
            text: 'Micronesia',
            additional: {
                image: 'assets/img/flags/1x1/fm.svg',
            }
          },
          {
            id: '+373',
            text: 'Moldova',
            additional: {
                image: 'assets/img/flags/1x1/md.svg',
            }
          },
          {
            id: '+377',
            text: 'Monaco',
            additional: {
                image: 'assets/img/flags/1x1/mc.svg',
            }
          },
          {
            id: '+976',
            text: 'Mongolia',
            additional: {
                image: 'assets/img/flags/1x1/mn.svg',
            }
          },
          {
            id: '+382',
            text: 'Montenegro',
            additional: {
                image: 'assets/img/flags/1x1/me.svg',
            }
          },
          {
            id: '+1664',
            text: 'Montserrat',
            additional: {
                image: 'assets/img/flags/1x1/ms.svg',
            }
          },
          {
            id: '+212',
            text: 'Morocco',
            additional: {
                image: 'assets/img/flags/1x1/ma.svg',
            }
          },
          {
            id: '+258',
            text: 'Mozambique',
            additional: {
                image: 'assets/img/flags/1x1/mz.svg',
            }
          },
          {
            id: '+95',
            text: 'Myanmar',
            additional: {
                image: 'assets/img/flags/1x1/mm.svg',
            }
          },
          {
            id: '+264',
            text: 'Namibia',
            additional: {
                image: 'assets/img/flags/1x1/na.svg',
            }
          },
          {
            id: '+674',
            text: 'Nauru',
            additional: {
                image: 'assets/img/flags/1x1/nr.svg',
            }
          },
          {
            id: '+977',
            text: 'Nepal',
            additional: {
                image: 'assets/img/flags/1x1/np.svg',
            }
          },
          {
            id: '+31',
            text: 'Netherlands',
            additional: {
                image: 'assets/img/flags/1x1/nl.svg',
            }
          },          
          {
            id: '+687',
            text: 'New Caledonia',
            additional: {
                image: 'assets/img/flags/1x1/nc.svg',
            }
          },
          {
            id: '+64',
            text: 'New Zealand',
            additional: {
                image: 'assets/img/flags/1x1/nz.svg',
            }
          },
          {
            id: '+505',
            text: 'Nicaragua',
            additional: {
                image: 'assets/img/flags/1x1/ni.svg',
            }
          },
          {
            id: '+227',
            text: 'Niger',
            additional: {
                image: 'assets/img/flags/1x1/ne.svg',
            }
          },
          {
            id: '+234',
            text: 'Nigeria',
            additional: {
                image: 'assets/img/flags/1x1/ng.svg',
            }
          },
          {
            id: '+683',
            text: 'Niue',
            additional: {
                image: 'assets/img/flags/1x1/nu.svg',
            }
          },
          {
            id: '+850',
            text: 'North Korea',
            additional: {
                image: 'assets/img/flags/1x1/kp.svg',
            }
          },
          {
            id: '+1670',
            text: 'Northern Mariana Islands',
            additional: {
                image: 'assets/img/flags/1x1/mp.svg',
            }
          },
          {
            id: '+47',
            text: 'Norway',
            additional: {
                image: 'assets/img/flags/1x1/no.svg',
            }
          },
          {
            id: '+968',
            text: 'Oman',
            additional: {
                image: 'assets/img/flags/1x1/om.svg',
            }
          },
          {
            id: '+92',
            text: 'Pakistan',
            additional: {
                image: 'assets/img/flags/1x1/pk.svg',
            }
          },
          {
            id: '+680',
            text: 'Palau',
            additional: {
                image: 'assets/img/flags/1x1/pw.svg',
            }
          },
          {
            id: '+970',
            text: 'Palestine',
            additional: {
                image: 'assets/img/flags/1x1/ps.svg',
            }
          },
          {
            id: '+507',
            text: 'Panama',
            additional: {
                image: 'assets/img/flags/1x1/pa.svg',
            }
          },
          {
            id: '+675',
            text: 'Papua New Guinea',
            additional: {
                image: 'assets/img/flags/1x1/pg.svg',
            }
          },
          {
            id: '+595',
            text: 'Paraguay',
            additional: {
                image: 'assets/img/flags/1x1/py.svg',
            }
          },
          {
            id: '+51',
            text: 'Peru',
            additional: {
                image: 'assets/img/flags/1x1/pe.svg',
            }
          },
          {
            id: '+63',
            text: 'Philippines',
            additional: {
                image: 'assets/img/flags/1x1/ph.svg',
            }
          },
          {
            id: '+64',
            text: 'Pitcairn',
            additional: {
                image: 'assets/img/flags/1x1/pn.svg',
            }
          },
          {
            id: '+48',
            text: 'Poland',
            additional: {
                image: 'assets/img/flags/1x1/pl.svg',
            }
          },
          {
            id: '+351',
            text: 'Portugal',
            additional: {
                image: 'assets/img/flags/1x1/pt.svg',
            }
          },
          {
            id: '+974',
            text: 'Qatar',
            additional: {
                image: 'assets/img/flags/1x1/qa.svg',
            }
          },
          {
            id: '+242',
            text: 'Republic of the Congo',
            additional: {
                image: 'assets/img/flags/1x1/cg.svg',
            }
          },
          {
            id: '+262',
            text: 'Reunion',
            additional: {
                image: 'assets/img/flags/1x1/re.svg',
            }
          },
          {
            id: '+40',
            text: 'Romania',
            additional: {
                image: 'assets/img/flags/1x1/ro.svg',
            }
          },
          {
            id: '+7',
            text: 'Russia',
            additional: {
                image: 'assets/img/flags/1x1/ru.svg',
            }
          },
          {
            id: '+250',
            text: 'Rwanda',
            additional: {
                image: 'assets/img/flags/1x1/rw.svg',
            }
          },
          {
            id: '+590',
            text: 'Saint Barthelemy',
            additional: {
                image: 'assets/img/flags/1x1/bl.svg',
            }
          },
          {
            id: '+290',
            text: 'Saint Helena',
            additional: {
                image: 'assets/img/flags/1x1/sh.svg',
            }
          },
          {
            id: '+1869',
            text: 'Saint Kitts and Nevis',
            additional: {
                image: 'assets/img/flags/1x1/kn.svg',
            }
          },
          {
            id: '+1758',
            text: 'Saint Lucia',
            additional: {
                image: 'assets/img/flags/1x1/lc.svg',
            }
          },
          {
            id: '+590',
            text: 'Saint Martin',
            additional: {
                image: 'assets/img/flags/1x1/mf.svg',
            }
          },
          {
            id: '+508',
            text: 'Saint Pierre and Miquelon',
            additional: {
                image: 'assets/img/flags/1x1/pm.svg',
            }
          },
          {
            id: '+1784',
            text: 'Saint Vincent and the Grenadines',
            additional: {
                image: 'assets/img/flags/1x1/vc.svg',
            }
          },
          {
            id: '+685',
            text: 'Samoa',
            additional: {
                image: 'assets/img/flags/1x1/ws.svg',
            }
          },
          {
            id: '+387',
            text: 'San Marino',
            additional: {
                image: 'assets/img/flags/1x1/sm.svg',
            }
          },
          {
            id: '+239',
            text: 'Sao Tome and Principe',
            additional: {
                image: 'assets/img/flags/1x1/st.svg',
            }
          },
          {
            id: '+966',
            text: 'Saudi Arabia',
            additional: {
                image: 'assets/img/flags/1x1/sa.svg',
            }
          },
          {
            id: '+221',
            text: 'Senegal',
            additional: {
                image: 'assets/img/flags/1x1/sn.svg',
            }
          },
          {
            id: '+381',
            text: 'Serbia',
            additional: {
                image: 'assets/img/flags/1x1/rs.svg',
            }
          },
          {
            id: '+248',
            text: 'Seychelles',
            additional: {
                image: 'assets/img/flags/1x1/sc.svg',
            }
          },
          {
            id: '+232',
            text: 'Sierra Leone',
            additional: {
                image: 'assets/img/flags/1x1/sl.svg',
            }
          },
          {
            id: '+65',
            text: 'Singapore',
            additional: {
                image: 'assets/img/flags/1x1/sg.svg',
            }
          },
          {
            id: '+1721',
            text: 'Sint Maarten',
            additional: {
                image: 'assets/img/flags/1x1/sx.svg',
            }
          },
          {
            id: '+421',
            text: 'Slovakia',
            additional: {
                image: 'assets/img/flags/1x1/sk.svg',
            }
          },
          {
            id: '+386',
            text: 'Slovenia',
            additional: {
                image: 'assets/img/flags/1x1/si.svg',
            }
          },
          {
            id: '+677',
            text: 'Solomon Islands',
            additional: {
                image: 'assets/img/flags/1x1/sb.svg',
            }
          },
          {
            id: '+252',
            text: 'Somalia',
            additional: {
                image: 'assets/img/flags/1x1/so.svg',
            }
          },
          {
            id: '+27',
            text: 'South Africa',
            additional: {
                image: 'assets/img/flags/1x1/za.svg',
            }
          },
          {
            id: '+82',
            text: 'South Korea',
            additional: {
                image: 'assets/img/flags/1x1/kr.svg',
            }
          },
          {
            id: '+211',
            text: 'South Sudan',
            additional: {
                image: 'assets/img/flags/1x1/ss.svg',
            }
          },
          {
            id: '+34',
            text: 'Spain',
            additional: {
                image: 'assets/img/flags/1x1/es.svg',
            }
          },
          {
            id: '+94',
            text: 'Sri Lanka',
            additional: {
                image: 'assets/img/flags/1x1/lk.svg',
            }
          },
          {
            id: '+249',
            text: 'Sudan',
            additional: {
                image: 'assets/img/flags/1x1/sd.svg',
            }
          },
          {
            id: '+597',
            text: 'Suriname',
            additional: {
                image: 'assets/img/flags/1x1/sr.svg',
            }
          },
          {
            id: '+47',
            text: 'Svalbard and Jan Mayen',
            additional: {
                image: 'assets/img/flags/1x1/sj.svg',
            }
          },
          {
            id: '+268',
            text: 'Swaziland',
            additional: {
                image: 'assets/img/flags/1x1/sz.svg',
            }
          },
          {
            id: '+46',
            text: 'Sweden',
            additional: {
                image: 'assets/img/flags/1x1/se.svg',
            }
          },
          {
            id: '+41',
            text: 'Switzerland',
            additional: {
                image: 'assets/img/flags/1x1/ch.svg',
            }
          },
          {
            id: '+963',
            text: 'Syria',
            additional: {
                image: 'assets/img/flags/1x1/sy.svg',
            }
          },
          {
            id: '+996',
            text: 'Taiwan',
            additional: {
                image: 'assets/img/flags/1x1/tw.svg',
            }
          },
          {
            id: '+992',
            text: 'Tajikistan',
            additional: {
                image: 'assets/img/flags/1x1/tj.svg',
            }
          },
          {
            id: '+255',
            text: 'Tanzania',
            additional: {
                image: 'assets/img/flags/1x1/tz.svg',
            }
          },
          {
            id: '+66',
            text: 'Thailand',
            additional: {
                image: 'assets/img/flags/1x1/th.svg',
            }
          },
          {
            id: '+228',
            text: 'Togo',
            additional: {
                image: 'assets/img/flags/1x1/tg.svg',
            }
          },
          {
            id: '+690',
            text: 'Tokelau',
            additional: {
                image: 'assets/img/flags/1x1/tk.svg',
            }
          },
          {
            id: '+676',
            text: 'Tonga',
            additional: {
                image: 'assets/img/flags/1x1/to.svg',
            }
          },
          {
            id: '+1868',
            text: 'Trinidad and Tobago',
            additional: {
                image: 'assets/img/flags/1x1/tt.svg',
            }
          },
          {
            id: '+216',
            text: 'Tunisia',
            additional: {
                image: 'assets/img/flags/1x1/tn.svg',
            }
          },
          {
            id: '+90',
            text: 'Turkey',
            additional: {
                image: 'assets/img/flags/1x1/tr.svg',
            }
          },
          {
            id: '+993',
            text: 'Turkmenistan',
            additional: {
                image: 'assets/img/flags/1x1/tm.svg',
            }
          },
          {
            id: '+1649',
            text: 'Turks and Caicos Islands',
            additional: {
                image: 'assets/img/flags/1x1/tc.svg',
            }
          },
          {
            id: '+688',
            text: 'Tuvalu',
            additional: {
                image: 'assets/img/flags/1x1/tv.svg',
            }
          },
          {
            id: '+1340',
            text: 'U.S. Virgin Islands',
            additional: {
                image: 'assets/img/flags/1x1/vi.svg',
            }
          },
          {
            id: '+256',
            text: 'Uganda',
            additional: {
                image: 'assets/img/flags/1x1/ug.svg',
            }
          },
          {
            id: '+380',
            text: 'Ukraine',
            additional: {
                image: 'assets/img/flags/1x1/ua.svg',
            }
          },
          {
            id: '+971',
            text: 'United Arab Emirates',
            additional: {
                image: 'assets/img/flags/1x1/ae.svg',
            }
          },
          {
            id: '+44',
            text: 'United Kingdom',
            additional: {
                image: 'assets/img/flags/1x1/gb.svg',
            }
          },          
          {
            id: '+1',
            text: 'United States',
            additional: {
                image: 'assets/img/flags/1x1/us.svg',
            }
          },
          {
            id: '+598',
            text: 'Uruguay',
            additional: {
                image: 'assets/img/flags/1x1/uy.svg',
            }
          },
          {
            id: '+998',
            text: 'Uzbekistan',
            additional: {
                image: 'assets/img/flags/1x1/uz.svg',
            }
          },
          {
            id: '+678',
            text: 'Vanuatu',
            additional: {
                image: 'assets/img/flags/1x1/vu.svg',
            }
          },
          {
            id: '+379',
            text: 'Vatican',
            additional: {
                image: 'assets/img/flags/1x1/va.svg',
            }
          },
          {
            id: '+58',
            text: 'Venezuela',
            additional: {
                image: 'assets/img/flags/1x1/ve.svg',
            }
          },
          {
            id: '+681',
            text: 'Wallis and Futuna',
            additional: {
                image: 'assets/img/flags/1x1/wf.svg',
            }
          },
          {
            id: '+212',
            text: 'Western Sahara',
            additional: {
                image: 'assets/img/flags/1x1/eh.svg',
            }
          },
          {
            id: '+967',
            text: 'Yemen',
            additional: {
                image: 'assets/img/flags/1x1/ye.svg',
            }
          },
          {
            id: '+260',
            text: 'Zambia',
            additional: {
                image: 'assets/img/flags/1x1/zm.svg',
            }
          },
          {
            id: '+263',
            text: 'Zimbabwe',
            additional: {
                image: 'assets/img/flags/1x1/zw.svg',
            }
          },

        ];      
    }

    changedPhoneCode(event) {
      this.tmpPhoneCode = event.value;
      this.callbackFunction.emit(event.value);
    }

    public phoneCodeTemplate: Select2TemplateFunction = (state: Select2OptionData): JQuery | string => 
    {
        if (!state.id) {
          return state.text;
        }
        let image = '';
        if (state.additional.image) {
          image = '<span class="image"><img style="width: 22px;" onError="this.src=\'assets/img/ava.png\'" src="' + state.additional.image + '"/></span>';
        }
        return jQuery('<span>' + image + ' <span>' + state.text + ' (' + state.id + ')</span></span>');
    }
    
    // function for selection template
    public phoneCodeSelection: Select2TemplateFunction = (state: Select2OptionData): JQuery | string => 
    {
      if (state.id) {
          return state.id + " (" + state.text + ")";
      }
      return jQuery('<span>' + state.text + '</span>');
    }
  }