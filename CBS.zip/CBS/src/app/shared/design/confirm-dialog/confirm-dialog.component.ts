import { Component, OnInit, Input, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'dnf-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class ConfirmDialogComponent { 
  content = '';

  constructor(
      @Inject(MAT_DIALOG_DATA) public obj: any,
      public dialogRef: MatDialogRef<ConfirmDialogComponent>,    
  )
  {
      this.content = this.obj.content;        
  }

  ok() {
    if(this.obj.callback){
      this.obj.callback(this.obj.data);
      this.cancel();
    }
  }

  cancel() {
    this.dialogRef.close();
  }
}