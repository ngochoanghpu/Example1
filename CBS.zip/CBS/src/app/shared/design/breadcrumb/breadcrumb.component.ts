import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dnf-breadcrumb',
  templateUrl: './breadcrumb.component.html'
})
export class BreadcrumbComponent implements OnInit {
  @Input() items: any;

  ngOnInit() {
  }
}
