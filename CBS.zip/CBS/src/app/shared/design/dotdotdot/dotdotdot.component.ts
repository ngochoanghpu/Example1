import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dnf-dotdotdot',
  templateUrl: './dotdotdot.component.html'
})
export class DotdotdotComponent {
  @Input() limit: number;
  @Input() text: string;

  constructor() {}

  isShowTooltip() {
      return this.text && this.text.length > this.limit;
  }
}