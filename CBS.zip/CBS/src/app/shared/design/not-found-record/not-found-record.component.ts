import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dnf-not-found-record',
  templateUrl: './not-found-record.component.html',
  styleUrls: ['./not-found-record.component.scss']
})
export class NotFoundRecordComponent {
  @Input() dataSource: any;

  constructor() {}
}