import { Component, OnInit, Input } from '@angular/core';
import { STATUS } from '@app/shared/constant';

@Component({
  selector: 'dnf-badge',
  templateUrl: './badge.component.html'
})
export class BadgeComponent implements OnInit {
  @Input() type: string;
  @Input() value: number;
  @Input() customBadge: any;
  badge: any;
  constructor() {
    this.badge = { style: 'unknow', text: 'LBL_STATUS_UNKNOWN' };
    if (!this.type) {
      this.type = 'default';
    }
  }

  ngOnInit() {
    this.initBadge(this.type, this.value);
  }

  initBadge(type: string, value: number): void {
    const statusObject = this.customBadge
      ? this.customBadge
      : STATUS[type.toLocaleUpperCase()];

    if (statusObject && statusObject[value]) {
      this.badge = statusObject[value];
    }
  }
}
