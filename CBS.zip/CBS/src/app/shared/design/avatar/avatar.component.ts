import { Component, OnInit, Input } from '@angular/core';
import { AVATAR } from '@app/shared/constant';

@Component({
  selector: 'dnf-avatar',
  templateUrl: './avatar.component.html'
})
export class AvatarComponent implements OnInit {
  @Input() size: string;
  @Input() src: string;
  @Input() align: string;
  @Input() name: string;
  @Input() class: string;
  @Input() border: boolean;
  @Input() width: string;
  @Input() height: string;
  imageClass: string;
  constructor() {}

  ngOnInit() {
    this.setSizeValue();
  }

  onErrorImage() {
    this.src = AVATAR.DEFAULT;
  }

  setSizeValue() {
    this.imageClass = this.size ? AVATAR.SIZE[this.size.toLocaleUpperCase()] : AVATAR.SIZE.DEFAULT;
    this.width = this.width ? this.width + 'px' : '';
    this.height = this.height ? this.height + 'px' : '';
  }
}
