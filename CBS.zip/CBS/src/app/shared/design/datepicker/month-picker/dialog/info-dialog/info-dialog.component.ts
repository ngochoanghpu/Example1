import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dnf-info-dialog',
  templateUrl: './info-dialog.component.html',
  styleUrls: ['./info-dialog.component.scss']
})
export class InfoDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
