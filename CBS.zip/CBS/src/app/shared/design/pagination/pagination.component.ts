import { Component, OnInit, AfterViewInit } from '@angular/core';

@Component({
  selector: 'dnf-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit, AfterViewInit {
  page = 1;

  constructor() {}

  ngOnInit() {}

  ngAfterViewInit() {

  }
}
