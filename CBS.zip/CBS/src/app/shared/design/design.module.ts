import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

import { Select2Module } from 'ng2-select2';
import 'hammerjs';

import {
  MatInputModule,
  MatSortModule,
  MatProgressSpinnerModule,
  MatTableModule,
  MatPaginatorModule,
  MatSelectModule,
  MatProgressBarModule,
  MatButtonModule,
  MatCheckboxModule,
  MatIconModule,
  MatTooltipModule,
  MatSlideToggleModule,
  MatAutocompleteModule,
  MatCardModule,
  MatMenuModule,
  MatDialogModule,
  MAT_DIALOG_DEFAULT_OPTIONS,
  MatDatepickerModule,
  MatNativeDateModule,
  MAT_PAGINATOR_INTL_PROVIDER,
  MatPaginatorIntl,
  MatListModule
} from '@angular/material';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaginationComponent } from './pagination/pagination.component';
import { DnfPaginatorIntl } from './pagination/paginator.intl';
import { RatingStarComponent } from './rating-star/rating-star.component';
import { MultiDatepickerComponent } from './datepicker/datepicker.component';
import { MonthPickerComponent } from './datepicker/month-picker/month-picker.component';
import { InfoDialogComponent } from './datepicker/month-picker/dialog/info-dialog/info-dialog.component';
import { YearPickerComponent } from './datepicker/year-picker/year-picker.component';
import { RegularDatepickerComponent } from './datepicker/regular-datepicker/regular-datepicker.component';
import { BadgeComponent } from './badge/badge.component';
import { ShortDatePipe, LongDatePipe } from '@app/core/pipes/datetime.pipe';
import { CurrencyPipe } from '@app/core/pipes/currency.pipe';
import { AvatarComponent } from './avatar/avatar.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { DotDotDotPipe } from '@app/core/pipes/dotdotdot.pipe';
import { DotdotdotComponent } from './dotdotdot/dotdotdot.component';
import { NotFoundRecordComponent } from './not-found-record/not-found-record.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { PhoneCodeComponent } from './phone-code/phone-code.component';

@NgModule({
  declarations: [
    PaginationComponent,
    RatingStarComponent,
    MonthPickerComponent,
    MultiDatepickerComponent,
    InfoDialogComponent,
    YearPickerComponent,
    RegularDatepickerComponent,
    BadgeComponent,
    ShortDatePipe,
    LongDatePipe,
    CurrencyPipe,
    AvatarComponent,
    BreadcrumbComponent,
    DropdownComponent,
    NotFoundRecordComponent,
    DotdotdotComponent,
    ConfirmDialogComponent,
    PhoneCodeComponent,
    DotDotDotPipe
  ],
  imports: [
    CommonModule,
    MatInputModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatPaginatorModule,
    MatSelectModule,
    MatProgressBarModule,
    MatButtonModule,
    MatCheckboxModule,
    MatIconModule,
    MatTooltipModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    MatCardModule,
    MatMenuModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatListModule,
    TranslateModule,

    NgbModule.forRoot(),

    FormsModule,
    ReactiveFormsModule,
    Select2Module
  ],
  exports: [
    MatInputModule,
    MatSortModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatPaginatorModule,
    MatSelectModule,
    MatProgressBarModule,
    MatButtonModule,
    MatCheckboxModule,
    MatIconModule,
    MatTooltipModule,
    MatSlideToggleModule,
    MatAutocompleteModule,
    MatCardModule,
    MatMenuModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    NgbModule,
    MatListModule,
    TranslateModule,

    FormsModule,
    ReactiveFormsModule,

    PaginationComponent,
    RatingStarComponent,
    MonthPickerComponent,
    MultiDatepickerComponent,
    InfoDialogComponent,
    YearPickerComponent,
    RegularDatepickerComponent,
    Select2Module,
    BadgeComponent,
    ShortDatePipe,
    LongDatePipe,
    CurrencyPipe,
    AvatarComponent,
    BreadcrumbComponent,
    DropdownComponent,
    NotFoundRecordComponent,
    DotdotdotComponent,
    ConfirmDialogComponent,
    PhoneCodeComponent,
    DotDotDotPipe
  ],
  providers: [
    { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: true } },
    {
      provide: MatPaginatorIntl,
      useClass: DnfPaginatorIntl
    }
  ]
})
export class DesignModule {}
