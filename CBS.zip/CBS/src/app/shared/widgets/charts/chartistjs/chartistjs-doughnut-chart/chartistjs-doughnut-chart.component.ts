import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dnf-chartistjs-doughnut-chart',
  templateUrl: './chartistjs-doughnut-chart.component.html',
})
export class ChartistjsDoughnutChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
