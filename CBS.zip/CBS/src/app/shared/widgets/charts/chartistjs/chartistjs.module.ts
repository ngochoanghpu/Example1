import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DesignModule } from '@app/shared/design/design.module';
import { ChartistjsDoughnutChartComponent } from './chartistjs-doughnut-chart/chartistjs-doughnut-chart.component';

@NgModule({
  declarations: [ChartistjsDoughnutChartComponent],
  imports: [CommonModule, DesignModule],
  exports: [ChartistjsDoughnutChartComponent]
})
export class ChartistjsModule {}
