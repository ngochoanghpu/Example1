import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MorrisModule } from './morris/morris.module';
import { DesignModule } from '@app/shared/design/design.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MorrisModule,
    DesignModule
  ],
  exports: [
    MorrisModule,
    DesignModule
  ]
})
export class WidgetChartsModule { }
