import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MorrisDoughnutChartComponent } from './morris-doughnut-chart/morris-doughnut-chart.component';
import { MorrisAreaChartComponent } from './morris-area-chart/morris-area-chart.component';

@NgModule({
  declarations: [MorrisDoughnutChartComponent, MorrisAreaChartComponent],
  imports: [CommonModule],
  exports: [MorrisDoughnutChartComponent, MorrisAreaChartComponent]
})

export class MorrisModule {}
