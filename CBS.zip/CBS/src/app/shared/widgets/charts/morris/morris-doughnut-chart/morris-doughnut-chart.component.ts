import { Component, OnInit, Input, AfterViewInit } from '@angular/core';

@Component({
  selector: 'dnf-morris-doughnut-chart',
  templateUrl: './morris-doughnut-chart.component.html',
  styleUrls: ['./morris-doughnut-chart.component.scss']
})
export class MorrisDoughnutChartComponent implements OnInit, AfterViewInit {
  @Input() options: any;
  @Input() width: string;
  @Input() height: string;
  @Input() showLegend: boolean;
  @Input() showTotalDescription: boolean;
  @Input() totalData: {
    totalNumber: '',
    totalUnit: ''
  };
  @Input() header = {
    title: '',
    desc: ''
  };

  constructor() {}

  ngOnInit(): void {}

  ngAfterViewInit() {
    Morris.Donut(this.options);
  }
}
