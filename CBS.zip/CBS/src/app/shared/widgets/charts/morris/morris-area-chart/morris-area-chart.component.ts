import {
  Component,
  OnInit,
  Input,
  AfterViewInit
} from '@angular/core';

@Component({
  selector: 'dnf-morris-area-chart',
  templateUrl: './morris-area-chart.component.html',
  styleUrls: ['./morris-area-chart.component.scss']
})
export class MorrisAreaChartComponent implements OnInit, AfterViewInit {
  @Input() chartName: string;
  @Input() height: string;
  _chartConfig: any;
  @Input() set chartConfig(val) {
    this._chartConfig = val;
  }
  get chartConfig() {
    return this._chartConfig;
  }

  constructor() {}

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    Morris.Area(this.chartConfig);
  }
}
