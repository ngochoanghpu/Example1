import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dnf-tab-list',
  templateUrl: './tab-list.component.html',
  styleUrls: ['./tab-list.component.scss']
})
export class TabListComponent implements OnInit {
  @Input() title: string;
  @Input() height: string;
  @Input() dataWeek: Array<any>;
  @Input() dataMonth: Array<any>;
  @Input() dataYear: Array<any>;

  @Input() items: Array<any>;

  constructor() { }

  ngOnInit() {
    this.onTabChanged('week');
  }

  onTabChanged(viewBy: string) {
    switch (viewBy) {
      case 'week':
        this.items = this.dataWeek;
        break;
      case 'month':
        this.items = this.dataMonth;
        break;
      case 'year':
        this.items = this.dataYear;
        break;
      default:
        break;
    }
  }
}
