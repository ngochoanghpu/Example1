import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'dnf-tab-chart',
  templateUrl: './tab-chart.component.html',
  styleUrls: []
})
export class TabChartComponent implements OnInit {
  @Input() title: string;
  @Input() height: string;
  @Input() service: any;
  @Input() chartName: string;
  @Input() chartConfig: any;
  isLoading = false;

  constructor(private ref: ChangeDetectorRef) {}

  ngOnInit() {
    this.chartConfig.element = this.chartName;
    this.onTabChanged('week');
  }

  _getDataByWeek() {
    this.service.getDataByWeek().subscribe(data => {
      this.chartConfig.data = data;
      this._drawChart();
    });
  }
  _getDataByMonth() {
    this.service.getDataByMonth().subscribe(data => {
      this.chartConfig.data = data;
      this._drawChart();
    });
  }
  _getDataByYear() {
    this.service.getDataByYear().subscribe(data => {
      this.chartConfig.data = data;
      this._drawChart();
    });
  }

  _drawChart() {
    this.isLoading = false;
    this.ref.detectChanges();
    $('#' + this.chartConfig.element).empty();
    Morris.Area(this.chartConfig).redraw();
  }

  onTabChanged(viewBy: string) {
    this.isLoading = true;
    switch (viewBy) {
      case 'week':
        this._getDataByWeek();
        break;
      case 'month':
        this._getDataByMonth();
        break;
      case 'year':
        this._getDataByYear();
        break;
      default:
        break;
    }
  }
}
