import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LayoutModule } from './layout/layout.module';
import { TranslateModule } from '@ngx-translate/core';
import { TabChartComponent } from './widgets/tab-chart/tab-chart.component';
import { TabListComponent } from './widgets/tab-list/tab-list.component';
import { WidgetChartsModule } from './widgets/charts/widget-charts.module';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [TabChartComponent, TabListComponent],
  imports: [CommonModule, RouterModule, LayoutModule, WidgetChartsModule],
  exports: [
    RouterModule,
    LayoutModule,
    TranslateModule,
    WidgetChartsModule,
    TabChartComponent,
    TabListComponent
  ]
})
export class SharedModule {}
