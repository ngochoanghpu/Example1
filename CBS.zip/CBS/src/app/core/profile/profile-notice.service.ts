import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileNoticeService {
    onNoticeChanged$: BehaviorSubject<any>;

	constructor() {
		this.onNoticeChanged$ = new BehaviorSubject(null);
	}

	setNotice(profile: any) {		
		this.onNoticeChanged$.next(profile);
	}
}