import { AbstractControl } from '@angular/forms';

export function SpacesValidator(control: AbstractControl) {
  if (control && control.value && control.value.trim().length === 0) {
    return { spacesOnly: true };
  }

  return null;
}