export class QueryParamsModel {
	// fields
	q: any;
	filter: any;
	sort: string;
	page: number;
	pageSize: number;

	// constructor overrides
	constructor(_filter: any,
		_sortOrder: string = 'asc',
		_sortField: string = '',
		_pageNumber: number = 0,
		_pageSize: number = 10) {
		this.filter = _filter;
		this.sort = _sortField ? `${_sortOrder === 'desc' ? '-' : ''}${_sortField}` : 'id';
		this.page = _pageNumber;
		this.pageSize = _pageSize;
	}
}
