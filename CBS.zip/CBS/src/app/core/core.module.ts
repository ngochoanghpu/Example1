import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenuAsideDirective } from './directives/menu-aside.directive';
import { MenuAsideOffcanvasDirective } from './directives/menu-aside-offcanvas.directive';
import { MenuHorizontalOffcanvasDirective } from './directives/menu-horizontal-offcanvas.directive';
import { MenuHorizontalDirective } from './directives/menu-horizontal.directive';
import { MenuAsideToggleDirective } from './directives/menu-aside-toggle.directive';

@NgModule({
  declarations: [
    MenuAsideDirective,
    MenuAsideToggleDirective,
    MenuAsideOffcanvasDirective,
    MenuHorizontalDirective,
    MenuHorizontalOffcanvasDirective
  ],
  imports: [CommonModule],
  exports: [
    MenuAsideDirective,
    MenuAsideOffcanvasDirective,
    MenuHorizontalDirective,
    MenuHorizontalOffcanvasDirective,
    MenuAsideToggleDirective
  ]
})
export class CoreModule {}
