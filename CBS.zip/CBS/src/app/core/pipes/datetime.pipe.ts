import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
import { DATETIME_FORMAT } from '@app/shared/constant';


@Pipe({
  name: 'shortDate'
})
export class ShortDatePipe implements PipeTransform {
  transform(value: any): any {
    return value ? moment(value).format(DATETIME_FORMAT.SHORT_DATE) : null;
  }
}

@Pipe({
  name: 'longDate'
})
export class LongDatePipe implements PipeTransform {
  transform(value: any): any {
    return value ? moment(value).format(DATETIME_FORMAT.LONG_DATE) : null;
  }
}
