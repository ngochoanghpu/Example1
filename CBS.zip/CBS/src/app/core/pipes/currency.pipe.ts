import { Pipe, PipeTransform } from '@angular/core';
import * as numeral from 'numeral';
import { CURRENCY, CURRENCY_DEFAULT } from '@app/shared/constant/currency';

@Pipe({
  name: 'currency'
})
export class CurrencyPipe implements PipeTransform {
  transform(value: number, args?: any): any {
    const currencyObject = args ? CURRENCY[args] : CURRENCY_DEFAULT;
    return this._formatCurrency(value, currencyObject);
  }

  setLocaleCurrency(currencyObject) {
    if (numeral.locales[currencyObject.locale] === undefined) {
      numeral.register('locale', currencyObject.locale, {
        delimiters: {
          thousands: currencyObject.delimiters.thousands,
          decimal: currencyObject.delimiters.decimal
        },
        abbreviations: {
          thousand: 'K',
          million: 'M',
          billion: 'B',
          trillion: 'T'
        },
        currency: {
          symbol: currencyObject.symbol
        }
      });
    }

    numeral.locale(currencyObject.locale);
  }

  _formatCurrency = (value: any, currency: any) => {
    this.setLocaleCurrency(currency);
    return numeral(value).format(currency.formatString);
  };
}
