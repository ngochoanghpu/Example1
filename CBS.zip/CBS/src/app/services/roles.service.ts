import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { PermissionsModel } from './models/permissions.model';
import { PERMISSIONS } from '@app/fake-api/permissions';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';
import { RoleModel } from '@app/services/models/role.model';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class RolesService {
  public roles: any = [];

  constructor(private httpClientService: HttpClientService) {}


  public getAllRole(queryParams: any = null): Observable<[]> {
    return this.httpClientService.get(ApiConfig.ROLE.GET_ALL).pipe(
      map(data => {
        return data.data;
      })
    );
  }

  public getAllFeature(queryParams: any = null): Observable<[]> {
    return this.httpClientService
      .get(ApiConfig.FEATURE.GET_ALL)
      .pipe(
        map(data => {
          return data.data;
        })
      );
  }

  public getRoles(queryParams: any = null): Observable<RoleModel> {
    return this.httpClientService
      .get(ApiConfig.ROLE.GET_ROLES, { params: queryParams })
      .pipe(
        map(data => {
          return data.data;
        })
      );
  }

  public getRoleDetail(id: number): Observable<[]> {
    return this.httpClientService
      .get(`${ApiConfig.ROLE.GET_ROLE_DETAIL}/${id}`)
      .pipe(
        map(data => {
          return data.data;
        })
      );
  }

  public createRole(user: Object) {
    return this.httpClientService.post(ApiConfig.ROLE.CREATE_ROLE, user).pipe(
      map(data => {
        return data.data;
      })
    );
  }

  public updateRole(id: Number, user: Object) {
    return this.httpClientService.put(`${ApiConfig.ROLE.UPDATE_ROLE}/${id}`, user).pipe(
      map(data => {
        return data.data;
      })
    );
  }

  public deteleRole(id: Number) {
    return this.httpClientService.delete(`${ApiConfig.ROLE.DELETE_ROLE}/${id}`).pipe(
      map(data => {
        return data.data;
      })
    );
  }

  public getPermission(): Observable<PermissionsModel[]> {
    return of(PERMISSIONS).pipe(delay(DELAY_TIME));
  }
}
