import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import {
  GeneralSettings,
  ScheduledBookingSettings,
  BookingInNowSettings,
  SettingsByCountries,
  TermsOfUse
} from '@app/fake-api/settings';
import {
  GeneralSettingsModel,
  BookingInNowSettingsModel,
  ScheduledBookingSettingsModel,
  SettingsByCountriesModel
} from './models/settings.model';
import { TermsOfUseModel } from './models/terms-of-use.model';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';
import { SETTINGS } from '@app/shared/constant'

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class SettingsService {
  constructor(private httpClientService: HttpClientService) {}

  public getGeneralSettings(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.CONFIG.GENERAL, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public getBookingInNowSettings(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.CONFIG.BOOKING_IN_NOW, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public getScheduleBookingSettings(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.CONFIG.SCHEDULED_BOOKING, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public getSettingsByCountries(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.CONFIG.SETTINGS_BY_COUNTRIES, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public updateGeneral(data, mode): any {
    let url = "";
    switch (mode) {
      case SETTINGS.General.toString():
        url = ApiConfig.CONFIG.GENERAL;
        break;   
        
      case SETTINGS.BookingInNow.toString():
        url = ApiConfig.CONFIG.BOOKING_IN_NOW;
        break;

      case SETTINGS.ScheduledBooking.toString():
        url = ApiConfig.CONFIG.SCHEDULED_BOOKING;
        break;

      case SETTINGS.SettingByCountries.toString():
        url = ApiConfig.CONFIG.SETTINGS_BY_COUNTRIES;
        break;
    }

    return this.httpClientService.put(url, data).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public getTermsOfUse(queryParams: any = null): Observable<TermsOfUseModel> {
    return of(TermsOfUse).pipe(delay(DELAY_TIME));
  }
}
