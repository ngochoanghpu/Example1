import { Injectable } from '@angular/core';
import { Select2OptionData } from 'ng2-select2';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { TRIP_HISTORY } from '@app/fake-api/trip-history';
import { TripHistoryModel } from './models/trip-history.model';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class TripHistoryService {
  public tripHistory: TripHistoryModel[] = [];

  constructor() {}

  public getTripHistory(queryParams: any = null): Observable<TripHistoryModel[]> {
    return of(TRIP_HISTORY).pipe(delay(DELAY_TIME));
  }

  getDriverList(): Select2OptionData[] {
    return [{
        id: '1',
        text: 'Khoa Nguyen',
        additional: {
          image: 'assets/img/image0.jpg',
        }
      },
      {
        id: '2',
        text: 'Huy Ly',
        additional: {
        }
      },
      {
        id: '3',
        text: 'Phat Le',
        additional: {
          image: 'assets/img/image1.jpg',
        }
      },
      {
        id: '4',
        text: 'Nguyen Le',
        additional: {
          image: 'assets/img/image2.jpg',
        }
      },
      {
        id: '5',
        text: 'Nam Nguyen',
        additional: {
          image: 'assets/img/image3.jpg',
        }
      }
    ];
  }
}
