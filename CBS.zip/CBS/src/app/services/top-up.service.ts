import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { TopUpModel } from './models/top-up.model';
import { TopUpDetailModel } from './models/top-up-detail.model';
import { TOPUP } from '@app/fake-api/top-up';
import { TOPUPDETAIL } from '@app/fake-api/top-up-detail';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class TopUpService {

  constructor() {}

  public getTopUp(queryParams: any = null): Observable<TopUpModel[]> {
    return of(TOPUP).pipe(delay(DELAY_TIME));
  }

  public getTopUpDetail(queryParams: any = null): Observable<TopUpDetailModel[]> {
    return of(TOPUPDETAIL).pipe();
  }
}
