import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { delay, map } from "rxjs/operators";
import { Vehicle } from "./models/vehicle.model";
import { VEHICLES } from "@app/fake-api/vehicles";
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';
import moment from 'moment';
import { DATETIME_FORMAT } from '@app/shared/constant';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable()
export class VehiclesService {
  constructor(private httpClientService: HttpClientService) {}

  public getVehicles(queryParams: any = null) : any {
    return this.httpClientService.get(ApiConfig.VEHICLE.GET, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public getAvailableVehicles(queryParams: any = null) : any {
    return this.httpClientService.get(ApiConfig.VEHICLE.GET_AVAILABLE, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  private convertVehicle(vehicle: any){    
    if(!vehicle.id){
      delete vehicle.id;
      if(vehicle.validUntil && typeof vehicle.validUntil === "string"){
        let validUntil = vehicle.validUntil.split('/');
        vehicle.validUntil = new Date(validUntil[1], validUntil[0], 1);
      }
    }
    else{
      vehicle.validUntil = moment(vehicle.validUntil).format(DATETIME_FORMAT.DEFAULT_DATE);
    }

    vehicle.seats = vehicle.seats ? parseInt(vehicle.seats) : null;
    vehicle.status = vehicle.status ? 1 : 0;    
    vehicle.year = vehicle.year ? moment(vehicle.year).format(DATETIME_FORMAT.DEFAULT_DATE) : null;
    vehicle.regoRenewalDate = vehicle.regoRenewalDate ? moment(vehicle.regoRenewalDate).format(DATETIME_FORMAT.DEFAULT_DATE) : null;
    vehicle.insuranceExpiryDate = vehicle.insuranceExpiryDate ? moment(vehicle.insuranceExpiryDate).format(DATETIME_FORMAT.DEFAULT_DATE) : null;    

    vehicle.isPremium = vehicle.isPremium ? true : false;
    vehicle.isServiceMessageSent = vehicle.isServiceMessageSent ? true : false;
    vehicle.lastServiceKms = vehicle.lastServiceKms || null;
    vehicle.nextServiceKms = vehicle.nextServiceKms || null;
    vehicle.currentKms = vehicle.currentKms || null;
    vehicle.kmsBeforeService = vehicle.kmsBeforeService || null;
  }

  public updateVehicle(vehicle: Vehicle) {
    this.convertVehicle(vehicle) ;

    if(vehicle.id){
      let vehicleId = vehicle.id;
      delete vehicle.id;
      return this.httpClientService.put(`${ApiConfig.VEHICLE.UPDATE_VEHICLE}/${vehicleId}`, vehicle).pipe(
        map(result => {
          return result.data;
        })
      );
    }
    else{      
      return this.httpClientService.post(ApiConfig.VEHICLE.CREATE_VEHICLE, vehicle).pipe(
        map(result => {
          return result.data;
        })
      );
    }
  }

  public assignDriver(vehicle: Vehicle) {
    let vehicleId = vehicle.id;
    delete vehicle.id;
    return this.httpClientService.post(ApiConfig.VEHICLE.ASSIGN_DRIVER.replace("{id}", vehicleId.toString()), vehicle).pipe(
      map(result => {
        return result.data;
      })
    );
  }

  public releaseDriver(vehicle: Vehicle) {    
    return this.httpClientService.post(ApiConfig.VEHICLE.RELEASE_DRIVER.replace("{id}", vehicle.id.toString())).pipe(
      map(result => {
        return result.data;
      })
    );
  }

  public updateStatus(vehicle: Vehicle) {
    let vehicleId = vehicle.id;
    delete vehicle.id;
    return this.httpClientService.put(`${ApiConfig.VEHICLE.UPDATE_VEHICLE}/${vehicleId}`, vehicle).pipe(
      map(result => {
        return result.data;
      })
    );
  }

  public deleteVehicle(id: Number) {
    return this.httpClientService.delete(`${ApiConfig.VEHICLE.DELETE_VEHICLE}/${id}`).pipe(
      map(data => {
        return data.data;
      })
    );
  }
}
