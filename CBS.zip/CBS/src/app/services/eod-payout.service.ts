import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { EODPAYOUT } from '@app/fake-api/eod-payout';
import { EODPayoutModel } from './models/eod-payout.model';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class EODPayoutService {

  constructor() {}

  public getEODPayout(queryParams: any = null): Observable<EODPayoutModel[]> {
    return of(EODPAYOUT).pipe(delay(DELAY_TIME));
  }
}
