import { Injectable } from '@angular/core';
import { dataWeek, dataMonth, dataYear } from '@app/fake-api/tab-chart';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class RevenueGrowthChartService {
  constructor() {}

  public getDataByWeek(queryParams: any = null): Observable<any> {
    return of(dataWeek).pipe(delay(DELAY_TIME));
  }

  public getDataByMonth(queryParams: any = null): Observable<any> {
    return of(dataMonth).pipe(delay(DELAY_TIME));
  }

  public getDataByYear(queryParams: any = null): Observable<any> {
    return of(dataYear).pipe(delay(DELAY_TIME));
  }
}
