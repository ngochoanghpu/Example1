export class TypeOfServicesModel {
  id: string;
  name: string;

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.name = model.name;
    }
  }
}
