export class TypeOfVehiclesModel {
  id: string;
  code: string;

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.code = model.code;
    }
  }
}
