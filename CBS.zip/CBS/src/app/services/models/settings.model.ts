export class GeneralSettingsModel {
  autoRefreshTime: number;
  smsEmail: string;
  landingPageUrl: string;

  constructor(model: any = null) {
    if (model) {
      this.autoRefreshTime = model.autoRefreshTime;
      this.smsEmail = model.smsEmail;
      this.landingPageUrl = model.landingPageUrl;
    }
  }
}

export class BookingInNowSettingsModel {
  receiveBookingRequestTime: number;
  bookingInNowRadius1st: number;
  bookingInNowRadius2nd: number;
  bookingInNowTime1st: number;
  bookingInNowTime2nd: number;

  constructor(model: any = null) {
    if (model) {
      this.receiveBookingRequestTime = model.receiveBookingRequestTime;
      this.bookingInNowRadius1st = model.bookingInNowRadius1st;
      this.bookingInNowRadius2nd = model.bookingInNowRadius2nd;
      this.bookingInNowTime1st = model.bookingInNowTime1st;
      this.bookingInNowTime2nd = model.bookingInNowTime2nd;
    }
  }
}

export class ScheduledBookingSettingsModel {
  receivingBookingRequestTime: number;
  scheduledBookingRadius1st: number;
  scheduledBookingRadius2nd: number;
  scheduledBookingAirportRadius1st: number;
  scheduledBookingAirportRadius2nd: number;
  scheduledBookingTime1st: number;
  scheduledBookingTime2nd: number;
  allowedTimeForCreatingBooking1st: number;
  allowedTimeForCreatingBooking2nd: number;
  reminderTime1st: number;
  reminderTime2nd: number;
  cancellationFeePeriod1st: number;
  cancellationFeePeriod2nd: number;
  cancellationFee1st: number;
  cancellationFee2nd: number;
  allowedTimeForMakingContact1st: number;
  allowedTimeForMakingContact2nd: number;
  timeoutForMigration1st: number;
  timeoutForMigration2nd: number;

  constructor(model: any = null) {
    if (model) {
      this.receivingBookingRequestTime = model.receivingBookingRequestTime;
      this.scheduledBookingRadius1st = model.scheduledBookingRadius1st;
      this.scheduledBookingRadius2nd = model.scheduledBookingRadius2nd;
      this.scheduledBookingAirportRadius1st = model.scheduledBookingAirportRadius1st;
      this.scheduledBookingAirportRadius2nd = model.scheduledBookingAirportRadius2nd;
      this.scheduledBookingTime1st = model.scheduledBookingTime1st;
      this.scheduledBookingTime2nd = model.scheduledBookingTime2nd;
      this.allowedTimeForCreatingBooking1st = model.allowedTimeForCreatingBooking1st;
      this.allowedTimeForCreatingBooking2nd = model.allowedTimeForCreatingBooking2nd;
      this.reminderTime1st = model.reminderTime1st;
      this.reminderTime2nd = model.reminderTime2nd;
      this.cancellationFeePeriod1st = model.cancellationFeePeriod1st;
      this.cancellationFeePeriod2nd = model.cancellationFeePeriod2nd;
      this.cancellationFee1st = model.cancellationFee1st;
      this.cancellationFee2nd = model.cancellationFee2nd;
      this.allowedTimeForMakingContact1st = model.allowedTimeForMakingContact1st;
      this.allowedTimeForMakingContact2nd = model.allowedTimeForMakingContact2nd;
      this.timeoutForMigration1st = model.timeoutForMigration1st;
      this.timeoutForMigration2nd = model.timeoutForMigration2nd;
    }
  }
}

export class SettingsByCountriesModel {
  countryName: string;
  cancellationFee: number;
  gst: number;
  warningLimit: number;
  depositLockCash: number;
  warningLimitSendSMS: Boolean;
  depositLockCashSendSMS: Boolean;

  constructor(model: any = null) {
    if (model) {
      this.countryName = model.countryName;
      this.cancellationFee = model.cancellationFee;
      this.gst = model.gst;
      this.warningLimit = model.warningLimit;
      this.depositLockCash = model.depositLockCash;
      this.warningLimitSendSMS = model.warningLimitSendSMS;
      this.depositLockCashSendSMS = model.depositLockCashSendSMS;
    }
  }
}
