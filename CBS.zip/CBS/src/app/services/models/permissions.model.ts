export class PermissionsModel {
    id: number;
    name: string;
    actions: {
        canRead: boolean,
        canCreate: boolean,
        canUpdate: boolean,
        canDelete: boolean
    };

    constructor(model: any = null) {
        if (model) {
            this.id = model.id;
            this.name = model.name;
            this.actions = model.actions;
        }
    }
}
