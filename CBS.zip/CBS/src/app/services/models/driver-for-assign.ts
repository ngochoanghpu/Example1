export class DriverForAssign {
  public id: number;
  public model?: string;
  public firstName: string;
  public profileImage: string; 
  public phoneNumber: string;

  constructor(model: DriverForAssign = null) {
    if(model){
      this.id = model.id;
      this.firstName = model.firstName;
      this.profileImage = model.profileImage;
      this.phoneNumber = model.phoneNumber;
    }    
  }
}
