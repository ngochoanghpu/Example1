export class UserModel {
  id: number;
  firstName: string;
  avatar: string;
  lastName: string;
  email: string;
  phoneCode: string;
  mobilePhone: string;
  homePhone: string;
  address: string;
  role: string;
  country: string;
  countryId: string;
  dob: string;

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.avatar = model.avatar;
      this.firstName = model.firstName;
      this.lastName = model.lastName;
      this.email = model.email;
      this.phoneCode = model.phoneCode;
      this.mobilePhone = model.mobilePhone;
      this.homePhone = model.homePhone;
      this.address = model.address;
      this.role = model.role;
      this.country = model.country;
      this.countryId = model.countryId;
      this.dob = model.dob;
    }
  }
}
