export class DriverModel {
  id: number;
  profileImage: string;
  firstName: string;
  lastName: string;
  phoneCode: string;
  phoneNumber: string;
  rating: number;
  email: string;
  countryId: number;
  dob: number;
  address: string;
  startDate: number;
  endDate: number;
  status: number;
  documents: any;
  vehicleId?: number;
  bankInformation: any;
  workingCalendar?: any;
  countryName: string;
  public vehicleInfo: {
    numberPlate: string,
    insuranceExpiryDate: string,
    model: string
  };

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.profileImage =  model.profileImage;
      this.firstName =  model.firstName;
      this.lastName =  model.lastName;
      this.phoneCode =  model.phoneCode;
      this.phoneNumber =  model.phoneNumber;
      this.rating =  model.rating;
      this.email =  model.email;
      this.countryId =  model.countryId;
      this.dob =  model.dob;
      this.address =  model.address;
      this.startDate =  model.startDate;
      this.endDate =  model.endDate;
      this.status =  model.status;
      this.documents =  model.documents;
      this.vehicleId =  model.vehicleId;
      this.bankInformation = model.bankInformation;
      this.workingCalendar = model.workingCalendar;
      this.countryName = model.countryName;
      this.vehicleInfo = model.vehicleInfo;
    }
  }
}
