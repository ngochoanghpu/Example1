export class TripDetailsModel {
    id: number;
    date: string;
    fare: number;
    tollFee: number;
    airport: number;
    earning: number;
    commission: number;
    hdGst: number;
    balance: number;
    totalGst: number;
    status: number;

    constructor(model: any = null) {
      if (model) {
        this.id = model.id;
        this.date = model.date;
        this.fare = model.fare;
        this.tollFee = model.tollFee;
        this.airport = model.airport;
        this.earning = model.earning;
        this.commission = model.commission;
        this.hdGst = model.hdGst;
        this.balance = model.balance;
        this.totalGst = model.totalGst;
        this.status = model.status;
      }
    }
  }
