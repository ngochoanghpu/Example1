export class Passenger {
  public id: number;
  public profileImage: any;
  public firstName: string;
  public lastName: string;
  public phoneCode: string;
  public phoneNumber: string;
  public homePhone: string;
  public email: string;
  public country: {
    id: number,
    name: string
  };
  public address: string;
  public rating: number;
  public status: number;
  public deactiveReason: string;
  public countryId: number;

  constructor(model: Passenger = null) {
    if (model) {
      this.id = model.id;
      this.profileImage = model.profileImage;
      this.firstName = model.firstName;
      this.lastName = model.lastName;
      this.phoneCode = model.phoneCode;
      this.phoneNumber = model.phoneNumber;
      this.homePhone = model.homePhone;
      this.email = model.email;
      this.country = model.country;
      this.address = model.address;
      this.rating = model.rating;
      this.status = model.status;
      this.deactiveReason = model.deactiveReason;
      this.countryId = model.countryId;
    }
  }
}
