import { PermissionsModel } from './permissions.model';

export class RoleModel {
  id: number;
  name: string;
  desc: string;
  permissions: PermissionsModel[];

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.name = model.name;
      this.desc = model.desc;
      this.permissions = model.permissions;
    }
  }
}
