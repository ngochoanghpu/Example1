export class TermsOfUseModel {
  content: string;

  constructor(model: any = null) {
    if (model) {
      this.content = model.content;
    }
  }
}
