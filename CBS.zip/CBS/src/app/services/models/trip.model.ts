export class TripModel {
  id: number;
  rider: string;
  driver: string;
  serviceType: string;
  pickUp: string;
  pickUpDate: string;
  distance: number;
  vehicle: number;
  cancelledBy: string;
  dropOff: string;
  dropOffDate: string;
  duration: number;
  status: number;
  rating: number;
  riderAvt: string;
  driverAvt: string;
  totalFare: number;
  paymentStatus: number;
  paymentMethod: string;
  cancelledFee: number;
  note: string;

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.rider = model.rider;
      this.driver = model.driver;
      this.serviceType = model.serviceType;
      this.pickUp = model.pickUp;
      this.pickUpDate = model.pickUpDate;
      this.distance = model.distance;
      this.vehicle = model.vehicle;
      this.cancelledBy = model.cancelledBy;
      this.dropOff = model.dropOff;
      this.dropOffDate = model.dropOffDate;
      this.duration = model.duration;
      this.status = model.status;
      this.riderAvt = model.riderAvt;
      this.driverAvt = model.driverAvt;
      this.rating = model.rating;
      this.totalFare = model.totalFare;
      this.paymentStatus = model.paymentStatus;
      this.paymentMethod = model.paymentMethod;
      this.cancelledFee = model.cancelledFee;
      this.note = model.note;
    }
  }
}
