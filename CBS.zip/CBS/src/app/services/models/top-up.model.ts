import { DriverModel } from './driver.model';

export class TopUpModel {
    id: number;
    driver: DriverModel;
    date: string;
    topupAmount: number;
    topupType: number;
    paymentStatus: number;
    status: number;

    constructor(model: any = null) {
        if (model) {
            this.id = model.id;
            this.driver = model.driver;
            this.date = model.date;
            this.topupAmount = model.topupAmount;
            this.topupType = model.topupType;
            this.paymentStatus = model.paymentStatus;
            this.status = model.status;
        }
    }
}
