import { DriverModel } from './driver.model';
import { TripDetailsModel } from './trip-details.model';

export class EODPayoutDetailModel {
  id: number;
  driver: DriverModel;
  tripDetail: TripDetailsModel[];

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.driver = model.driver;
      this.tripDetail = model.tripDetail;
    }
  }
}
