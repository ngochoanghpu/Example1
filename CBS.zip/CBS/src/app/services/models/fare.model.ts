export class Fare {
  public id: number;
  public name: string;
  public countryId: string;
  public effectiveFrom: string;
  public effectiveTo: string;
  public typeOfService: string;
  public typeOfServiceId: string;
  public typeOfRide: string;
  public typeOfRideId: string;
  public typeOfVehicle: string;
  public typeOfVehicleId: string;
  public description?: string;
  public currency?: string;
  public openingPrice?: number;
  public kmPrice?: number;
  public country: {
    id: number,
    name: string  
  };

  constructor(model: Fare = null) {
    if (model) {
      this.id = model.id;
      this.name = model.name;
      this.countryId = model.countryId;
      this.country = model.country;
      this.effectiveFrom = model.effectiveFrom;
      this.effectiveTo = model.effectiveTo;
      this.typeOfService = model.typeOfService;
      this.typeOfServiceId = model.typeOfServiceId;
      this.typeOfRide = model.typeOfRide;
      this.typeOfRideId = model.typeOfRideId;
      this.typeOfVehicle = model.typeOfVehicle;
      this.typeOfVehicleId = model.typeOfVehicleId;
      this.description = model.description;
      this.currency = model.currency;
      this.openingPrice = model.openingPrice;
      this.kmPrice = model.kmPrice;
    }
  }
}
