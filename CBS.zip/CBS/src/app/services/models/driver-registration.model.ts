export class DriverRegistrationModel {
  id: number;
  avatar: string;
  firstName: string;
  lastName: string;
  phoneCode: string;
  phoneNumber: string;
  homePhone: string;
  rating: number;
  email: string;
  country: string;
  dob: number;
  address: string;
  startDate: number;
  registrationDate: number;
  endDate: number;
  license: number;
  licenseExpiryDate: number;
  typeOfService: string[];
  availableCar: string;
  cardAuthorityNo: number;
  cardExpiryDate: number;
  depositAmount: number;
  commission: number;
  status: number;
  rejectNote: string;
  model: string;
  numberPlate: string;
  passengerSeats: number;
  year: string;
  vin: string;
  regoRenewalDate: string;
  lastServiceKms?: string;
  nextServiceKms?: string;
  currentKms?: number;
  kmsBeforeService?: number;
  insuranceRenewalDate?: string;
  etagNumber?: string;
  accountName?: string;
  accountNumber?: string;
  bankName?: string;
  bsbNumber: string;
  abn: string;
  driverLicense: string[];
  proofOfId: string[];
  vehicleInsuranceCert: string[];
  drivingRecord: string[];
  criminalBackgroundCheck: string[];
  certOfRegistration: string[];
  other: string[];
  workingCalendar: string[];
  documents: any;
  public vehicleInfo: {
    numberPlate: string,
    insuranceExpiryDate: string,
    model: string
  };
  public bankInformation: {
    bankAccName: string,
    bankName: string,
    bankAccNo: string,
    bankBsbNo: string,
    bankAbn: string
  }

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.avatar =  model.avatar;
      this.firstName =  model.firstName;
      this.lastName =  model.lastName;
      this.phoneCode =  model.phoneCode;
      this.phoneNumber =  model.phoneNumber;
      this.homePhone =  model.homePhone;
      this.rating =  model.rating;
      this.email =  model.email;
      this.country =  model.country;
      this.dob =  model.dob;
      this.address =  model.address;
      this.startDate =  model.startDate;
      this.registrationDate =  model.registrationDate;
      this.endDate =  model.endDate;
      this.license =  model.license;
      this.licenseExpiryDate =  model.licenseExpiryDate;
      this.typeOfService =  model.typeOfService;
      this.availableCar =  model.availableCar;
      this.cardAuthorityNo =  model.cardAuthorityNo;
      this.cardExpiryDate =  model.cardExpiryDate;
      this.depositAmount =  model.depositAmount;
      this.commission =  model.commission;
      this.status =  model.status;
      this.rejectNote =  model.rejectNote;
      this.driverLicense =  model.driverLicense;
      this.proofOfId =  model.proofOfId;
      this.vehicleInsuranceCert =  model.vehicleInsuranceCert;
      this.drivingRecord =  model.drivingRecord;
      this.criminalBackgroundCheck =  model.criminalBackgroundCheck;
      this.certOfRegistration =  model.certOfRegistration;
      this.other =  model.other;
      this.workingCalendar =  model.workingCalendar;
      this.model =  model.model;
      this.numberPlate =  model.numberPlate;
      this.passengerSeats =  model.passengerSeats;
      this.year =  model.year;
      this.vin =  model.vin;
      this.regoRenewalDate =  model.regoRenewalDate;
      this.lastServiceKms =  model.lastServiceKms;
      this.nextServiceKms =  model.nextServiceKms;
      this.currentKms =  model.currentKms;
      this.kmsBeforeService =  model.kmsBeforeService;
      this.insuranceRenewalDate =  model.insuranceRenewalDate;
      this.etagNumber =  model.etagNumber;
      this.accountName =  model.accountName;
      this.accountNumber =  model.accountNumber;
      this.bankName =  model.bankName;
      this.bsbNumber =  model.bsbNumber;
      this.abn =  model.abn;
      this.documents =  model.documents;
      this.vehicleInfo = model.vehicleInfo;
      this.bankInformation = model.bankInformation;
    }
  }
}
