export class Vehicle {
  public id: number;
  public driverId: number;
  public model: string;
  public numberPlate: string;
  public seats: number;
  public year: string;
  public driverInfo: {
    firstName: string,
    lastName: string,
    phoneCode: string,
    mobilePhone: string,
    avatar: string
  };
  public isPremium: boolean;
  public status: number;
  public vin: string;
  public validUntil?: string;
  public regoRenewalDate: string;
  public lastServiceKms?: string;
  public nextServiceKms?: string;
  public currentKms?: number;
  public kmsBeforeService?: number;
  public insuranceExpiryDate?: string;
  public etagNumber?: string;
  public isServiceMessageSent?: boolean;

  constructor(model: Vehicle = null) {
    if (model) {
      this.id = model.id;
      this.driverId = model.driverId;
      this.driverInfo = model.driverInfo;
      this.numberPlate = model.numberPlate;
      this.model = model.model;
      this.vin = model.vin;
      this.year = model.year;
      this.validUntil = model.validUntil;
      this.regoRenewalDate = model.regoRenewalDate;
      this.lastServiceKms = model.lastServiceKms;
      this.nextServiceKms = model.nextServiceKms;
      this.currentKms = model.currentKms;
      this.kmsBeforeService = model.kmsBeforeService;
      this.insuranceExpiryDate = model.insuranceExpiryDate;
      this.etagNumber = model.etagNumber;
      this.status = model.status;
      this.seats = model.seats;
      this.isPremium = model.isPremium;
      this.isServiceMessageSent = model.isServiceMessageSent;
    }
  }
}
