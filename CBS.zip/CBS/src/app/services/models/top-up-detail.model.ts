export class TopUpDetailModel {
    id: number;
    date: string;
    topupAmount: number;
    topupType: number;
    paymentStatus: number;

    constructor(model: any = null) {
        if (model) {
            this.id = model.id;
            this.date = model.date;
            this.topupAmount = model.topupAmount;
            this.topupType = model.topupType;
            this.paymentStatus = model.paymentStatus;
        }
    }
}
