export class CountryModel {
  id: number;
  code: string;
  name: string;
  flag: string;

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.code = model.code;
      this.name = model.name;
      this.flag = model.flag;
    }
  }
}
