import { DriverModel } from './driver.model';

export class PaymentModel {
    id: number;
    driver: DriverModel;
    startDateTime: string;
    tripId: number;
    paymentMethod: string;
    preCollect: number;
    fare: number;
    hdGst: number;
    driverGst: number;
    commission: number;

    constructor(model: any = null) {
        if (model) {
            this.id = model.id;
            this.driver = model.driver;
            this.startDateTime = model.startDateTime;
            this.tripId = model.tripId;
            this.paymentMethod = model.paymentMethod;
            this.preCollect = model.preCollect;
            this.fare = model.fare;
            this.hdGst = model.hdGst;
            this.driverGst = model.driverGst;
            this.commission = model.commission;
        }
    }
}
