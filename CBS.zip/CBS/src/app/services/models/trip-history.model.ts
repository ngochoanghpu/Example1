export class TripHistoryModel {
  id: number;
  driver: string;
  endDateTime: string;
  pickUp: string;
  dropOff: string;
  passenger: string;
  rating: number;
  passengerAvt: string;
  driverAvt: string;
  totalFare: number;
  comment: string;

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.driver = model.driver;
      this.endDateTime = model.endDateTime;
      this.pickUp = model.pickUp;
      this.dropOff = model.dropOff;
      this.passenger = model.passenger;
      this.passengerAvt = model.passengerAvt;
      this.driverAvt = model.driverAvt;
      this.rating = model.rating;
      this.totalFare = model.totalFare;
      this.comment = model.comment;
    }
  }
}
