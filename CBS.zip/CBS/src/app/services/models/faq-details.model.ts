export class FAQItemModel {
    id: number;
    title: string;
    content: string;

    constructor(model: any = null) {
        if (model) {
            this.id = model.id;
            this.title = model.title;
            this.content = model.content;
        }
    }
}
