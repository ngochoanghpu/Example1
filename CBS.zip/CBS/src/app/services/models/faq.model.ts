import { FAQItemModel } from './faq-details.model';

export class FAQCategoryModel {
  id: number;
  title: string;
  subTitle: string;
  icon: string;
  iconColor: string;
  details?: FAQItemModel[];

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.title = model.title;
      this.subTitle = model.subTitle;
      this.icon = model.icon;
      this.iconColor = model.iconColor;
      this.details = model.details;
    }
  }
}
