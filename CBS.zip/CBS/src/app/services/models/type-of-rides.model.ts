export class TypeOfRidesModel {
  id: number;
  name: string;

  constructor(model: any = null) {
    if (model) {
      this.id = model.id;
      this.name = model.name;
    }
  }
}
