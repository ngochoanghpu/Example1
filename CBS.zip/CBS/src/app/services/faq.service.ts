import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { FAQ } from '@app/fake-api/faq';
import { FAQCategoryModel } from './models/faq.model';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable()
export class FAQService {

  constructor() {}

  public getFAQs(queryParams: any = null): Observable<FAQCategoryModel[]> {
    return of(FAQ).pipe();
  }

  public getDetailFAQCategory(): Observable<FAQCategoryModel> {
    return of(FAQ[0]).pipe(delay(DELAY_TIME));
  }
}
