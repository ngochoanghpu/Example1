import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { TypeOfRides } from '@app/fake-api/type-of-rides';
import { TypeOfRidesModel } from './models/type-of-rides.model';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class TypeOfRidesService {
  constructor() {}

  public getTypeOfRides(queryParams: any = null): Observable<TypeOfRidesModel[]> {
    return of(TypeOfRides).pipe(delay(DELAY_TIME));
  }
}
