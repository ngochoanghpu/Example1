import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { DriverModel } from './models/driver.model';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';

@Injectable({
  providedIn: 'root'
})
export class DriversService {
  public drivers: any = [];

  constructor(private httpClientService: HttpClientService) {}
  
  public getDrivers(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.DRIVER.GET, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }  

  public getAvailableDrivers(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.DRIVER.AVAILABLE, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }


  public getDriverDetails(id: number): Observable<DriverModel> {
    return this.httpClientService.get(`${ApiConfig.DRIVER.GET}/${id}`).pipe(
      map(res => {
        return res.data;
      })
    );
  }

  public assignVehicle(id, data): Observable<any> {
    return this.httpClientService
      .post(`${ApiConfig.DRIVER.ASSIGN_VEHICLE.replace("{id}", id.toString())}`, data)
      .pipe(map(res => res.data));
  }

  public releaseVehicle(id, data): Observable<any> {
    return this.httpClientService
      .post(`${ApiConfig.DRIVER.RELEASE_VEHICLE.replace("{id}", id.toString())}`, data)
      .pipe(map(res => res.data));
  }

  public updateDriver(id, data): Observable<any> {
    return this.httpClientService
      .put(`${ApiConfig.DRIVER.UPDATE}/${id}`, data)
      .pipe(map(res => res.data));
  }

  public createDriver(data): Observable<any> {
    return this.httpClientService
      .post(ApiConfig.DRIVER.CREATE, data)
      .pipe(map(res => res.data));
  }
}
