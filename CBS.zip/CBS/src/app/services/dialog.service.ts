import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DialogService {
  public status: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  private show(value: boolean) {
    this.status.next(value);
  }
}

export const DIALOG_SIZE = {
  default: '430px',
  medium: '700px',
  large: '900px',
  xLarge: '1100px'
};
