import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { PaymentModel } from './models/payment.model';
import { PAYMENT } from '@app/fake-api/payment';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  public payment: PaymentModel[] = [];

  constructor() {}

  public getPayment(queryParams: any = null): Observable<PaymentModel[]> {
    return of(PAYMENT).pipe(delay(DELAY_TIME));
  }
}
