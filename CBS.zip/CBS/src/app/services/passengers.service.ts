import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, map  } from 'rxjs/operators';
import { Passenger } from './models/passenger.model';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';


@Injectable()
export class PassengersService {
  public vehicles: Passenger[] = [];

  constructor(private httpClientService: HttpClientService) {}

  public getPassengers(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.PASSENGER.GET, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  // public updatePassenger(passenger: Passenger) {
  //   let passengerId = passenger.id;
  //   delete passenger.id;

  //   return this.httpClientService.put(`${ApiConfig.PASSENGER.UPDATE_STATUS}/${passengerId}`, passenger).pipe(
  //     map(result => {
  //       return result.data;
  //     })
  //   );
  // }

  public updatePassenger(passenger: Passenger) {
    let passengerId = passenger.id;
    delete passenger.id;

    return this.httpClientService.put(`${ApiConfig.PASSENGER.UPDATE_PASSENGER}/${passengerId}`, passenger).pipe(
      map(result => {
        return result.data;
      })
    );
  }
}
