import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PermissionService {

  constructor() { }

  _getFeaturePermission(featureCode) {
    const currentUserProfile = JSON.parse(localStorage.getItem('userProfile'));
    if (currentUserProfile && currentUserProfile.isSuperAdmin) {
      return {
        canRead: true,
        canCreate: true,
        canUpdate: true,
        canDelete: true,
      };
    }
    if (currentUserProfile && currentUserProfile.permissions) {
      const userPermissions = currentUserProfile.permissions.filter(p => p.code === featureCode);
      if (userPermissions.length !== 0) {
        return userPermissions[0].actions;
      } else {
        return {
          canRead: false,
          canCreate: false,
          canUpdate: false,
          canDelete: false,
        };
      }
    }
  }
}
