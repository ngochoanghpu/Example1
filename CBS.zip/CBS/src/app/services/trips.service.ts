import { Injectable } from '@angular/core';
import { Select2OptionData } from 'ng2-select2';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { TRIPS } from '@app/fake-api/trips';
import { TripModel } from './models/trip.model';
import { TRIPDETAIL } from '@app/fake-api/trip-detail';
import { TripDetailsModel } from './models/trip-details.model';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';
import { DriversService } from '@app/services/drivers.service';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class TripsService {
  public trips: TripModel[] = [];

  constructor(private httpClientService: HttpClientService, private driverService: DriversService,) {}

  public getTrips(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.TRIP.GET, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public getTripDetail(queryParams: any = null): Observable<TripDetailsModel[]> {
    return of(TRIPDETAIL).pipe();
  }

  getDriverList() {    
    return [{
        id: '1',
        text: 'Khoa Nguyen',
        additional: {
          image: 'assets/img/image0.jpg',
        }
      },
      {
        id: '2',
        text: 'Huy Ly',
        additional: {
        }
      },
      {
        id: '3',
        text: 'Phat Le',
        additional: {
          image: 'assets/img/image1.jpg',
        }
      },
      {
        id: '4',
        text: 'Nguyen Le',
        additional: {
          image: 'assets/img/image2.jpg',
        }
      },
      {
        id: '5',
        text: 'Nam Nguyen',
        additional: {
          image: 'assets/img/image3.jpg',
        }
      }
    ];
  }
}
