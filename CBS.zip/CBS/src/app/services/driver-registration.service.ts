import { Injectable } from '@angular/core';
import { DRIVER_REGISTRATION } from '@app/fake-api/driver-registration';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class DriverRegistrationService {
  public driverRegistration: any = [];

  constructor(private httpClientService: HttpClientService) {}

  public getRegistrationDrivers(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.DRIVER.GET_REGISTRATION, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public rejectDriver(driverId, rejectNode): any {
    return this.httpClientService.put(ApiConfig.DRIVER.REJECT_REGISTRATION.replace("{id}", driverId.toString()), rejectNode).pipe(
      map(resp => {
        return resp.message;
      })
    );
  }

  public approveDriver(driverId): any {
    return this.httpClientService.put(ApiConfig.DRIVER.APPROVE_REGISTRATION.replace("{id}", driverId.toString())).pipe(
      map(resp => {
        return resp.message;
      })
    );
  }
}
