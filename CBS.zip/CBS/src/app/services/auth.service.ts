import { Injectable } from '@angular/core';
import { map, switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { HttpClientService } from './http-client.service';
import { ApiConfig } from '@app/config/api';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpClientService: HttpClientService) { }

  public authenticated(): boolean {
    return this.getUserToken() !== null;
  }

  public getUserToken(): string {
    return localStorage.getItem('accessToken');
  }

  public login(email: string, password: string): Observable<any> {
    return this.httpClientService.post(ApiConfig.AUTH.LOGIN, { email, password }).pipe(
      switchMap(resp => {
        if (resp && resp.data.accessToken) {
          localStorage.setItem('accessToken', resp.data.accessToken);
          return this.httpClientService.get(ApiConfig.USER.GET_PROFILE).pipe(
            map(res => {
              return res.data;
            })
          );
        }
      })
    );
  }

  public forgotPassword(email: string): Observable<any> {
    return this.httpClientService.post(ApiConfig.AUTH.FORGOT_PASSWORD, { email }).pipe(
      map(resp => {
        return resp;
      })
    );
  }

  public resetPassword(data): Observable<any> {
    return this.httpClientService.post(ApiConfig.AUTH.RESET_PASSWORD, data).pipe(
      map(resp => {
        return resp;
      })
    );
  }

  public changePassword(data): Observable<any> {
    return this.httpClientService.put(ApiConfig.AUTH.CHANGE_PASSWORD, data).pipe(
      map(resp => {
        return resp;
      })
    );
  }

  public logout(): Observable<any> {
    return this.httpClientService.post(ApiConfig.AUTH.LOGOUT).pipe(
      map(result => {
        return result.message;
      })
    );
  }
}
