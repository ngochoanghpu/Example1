import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { CountryModel } from './models/country.model';
import { ApiConfig } from '@app/config/api';
import { HttpClientService } from '@app/services/http-client.service';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class CountriesService {
  public countries: any = [];

  constructor(private httpClientService: HttpClientService) {}

public getCountries(): Observable<[]> {
    return this.httpClientService.get(ApiConfig.COUNTRY.GET).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }
}
