import { Injectable } from '@angular/core';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';
import { map } from "rxjs/operators";
import { environment } from '@env/environment';
import { HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable()
export class DocumentsService {
  private API_ENDPOINT = environment.API_ENDPOINT;

  constructor(private httpClientService: HttpClientService, private httpClient: HttpClient) {}

  public uploadImage(base64: any) {    
    return this.httpClientService.post(`${ApiConfig.DOCUMENT.UPLOAD}`, { "file": base64}).pipe(
      map(result => {
        return result.data.url;
      })
    );
  }

  public deleteDraftImages(darftImages: string[]) {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: { "paths": darftImages}
   };

    return this.httpClient.request('delete', `${this.API_ENDPOINT}${ApiConfig.DOCUMENT.DELETE_DRAFT_IMAGES}`, httpOptions);
  }                  
}