import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { Fare } from './models/fare.model';
import { FARES } from '@app/fake-api/fares';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';


@Injectable()
export class FaresService {
  public vehicles: Fare[] = [];

  constructor(private httpClientService: HttpClientService) {}

  public getFares(queryParams: any = null): any {
    return this.httpClientService.get(ApiConfig.FARE.GET, { params: queryParams }).pipe(
      map(resp => {
        return resp.data;
      })
    );
  }

  public updateFare(fare: Fare) {
    let fareId = fare.id;
    delete fare.id;

    return this.httpClientService.put(`${ApiConfig.FARE.UPDATE_FARE}/${fareId}`, fare).pipe(
      map(result => {
        return result.data;
      })
    );
  }

  public deleteFare(fareId: number) {    
    return this.httpClientService.put(`${ApiConfig.FARE.DELETE_FARE}/${fareId}`).pipe(
      map(result => {
        return result.data;
      })
    );
  }

  public addFare(fare: Fare) {    
    return this.httpClientService.post(`${ApiConfig.FARE.CREATE_FARE}`, fare).pipe(
      map(result => {
        return result.data;
      })
    );
  }
}
