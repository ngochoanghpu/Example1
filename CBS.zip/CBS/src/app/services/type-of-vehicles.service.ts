import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { TypeOfVehicleFare } from '@app/fake-api/type-of-vehicle-fare';
import { TypeOfVehicles } from '@app/fake-api/type-of-vehicles';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class TypeOfVehiclesService {
  constructor() {}

  public getTypeOfVehicles(queryParams: any = null, isTypeOfFare = false): any {
    if(isTypeOfFare){
      return of(TypeOfVehicleFare).pipe();
    }

    return of(TypeOfVehicles).pipe();
  }
}
