import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { TypeOfServices } from '@app/fake-api/type-of-services';
import { TypeOfServicesModel } from './models/type-of-services.model';

// only for testing
const DELAY_TIME = 1000;
// ----

@Injectable({
  providedIn: 'root'
})
export class TypeOfServicesService {
  constructor() {}

  public getTypeOfServices(queryParams: any = null): Observable<TypeOfServicesModel[]> {
    return of(TypeOfServices).pipe(delay(DELAY_TIME));
  }
}
