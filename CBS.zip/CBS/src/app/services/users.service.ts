import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from '@app/services/http-client.service';
import { ApiConfig } from '@app/config/api';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  public users: any = [];

  constructor(private httpClientService: HttpClientService) {}

  public getUsers(queryParams: any = null): Observable<[]> {
    return this.httpClientService
      .get(ApiConfig.USER.GET_USERS, { params: queryParams })
      .pipe(
        map(data => {
          return data.data;
        })
      );
  }

  public getProfile(): any {
    return this.httpClientService.get(ApiConfig.USER.GET_PROFILE).pipe(
      map(data => {
        return data.data;
      })
    );
  }

  public createUser(user: Object) {
    return this.httpClientService.post(ApiConfig.USER.CREATE_USER, user).pipe(
      map(data => {
        return data.data;
      })
    );
  }

  public updateUser(id: Number, user: Object) {
    return this.httpClientService.put(`${ApiConfig.USER.CREATE_USER}/${id}`, user).pipe(
      map(data => {
        return data.data;
      })
    );
  }

  public deleteUser(id: Number) {
    return this.httpClientService.delete(`${ApiConfig.USER.DELETE_USER}/${id}`).pipe(
      map(data => {
        return data.data;
      })
    );
  }
}
