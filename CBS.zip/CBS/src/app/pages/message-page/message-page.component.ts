import { Component, OnInit, HostBinding } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'dnf-message-page',
  templateUrl: './message-page.component.html'
})
export class MessagePageComponent implements OnInit {

  @HostBinding('class') classes = 'dnf-message';

  constructor(private router: Router) {}

  ngOnInit() {}

  back() {
    this.router.navigate(['/login']);
  }

}
