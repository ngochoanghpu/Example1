import { Component, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { Inject } from '@angular/core';
import { PAYMENT_METHOD } from '@app/shared/constant';

@Component({
  selector: 'dnf-trip-detail-dialog',
  templateUrl: './trip-detail-dialog.component.html',
  styleUrls: ['./trip-detail-dialog.component.scss']
})
export class TripDetailDialogComponent implements OnInit {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { } 

  ngOnInit() {
    this.data.item.paymentInfo.paymentMethod = PAYMENT_METHOD[this.data.item.paymentInfo.type];
  }
}