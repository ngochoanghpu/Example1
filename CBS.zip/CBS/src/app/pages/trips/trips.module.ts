import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripsComponent } from './trips.component';
import { DesignModule } from '@app/shared/design/design.module';
import { RouterModule } from '@angular/router';
import { TripDetailDialogComponent } from './components/trip-detail-dialog/trip-detail-dialog.component';
import { SharedModule } from '@app/shared';

@NgModule({
  declarations: [TripsComponent, TripDetailDialogComponent],
  imports: [
    CommonModule,
    DesignModule,
    SharedModule,
    RouterModule.forChild([
      {
        path: '',
        component: TripsComponent
      }
    ])
  ],
  entryComponents: [TripDetailDialogComponent],
})
export class TripsModule { }
