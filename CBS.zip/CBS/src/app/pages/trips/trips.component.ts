import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatSort,
  MatPaginator,
  MatDialog,
  MatInput,
  MatTableDataSource
} from '@angular/material';
import { LoaderService } from '@app/services/loader.service';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { TripsService } from '@app/services/trips.service';
import { TripModel } from '@app/services/models/trip.model';
import { TripDetailDialogComponent } from './components/trip-detail-dialog/trip-detail-dialog.component';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { Select2TemplateFunction, Select2OptionData } from 'ng2-select2';
import { AVATAR } from '@app/shared/constant';
import { DriversService } from '@app/services/drivers.service';
import moment from 'moment';
import { PermissionService } from '@app/services/permission.service';

@Component({
  selector: 'dnf-trips',
  templateUrl: './trips.component.html',
  styleUrls: ['./trips.component.scss']
})
export class TripsComponent implements OnInit {
  featureCode = 'TRI';
  permission = {
    canRead: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false
  };
  public drivers: Array<Select2OptionData>;
  public options: Select2Options;
  isLoading = false;
  displayedColumns: string[] = [
    'passenger',
    'driver',
    'pickup',
    'dropoff',
    'tripDate',
    'time',
    'amount',
    'status',
    'paymentStatus',
    'actions'
  ];
  dataSource: any;
  breadcrumbs = [{ icon: 'flaticon-user', text: 'LBL_TRIPS' }];
  typeOfStatusId = '';
  typeOfPaymentId = '';
  startDate = null;
  currentDriverId = null;
  keyword = '';

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  constructor(
    private permissionService: PermissionService,
    private tripService: TripsService,
    private loaderService: LoaderService,
    public dialog: MatDialog,
    private driverService: DriversService,
  ) {}

  ngOnInit() {
    this.permission = this.permissionService._getFeaturePermission(this.featureCode);
    this.getDrivers();

    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
  }

  _loadItems(firstLoad: boolean = false, isSearch: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
        status: this.typeOfStatusId,
        'paymentInfo[status]': this.typeOfPaymentId,
        tripDate: this.startDate ? moment(this.startDate).format('YYYY-MM-DD') : null,
        driverId: this.currentDriverId
      },
      this.sort.direction,
      this.sort.active,
      firstLoad || isSearch ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.tripService.getTrips(queryParams).subscribe(trips => {
      this.paginator.length = trips.total;
      this.dataSource = new MatTableDataSource<TripModel>(trips.results);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  viewDetails(item): void {
    this._initDialog(item);
  }

  private _initDialog(item = null) {
    const dialogRef = this.dialog.open(TripDetailDialogComponent, {
      width: DIALOG_SIZE.large,
      data: { item: item }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('View close');
    });
  }

  search() {
    this._loadItems(null, true);
  }

  reset() {
    this.keyword = '';
    this.typeOfStatusId = '';
    this.typeOfPaymentId = '';
    this.startDate = null;
    this.currentDriverId = null;
  }

  getDrivers() {
    this.driverService.getDrivers().subscribe(drivers => {
      // Config select2
      this.options = {
        templateResult: this.driverList,
        templateSelection: this.driverSelection,
        placeholder: { id: '', text: 'Driver' },
        allowClear: true,
        width: '100%'
      };

      this.drivers = drivers.results.map(driver => {
        return {
          id: driver.id.toString(),
          text: driver.firstName,
          additional: {
            image: driver.profileImage
          }
        };
      });

      this.drivers.unshift({id: '', text: 'Driver'});
    });
  }

  changedDriver(event) {
    this.currentDriverId = event.value;
  }

  public driverList: Select2TemplateFunction = (
    state: Select2OptionData
  ): JQuery | string => {
    if (!state.id) {
      return state.text;
    }
    const image = `<img class="${AVATAR.SIZE.DEFAULT}" onError="this.src='${
      AVATAR.DEFAULT
    }'" src="${
      state.additional.image ? state.additional.image : AVATAR.DEFAULT
    }"/>`;
    return jQuery(
      `<span class="dnf-avatar">${image} <span>${state.text}</span></span>`
    );
  };

  // function for selection template
  public driverSelection: Select2TemplateFunction = (
    state: Select2OptionData
  ): JQuery | string => {
    if (!state.id) {
      return state.text;
    }
    return jQuery(`<span>${state.text}</span>`);
  };
}
