import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorPageComponent } from './error-page/error-page.component';
import { PagesComponent } from './pages.component';
import { MessagePageComponent } from './message-page/message-page.component';

const routes: Routes = [
  {
    path: '',
    component: PagesComponent,
    // canActivate: [NgxPermissionsGuard],
    data: {
      permissions: {
        only: ['ADMIN', 'USER'],
        except: ['GUEST'],
        redirectTo: '/login'
      }
    },
    children: [
      {
        path: '',
        loadChildren: './dashboard/dashboard.module#DashboardModule'
      },
      {
        path: 'vehicles',
        loadChildren: './vehicles/vehicles.module#VehiclesModule'
      },
      {
        path: 'drivers',
        loadChildren: './drivers/drivers.module#DriversModule'
      },
      {
        path: 'trips',
        loadChildren: './trips/trips.module#TripsModule'
      },
      {
        path: 'passengers',
        loadChildren: './passengers/passengers.module#PassengersModule'
      },
      {
        path: 'fares',
        loadChildren: './fares/fares.module#FaresModule'
      },
      {
        path: 'users',
        loadChildren: './users/users.module#UsersModule'
      },
      {
        path: 'roles',
        loadChildren: './roles/roles.module#RolesModule'
      },
      {
        path: 'reports',
        loadChildren: './reports/reports.module#ReportsModule'
      },
      {
        path: 'faq',
        loadChildren: './faq/faq.module#FaqModule'
      },
      {
        path: 'settings',
        loadChildren: './generals/generals.module#GeneralsModule'
      },
      {
        path: 'terms',
        loadChildren: './terms-of-use/terms-of-use.module#TermsOfUseModule'
      }
    ]
  },
  {
    path: '',
    // canActivate: [NgxPermissionsGuard],
    loadChildren: './auth/auth.module#AuthModule'
    // data: {
    // 	permissions: {
    // 		except: 'ADMIN'
    // 	}
    // },
  },
  {
    path: 'error',
    component: ErrorPageComponent
  },
  {
    path: 'message',
    component: MessagePageComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule {}
