import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatPaginator, MatSort, MatTableDataSource, MatDialog, MatInput } from '@angular/material';
import { LoaderService } from '@app/services/loader.service';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { Vehicle } from '@app/services/models/vehicle.model';
import { VehiclesService } from '@app/services/vehicles.service';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { AssignConfirmationComponent } from './assign-confirmation/assign-confirmation.component';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'dnf-assign-vehicle',
  templateUrl: './assign-vehicle.component.html',
  styleUrls: ['./assign-vehicle.component.scss']
})
export class AssignVehicleComponent implements OnInit {
  driverName: string;
  keyword = '';
  public displayedColumns: string[] = [
    'model',
    'numberPlate',
    'seats',
    'actions'
  ];
  public dataSource: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  constructor(
    public dialogRef: MatDialogRef<AssignVehicleComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private loaderService: LoaderService,
    private vehiclesService: VehiclesService,
    private dialog: MatDialog) { }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
    this.driverName = this.data.driverName;
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      { 
        q: this.keyword,
      },
      this.sort.direction,
      this.sort.active,
      firstLoad ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.vehiclesService.getAvailableVehicles(queryParams).subscribe(vehicles => {
      this.paginator.length = vehicles.total;
      this.dataSource = new MatTableDataSource<Vehicle>(vehicles.results);      
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  assign(item: Vehicle) {
    const dialogRef = this.dialog.open(AssignConfirmationComponent, {
      width: DIALOG_SIZE.default,
      data: { editMode: false, item: item, driverName: this.driverName, driverId: this.data.driverId }
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
        this.dialogRef.close(result);
      }
    });
  }

  search() {
    this._loadItems(true);
  }

  reset() {
    this.keyword = '';
  }
}
