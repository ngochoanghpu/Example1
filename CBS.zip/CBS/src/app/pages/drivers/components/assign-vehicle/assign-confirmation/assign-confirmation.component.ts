import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { DriverModel } from '@app/services/models/driver.model';
import { LoaderService } from '@app/services/loader.service';
import { DriversService } from '@app/services/drivers.service';

@Component({
  selector: 'dnf-assign-confirmation',
  templateUrl: './assign-confirmation.component.html',
  styleUrls: ['./assign-confirmation.component.scss']
})
export class AssignConfirmationComponent implements OnInit {
  item: any;
  driverName: string;
  constructor(
    public dialogRef: MatDialogRef<AssignConfirmationComponent>,
    private driverService: DriversService,
    private loaderService: LoaderService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
    this.item = this.data.item;
    this.driverName = this.data.driverName;
  }

  assign() {
    let driver = new DriverModel();    
    driver.vehicleId = this.item.id;

    this.loaderService.show();
    this.driverService.assignVehicle(this.data.driverId, driver).subscribe(driver => {      
      this.loaderService.hide();
      this.dialogRef.close(true);
    });
  }
}
