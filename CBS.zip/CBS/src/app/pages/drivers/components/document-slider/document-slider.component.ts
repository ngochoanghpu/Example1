import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'dnf-document-slider',
  templateUrl: './document-slider.component.html',
  styleUrls: ['./document-slider.component.scss']
})
export class DocumentSliderComponent implements OnInit {
  @Input() type: any;
  @Input() images: any;
  @Input() editMode: boolean; 
  @Output() callbackFunction = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
    this.handleImages();
  }

  handleImages() {
    const handled: any = [];
    if (this.images) {
      this.images.forEach(image => {
        handled.push(image);
      });
    } else {
      handled.push('assets/img/driver/no_file.png');
    }
    this.images = handled;
  }

  deleteItem(item: string) {
    const index: number = $.inArray( item, this.images);
    if (index !== -1) {
        this.images.splice(index, 1);
    }

    this.callbackFunction.emit({images: this.images, type: this.type});

    if(this.images.length === 0){
      this.images = ['assets/img/driver/no_file.png'];
      this.editMode = false;
    }
  }
}