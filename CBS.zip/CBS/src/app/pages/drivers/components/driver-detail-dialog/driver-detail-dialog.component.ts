import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { CountriesService } from '@app/services/countries.service';
import { DriverModel } from '@app/services/models/driver.model';
import { DriversService } from '@app/services/drivers.service';
import { LoaderService } from '@app/services/loader.service';
import { DAYS_OF_WEEK } from '@app/shared/constant';

@Component({
  selector: 'dnf-driver-detail-dialog',
  templateUrl: './driver-detail-dialog.component.html',
  styleUrls: ['./driver-detail-dialog.component.scss']
})
export class DriverDetailDialogComponent implements OnInit {
  item: DriverModel;
  displayedColumns: string[] = [
    'fromDate',
    'toDate'
  ];
  dataSource: any;
  daysOfWeek: string[] = DAYS_OF_WEEK;
  listWorkingDaysObj: any;
  listWorkingDays: string[];
  workingDays: any;
  vehicleList: any;
  countryList: any;
  countries: any;
  vehicles: any;

  constructor(
    public dialogRef: MatDialogRef<DriverDetailDialogComponent>,
    private countriesServive: CountriesService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.item = new DriverModel(this.data.item);  
    this.dataSource = this.item.workingCalendar ? this.item.workingCalendar.holidays : null;
    this.listWorkingDaysObj = this.getWorkingDaysBinary()
      
    this.workingDays = [];
    if (this.listWorkingDaysObj) {
      for (var i = 0; i < DAYS_OF_WEEK.length; i++) {
        if (this.listWorkingDaysObj.charAt(i) == 1) {
          this.workingDays.push(DAYS_OF_WEEK[i]);
        }
        else {
          this.workingDays.push(null);
        }
      }
    }
  }

  edit() {
    this.dialogRef.close(true);
  }

  checkSelectedDay(day: string): boolean {
    return this.workingDays.indexOf(day) > -1;
  }

  getVehicle(vehicleId) {
    const vehicle = this.vehicleList.find(e => e.id === vehicleId);
    return vehicle ? vehicle.name : "";
  }

  getWorkingDaysBinary(){
    this.listWorkingDaysObj = this.item.workingCalendar ? (this.item.workingCalendar.workingDays).toString(2) : null;
    if(this.listWorkingDaysObj && this.listWorkingDaysObj.length < 7){
      let addMoreBit = 7 - this.listWorkingDaysObj.length;
      for(let i = 0; i < addMoreBit; i++){
        this.listWorkingDaysObj = "0" + this.listWorkingDaysObj;
      }
    }

    return this.listWorkingDaysObj;
  }
}
