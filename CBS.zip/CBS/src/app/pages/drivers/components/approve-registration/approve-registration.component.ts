import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DriverRegistrationService } from '@app/services/driver-registration.service';

@Component({
  selector: 'dnf-approve-registration',
  templateUrl: './approve-registration.component.html',
  styleUrls: ['./approve-registration.component.scss']
})
export class ApproveRegistrationComponent implements OnInit {
  driverName: string;
  constructor(
    public dialogRef: MatDialogRef<ApproveRegistrationComponent>,
    public dialog: MatDialog,
    private driverRegistrationService: DriverRegistrationService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.driverName = this.data.item.firstName + ' ' + this.data.item.lastName;
  }

  approve() {
    this.driverRegistrationService
      .approveDriver(this.data.item.id)
      .subscribe(driverRegistration => {
        this.dialogRef.close('LBL_ACTION_APPROVE');
      });
  }
}
