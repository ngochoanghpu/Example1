import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DocumentsService } from '@app/services/document.service';

@Component({
  selector: 'dnf-delete-draft-images',
  templateUrl: './delete-draft-images.component.html',
  styleUrls: ['./delete-draft-images.component.scss']
})
export class DeleteDraftImagesComponent implements OnInit {
  constructor(
    private documentsService: DocumentsService,
    public dialogRef: MatDialogRef<DeleteDraftImagesComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    
  }

  deleteDraftImages() {    
    this.documentsService.deleteDraftImages(this.data.draftImages)
                             .subscribe(res => {     
                                console.log("delete draft images successfully");
                                this.dialog.closeAll();                              
                              }, err => {console.log(err)});
  }
}
