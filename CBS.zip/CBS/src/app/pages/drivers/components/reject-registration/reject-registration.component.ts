import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DriverRegistrationService } from '@app/services/driver-registration.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SpacesValidator } from '../../../../core/validators/spaces-validator';

@Component({
  selector: 'dnf-reject-registration',
  templateUrl: './reject-registration.component.html',
  styleUrls: ['./reject-registration.component.scss']
})
export class RejectRegistrationComponent implements OnInit {
  driverName: string;
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private driverRegistrationService: DriverRegistrationService,
    public dialogRef: MatDialogRef<RejectRegistrationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.form = this.fb.group({
      rejectNote: ['', [SpacesValidator]]
    });

    this.driverName = this.data.item.firstName + ' ' + this.data.item.lastName;
  }

  reject() {  
    const rejectNote = {rejectNote: this.form.value.rejectNote};
    
    this.driverRegistrationService
      .rejectDriver(this.data.item.id, rejectNote)
      .subscribe(driverRegistration => {
        this.dialogRef.close('LBL_ACTION_REJECT');
      });
  }

  hasError(field, type) {
    return this.form.get(field).hasError(type);
  }
}