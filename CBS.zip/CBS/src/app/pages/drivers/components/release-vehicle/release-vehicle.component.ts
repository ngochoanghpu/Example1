import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DriversService } from '@app/services/drivers.service';
import { DriverModel } from '@app/services/models/driver.model';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-release-vehicle',
  templateUrl: './release-vehicle.component.html',
  styleUrls: ['./release-vehicle.component.scss']
})
export class ReleaseVehicleComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<ReleaseVehicleComponent>,
    private driverService: DriversService,
    private loaderService: LoaderService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    
  }

  release() {
    let driver = new DriverModel();    
    driver.vehicleId = null;

    this.loaderService.show();
    this.driverService.releaseVehicle(this.data.item.id, driver).subscribe(driver => {      
      this.loaderService.hide();
      this.dialogRef.close(true);
    });
  }
}
