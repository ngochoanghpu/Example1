import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DriversService } from '@app/services/drivers.service';
import { LoaderService } from '@app/services/loader.service';
import { STATUS_ENUM } from '@app/shared/constant';
import { DriverModel } from '@app/services/models/driver.model';

@Component({
  selector: 'dnf-deactivate',
  templateUrl: './deactivate.component.html',
  styleUrls: ['./deactivate.component.scss']
})
export class DeactivateDriverComponent implements OnInit {
  driverName: string;
  status: any;
  constructor(
    public dialogRef: MatDialogRef<DeactivateDriverComponent>,
    private driverService: DriversService,
    private loaderService: LoaderService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.driverName = this.data.item.firstName + ' ' + this.data.item.lastName;
    this.status = this.data.item.status;
  }

  updateStatus() {
    let driver = new DriverModel();    
    driver.status = this.data.item.status === STATUS_ENUM.ACTIVE ? STATUS_ENUM.INACTIVE : STATUS_ENUM.ACTIVE;

    this.loaderService.show();
    this.driverService.updateDriver(this.data.item.id, driver).subscribe(driver => {      
      this.loaderService.hide();
      this.dialogRef.close(true);
    });
  }
}
