import { Component, OnInit, Inject, ChangeDetectorRef } from '@angular/core';
import { DriverModel } from '@app/services/models/driver.model';
import { MatDialogRef, MAT_DIALOG_DATA, MatSelectChange, MatOption, MatDialog } from '@angular/material';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { DAYS_OF_WEEK } from '@app/shared/constant';
import { CountryModel } from '@app/services/models/country.model';
import { CountriesService } from '@app/services/countries.service';
import { DriversService } from '@app/services/drivers.service';
import { DocumentsService } from '@app/services/document.service';
import { LoaderService } from '@app/services/loader.service';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { DeleteDraftImagesComponent  } from '../delete-draft-images-dialog/delete-draft-images.component';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { SpacesValidator } from '../../../../core/validators/spaces-validator';

@Component({
  selector: 'dnf-edit',
  templateUrl: './driver-form-dialog.component.html',
  styleUrls: [
    './driver-form-dialog.component.scss',
    '../driver-detail-dialog/driver-detail-dialog.component.scss'
  ]
})
export class DriverFormDialogComponent implements OnInit {
  item: DriverModel;
  form: FormGroup;
  editMode: boolean;
  phoneCodeList: any = [];
  countryList: any = [];
  vehicleList: any = [];
  serviceList: any = [];
  draftImages: any = [];
  public imagePath;
  imgURL: any;
  fromDate = null;
  toDate = null;
  isUpdatedAvatar = false;
  countries: any = [];
  displayedColumns: string[] = [
    'fromDate',
    'toDate'
  ];
  maxFromDate = null;
  minFromDate = new Date();
  minToDate = new Date();
  holidays: any;
  daysOfWeek: string[] = DAYS_OF_WEEK;
  listWorkingDaysObj: any;
  listWorkingDays: string[];
  workingDays = {
    LBL_MON: 0,
    LBL_TUE: 0,
    LBL_WED: 0,
    LBL_THU: 0,
    LBL_FRI: 0,
    LBL_SAT: 0,
    LBL_SUN: 0,
  };

  constructor(
    private countriesServive: CountriesService,
    private driversService: DriversService,
    private documentsService: DocumentsService,
    private loaderService: LoaderService,
    public dialog: MatDialog,
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<DriverFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }
  _getCountries() {
    this.countriesServive.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  }
  ngOnInit() {
    this._getCountries();
    this.triggerUploadFileInput();
    this.item = new DriverModel(this.data.item);
    this.imgURL = this.item.profileImage;
    this.phoneCodeList = ['+84', '+01'];
    this.vehicleList = this.data.vehicles;

    this.listWorkingDaysObj = this.getWorkingDaysBinary();    
    this.listWorkingDays = [];
    if(this.listWorkingDaysObj){
      for (var i = 0; i < DAYS_OF_WEEK.length; i++) {       
        if(this.listWorkingDaysObj.charAt(i) == 1){
          this.listWorkingDays.push(DAYS_OF_WEEK[i]);
          this.workingDays[DAYS_OF_WEEK[i]] = 1;
        }
        else{
          this.listWorkingDays.push(null);
          this.workingDays[DAYS_OF_WEEK[i]] = 0;
        }
      }
    }
    this.holidays = this.item.workingCalendar ? this.item.workingCalendar.holidays : [];

    this.form = this.fb.group({
      firstName: [this.item.firstName, [SpacesValidator]],
      lastName: [this.item.lastName, [SpacesValidator]],
      phoneCode: this.item.phoneCode,
      phoneNumber: this.item.phoneNumber,
      email: this.item.email,
      profileImage: this.imgURL,
      countryId: this.item.countryId,
      dob: this.item.dob ? new Date(this.item.dob) : null,
      address: [this.item.address, [SpacesValidator]],
      startDate: this.item.startDate ? new Date(this.item.startDate) : null,
      endDate: this.item.endDate ? new Date(this.item.endDate) : null,
      vehicleId: this.item.vehicleId,
      driverLicense: this.item.documents && this.item.documents.driverLicense ? this.fb.array(this.item.documents.driverLicense) : null,
      proofOfId: this.item.documents && this.item.documents.proofOfId ? this.fb.array(this.item.documents.proofOfId) : null,
      vehicleInsuranceCert: this.item.documents && this.item.documents.vehicleInsuranceCert ? this.fb.array(this.item.documents.vehicleInsuranceCert) : null,
      drivingRecord: this.item.documents && this.item.documents.drivingRecord ? this.fb.array(this.item.documents.drivingRecord) : null,
      criminalBackgroundCheck: this.item.documents && this.item.documents.criminalBackgroundCheck ? this.fb.array(this.item.documents.criminalBackgroundCheck) : null,
      certOfRegistration: this.item.documents && this.item.documents.certOfRegistration ? this.fb.array(this.item.documents.certOfRegistration) : null,
      other: this.item.documents && this.item.documents.other ? this.fb.array(this.item.documents.other) : null,
      bankAccName: [this.item.bankInformation ? this.item.bankInformation.bankAccName : null, [SpacesValidator]],
      bankName: [this.item.bankInformation ? this.item.bankInformation.bankName : null, [SpacesValidator]],
      bankAccNo: [this.item.bankInformation ? this.item.bankInformation.bankAccNo : null, [SpacesValidator]],
      bankBsbNo: this.item.bankInformation ? this.item.bankInformation.bankBsbNo : null,
      bankAbn: this.item.bankInformation ? this.item.bankInformation.bankAbn : null,
    });
  }

  changeFromDate(event: MatDatepickerInputEvent<Date>) {
    this.minToDate = event.value;
  }

  changeToDate(event: MatDatepickerInputEvent<Date>) {
      this.maxFromDate = event.value;
  }

  getPhoneCode (event) {
    this.form.value.phoneCode = event;
  }

  getWorkingDaysBinary(){
    this.listWorkingDaysObj = this.item.workingCalendar ? (this.item.workingCalendar.workingDays).toString(2) : null;
    if(this.listWorkingDaysObj && this.listWorkingDaysObj.length < 7){
      let addMoreBit = 7 - this.listWorkingDaysObj.length;
      for(let i = 0; i < addMoreBit; i++){
        this.listWorkingDaysObj = "0" + this.listWorkingDaysObj;
      }
    }

    return this.listWorkingDaysObj;
  }

  save() {
    this.loaderService.show();
    const data = Object.assign({}, this.form.value);
    data.profileImage = this.imgURL;
    data.bankInformation = {
      bankAccName: this.form.value.bankAccName,
      bankName: this.form.value.bankName,
      bankAccNo: this.form.value.bankAccNo,
      bankBsbNo: this.form.value.bankBsbNo,
      bankAbn: this.form.value.bankAbn
    };
    data.workingCalendar = {
      workingDays: this.workingDays,
      holidays: this.holidays
    };
    data.documents = {
      driverLicense: data.driverLicense || [],
      proofOfId: data.proofOfId || [],
      vehicleInsuranceCert: data.vehicleInsuranceCert || [],
      drivingRecord: data.drivingRecord || [],
      criminalBackgroundCheck: data.criminalBackgroundCheck || [],
      certOfRegistration: data.certOfRegistration || [],
      other: data.other || []
    };
    delete data.bankAccName;
    delete data.bankName;
    delete data.bankAccNo;
    delete data.bankBsbNo;
    delete data.bankAbn;
    delete data.driverLicense;
    delete data.proofOfId;
    delete data.vehicleInsuranceCert;
    delete data.drivingRecord;
    delete data.criminalBackgroundCheck;
    delete data.certOfRegistration;
    delete data.other;

    data.workingCalendar.workingDays = this.getWorkingDaysDecimal(data.workingCalendar.workingDays);

    if (this.data && this.data.editMode) {
      if(!this.isUpdatedAvatar){
        delete data.profileImage;
      }

      this.driversService.updateDriver(this.item.id, data).subscribe(res => {
        if (res) {
          this.loaderService.hide();
          this.dialogRef.close('LBL_UPDATED_SUCCESSFULLY');
        }
      });
    } else {
      this.driversService.createDriver(data).subscribe(res => {
        if (res) {
          this.loaderService.hide();
          this.dialogRef.close('LBL_CREATED_SUCCESSFULLY');
        }
      });
    }
  }

  getWorkingDaysDecimal(workingDays){
    let tmp = "";
    Object.keys(workingDays).forEach(function (item) {
      tmp += workingDays[item];
    });
    return parseInt(tmp, 2);
  }

  hasError(field, type) {
    return this.form.get(field).hasError(type);
  }

  triggerUploadFileInput() {
    $('#upload-avt').click(function() {
      $('#upload-avt-input').click();
    });
  }

  preview(files) {
    if (files.length === 0) {
      return;
    }
    const reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]);
    reader.onload = _event => {
      this.isUpdatedAvatar = true;
      this.imgURL = reader.result;
      this.cdr.detectChanges();
    };
  }

  uploadItem(fieldId) {
    $('input#' + fieldId).click();
  }

  getItem(event, fieldId) {
    if (event.target.files && event.target.files[0]) {
      //upload draft image
      this.loaderService.show();
      const reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = _event => {
        this.documentsService.uploadImage(reader.result).subscribe(res => {
          if (res) {           
            if(!this.form.value[fieldId]){             
              this.form.value[fieldId] = [];
            }

            if(!this.item.documents[fieldId]){             
              this.item.documents[fieldId] = [];
            }
            else{
              let currentSlides = this.item.documents[fieldId];
              this.item.documents[fieldId] = [];
              currentSlides.forEach(slide => {                  
                this.item.documents[fieldId].push(slide);
              });
            }
            this.item.documents[fieldId].push(res);
            let tmp = this.item.documents[fieldId];
            this.item.documents[fieldId] = [res];
            setTimeout(() => {
              this.item.documents[fieldId] = tmp;
            }, 100);
            
            this.form.value[fieldId].push(res);
            this.draftImages.push(res);
            $('input#upload-' + fieldId).val(null);  
            this.loaderService.hide();
          }
        });
      };
    }
  }

  closeDialog() {   
    if(this.draftImages.length === 0){
      this.dialogRef.close();
    }
    else{
      const dialogDraftImage = this.dialog.open(DeleteDraftImagesComponent, {
        width: DIALOG_SIZE.default,
        data: { draftImages: this.draftImages }
      });
    }
  }  
  
  initWorkingDays(workingDays){
    Object.keys(this.workingDays).forEach(function (item) {
      workingDays[item] = 0; 
    });
  }

  onSelectionChange(event: any) {
    this.listWorkingDays = event.map(item => item.value);
    this.initWorkingDays(this.workingDays);
    this.listWorkingDays.forEach(v => {
      this.workingDays[v] = 1;
    });

    let a = 1;
  }

  addHolidays() {
    if (this.fromDate && this.toDate) {
      let allowAdd = true;
      const fromDate = this.fromDate.getTime();
      const toDate = this.toDate.getTime();
      if (this.holidays) {
        this.holidays.every((element, index) => {
          // Do your thing, then:
          if (element.fromDate === fromDate && element.toDate === toDate) {
            alert('This holiday was existed');
            allowAdd = false;
            return allowAdd;
          } else {
            allowAdd = true;
            return allowAdd;
          }
        });
      }
      if (allowAdd) {
        const newHoliday = {
          fromDate: fromDate,
          toDate: toDate
        };
        this.holidays.unshift(newHoliday);
        const cloned = [...this.holidays];
        this.holidays = cloned;
        this.cdr.detectChanges();
        this.fromDate = null;
        this.toDate = null;
      }
      
      //reset validate fromDate, toDate
      this.minFromDate = new Date();
      this.minToDate = new Date();
      this.maxFromDate = null;
    }
  }

  getVehicleInfo = (event: MatSelectChange) => {
    const selectedData = {
      text: (event.source.selected as MatOption).viewValue,
      value: event.source.value
    };

    this.item.vehicleInfo = this.vehicleList.find(e => e.id == selectedData.value);
  };

  isAllowAssignVehicle() {
    return this.data.isAllowAssignVehicle || !this.data.editMode;
  }

  updateSlide (event) {
    this.form.value[event.type] = event.images;
  }
}
