import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DIALOG_SIZE } from '@app/services/dialog.service';

import { DriverRegistrationModel } from '@app/services/models/driver-registration.model';
import { RejectRegistrationComponent } from '../reject-registration/reject-registration.component';
import { ApproveRegistrationComponent } from '../approve-registration/approve-registration.component';

@Component({
  selector: 'dnf-registration-detail-dialog',
  templateUrl: './registration-detail-dialog.component.html',
  styleUrls: ['./registration-detail-dialog.component.scss', '../driver-detail-dialog/driver-detail-dialog.component.scss']
})
export class RegistrationDetailDialogComponent implements OnInit {
  item: DriverRegistrationModel;
  calendar: any;
  countryName = "";

  constructor(
    public dialogRef: MatDialogRef<RegistrationDetailDialogComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    ngOnInit() {      
      this.calendar = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      this.item = new DriverRegistrationModel(this.data.item);
      this.countryName = this.data.countryName;
      this.getWorkingDaysBinary();
    }

    isWorkingDay(index){
      return this.data.listWorkingDays.charAt(index) == 1;
    }

    getWorkingDaysBinary(){
      let workingDays = this.data.listWorkingDays;
      workingDays = workingDays.toString(2);
      if(workingDays.length < 7){
        let addMoreBit = 7 - workingDays.length;
        for(let i = 0; i < addMoreBit; i++){
          workingDays = "0" + workingDays;
        }
      }
  
      this.data.listWorkingDays = workingDays;
    }

    reject() {
      const dialogReject = this.dialog.open(RejectRegistrationComponent, {
        width: DIALOG_SIZE.default,
        data: { item: this.item }
      });

      dialogReject.afterClosed().subscribe(result => {
        if(result){
          this.dialogRef.close(result);
        }
      });
    }

    approve() {
      const dialogApprove = this.dialog.open(ApproveRegistrationComponent, {
        width: DIALOG_SIZE.default,
        data: { item: this.item }
      });

      dialogApprove.afterClosed().subscribe(result => {
        if(result){
          this.dialogRef.close(result);
        }
      });
    }
}