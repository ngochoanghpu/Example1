import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatDialog,
  MatInput
} from '@angular/material';
import { DriversService } from '@app/services/drivers.service';
import { DriverModel } from '@app/services/models/driver.model';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { LoaderService } from '@app/services/loader.service';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { DriverDetailDialogComponent } from '../components/driver-detail-dialog/driver-detail-dialog.component';
import { DriverFormDialogComponent } from '../components/driver-form-dialog/driver-form-dialog.component';
import { DeactivateDriverComponent } from '../components/deactivate/deactivate.component';
import { ReleaseVehicleComponent } from '../components/release-vehicle/release-vehicle.component';
import { AssignVehicleComponent } from '../components/assign-vehicle/assign-vehicle.component';
import { CountryModel } from '@app/services/models/country.model';
import { Vehicle } from '@app/services/models/vehicle.model';
import { CountriesService } from '@app/services/countries.service';
import { VehiclesService } from '@app/services/vehicles.service';
import { DAYS_OF_WEEK } from '@app/shared/constant';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { DRIVER_DOCUMENTS } from '@app/shared/constant';
import { DocumentsService } from '@app/services/document.service';
import { PermissionService } from '@app/services/permission.service';


@Component({
  selector: 'dnf-driver-list',
  templateUrl: './driver-list.component.html',
  styleUrls: ['./driver-list.component.scss']
})
export class DriverListComponent implements OnInit {
  isLoading = false;
  featureCode = 'DRI';
  displayedColumns: string[] = [
    'avatar',
    'firstName',
    'lastName',
    'phoneNumber',
    'dob',
    'countryId',
    'vehicle',
    'status',
    'actions'
  ];
  dataSource: any;
  countries: Array<CountryModel>;
  vehicles: Array<Vehicle>;
  breadcrumbs = [
    { icon: 'dnf-ic-driver', text: 'LBL_DRIVERS', url: '/drivers/driver-list' },
    { icon: 'flaticon-users', text: 'LBL_DRIVER_LIST' },
  ];
  keyword = '';
  countryId = '';
  status = '';
  workingDays = {};
  selectedDays = '';
  daysOfWeek: string[] = DAYS_OF_WEEK;

  permission = {
    canRead: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false
  };

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  constructor(
    private countriesServive: CountriesService,
    private permissionService: PermissionService,
    private vehiclesService: VehiclesService,
    private driverService: DriversService,
    private loaderService: LoaderService,
    private documentsService: DocumentsService,
    public dialog: MatDialog,
    private translate: TranslateService,
    private toastr: ToastrService,
    private elem: ElementRef
  ) { }

  _getCountries() {
    this.countriesServive.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  }

  getCountry(countryId) {
    const country = this.countries.find(e => e.id === countryId);
    return country ? country.name : '';
  }

  _getAvailableVehicles() {
    this.vehiclesService.getAvailableVehicles().subscribe(vehicles => {
      this.vehicles = vehicles;
    });
  }

  ngOnInit() {
    this._getCountries();
    this._getAvailableVehicles();
    this.permission = this.permissionService._getFeaturePermission(this.featureCode);
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
  }

  _loadItems(firstLoad: boolean = false, isSearch: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
        countryId: this.countryId,
        status: this.status,
        'workingCalendar[workingDays]': this.workingDays ? this.workingDays : '',
      },
      this.sort.direction,
      this.sort.active,
      firstLoad || isSearch ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );
    this.driverService.getDrivers(queryParams).subscribe(drivers => {
      this.paginator.length = drivers.total;
      this.dataSource = new MatTableDataSource<DriverModel>(drivers.results);
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  addItem() {
    this._initDialog();
  }

  viewDetails(id: number): void {
    this.driverService.getDriverDetails(id).subscribe(driver => {
      this._initDocument(driver.documents);
      driver.countryName = this.getCountry(driver.countryId);
      const dialogRef = this.dialog.open(DriverDetailDialogComponent, {
        width: DIALOG_SIZE.medium,
        data: { item: driver }
      });

      dialogRef.afterClosed().subscribe((isEdit) => {
        if (isEdit) {
          this._initDialog(true, driver);
        }
      });
    });
  }

  editItem(id: number): void {
    this.driverService.getDriverDetails(id).subscribe(driver => {
      this._initDialog(true, driver);
    });
  }

  deleteItem(id): void {
    alert('Delete Item: ' + id);
  }

  search() {
    this._loadItems(null, true);
  }

  reset() {
    this.keyword = '';
    this.status = '';
    this.selectedDays = '';
    this.workingDays = {};
    this.countryId = '';
  }


  updateStatus(item: DriverModel) {
    const dialogRef = this.dialog.open(DeactivateDriverComponent, {
      width: DIALOG_SIZE.default,
      data: { editMode: false, item: item }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        // update UI
        this._loadItems();

        // show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_SINGLE_DRIVER'),
            action: this.translate.instant('ACTION_UPDATED')
          })
        );
      }
    });
  }

  releaseVehicle(item: DriverModel) {
    const dialogRef = this.dialog.open(ReleaseVehicleComponent, {
      width: DIALOG_SIZE.default,
      data: { editMode: false, item: item }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        // update UI
        this._loadItems();

        // show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_ACTION_RELEASE_VEHICLE'),
            action: ''
          })
        );
      }
    });
  }

  private _initDialog(editMode = false, item = null) {
    item = item || {};
    item.documents = this._initDocument(item.documents);

    const dialogRef = this.dialog.open(DriverFormDialogComponent, {
      width: DIALOG_SIZE.medium,
      data: { editMode: editMode, item: item, vehicles: this.vehicles, isAllowAssignVehicle: item.status === 1 }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._loadItems();
        this.toastr.success(this.translate.instant(result));
      }

    });
  }

  assignVehicle(driver: DriverModel) {
    const driverName = driver.firstName + ' ' + driver.lastName;
    const dialogRef = this.dialog.open(AssignVehicleComponent, {
      width: DIALOG_SIZE.medium,
      data: { editMode: true, driverName: driverName, driverId: driver.id }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // update UI
        this._loadItems();

        // show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_POPUP_ASSIGN_VEHICLE'),
            action: ''
          })
        );
      }
    });
  }

  onSelectionChange(values: string[]) {
    if (values.length > 0) {
      let strHtml = '';
      let j = 0;
      for (let i = 0; i < values.length; i++) {
        const value = this.translate.instant(values[i]);
        if (i < 2) {
          strHtml += `<span class="dnf-selected-values">${value.substring(0, 3)}</span>`;
        } else {
          j++;
        }
      }
      if (j > 0) {
        strHtml += `<span>+ ${j} </span>`;
      }
      setTimeout(() => {
        const selectedValueList = this.elem.nativeElement.querySelector('#working-calendar .mat-select-value-text') as HTMLElement;
        selectedValueList.children[0].innerHTML = '';
        selectedValueList.children[0].innerHTML = strHtml;
      }, 100);
      values.forEach(v => {
        const day = v.replace('LBL_', '').toLowerCase();
        this.workingDays[day] = true;
      });
    }
  }

  _initDocument(documents: any) {
    if (!documents) {
      documents = {};
    }

    DRIVER_DOCUMENTS.forEach(item => {
      if (!documents[item] || (documents[item] && documents[item].length === 0)) {
        documents[item] = null;
      }
    });

    return documents;
  }

}
