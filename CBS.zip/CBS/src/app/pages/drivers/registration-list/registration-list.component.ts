import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatDialog
} from '@angular/material';
import { DriverRegistrationService } from '@app/services/driver-registration.service';
import { DriverRegistrationModel } from '@app/services/models/driver-registration.model';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { LoaderService } from '@app/services/loader.service';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { RegistrationDetailDialogComponent } from '../components/registration-detail-dialog/registration-detail-dialog.component';
import { RejectRegistrationComponent } from '../components/reject-registration/reject-registration.component';
import { ApproveRegistrationComponent } from '../components/approve-registration/approve-registration.component';
import { CountryModel } from '@app/services/models/country.model';
import { CountriesService } from '@app/services/countries.service';
import { DRIVER_DOCUMENTS } from '@app/shared/constant';
import { DocumentsService } from '@app/services/document.service';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
import { PermissionService } from '@app/services/permission.service';

@Component({
  selector: 'dnf-registration-list',
  templateUrl: './registration-list.component.html',
  styleUrls: ['./registration-list.component.scss']
})
export class RegistrationListComponent implements OnInit {
  featureCode = 'DRI';
  isLoading = false;
  displayedColumns: string[] = [
    'avatar',
    'firstName',
    'lastName',
    'phoneNumber',
    'dob',
    'country',
    'vehicle',
    'registrationDate',
    'status',
    'actions'
  ];
  dataSource: any;
  keyword = '';
  countryId = '';
  typeOfStatusId = '';
  countries: Array<CountryModel>;
  breadcrumbs = [
    { icon: 'dnf-ic-driver', text: 'LBL_DRIVERS', url: '/drivers/driver-list' },
    { icon: 'flaticon-users', text: 'LBL_REGISTRATION_LIST' }
  ];
  permission = {
    canRead: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false
  };
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private countriesServive: CountriesService,
    private driverRegistrationService: DriverRegistrationService,
    private loaderService: LoaderService,
    private documentsService: DocumentsService,
    private translate: TranslateService,
    private toastr: ToastrService,
    public dialog: MatDialog,
    private permissionService: PermissionService,
  ) {}

  _getCountries() {
    this.countriesServive.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  }

  ngOnInit() {
    this.permission = this.permissionService._getFeaturePermission(this.featureCode);
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
    - when a pagination event occurs => this.paginator.page
    - when a sort event occurs => this.sort.sortChange
    **/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
    this._getCountries();
  }

  _loadItems(firstLoad: boolean = false, isSearch: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
        status: this.typeOfStatusId,
        countryId: this.countryId,
      },
      this.sort.direction,
      this.sort.active,
      firstLoad || isSearch ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.driverRegistrationService
      .getRegistrationDrivers(queryParams)
      .subscribe(driverRegistration => {
        this.paginator.length = driverRegistration.total;
        this.dataSource = new MatTableDataSource<DriverRegistrationModel>(driverRegistration.results);
        this.dataSource.sort = this.sort;
        this.loaderService.hide();
      });
  }

  _initDocument(documents: any) {
    if (!documents) {
      documents = {};
    }

    DRIVER_DOCUMENTS.forEach(item => {
      if (!documents[item] || (documents[item] && documents[item].length === 0)) {
        documents[item] = null;
      }
    });

    return documents;
  }

  viewDetails(item): void {
    item.documents = this._initDocument(item.documents);

    const dialogRef = this.dialog.open(RegistrationDetailDialogComponent, {
      width: DIALOG_SIZE.large,
      data: { item: item, countryName: this.getCountry(item.countryId), listWorkingDays: item.workingCalendar.workingDays }
    });

    this.loadItemAgain(dialogRef);
  }

  getCountry(countryId) {
    try {
      const country = this.countries.find(e => e.id === countryId);
      return country ? country.name : '';
    } catch (ex) {
      return '';
    }
  }

  reject(item): void {
    const dialogReject = this.dialog.open(RejectRegistrationComponent, {
      width: DIALOG_SIZE.default,
      data: { item: item }
    });

    this.loadItemAgain(dialogReject);
  }

  approve(item): void {
    const dialogReject = this.dialog.open(ApproveRegistrationComponent, {
      width: DIALOG_SIZE.default,
      data: { item: item }
    });

    this.loadItemAgain(dialogReject);
  }

  loadItemAgain(dialogRef) {
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
          // update UI
          this._loadItems();

          // show toast notify
          this.toastr.success(
            this.translate.instant('MSG_SUCCESSFULLY', {
              item: '',
              action: this.translate.instant(result)
            })
          );
      }
    });
  }

  search(): void {
    this._loadItems(null, true);
  }

  reset(): void {
    this.keyword = '';
    this.typeOfStatusId = '';
    this.countryId = '';
  }
}
