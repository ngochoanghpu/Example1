import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DesignModule } from '@app/shared/design/design.module';

import { DriverDetailDialogComponent } from './components/driver-detail-dialog/driver-detail-dialog.component';
import { RegistrationListComponent } from './registration-list/registration-list.component';
import { DriverListComponent } from './driver-list/driver-list.component';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@app/shared';
import { DocumentSliderComponent } from './components/document-slider/document-slider.component';
import { DriverFormDialogComponent } from './components/driver-form-dialog/driver-form-dialog.component';
import { DeactivateDriverComponent } from './components/deactivate/deactivate.component';
import { ReleaseVehicleComponent } from './components/release-vehicle/release-vehicle.component';
import { RegistrationDetailDialogComponent } from './components/registration-detail-dialog/registration-detail-dialog.component';
import { RejectRegistrationComponent } from './components/reject-registration/reject-registration.component';
import { ApproveRegistrationComponent } from './components/approve-registration/approve-registration.component';
import { AssignVehicleComponent } from './components/assign-vehicle/assign-vehicle.component';
import { AssignConfirmationComponent } from './components/assign-vehicle/assign-confirmation/assign-confirmation.component';
import { DeleteDraftImagesComponent  } from './components/delete-draft-images-dialog/delete-draft-images.component';
import { VehiclesService } from '@app/services/vehicles.service';
import { DocumentsService } from '@app/services/document.service';

@NgModule({
  declarations: [
    DriverListComponent,
    RegistrationListComponent,
    DriverDetailDialogComponent,
    DocumentSliderComponent,
    DriverFormDialogComponent,
    DeactivateDriverComponent,
    ReleaseVehicleComponent,
    RegistrationDetailDialogComponent,
    RejectRegistrationComponent,
    ApproveRegistrationComponent,
    AssignVehicleComponent,
    AssignConfirmationComponent,
    DeleteDraftImagesComponent,
  ],
  imports: [
    CommonModule,
    DesignModule,
    RouterModule.forChild([
      {
        path: '',
        children: [
          {
            path: 'driver-list',
            component: DriverListComponent
          },
          {
            path: 'registration-list',
            component: RegistrationListComponent
          }
        ]
      }
    ]),
    SharedModule
  ],
  providers: [VehiclesService, DocumentsService],
  entryComponents: [
    DriverDetailDialogComponent,
    DriverFormDialogComponent,
    DeactivateDriverComponent,
    ReleaseVehicleComponent,
    RegistrationDetailDialogComponent,
    RejectRegistrationComponent,
    ApproveRegistrationComponent,
    AssignVehicleComponent,
    AssignConfirmationComponent,
    DeleteDraftImagesComponent
  ]
})
export class DriversModule {}
