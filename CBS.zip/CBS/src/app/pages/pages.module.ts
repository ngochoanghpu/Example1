import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PagesRoutingModule } from './pages-routing.module';
import { ErrorPageComponent } from './error-page/error-page.component';
import { PagesComponent } from './pages.component';
import { CoreModule } from '@app/core';
import { SharedModule } from '@app/shared';
import { MessagePageComponent } from './message-page/message-page.component';

@NgModule({
  declarations: [
    ErrorPageComponent,
    PagesComponent,
    MessagePageComponent
  ],
  imports: [CommonModule, PagesRoutingModule, CoreModule, SharedModule]
})
export class PagesModule {}
