import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource } from '@angular/material';
import { LoaderService } from '@app/services/loader.service';
import { EODPayoutService } from '@app/services/eod-payout.service';
import { merge } from 'rxjs';
import { tap } from 'rxjs/internal/operators/tap';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { EODPayoutModel } from '@app/services/models/eod-payout.model';
import { EodPayoutDetailComponent } from '../component/eod-payout-detail/eod-payout-detail.component';
import { DIALOG_SIZE } from '@app/services/dialog.service';

@Component({
  selector: 'dnf-eod-payout',
  templateUrl: './eod-payout.component.html',
  styleUrls: ['./eod-payout.component.scss']
})
export class EodPayoutComponent implements OnInit {

  displayedColumns: string[] = [
    'driver',
    'phoneNo',
    'date',
    'payAmount',
    'payDate',
    'paymentStatus',
    'actions'
  ];
  dataSource: any;

  breadcrumbs = [
    { icon: 'flaticon-interface-11', text: 'LBL_REPORTS' },
    { icon: 'flaticon-coins', text: 'LBL_EOD_PAYOUT' }
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private eodPayoutService: EODPayoutService,
    private loaderService: LoaderService,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {},
      this.sort.direction,
      this.sort.active,
      this.paginator.pageIndex,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.eodPayoutService.getEODPayout(queryParams).subscribe(eodPayout => {
      this.dataSource = new MatTableDataSource<EODPayoutModel>(eodPayout);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  search() {
    alert('Search');
  }

  makePayment() {
    alert('Make Payment');
  }

  paid() {
    alert('Paid');
  }

  viewDetails(item: any) {
    const dialogRef = this.dialog.open(EodPayoutDetailComponent, {
      width: DIALOG_SIZE.xLarge,
      data: { editMode: false, item: item }
    });

    dialogRef.afterClosed().subscribe((isEdit) => {

    });
  }
}
