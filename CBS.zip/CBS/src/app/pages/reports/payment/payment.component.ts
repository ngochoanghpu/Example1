import { Component, OnInit, ViewChild } from '@angular/core';
import { Select2OptionData, Select2TemplateFunction } from 'ng2-select2';
import { TripsService } from '@app/services/trips.service';
import { CountryModel } from '@app/services/models/country.model';
import { CountriesService } from '@app/services/countries.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { LoaderService } from '@app/services/loader.service';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { PaymentModel } from '@app/services/models/payment.model';
import { PaymentService } from '@app/services/payment.service';

@Component({
  selector: 'dnf-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {

  displayedColumns: string[] = [
    'driver',
    'startDateTime',
    'tripId',
    'paymentMethod',
    'preCollect',
    'fare',
    'hdGst',
    'driverGst',
    'commission'
  ];

  driverList: Array<Select2OptionData> = [];
  options: Select2Options;
  countries: Array<CountryModel>;

  dataSource: any;

  breadcrumbs = [
    { icon: 'flaticon-interface-11', text: 'LBL_REPORTS' },
    { icon: 'dnf-ic-payment', text: 'LBL_PAYMENT' }
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private countriesServive: CountriesService,
    private tripService: TripsService,
    private paymentService: PaymentService,
    private loaderService: LoaderService
  ) { }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
    this._getCountries();
    this._getDriverList();
    this.options = {
      templateResult: this.driverListTemplate,
      templateSelection: this.driverSelection,
      placeholder: { id: '', text: 'Select Driver' },
      allowClear: true,
      width: '100%'
    };
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {},
      this.sort.direction,
      this.sort.active,
      this.paginator.pageIndex,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.paymentService.getPayment(queryParams).subscribe(payment => {
      this.dataSource = new MatTableDataSource<PaymentModel>(payment);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  _getCountries() {
    this.countriesServive.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  }

  _getDriverList() {
    this.driverList = this.tripService.getDriverList();
  }

  public driverListTemplate: Select2TemplateFunction = (state: Select2OptionData): JQuery | string => {
    if (!state.id) {
      return state.text;
    }
    let image = '<span class="image"><img class="dnf-avatar--size-default" src="assets/img/ava.png"</span>';
    if (state.additional.image) {
      image = '<span class="image"><img class="dnf-avatar--size-default" onError="this.src=\'assets/img/ava.png\'" src="' + state.additional.image + '"/></span>';
    }
    return jQuery('<span>' + image + ' <span>' + state.text + '</span></span>');
  }

  // function for selection template
  public driverSelection: Select2TemplateFunction = (state: Select2OptionData): JQuery | string => {
    if (!state.id) {
      return state.text;
    }
    return jQuery('<span>' + state.text + '</span>');
  }

  search() { }

  export() { }
}
