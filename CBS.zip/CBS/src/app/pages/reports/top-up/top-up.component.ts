import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource } from '@angular/material';
import { LoaderService } from '@app/services/loader.service';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { TopUpService } from '@app/services/top-up.service';
import { TopUpModel } from '@app/services/models/top-up.model';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { TopUpDetailComponent } from '../component/top-up-detail/top-up-detail.component';

@Component({
  selector: 'dnf-top-up',
  templateUrl: './top-up.component.html',
  styleUrls: ['./top-up.component.scss']
})
export class TopUpComponent implements OnInit {

  displayedColumns: string[] = [
    'driver',
    'phoneNo',
    'date',
    'topupAmount',
    'topupType',
    'paymentStatus',
    'actions'
  ];
  dataSource: any;

  breadcrumbs = [
    { icon: 'flaticon-interface-11', text: 'LBL_REPORTS' },
    { icon: 'dnf-ic-topup', text: 'LBL_TOP_UP' }
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private topupService: TopUpService,
    private loaderService: LoaderService,
    public dialog: MatDialog) { }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {},
      this.sort.direction,
      this.sort.active,
      this.paginator.pageIndex,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.topupService.getTopUp(queryParams).subscribe(topup => {
      this.dataSource = new MatTableDataSource<TopUpModel>(topup);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  search() {
  }

  collect() {
  }

  collected() {
  }

  viewDetails(item: any) {
    const dialogRef = this.dialog.open(TopUpDetailComponent, {
      width: DIALOG_SIZE.medium,
      data: { editMode: false, item: item }
    });

    dialogRef.afterClosed().subscribe((isEdit) => {

    });
  }

}
