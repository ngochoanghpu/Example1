import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { LoaderService } from '@app/services/loader.service';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { TripHistoryService } from '@app/services/trip-history.service';
import { TripHistoryModel } from '@app/services/models/trip-history.model';
import { CountryModel } from '@app/services/models/country.model';
import { CountriesService } from '@app/services/countries.service';
import { Select2OptionData, Select2TemplateFunction } from 'ng2-select2';
import { AVATAR } from '@app/shared/constant';


@Component({
  selector: 'dnf-trip-history',
  templateUrl: './trip-history.component.html',
  styleUrls: ['./trip-history.component.scss']
})
export class TripHistoryComponent implements OnInit {
  displayedColumns: string[] = [
    'driver',
    'endDateTime',
    'pickUp',
    'dropOff',
    'passenger',
    'totalFare',
    'rating',
    'comment'
  ];
  dataSource: any;
  countries: Array<CountryModel>;
  driverList: Array<Select2OptionData> = [];
  options: Select2Options;
  breadcrumbs = [
    { icon: 'flaticon-interface-11', text: 'LBL_REPORTS' },
    { icon: 'flaticon-time-1', text: 'LBL_TRIP_HISTORY' }
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private tripHistoryService: TripHistoryService,
    private loaderService: LoaderService,
    private countriesServive: CountriesService
  ) {}

  _getCountries() {
    this.countriesServive.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
    this._getCountries();
    this._getDriverList();
    this.options = {
      templateResult: this.driverListTemplate,
      templateSelection: this.driverSelection,
      placeholder: { id: '', text: 'Select Driver' },
      allowClear: true,
      width: '100%'
    };
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {},
      this.sort.direction,
      this.sort.active,
      this.paginator.pageIndex,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.tripHistoryService.getTripHistory(queryParams).subscribe(trips => {
      this.dataSource = new MatTableDataSource<TripHistoryModel>(trips);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  search() {}

  reset() {}

  _getDriverList() {
    this.driverList = this.tripHistoryService.getDriverList();
  }

  public driverListTemplate: Select2TemplateFunction = (state: Select2OptionData): JQuery | string => {
    if (!state.id) {
      return state.text;
    }
    const image = `<img class="${AVATAR.SIZE.DEFAULT}" onError="this.src='${
      AVATAR.DEFAULT
    }'" src="${
      state.additional.image ? state.additional.image : AVATAR.DEFAULT
    }"/>`;
    return jQuery(
      `<span class="dnf-avatar">${image} <span>${state.text}</span></span>`
    );
  }

  // function for selection template
  public driverSelection: Select2TemplateFunction = (state: Select2OptionData): JQuery | string => {
    if (!state.id) {
      return state.text;
    }
    return jQuery(`<span>${state.text}</span>`);
  }
}
