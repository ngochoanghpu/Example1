import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DesignModule } from '@app/shared/design/design.module';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@app/shared';
import { EodPayoutComponent } from './eod-payout/eod-payout.component';
import { PaymentComponent } from './payment/payment.component';
import { TopUpComponent } from './top-up/top-up.component';
import { EodPayoutDetailComponent } from './component/eod-payout-detail/eod-payout-detail.component';
import { TopUpDetailComponent } from './component/top-up-detail/top-up-detail.component';
import { TripHistoryComponent } from './trip-history/trip-history.component';

@NgModule({
  declarations: [
    EodPayoutComponent,
    EodPayoutDetailComponent,
    PaymentComponent,
    TopUpComponent,
    TopUpDetailComponent,
    TripHistoryComponent
  ],
  imports: [
    CommonModule,
    DesignModule,
    RouterModule.forChild([
      {
        path: '',
        children: [
          {
            path: 'eod-payout',
            component: EodPayoutComponent
          },
          {
            path: 'payment',
            component: PaymentComponent
          },
          {
            path: 'top-up',
            component: TopUpComponent
          },
          {
            path: 'trip-history',
            component: TripHistoryComponent
          }
        ]
      }
    ]),
    SharedModule
  ],
  entryComponents: [
    EodPayoutDetailComponent,
    TopUpDetailComponent
  ]
})
export class ReportsModule { }
