import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatPaginator, MatSort, MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource } from '@angular/material';
import { TopUpService } from '@app/services/top-up.service';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { TopUpDetailModel } from '@app/services/models/top-up-detail.model';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-top-up-detail',
  templateUrl: './top-up-detail.component.html',
  styleUrls: ['./top-up-detail.component.scss']
})
export class TopUpDetailComponent implements OnInit {

  displayedColumns: string[] = [
    'date',
    'topupAmount',
    'topupType',
    'paymentStatus'
  ];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(public dialogRef: MatDialogRef<TopUpDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private topupService: TopUpService,
    private loaderService: LoaderService) { }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {},
      this.sort.direction,
      this.sort.active,
      this.paginator.pageIndex,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.topupService.getTopUpDetail(queryParams).subscribe(topupDetail => {
      this.dataSource = new MatTableDataSource<TopUpDetailModel>(topupDetail);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

}
