import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { TripsService } from '@app/services/trips.service';
import { TripDetailsModel } from '@app/services/models/trip-details.model';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-eod-payout-detail',
  templateUrl: './eod-payout-detail.component.html',
  styleUrls: ['./eod-payout-detail.component.scss']
})
export class EodPayoutDetailComponent implements OnInit {

  displayedColumns: string[] = [
    'tripId',
    'date',
    'fare',
    'tollFee',
    'airport',
    'earning',
    'commission',
    'hdGst',
    'balance',
    'totalGst',
    'status'
  ];
  dataSource: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(public dialogRef: MatDialogRef<EodPayoutDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private tripService: TripsService,
    private loaderService: LoaderService) { }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {},
      this.sort.direction,
      this.sort.active,
      this.paginator.pageIndex,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.tripService.getTripDetail(queryParams).subscribe(tripDetail => {
      this.dataSource = new MatTableDataSource<TripDetailsModel>(tripDetail);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

}
