import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { REGEX_PATTERN } from '@app/shared/constant';
import { UsersService } from '@app/services/users.service';
import { LoaderService } from '@app/services/loader.service';
import { CountriesService } from '@app/services/countries.service';
import { CountryModel } from '@app/services/models/country.model';
import _ from 'lodash';
import moment from 'moment';
import { DATETIME_FORMAT } from '@app/shared/constant';
import { SpacesValidator } from '../../../../core/validators/spaces-validator';

@Component({
  selector: 'dnf-user-form-dialog',
  templateUrl: './user-form-dialog.component.html',
  styleUrls: ['./user-form-dialog.component.scss']
})
export class UserFormDialogComponent implements OnInit {

  form: FormGroup;
  item: any;
  roles: any[];
  countries: Array<CountryModel>;

  constructor(
    private fb: FormBuilder,
    private userService: UsersService,
    private loaderService: LoaderService,
    private countryService: CountriesService,
    public dialogRef: MatDialogRef<UserFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    dialogRef.disableClose = true;
  }

  ngOnInit() {
    this._getCountries();
    this._triggerUploadFileInput();
    this.item = this.data.item || {};
    this.roles = this.data.roles;
    const userRoles = [];
    if (this.item.roles && this.item.roles.length > 0) {
      this.item.roles.forEach(role => {
        userRoles.push(role.id);
      });
    }
    this.form = this.fb.group({
      id: this.item._id,
      firstName: [this.item.firstName, [SpacesValidator]],
      lastName: [this.item.lastName, [SpacesValidator]],
      email: [this.item.email, Validators.pattern(REGEX_PATTERN.EMAIL)],
      phoneCode: this.item.phoneCode,
      phoneNumber: this.item.phoneNumber,
      dob: this.item.dob,
      countryId: this.item.countryId,
      roles: [userRoles]
    });

    if (this.data.editMode) {
      this.form.controls['email'].disable();
    }
  }

  _getCountries(): void {
    this.countryService.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  }

  save() {
    this.loaderService.show();
    if ($('#upload-avt-input').val()) {
      this.form.value.avatar = this.item.profileImage;
    }
    else if(!this.item.profileImage) {
      this.form.value.avatar = null;
    }

    this.form.value.dob = moment(this.form.value.dob).format(DATETIME_FORMAT.DEFAULT_DATE);
    this.form.value.email = this.data.editMode ? this.item.email : this.form.value.email;    

    if (!this.item.id) {
      return this.userService.createUser(
        _.omit(this.form.value, ['id'])
      ).subscribe(resp => {
        this.loaderService.hide();
        this.dialogRef.close(true);
      });
    }
    this.userService.updateUser(this.item.id,
      _.omit(this.form.value, ['id', 'email']),
    ).subscribe(resp => {
      this.loaderService.hide();
      this.dialogRef.close(true);
    });

  }

  deleteAvatar(image){
    this.item.profileImage  = null;    
    $('#upload-avt-input').val(null);
  }

  _triggerUploadFileInput() {
    $('#upload-avt').click(function () {
      $('#upload-avt-input').click();
    });
  }

  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = _event => {
        this.item.profileImage = reader.result;
      };
    }
  }

  cancel() {
    this.dialogRef.close();
  }

  _getDataItem() {
    // TODO
    return this.data.item;
  }

  hasError(field, type) {
    return this.form.get(field).hasError(type);
  }

  getPhoneCode (event) {
    this.form.value.phoneCode = event;
  }
}
