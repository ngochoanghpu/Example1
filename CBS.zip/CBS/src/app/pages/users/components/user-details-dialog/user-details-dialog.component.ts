import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'dnf-user-details-dialog',
  templateUrl: './user-details-dialog.component.html',
  styleUrls: ['./user-details-dialog.component.scss']
})
export class UserDetailsDialogComponent implements OnInit {

  item: any;
  roles: any;

  constructor(
    public dialogRef: MatDialogRef<UserDetailsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    dialogRef.disableClose = true;
  }

  listCountry: any = ['', 'Việt Nam', 'Singapore'];

  ngOnInit() {
    this.item = {
      ...this.data.item,
      countryName: this.listCountry[this.data.item.countryId || 0],
    };
    this.roles = this.data.roles;
  }

  _getDataItem() {
    // TODO
    return this.data.item;
  }

  edit() {
    this.dialogRef.close(true);
  }

}
