import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { UsersService } from '@app/services/users.service';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-delete-users-dialog',
  templateUrl: './delete-users-dialog.component.html',
  styleUrls: ['./delete-users-dialog.component.scss']
})
export class DeleteUsersDialogComponent implements OnInit {

  constructor(
    private toastr: ToastrService,
    private translate: TranslateService,
    private userService: UsersService,
    private loaderService: LoaderService,
    public dialogRef: MatDialogRef<DeleteUsersDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    dialogRef.disableClose = true;
  }

  ngOnInit() {}

  delete() {
    this.loaderService.show();
    
    this.userService.deleteUser(this.data.id).subscribe(() => {
      this.loaderService.hide();
      this.dialogRef.close(true);
    });
  }

}
