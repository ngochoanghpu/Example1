import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatDialog,
  MatInput
} from '@angular/material';
import { UsersService } from '@app/services/users.service';
import { UserModel } from '@app/services/models/user.model';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { LoaderService } from '@app/services/loader.service';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { UserFormDialogComponent } from './components/user-form-dialog/user-form-dialog.component';
import { UserDetailsDialogComponent } from './components/user-details-dialog/user-details-dialog.component';
import { TranslateService } from '@ngx-translate/core';
import { RolesService } from '@app/services/roles.service';
import { ToastrService } from 'ngx-toastr';
import { DeleteUsersDialogComponent } from '@app/pages/users/components/delete-users-dialog/delete-users-dialog.component';
import { ConfirmDialogComponent } from '../../shared/design/confirm-dialog/confirm-dialog.component';
import { STATUS_ENUM } from '@app/shared/constant';

@Component({
  selector: 'dnf-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  keyword = '';
  isLoading = false;
  displayedColumns: string[] = [
    'firstName',
    'lastName',
    'email',
    'phoneNumber',
    'role',
    'status',
    'actions'
  ];
  dataSource: any;
  breadcrumbs = [
    { icon: 'flaticon-settings', text: 'LBL_SETTINGS' },
    { icon: 'flaticon-user', text: 'LBL_ADMIN_USERS' }
  ];
  
  selectedRole: any = [];
  selectedStatus: any = '';
  listRoles = [];
  userStatus = [
    { id: '', name: 'All Status' },
    { id: 1, name: 'Active' },
    { id: 2, name: 'Inactive' }
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  self: any;

  constructor(
    private userService: UsersService,
    private rolesService: RolesService,
    private loaderService: LoaderService,
    public dialog: MatDialog,
    private toastr: ToastrService,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this.rolesService.getAllRole().subscribe((roles: any) => {
      this.listRoles = roles;
    });

    this._loadItems(true);
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
        status: this.selectedStatus,
        roles: this.selectedRole
      },
      this.sort.direction,
      this.sort.active || 'firstName',
      firstLoad ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.userService.getUsers(queryParams).subscribe((data: any) => {
      this.paginator.length = data.total;
      if (data.results) {
        data.results.forEach(user => {
          return user.role = user.roles.map(role => role.name).join(', ');
        });
        this.dataSource = new MatTableDataSource<UserModel>(data.results);
        this.dataSource.sortingDataAccessor = (item: any, property: any) => {
          switch (property) {
            case 'firstName':
              return item.firstName.toLowerCase();
            case 'lastName':
              return item.lastName.toLowerCase();
            default:
              return item[property];
          }
        };
        this.dataSource.sort = this.sort;
      }
      this.loaderService.hide();
    });
  }

  addItem() {
    this._initDialog();
  }

  editItem(item): void {
    this._initDialog(true, item);
  }

  _initDialog(editMode = false, item = null) {
    const dialogRef = this.dialog.open(UserFormDialogComponent, {
      width: DIALOG_SIZE.medium,
      data: { editMode: editMode, item: item, roles: this.listRoles }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._loadItems();
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_USER'),
            action: editMode ? this.translate.instant('ACTION_UPDATED') : this.translate.instant('ACTION_CREATED')
          })
        );
      }
    });
  }

  deleteItem(id): void {    
        const dialogRef = this.dialog.open(DeleteUsersDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { id }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._loadItems();
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_USER'),
            action: this.translate.instant('ACTION_DELETED')
          })
        );
      }
    });
  }

  viewDetails(item): void {
    const dialogRef = this.dialog.open(UserDetailsDialogComponent, {
      width: DIALOG_SIZE.medium,
      data: { item: item, roles: this.listRoles }
    });

    dialogRef.afterClosed().subscribe((isEdit) => {
      if (isEdit) {
        this.editItem(item);
      }
    });
  }

  changeStatus(obj){
    obj.self.loaderService.show();

    obj.self.userService.updateUser(obj.item.id, {
      status: obj.status,
    }).subscribe((data: any) => {      
      obj.self._loadItems();    
      obj.self.toastr.success(
        obj.self.translate.instant('MSG_SUCCESSFULLY', {
          item: obj.self.translate.instant('LBL_USER'),
          action: obj.status === STATUS_ENUM.ACTIVE ? obj.self.translate.instant('LBL_ACTION_ACTIVE').toLowerCase() : obj.self.translate.instant('LBL_ACTION_DEACTIVE').toLowerCase()
        })
      );  
    });
  }

  showDialogChangeStatus(item, status): void {
    let action = status === STATUS_ENUM.ACTIVE ? this.translate.instant('LBL_ACTION_ACTIVE').toLowerCase() : this.translate.instant('LBL_ACTION_DEACTIVE').toLowerCase();
    const content = this.translate.instant('LBL_COMFIRM_ACTION', {
      action: `${action} ${this.translate.instant('LBL_COMFIRM_ACTION_THIS_USER')}`, 
    });

    let data = { item, status, self: this };
    
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { content, data, callback: this.changeStatus, self: this }
    });    
  }

  search() {
    this._loadItems(true);
  }

  reset() {
    this.keyword = '';
    this.selectedStatus = '';
    this.selectedRole = '';
  }
}