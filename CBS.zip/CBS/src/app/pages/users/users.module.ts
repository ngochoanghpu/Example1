import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersComponent } from './users.component';
import { UserFormDialogComponent } from './components/user-form-dialog/user-form-dialog.component';
import { DesignModule } from '@app/shared/design/design.module';
import { RouterModule } from '@angular/router';
import { UserDetailsDialogComponent } from './components/user-details-dialog/user-details-dialog.component';
import { DeleteUsersDialogComponent } from './components/delete-users-dialog/delete-users-dialog.component';
import { ConfirmDialogComponent } from '../../shared/design/confirm-dialog/confirm-dialog.component';

@NgModule({
  declarations: [UsersComponent, UserFormDialogComponent, UserDetailsDialogComponent, DeleteUsersDialogComponent],
  imports: [
    CommonModule,
    DesignModule,
    RouterModule.forChild([
      {
        path: '',
        component: UsersComponent
      }
    ])
  ],
  entryComponents: [UserFormDialogComponent, UserDetailsDialogComponent, DeleteUsersDialogComponent, ConfirmDialogComponent]
})
export class UsersModule {}
