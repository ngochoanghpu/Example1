import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SettingsService } from '@app/services/settings.service';
import { MatDialog } from '@angular/material';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { GeneralDialogComponent } from '../../components/general-form-dialog/general-form-dialog.component'
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { SETTINGS } from '@app/shared/constant'

@Component({
  selector: 'dnf-general-form',
  templateUrl: './general-form.component.html',
  styleUrls: ['../../generals.component.scss']
})
export class GeneralFormComponent implements OnInit {
  form: FormGroup;
  originSettings: any;

  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private toastr: ToastrService,
    private translate: TranslateService,
    private settingService: SettingsService) { }

  ngOnInit() {
    this.form = this.fb.group({
      autoRefreshTime: null,
      smsEmail: null,
      landingPageUrl: null
    });

    this.settingService.getGeneralSettings().subscribe(settings => {
      this.originSettings = settings;
      this.loadData(settings);
    });
  }

  loadData(settings) {
    this.form.controls['autoRefreshTime'].setValue(settings.autoRefreshTime);
    this.form.controls['smsEmail'].setValue(settings.emailForSendingSMSTo);
    this.form.controls['landingPageUrl'].setValue(settings.driverSigningUpLandingPageURL);
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  save(): void {
    let formData = this.form.value;
    let mode = SETTINGS.General.toString();

    const dialogRef = this.dialog.open(GeneralDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { formData, mode }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        //show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_GENERAL_SETTINGS'),
            action: this.translate.instant('ACTION_UPDATED')
          })
        );
      }
    });
  }

  cancel(): void {
    this.loadData(this.originSettings);
  }
}
