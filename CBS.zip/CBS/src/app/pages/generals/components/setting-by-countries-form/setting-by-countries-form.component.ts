import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SettingsService } from '@app/services/settings.service';
import { SETTINGS } from '@app/shared/constant';
import { MatDialog } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { GeneralDialogComponent } from '../../components/general-form-dialog/general-form-dialog.component';

@Component({
  selector: 'dnf-setting-by-countries-form',
  templateUrl: './setting-by-countries-form.component.html',
  styleUrls: ['../../generals.component.scss']
})
export class SettingByCountriesFormComponent implements OnInit {
  form: FormGroup;
  countriesSettings: any;
  originSettings: any;

  constructor(private fb: FormBuilder, 
              private settingService: SettingsService,
              private dialog: MatDialog,
              private toastr: ToastrService,
              private translate: TranslateService,
              )
              { }

  ngOnInit() {
    this.form = this.fb.group({
      countryName: null,
      cancellationFee: null,
      gst: null,
      warningLimit: null,
      depositLockCash: null,
      warningLimitSendSMS: null,
      depositLockCashSendSMS: null
    });

    this.settingService.getSettingsByCountries().subscribe(settings => {
      this.originSettings = settings;
      this.loadData(settings);
    });
  }

  loadData(settings){
    this.form.controls['countryName'].setValue(settings.country);
    this.form.controls['cancellationFee'].setValue(settings.cancellationFeeBookingNow);
    this.form.controls['gst'].setValue(settings.gts);
    this.form.controls['warningLimit'].setValue(settings.warningLimit);
    this.form.controls['depositLockCash'].setValue(settings.depositLockCashBookingLimit);
    this.form.controls['warningLimitSendSMS'].setValue(settings.warningLimitSendSMS);
    this.form.controls['depositLockCashSendSMS'].setValue(settings.depositLockCashSendSMS);
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  save(): void {
    let formData = this.form.value;
    let mode = SETTINGS.SettingByCountries.toString();

    const dialogRef = this.dialog.open(GeneralDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { formData, mode }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        //show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_GENERAL_SETTING_BY_COUNTRIES'),
            action: this.translate.instant('ACTION_UPDATED')
          })
        );
      }
    });
  }

  cancel(): void {
    this.loadData(this.originSettings);
  }
}
