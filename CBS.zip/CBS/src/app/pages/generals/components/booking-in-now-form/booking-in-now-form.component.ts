import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { SettingsService } from '@app/services/settings.service';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { GeneralDialogComponent } from '../../components/general-form-dialog/general-form-dialog.component';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { MatDialog } from '@angular/material';
import { SETTINGS } from '@app/shared/constant';

@Component({
  selector: 'dnf-booking-in-now-form',
  templateUrl: './booking-in-now-form.component.html',
  styleUrls: ['../../generals.component.scss']
})
export class BookingInNowFormComponent implements OnInit {
  form: FormGroup;
  config: any;
  originSettings: any;

  constructor(private fb: FormBuilder, 
             private settingService: SettingsService,            
             private dialog: MatDialog,
             private toastr: ToastrService,
             private translate: TranslateService,
             ){ }

  ngOnInit() {
    this.form = this.fb.group({
      receiveBookingRequestTime: null,
      bookingInNowRadius1st: null,
      bookingInNowRadius2nd: null,
      bookingInNowTime1st: null,
      bookingInNowTime2nd: null
    });

    this.settingService.getBookingInNowSettings().subscribe(settings => {
      this.originSettings = settings;
      this.loadData(settings);
    });
  }

  loadData(settings){
    this.form.controls['receiveBookingRequestTime'].setValue(settings.receivingBookingRequestTime);
    this.form.controls['bookingInNowRadius1st'].setValue(settings.bookingInNowRadius[0]);
    this.form.controls['bookingInNowRadius2nd'].setValue(settings.bookingInNowRadius[1]);
    this.form.controls['bookingInNowTime1st'].setValue(settings.bookingInNowTime[0]);
    this.form.controls['bookingInNowTime2nd'].setValue(settings.bookingInNowTime[1]);
  }

  hasError = (field: string, type: string) =>
    this.form.get(field).hasError(type);

  save(): void {
    let formData = this.form.value;
    let mode = SETTINGS.BookingInNow.toString();

    const dialogRef = this.dialog.open(GeneralDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { formData, mode }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        //show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_GENERAL_BOOKING_IN_NOW'),
            action: this.translate.instant('ACTION_UPDATED')
          })
        );
      }
    });
  }

  cancel(): void {
    this.loadData(this.originSettings);
  }
}
