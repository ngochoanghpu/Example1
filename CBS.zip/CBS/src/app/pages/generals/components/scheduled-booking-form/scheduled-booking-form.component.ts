import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { SettingsService } from '@app/services/settings.service';
import { SETTINGS } from '@app/shared/constant';
import { MatDialog } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { GeneralDialogComponent } from '../../components/general-form-dialog/general-form-dialog.component';

@Component({
  selector: 'dnf-scheduled-booking-form',
  templateUrl: './scheduled-booking-form.component.html',
  styleUrls: ['../../generals.component.scss']
})
export class ScheduledBookingFormComponent implements OnInit {
  form: FormGroup;
  scheduleBookingConfig: any;
  originSettings: any;

  constructor(private fb: FormBuilder, 
             private settingService: SettingsService,
             private dialog: MatDialog,
             private toastr: ToastrService,
             private translate: TranslateService,
             ){ }

  ngOnInit() {
    this.form = this.fb.group({
      receivingBookingRequestTime: null,
      scheduledBookingRadius1st: null,
      scheduledBookingRadius2nd: null,
      scheduledBookingTime1st: null,
      scheduledBookingTime2nd: null,
      allowedTimeForCreatingBooking1st: null,
      reminderTime1st: null,
      cancellationFeePeriod1st: null,
      cancellationFee1st: null,
      allowedTimeForMakingContact1st: null,
      timeoutForMigration1st: null
    });

    this.settingService.getScheduleBookingSettings().subscribe(settings => {
      this.originSettings = settings;
      this.loadData(settings);
    });
  }

  loadData(settings){
    this.form.controls['receivingBookingRequestTime'].setValue(settings.receivingBookingRequestTime);
    this.form.controls['scheduledBookingRadius1st'].setValue(settings.scheduledBookingRadius[0]);
    this.form.controls['scheduledBookingRadius2nd'].setValue(settings.scheduledBookingRadius[1]);
    this.form.controls['scheduledBookingTime1st'].setValue(settings.scheduledBookingTime[0]);
    this.form.controls['scheduledBookingTime2nd'].setValue(settings.scheduledBookingTime[1]);
    this.form.controls['allowedTimeForCreatingBooking1st'].setValue(settings.allowedTimeForCreatingScheduledBooking);
    this.form.controls['reminderTime1st'].setValue(settings.reminderTimeOfScheduledBooking);
    this.form.controls['cancellationFeePeriod1st'].setValue(settings.applyingCancellationFeePeriod);
    this.form.controls['cancellationFee1st'].setValue(settings.cancellationFee);
    this.form.controls['allowedTimeForMakingContact1st'].setValue(settings.allowedTimeForMakingContact);
    this.form.controls['timeoutForMigration1st'].setValue(settings.timeOutForMigrationBookingRequest);
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  save(): void {
    let formData = this.form.value;
    let mode = SETTINGS.ScheduledBooking.toString();

    const dialogRef = this.dialog.open(GeneralDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { formData, mode }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        //show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_GENERAL_SCHEDULED_BOOKING'),
            action: this.translate.instant('ACTION_UPDATED')
          })
        );
      }
    });
  }

  cancel(): void {
    this.loadData(this.originSettings);
  }
}
