import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { SettingsService } from '@app/services/settings.service';
import { SETTINGS } from '@app/shared/constant'

@Component({
  selector: 'dnf-general-dialog',
  templateUrl: './general-form-dialog.component.html'
})
export class GeneralDialogComponent implements OnInit {
  item: any = {};
  constructor(
    private settingsService: SettingsService,
    public dialogRef: MatDialogRef<GeneralDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    dialogRef.disableClose = true;
  }

  ngOnInit() {
    this.convertData(this.data.mode);
  }

  convertData(mode: string) {
    switch (mode) {
      case SETTINGS.General.toString(): {
        this.item.autoRefreshTime = parseInt(this.data.formData.autoRefreshTime) || null;
        this.item.emailForSendingSMSTo = this.data.formData.smsEmail || null;
        this.item.driverSigningUpLandingPageURL = this.data.formData.landingPageUrl || null;
        break;
      }
      case SETTINGS.BookingInNow.toString(): {
        this.item.receivingBookingRequestTime = parseInt(this.data.formData.receiveBookingRequestTime) || null;
        this.item.bookingInNowRadius = [this.data.formData.bookingInNowRadius1st, this.data.formData.bookingInNowRadius2nd];
        this.item.bookingInNowTime = [this.data.formData.bookingInNowTime1st, this.data.formData.bookingInNowTime2nd];
        break;
      }
      case SETTINGS.ScheduledBooking.toString(): {
        this.item.receivingBookingRequestTime = parseInt(this.data.formData.receivingBookingRequestTime) || null;
        this.item.scheduledBookingRadius = [this.data.formData.scheduledBookingRadius1st, this.data.formData.scheduledBookingRadius2nd];
        this.item.scheduledBookingTime = [this.data.formData.scheduledBookingTime1st, this.data.formData.scheduledBookingTime2nd];
        this.item.allowedTimeForCreatingScheduledBooking = parseInt(this.data.formData.allowedTimeForCreatingBooking1st) || null;
        this.item.reminderTimeOfScheduledBooking = parseInt(this.data.formData.reminderTime1st) || null;
        this.item.applyingCancellationFeePeriod = parseInt(this.data.formData.cancellationFeePeriod1st) || null;
        this.item.cancellationFee = parseInt(this.data.formData.cancellationFee1st) || null;
        this.item.allowedTimeForMakingContact = parseInt(this.data.formData.allowedTimeForMakingContact1st) || null;
        this.item.timeOutForMigrationBookingRequest = parseInt(this.data.formData.timeoutForMigration1st) || null;
        break;
      }
      case SETTINGS.SettingByCountries.toString(): {
        this.item.country = this.data.formData.countryName || null;
        this.item.cancellationFeeBookingNow =  parseInt(this.data.formData.cancellationFee) || null;
        this.item.gts = parseInt(this.data.formData.gst) || null;
        this.item.warningLimit = parseInt(this.data.formData.warningLimit) || null;
        this.item.depositLockCashBookingLimit = parseInt(this.data.formData.depositLockCash) || null;
        this.item.warningLimitSendSMS = this.data.formData.warningLimitSendSMS || false;
        this.item.depositLockCashSendSMS = this.data.formData.depositLockCashSendSMS || false;
        break;
      }
    }
  }

  save() {
    this.settingsService.updateGeneral(this.item, this.data.mode).subscribe(() => {
      this.dialogRef.close(true);
    });
  }
}
