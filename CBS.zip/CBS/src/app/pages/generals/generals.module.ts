import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatListModule } from '@angular/material';

import { DesignModule } from '@app/shared/design/design.module';
import { GeneralsComponent } from './generals.component';
import { SharedModule } from '@app/shared';
import { GeneralFormComponent } from './components/general-form/general-form.component';
import { BookingInNowFormComponent } from './components/booking-in-now-form/booking-in-now-form.component';
import { ScheduledBookingFormComponent } from './components/scheduled-booking-form/scheduled-booking-form.component';
import { SettingByCountriesFormComponent } from './components/setting-by-countries-form/setting-by-countries-form.component';
import { GeneralDialogComponent } from '../../pages/generals/components/general-form-dialog/general-form-dialog.component';


@NgModule({
  declarations: [
    GeneralsComponent,
    GeneralFormComponent,
    BookingInNowFormComponent,
    ScheduledBookingFormComponent,
    SettingByCountriesFormComponent,
    GeneralDialogComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {
        path: '',
        component: GeneralsComponent
      }
    ]),
    SharedModule,
    DesignModule,
    MatListModule
  ],
  entryComponents: [GeneralDialogComponent]
})
export class GeneralsModule {}
