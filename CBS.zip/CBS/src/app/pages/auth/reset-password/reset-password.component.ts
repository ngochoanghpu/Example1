import { Component, OnInit, HostBinding } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from '@app/services/auth.service';
import { SuccessMessage, ErrorMessage } from '@app/shared/constant/message';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { REGEX_PATTERN } from '@app/shared/constant';
import { ErrorStateMatcher } from '@angular/material/core';
import { LoaderService } from '@app/services/loader.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl): boolean {
    let confirmNewPassword = control.parent.get('confirmNewPassword');
    if(confirmNewPassword.touched && (confirmNewPassword.hasError("required") || confirmNewPassword.hasError("pattern"))){
      return true;
    }

    let newPassword = control.parent.get('newPassword');
    return (confirmNewPassword.value && newPassword.value !== confirmNewPassword.value && control.dirty)
  }
}

@Component({
  selector: 'dnf-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  @HostBinding('class') classes = 'dnf-auth';

  private data: any = {};
  public model: any = {};
  form: FormGroup;
  matcher = new MyErrorStateMatcher();

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,
    private toastr: ToastrService,
    private loaderService: LoaderService,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(data => {
      this.data.code = data['code'] || '';
      this.data.id = data['id'] || '';
    });

    this.form = this.fb.group({      
      newPassword: [null, Validators.pattern(REGEX_PATTERN.PASSWORD)],
      confirmNewPassword: [null, Validators.pattern(REGEX_PATTERN.PASSWORD)],
    },{ validator: this.checkPasswords });
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  submit() {
    this.loaderService.show(); 
    this.authService.resetPassword({
      ...this.data,
      password: this.form.value.newPassword,
    })
      .subscribe(() => {
        this.toastr.success(this.translate.instant(SuccessMessage.RESET_PASSWORD_SUCCESS,
          {}));
          this.loaderService.hide();   
        this.router.navigate(['/login']);
      });
  }

  checkPasswords(group: FormGroup) {
    let newPassword = group.controls.newPassword.value;
    let confirmNewPassword = group.controls.confirmNewPassword.value;
    return newPassword == confirmNewPassword ? null : { notMatch: true };
  }
}
