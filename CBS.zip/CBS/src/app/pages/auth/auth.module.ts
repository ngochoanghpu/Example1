import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { AuthNoticeComponent } from './auth-notice/auth-notice.component';
import { DesignModule } from '@app/shared/design/design.module';
import { RouterModule } from '@angular/router';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

@NgModule({
  declarations: [LoginComponent, AuthNoticeComponent, ForgotPasswordComponent, ResetPasswordComponent],
  imports: [
    CommonModule,
    DesignModule,
    RouterModule.forChild([
      {
        path: '',
        children: [
          {
            path: 'login',
            component: LoginComponent
          },
          {
            path: 'forgot-password',
            component: ForgotPasswordComponent
          },
          {
            path: 'reset-password',
            component: ResetPasswordComponent
          }
        ]
      }
    ])
  ]
})
export class AuthModule { }
