import { Component, OnInit, HostBinding } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService} from '@app/services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { ErrorMessage } from '@app/shared/constant/message';
import { FormGroup, FormBuilder} from '@angular/forms';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  @HostBinding('class') classes = 'dnf-auth';

  public model: any = { email: ''};
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private toastr: ToastrService,
    private loaderService: LoaderService,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    this.form = this.fb.group({      
      email: null   
    });
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  submit() {
    this.loaderService.show();

    this.authService.forgotPassword(this.form.value.email)
      .subscribe(() => {
        this.loaderService.hide();
        this.router.navigate(['/message']);
      });
  }
}