import {
  Component,
  OnInit,
  Input,
  Output,
  OnDestroy,
  HostBinding
} from '@angular/core';
import { Subject } from 'rxjs';
import { AuthNoticeService } from '@app/core/auth/auth-notice.service';
import { AuthService } from '@app/services/auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { ErrorMessage } from '@app/shared/constant/message';
import { CONSTANTS } from '@app/shared/constant';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit, OnDestroy {
  @HostBinding('class') classes = 'dnf-auth';

  @Output() actionChange = new Subject<string>();
  @Input() action: string;

  public model: any = { email: '', password: '' };
  private returnUrl: string;

  constructor(
    public authNoticeService: AuthNoticeService,
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,
    private toastr: ToastrService,
    private translate: TranslateService,
    private loaderService: LoaderService,
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(data => {
      this.returnUrl = data['returnUrl'] || '';
    });

    localStorage.clear();
  }

  ngOnDestroy(): void {
    this.authNoticeService.setNotice(null);
  }

  submit() {

    const errorCode = _checkValidate(this.model);

    if (errorCode) {
      return this.toastr.error(this.translate.instant(errorCode,
        {}));
    }

    this.loaderService.show();

    this.authService.login(this.model.email, this.model.password)
      .subscribe((userInfo: any) => {
        this.loaderService.hide();
        if (userInfo) {
          localStorage.setItem(CONSTANTS.LOCAL_STORAGE.USER_PROFILE, JSON.stringify(userInfo));
          if (this.returnUrl) {
            return this.router.navigateByUrl(this.returnUrl);
          }
          return this.router.navigate(['/']);
        }
      });
  }
}

const _checkValidate = (model) => {
  if (!model.email || !model.password) {
    return ErrorMessage.INVALID_PARAMETER;
  }
  return null;
};
