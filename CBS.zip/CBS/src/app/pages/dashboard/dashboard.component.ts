import { Component, OnInit } from '@angular/core';
import { DriverGrowthChartService } from '@app/services/driver-grow-chart.service';
import { RevenueGrowthChartService } from '@app/services/revenue-grow-chart.service';
import { RiderGrowthChartService } from '@app/services/rider-grow-chart.service';
import { TripGrowthChartService } from '@app/services/trip-grow-chart.service';

@Component({
  selector: 'dnf-dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {
  donutChartTripStatusData = {
    element: 'donut-chart-region-for-trip',
    colors: ['#f4516c', '#00c5dc', '#5867dd'],
    data: [
      { value: 20, label: 'Completed' },
      { value: 30, label: 'Cancelled' },
      { value: 50, label: 'On Going' }
    ],
    // formatter: function (x) { return x + '%'; },
    resize: true
  };

  donutChartProfitData = {
    element: 'donut-chart-region-for-profit',
    colors: ['#efbb3f', '#6f6cc6'],
    data: [{ value: 50, label: 'Company' }, { value: 50, label: 'Driver' }],
    // formatter: function (x) { return x + '%'; },
    resize: true
  };

  donutChartCurrentDriverStatusData = {
    element: 'donut-chart-region-for-driver-status',
    colors: ['#5bc8a0', '#d7616e', '#716aca'],
    data: [
      { value: 20, label: 'On Trip' },
      { value: 50, label: 'Offline' },
      { value: 30, label: 'Online' }
    ],
    // formatter: function (x) { return x + '%'; },
    resize: true
  };

  donutChartCurrentPaymentStatusData = {
    element: 'donut-chart-region-for-payment-status',
    colors: ['#d7616e', '#6cc1da'],
    data: [
      { value: 63, label: 'Credit Card' },
      { value: 37, label: 'Cash' }
    ],
    // formatter: function (x) { return x + '%'; },
    resize: true
  };

  donutChartTripTimeVarianceData = {
    element: 'donut-chart-region-for-trip-time-variance',
    colors: ['#efa48d', '#6f6cc6', '#6cc1da'],
    data: [
      { value: 63, label: 'Early' },
      { value: 30, label: 'On time' },
      { value: 7, label: 'Late' }
    ],
    // formatter: function (x) { return x + '%'; },
    resize: true
  };

  dataByWeek = [
    {
      name: 'Khoa Nguyen 01',
      star: 5,
      avatar: 'user-1.jpg',
      total: 65000
    },
    {
      name: 'Khoa Nguyen 02',
      star: 5,
      avatar: 'user-1.jpg',
      total: 62000
    },
    {
      name: 'Khoa Nguyen 03',
      star: 4,
      avatar: 'user-1.jpg',
      total: 61000
    },
    {
      name: 'Khoa Nguyen 04',
      star: 3,
      avatar: 'user-1.jpg',
      total: 53000
    },
    {
      name: 'Khoa Nguyen 05',
      star: 2,
      avatar: 'user-1.jpg',
      total: 52000
    }
  ];

  dataByMonth = [
    {
      name: 'Phat Le 01',
      star: 5,
      avatar: 'user-1.jpg',
      total: 6000
    },
    {
      name: 'Phat Le 02',
      star: 5,
      avatar: 'user-1.jpg',
      total: 600
    },
    {
      name: 'Phat Le 03',
      star: 4,
      avatar: 'user-1.jpg',
      total: 60
    },
    {
      name: 'Phat Le 04',
      star: 3,
      avatar: 'user-1.jpg',
      total: 50
    },
    {
      name: 'Phat Le 05',
      star: 2,
      avatar: 'user-1.jpg',
      total: 20
    }
  ];

  dataByYear = [
    {
      name: 'Nam Nguyen 01',
      star: 1,
      avatar: 'user-1.jpg',
      total: 500
    },
    {
      name: 'Nam Nguyen 02',
      star: 2,
      avatar: 'user-1.jpg',
      total: 450
    },
    {
      name: 'Nam Nguyen 03',
      star: 5,
      avatar: 'user-1.jpg',
      total: 400
    },
    {
      name: 'Nam Nguyen 04',
      star: 5,
      avatar: 'user-1.jpg',
      total: 350
    },
    {
      name: 'Nam Nguyen 05',
      star: 5,
      avatar: 'user-1.jpg',
      total: 300
    }
  ];

  config = {
    element: '',
    data: null,
    xkey: null,
    ykeys: null,
    labels: [],
    fillOpacity: 0.6,
    hideHover: 'auto',
    behaveLikeLine: true,
    postUnits: null,
    pointFillColors: [],
    pointStrokeColors: [],
    lineColors: [],
    axes: false,
    grid: false,
    resize: true
  };

  // Must be clone to another object
  revenueGrowthChartConfig = Object.assign({}, this.config);
  driverGrowthChartConfig = Object.assign({}, this.config);
  riderGrowthChartConfig = Object.assign({}, this.config);
  tripGrowthChartConfig = Object.assign({}, this.config);
  chartHeight = '300px';

  constructor(
    public driverGrowthChartService: DriverGrowthChartService,
    public revenueGrowthChartService: RevenueGrowthChartService,
    public riderGrowthChartService: RiderGrowthChartService,
    public tripGrowthChartService: TripGrowthChartService
  ) {}

  ngOnInit() {
    // For Revenue Growth Area chart
    this.revenueGrowthChartConfig.xkey = 'y';
    this.revenueGrowthChartConfig.ykeys = ['a'];
    this.revenueGrowthChartConfig.labels = ['Revenue Growth'];
    this.revenueGrowthChartConfig.postUnits = '$';
    this.revenueGrowthChartConfig.pointFillColors = ['#6f6cc6'];
    this.revenueGrowthChartConfig.pointStrokeColors = ['#6cc1da'];
    this.revenueGrowthChartConfig.lineColors = ['#6f6cc6'];

    // For Driver Growth Area chart
    this.driverGrowthChartConfig.xkey = 'y';
    this.driverGrowthChartConfig.ykeys = ['a'];
    this.driverGrowthChartConfig.labels = ['Driver Growth'];
    this.driverGrowthChartConfig.postUnits = '$';
    this.driverGrowthChartConfig.pointFillColors = ['#2e9b85'];
    this.driverGrowthChartConfig.pointStrokeColors = ['#7dcdb0'];
    this.driverGrowthChartConfig.lineColors = ['#2e9b85'];

    // For Trip Growth Area chart
    this.tripGrowthChartConfig.xkey = 'y';
    this.tripGrowthChartConfig.ykeys = ['a'];
    this.tripGrowthChartConfig.labels = ['Trip Growth'];
    this.tripGrowthChartConfig.postUnits = '$';
    this.tripGrowthChartConfig.pointFillColors = ['#f0bd48'];
    this.tripGrowthChartConfig.pointStrokeColors = ['#fcf4e0'];
    this.tripGrowthChartConfig.lineColors = ['#f0bd48'];

    // For Rider Growth Area chart
    this.riderGrowthChartConfig.xkey = 'y';
    this.riderGrowthChartConfig.ykeys = ['a'];
    this.riderGrowthChartConfig.labels = ['Rider Growth'];
    this.riderGrowthChartConfig.postUnits = '$';
    this.riderGrowthChartConfig.pointFillColors = ['#6cc1da'];
    this.riderGrowthChartConfig.pointStrokeColors = ['#dcf4f8'];
    this.riderGrowthChartConfig.lineColors = ['#6cc1da'];
  }
}
