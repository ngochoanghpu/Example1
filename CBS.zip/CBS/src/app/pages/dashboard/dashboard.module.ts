import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardComponent } from './dashboard.component';
import { WidgetChartsModule } from '@app/shared/widgets/charts/widget-charts.module';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@app/shared';

@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    WidgetChartsModule,
    SharedModule,

    RouterModule.forChild([{ path: '', component: DashboardComponent }])
  ]
})
export class DashboardModule {}
