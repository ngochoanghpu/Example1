import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatPaginator } from '@angular/material';

import { FAQCategoryModel } from '@app/services/models/faq.model';
import { FAQService } from '@app/services/faq.service';
import { FAQItemModel } from '@app/services/models/faq-details.model';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { FaqFormDialogComponent } from './components/faq-form-dialog/faq-form-dialog.component';
import { DeleteFaqFormDialogComponent } from './components/delete-faq-form-dialog/delete-faq-form-dialog.component';
import { FaqCatergoriesFormDialogComponent } from './components/faq-catergories-form-dialog/faq-catergories-form-dialog.component';

@Component({
  selector: 'dnf-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {
  listFAQ: FAQCategoryModel[] = [];
  selectedFAQ: FAQCategoryModel;
  faqItems: FAQItemModel[];
  showContent = {};
  breadcrumbs = [
    { icon: 'flaticon-info', text: 'LBL_HELP' },
    { icon: 'flaticon-info', text: 'LBL_FAQ' }
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private faqService: FAQService, public dialog: MatDialog) {}

  ngOnInit() {
    this._loadItems();
  }

  _loadItems() {
    this.faqService.getFAQs().subscribe(faqs => {
      this.listFAQ = faqs;
      this.showFAQItems(this.listFAQ[0]);
    });
  }

  _initDialog(
    component: any,
    dialogSize: string,
    editMode = false,
    item = null,
    callbackFunction: Function
  ) {
    const dialogRef = this.dialog.open(component, {
      width: dialogSize,
      data: { editMode: editMode, item: item }
    });

    dialogRef.afterClosed().subscribe(result => {
      callbackFunction(result);
    });
  }

  showFAQCategoryDialog(item?: FAQCategoryModel) {
    this._initDialog(
      FaqCatergoriesFormDialogComponent,
      DIALOG_SIZE.medium,
      true,
      item,
      () => {}
    );
  }

  showFAQFormDialog(item?: FAQItemModel) {
    this._initDialog(
      FaqFormDialogComponent,
      DIALOG_SIZE.medium,
      true,
      item,
      () => {}
    );
  }

  showFAQItems(item?: FAQCategoryModel) {
    this.selectedFAQ = item;
    this.faqItems = item.details;
  }

  deleteFAQCategory(item: FAQCategoryModel) {
    this._initDialog(
      DeleteFaqFormDialogComponent,
      DIALOG_SIZE.default,
      false,
      null,
      () => {}
    );
  }

  deleteFAQItem(item: FAQItemModel) {
    // Will do the same action with: deleteFAQCategory
    // Will implement after create common confirmation dialog
  }

  changeConent(i: number) {
    if (this.showContent[i]) {
    this.showContent[i] = !this.showContent[i];
    } else {
      this.showContent[i] = true;
    }
  }

  getContent(i: number) {
    if (this.showContent[i]) {
      return  this.showContent[i];
    }
    return false;
  }

}
