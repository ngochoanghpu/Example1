import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'dnf-delete-faq-form-dialog',
  templateUrl: './delete-faq-form-dialog.component.html',
  styleUrls: ['./delete-faq-form-dialog.component.scss']
})
export class DeleteFaqFormDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<DeleteFaqFormDialogComponent>) { }

  ngOnInit() {
  }

  delete() {
    this.dialogRef.close();
  }

}
