import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'dnf-faq-form-dialog',
  templateUrl: './faq-form-dialog.component.html',
  styleUrls: ['./faq-form-dialog.component.scss']
})
export class FaqFormDialogComponent implements OnInit {
  item: any;
  form: FormGroup;
  isEdit: Boolean;

  constructor(
    public dialogRef: MatDialogRef<FaqFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    this.isEdit = this.data.item !== null;

    this.form = this.fb.group({
      title: '',
      content: ''
    });

    if (this.isEdit) {
      this.form.controls['title'].setValue(this.data.item.title);
      this.form.controls['content'].setValue(this.data.item.content);
    }

    this.item = this.data.item;
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  save() {
    this.dialogRef.close();
  }
}
