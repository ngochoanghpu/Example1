import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FAQCategoryModel } from '@app/services/models/faq.model';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'dnf-faq-catergories-form-dialog',
  templateUrl: './faq-catergories-form-dialog.component.html',
  styleUrls: ['./faq-catergories-form-dialog.component.scss']
})
export class FaqCatergoriesFormDialogComponent implements OnInit {
  item: FAQCategoryModel;
  form: FormGroup;
  isEdit: Boolean;
  selectedIcon: any;
  icons = [
    'flaticon-lifebuoy',
    'flaticon-danger',
    'flaticon-technology-1',
    'flaticon-letter-g',
    'flaticon-cancel',
    'flaticon-warning-sign',
    'flaticon-coins',
    'flaticon-lock',
    'flaticon-support',
    'flaticon-file'
  ];
  color = '#000000';

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<FaqCatergoriesFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.isEdit = this.data.item !== null;

    this.form = this.fb.group({
      title: '',
      subTitle: '',
      icon: '',
      iconColor: ''
    });

    this.selectedIcon = this.icons[0];
    if (this.isEdit) {
      this.color = this.data.item.iconColor;
      this.selectedIcon = this.data.item.icon;

      this.form.controls['title'].setValue(this.data.item.title);
      this.form.controls['subTitle'].setValue(this.data.item.subTitle);
    }
  }

  hasError = (field: string, type: string) => this.form.get(field).hasError(type);

  save(): void {
    this.dialogRef.close();
  }

  changeIcon(icon: string) {
    this.selectedIcon = icon;
    this.form.controls['icon'].setValue(icon);
  }

  getIconColor(color) {
    this.form.controls['iconColor'].setValue(color);
  }
}
