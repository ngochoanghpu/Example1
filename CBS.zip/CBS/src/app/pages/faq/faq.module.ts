import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ColorPickerModule } from 'ngx-color-picker';

import { DesignModule } from '@app/shared/design/design.module';
import { FaqComponent } from './faq.component';
import { FAQService } from '@app/services/faq.service';
import { FaqFormDialogComponent } from './components/faq-form-dialog/faq-form-dialog.component';
import { DeleteFaqFormDialogComponent } from './components/delete-faq-form-dialog/delete-faq-form-dialog.component';
import { FaqCatergoriesFormDialogComponent } from './components/faq-catergories-form-dialog/faq-catergories-form-dialog.component';

@NgModule({
  declarations: [
    FaqComponent,
    FaqFormDialogComponent,
    DeleteFaqFormDialogComponent,
    FaqCatergoriesFormDialogComponent
  ],
  imports: [
    CommonModule,
    DesignModule,
    ColorPickerModule,
    RouterModule.forChild([
      {
        path: '',
        component: FaqComponent
      }
    ])
  ],
  providers: [FAQService],
  exports: [],
  entryComponents: [
    FaqFormDialogComponent,
    DeleteFaqFormDialogComponent,
    FaqCatergoriesFormDialogComponent
  ]
})
export class FaqModule {}
