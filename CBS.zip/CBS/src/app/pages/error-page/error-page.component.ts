import { Component, OnInit, HostBinding } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'dnf-error-page',
  templateUrl: './error-page.component.html',
})
export class ErrorPageComponent implements OnInit {
  @HostBinding('class') classes = 'dnf-error';

  constructor(private router: Router) {}

  ngOnInit() {}

  back() {
    this.router.navigate(['/']);
  }
}
