import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RolesComponent } from './roles.component';
import { DesignModule } from '@app/shared/design/design.module';
import { RouterModule } from '@angular/router';
import { RolesFormDialogComponent } from './component/roles-form-dialog/roles-form-dialog.component';
import { DeleteRolesDialogComponent } from './component/delete-roles-dialog/delete-roles-dialog.component';

@NgModule({
  declarations: [RolesComponent, RolesFormDialogComponent, DeleteRolesDialogComponent],
  imports: [
    CommonModule,
    DesignModule,
    RouterModule.forChild([
      {
        path: '',
        component: RolesComponent
      }
    ])
  ],
  entryComponents: [RolesFormDialogComponent, DeleteRolesDialogComponent]
})
export class RolesModule { }
