import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort, MatPaginator, MatDialog, MatTableDataSource, MatInput } from '@angular/material';
import { LoaderService } from '@app/services/loader.service';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { RolesService } from '@app/services/roles.service';
import { RoleModel } from '@app/services/models/role.model';
import { RolesFormDialogComponent } from './component/roles-form-dialog/roles-form-dialog.component';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { DeleteRolesDialogComponent } from './component/delete-roles-dialog/delete-roles-dialog.component';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'dnf-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.scss']
})
export class RolesComponent implements OnInit {
  isLoading = false;
  displayedColumns: string[] = [
    'name',
    'description',
    'permissions',
    'actions'
  ];

  keyword = '';
  dataSource: any;
  breadcrumbs = [
    { icon: 'flaticon-settings', text: 'LBL_SETTINGS' },
    { icon: 'flaticon-user', text: 'LBL_ROLES_PERMISSIONS' }
  ];
  listFeature = [];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  constructor(
    private roleService: RolesService,
    private loaderService: LoaderService,
    private toastr: ToastrService,
    private translate: TranslateService,
    public dialog: MatDialog,
  ) { }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);

    this.roleService.getAllFeature().subscribe((data: any) => {
      this.listFeature = data;
    });
  }

  _loadItems(firstLoad: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
      },
      this.sort.direction,
      this.sort.active || 'name',
      firstLoad ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.roleService.getRoles(queryParams).subscribe((data: any) => {
      this.paginator.length = data.total;
      if (data.results) {
        data.results.forEach(role => {
          return role.permission = role.feature.map(feature => feature.name).join(', ');
        });
        this.dataSource = new MatTableDataSource<RoleModel>(data.results);
        this.dataSource.sort = this.sort;
      }
      this.loaderService.hide();
    });
  }

  add() {
    this.openRolesDialog(true);
  }

  search() {
    this._loadItems(true);
  }

  reset() {
    this.keyword = '';
  }

  editDetails(edit = false, element: RoleModel) {
    this.openRolesDialog(edit, element);
  }

  delete(id: number) {
    const dialogRef = this.dialog.open(DeleteRolesDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { id }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._loadItems();
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_ROLE'),
            action: this.translate.instant('ACTION_DELETED')
          })
        );
      }
    });
  }

  openRolesDialog(edit = false, element: RoleModel = null) {
    const dialogRef = this.dialog.open(RolesFormDialogComponent, {
      width: DIALOG_SIZE.large,
      data: { editMode: edit, item: element, features: this.listFeature }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._loadItems();
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_ROLE'),
            action: edit ? this.translate.instant('ACTION_UPDATED') : this.translate.instant('ACTION_CREATED')
          })
        );
      }
    });
  }
}
