import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource } from '@angular/material';
import { RoleModel } from '@app/services/models/role.model';
import { RolesService } from '@app/services/roles.service';
import { PermissionsModel } from '@app/services/models/permissions.model';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { LoaderService } from '@app/services/loader.service';
import { ACTIONS, CONSTANTS } from '@app/shared/constant';
import { SpacesValidator } from '../../../../core/validators/spaces-validator';


@Component({
  selector: 'dnf-roles-form-dialog',
  templateUrl: './roles-form-dialog.component.html',
  styleUrls: ['./roles-form-dialog.component.scss']
})
export class RolesFormDialogComponent implements OnInit {
  featuresCode = CONSTANTS.FEATURES_CODE;
  actions = ACTIONS;
  isEdit: boolean;
  role: RoleModel;
  form: FormGroup;
  dataSource: any;
  displayedColumns: string[] = [
    'permission',
    'read',
    'create',
    'update',
    'delete',
    'checkAll'
  ];
  features: [];

  constructor(private rolesService: RolesService,
    private loaderService: LoaderService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<RolesFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
  }

  ngOnInit() {
    this.features = this.data.features.map(feature => {
      return {
        ...feature,
        actions: {
          canRead: false,
          canCreate: false,
          canUpdate: false,
          canDelete: false,
        }
      };
    });

    this.role = this.data.item || {};
    this.isEdit = this.data.editMode;

    this.createFormControl();
    this.loadPermission();
    if (this.data.item) {
      setTimeout(() => {
        this.loaderService.show();
        this.rolesService.getRoleDetail(this.data.item.id).subscribe((roleDetail: any) => {
          this.role = roleDetail;
          this.loadPermission();
          this.loaderService.hide();
        });
      });
    }
  }

  createFormControl() {
    this.form = this.fb.group({
      name: new FormControl({ value: this.role.name, disabled: !this.isEdit }, [Validators.required, SpacesValidator]),
      desc: new FormControl({ value: this.role.desc, disabled: !this.isEdit })
    });
  }

  loadPermission() {
    if (this.role.permissions) {
      const newArr: PermissionsModel[] = this.features;
      newArr.map((a) => {
        const obj = this.role.permissions.find((b) => a.name === b.name);
        if (obj) {
          Object.assign(a, obj);
          a.actions.canRead = a.actions.canRead || a.actions.canCreate || a.actions.canUpdate || a.actions.canDelete;
        }
        return a;
      });
      this.dataSource = new MatTableDataSource<PermissionsModel>(newArr);
      return;
    }
    this.dataSource = new MatTableDataSource<PermissionsModel>(this.features);
  }

  setAllValue(checked: boolean, element: any) {
    for (const property of Object.keys(element.actions)) {
      const cannotDelFeatures = [CONSTANTS.FEATURES_CODE.VEHICLE, CONSTANTS.FEATURES_CODE.DRIVER, CONSTANTS.FEATURES_CODE.PASSENGER, CONSTANTS.FEATURES_CODE.TRIP];
      const isNotAllowDeleteCondition = property === CONSTANTS.ACTIONS.DELETE && (cannotDelFeatures.indexOf(element.code) !== -1);
      const isNotAllowCreateCondition = property === CONSTANTS.ACTIONS.CREATE && ([CONSTANTS.FEATURES_CODE.PASSENGER, CONSTANTS.FEATURES_CODE.TRIP].indexOf(element.code) !== -1);
      const isNotAllowUpdateCondition = property === CONSTANTS.ACTIONS.UPDATE && (element.code === CONSTANTS.FEATURES_CODE.TRIP);
      if (isNotAllowDeleteCondition || isNotAllowCreateCondition || isNotAllowUpdateCondition) {
        element.actions[property] = false;
      } else {
        element.actions[property] = checked;
      }
    }
  }

  setValue(checked: boolean, element: any, type: number) {
    element.actions[ACTIONS[type]] = checked;
    if (checked) {
      element.actions.canRead = true;
    }
  }

  setReadValue(checked: boolean, element: any) {
    element.actions.canRead = checked;
    if (!checked) {
      for (const property of Object.keys(element.actions)) {
        element.actions[property] = false;
      }
    }
  }

  save() {

    const permissions = this.dataSource.data;

    const roleParams = {
      ...this.form.value,
      permissions: permissions.map(permission => {
        return {
          ...permission.actions,
          featureId: permission.id,
        };
      })
    };

    this.loaderService.show();
    if (!this.role.id) {
      this.rolesService.createRole(roleParams).subscribe(resp => {
        this.loaderService.hide();
        this.dialogRef.close(true);
      });
    } else {
      this.rolesService.updateRole(this.role.id, roleParams).subscribe(resp => {
        this.loaderService.hide();
        this.dialogRef.close(true);
      });
    }
  }

  hasError(field, type) {
    return this.form.get(field).hasError(type);
  }
}
