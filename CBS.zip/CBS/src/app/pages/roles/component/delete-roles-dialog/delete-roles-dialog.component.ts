import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { RolesService } from '@app/services/roles.service';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-delete-roles-dialog',
  templateUrl: './delete-roles-dialog.component.html',
  styleUrls: ['./delete-roles-dialog.component.scss']
})
export class DeleteRolesDialogComponent implements OnInit {

  constructor(
    private toastr: ToastrService,
    private translate: TranslateService,
    private rolesService: RolesService,
    private loaderService: LoaderService,
    public dialogRef: MatDialogRef<DeleteRolesDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {}

  delete() {
    this.loaderService.show();
    this.rolesService.deteleRole(this.data.id).subscribe(() => {
      this.loaderService.hide();
      this.dialogRef.close(true);
    });
  }

}
