import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatSelectChange,
  MatOption
} from '@angular/material';

import { Fare } from '@app/services/models/fare.model';
import { CountriesService } from '@app/services/countries.service';
import { TypeOfRidesService } from '@app/services/type-of-rides.service';
import { TypeOfServicesService } from '@app/services/type-of-services.service';
import { TypeOfVehiclesService } from '@app/services/type-of-vehicles.service';
import { TypeOfVehiclesModel } from '@app/services/models/type-of-vehicles.model';
import { TypeOfRidesModel } from '@app/services/models/type-of-rides.model';
import { TypeOfServicesModel } from '@app/services/models/type-of-services.model';
import { CountryModel } from '@app/services/models/country.model';
import { FaresService } from '@app/services/fares.service';
import { LoaderService } from '@app/services/loader.service';
import { TYPE_OF_SERVICES, TYPE_OF_RIDES, TYPE_OF_VEHICLES } from '@app/shared/constant';
import _ from 'lodash';
import { SpacesValidator } from '../../../../core/validators/spaces-validator';

@Component({
  selector: 'dnf-fare-form-dialog',
  templateUrl: './fare-form-dialog.component.html',
  styleUrls: []
})
export class FareFormDialogComponent implements OnInit {
  item: Fare;
  form: FormGroup;

  countries: Array<CountryModel>;
  typeOfVehicles: Array<TypeOfVehiclesModel>;
  typeOfServices: Array<TypeOfServicesModel>;
  typeOfRides: Array<TypeOfRidesModel>;

  constructor(
    private fb: FormBuilder,
    private countryService: CountriesService,
    private typeOfRideService: TypeOfRidesService,
    private typeOfServiceService: TypeOfServicesService,
    private typeOfVehicleService: TypeOfVehiclesService,
    private faresService: FaresService,
    private loaderService: LoaderService,
    public dialogRef: MatDialogRef<FareFormDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.item = this._getDataItem();

    this.form = this.fb.group({
      id: this.item.id,
      name: [this.item.name, [SpacesValidator]],
      description: this.item.description,
      countryId: this.item.countryId,
      currency: this.item.currency,
      typeOfServiceId: this.item.typeOfServiceId,
      typeOfRideId: this.item.typeOfRideId,
      typeOfVehicleId: this.item.typeOfVehicleId,
      openingPrice: this.item.openingPrice,
      kmPrice: this.item.kmPrice,
      effectiveFrom: new Date(this.item.effectiveFrom),
      effectiveTo: this.item.effectiveTo ? new Date(this.item.effectiveTo) : null
    });

    this._getCountries();
    this._getTypeOfRides();
    this._getTypeOfServices();
    this._getTypeOfVehicles();
  }

  hasError = (field, type) => this.form.get(field).hasError(type);

  save = () => {
    this.loaderService.show();
    

    if(this.form.value.id){
      let fare = _.omit(this.form.value, ['typeOfServiceId', 'typeOfRideId', 'typeOfVehicleId']);
      this.faresService.updateFare(fare).subscribe((result: any) => {
        this.loaderService.hide();
        this.dialogRef.close(this.form.value);
      });
    }
    else{
      //TODO get typeOfService, typeOfVehicle, typeOfRide
      let fare = this.form.value;      
      fare.typeOfRide = TYPE_OF_RIDES[fare.typeOfRideId];
      fare.typeOfService = TYPE_OF_SERVICES[fare.typeOfServiceId];
      fare.typeOfVehicle = TYPE_OF_VEHICLES[fare.typeOfVehicleId];
      fare = _.omit(fare, ['id', 'typeOfServiceId', 'typeOfRideId', 'typeOfVehicleId']);

      this.faresService.addFare(fare).subscribe((result: any) => {
        this.loaderService.hide();
        this.dialogRef.close(this.form.value);
      });
    }
  };

  _getDataItem = () => new Fare(this.data.item);

  _getCountries = () => {
    this.countryService.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  };

  _getTypeOfVehicles() {
    this.typeOfVehicleService.getTypeOfVehicles(null, true).subscribe(typeOfVehicles => {
      this.typeOfVehicles = typeOfVehicles;
    });
  }

  _getTypeOfServices() {
    this.typeOfServiceService.getTypeOfServices().subscribe(typeOfServices => {
      this.typeOfServices = typeOfServices;
    });
  }

  _getTypeOfRides() {
    this.typeOfRideService.getTypeOfRides().subscribe(typeOfRides => {
      this.typeOfRides = typeOfRides;
    });
  }

  setCurrency = (event: MatSelectChange) => {
    const selectedData = {
      text: (event.source.selected as MatOption).viewValue,
      value: event.source.value
    };
 
    let country: any = _.find(this.countries, function(country){
        return country.id == selectedData.value;
    });

    let currency = country ? country.currency : "VND";
    this.form.controls['currency'].setValue(currency);
  };
}
