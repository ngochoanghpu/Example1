import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FaresService } from '@app/services/fares.service';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-fare-delete-dialog',
  templateUrl: './fare-delete-dialog.component.html',
  styleUrls: []
})
export class FareDeleteDialogComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<FareDeleteDialogComponent>,
    private faresService: FaresService,
    private loaderService: LoaderService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}

  delete() {
    this.loaderService.show();   
    this.faresService.deleteFare(this.data.id).subscribe((result: any) => {
      this.loaderService.hide();
      this.dialogRef.close(true);
    });
  }
}
