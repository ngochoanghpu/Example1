import { Component, OnInit, Inject } from '@angular/core';
import { Fare } from '@app/services/models/fare.model';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'dnf-fare-view-detail-dialog',
  templateUrl: './fare-view-detail-dialog.component.html',
  styleUrls: []
})
export class FareViewDetailDialogComponent implements OnInit {
  item: Fare;
  constructor(
    private dialogRef: MatDialogRef<FareViewDetailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any
  ) {}

  ngOnInit() {
    this.item = new Fare(this.data.item);
  }

  edit() {
    this.dialogRef.close({ editMode: true });
  }
}
