import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatPaginator,
  MatSort,
  MatDialog,
  MatInput,
  MatTableDataSource
} from '@angular/material';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';

import { FaresService } from '@app/services/fares.service';
import { LoaderService } from '@app/services/loader.service';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { Fare } from '@app/services/models/fare.model';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { FareViewDetailDialogComponent } from './components/fare-view-detail-dialog/fare-view-detail-dialog.component';
import { FareDeleteDialogComponent } from './components/fare-delete-dialog/fare-delete-dialog.component';
import { FareFormDialogComponent } from './components/fare-form-dialog/fare-form-dialog.component';
import { TypeOfRidesService } from '@app/services/type-of-rides.service';
import { TypeOfServicesService } from '@app/services/type-of-services.service';
import { TypeOfVehiclesService } from '@app/services/type-of-vehicles.service';
import { CountriesService } from '@app/services/countries.service';
import { TypeOfVehiclesModel } from '@app/services/models/type-of-vehicles.model';
import { TypeOfRidesModel } from '@app/services/models/type-of-rides.model';
import { TypeOfServicesModel } from '@app/services/models/type-of-services.model';
import { CountryModel } from '@app/services/models/country.model';

import { TYPE_OF_SERVICES, TYPE_OF_RIDES, TYPE_OF_VEHICLES } from '@app/shared/constant';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import moment from 'moment';
import { PermissionService } from '@app/services/permission.service';

@Component({
  selector: 'dnf-fares',
  templateUrl: './fares.component.html',
  styleUrls: []
})
export class FaresComponent implements OnInit {
  featureCode = 'FAR';
  permission = {
    canRead: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false
  };
  displayedColumns: string[] = [
    'country',
    'name',
    'effectiveFrom',
    'effectiveTo',
    'typeOfService',
    'typeOfRide',
    'typeOfVehicle',
    'actions'
  ];

  dataSource: any;
  // Using for fill data to the selectbox
  typeOfVehicles: Array<TypeOfVehiclesModel>;
  typeOfRides: Array<TypeOfRidesModel>;
  typeOfServices: Array<TypeOfServicesModel>;
  countries: Array<CountryModel>;

  // Using for searching
  countryId = '';
  typeOfServiceId = '';
  typeOfRideId = '';
  typeOfVehicleId = '';
  effectiveFrom = null;
  keyword = '';

  breadcrumbs = [
    {icon: 'flaticon-notepad', text: 'LBL_FARES'}
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  constructor(
    private permissionService: PermissionService,
    private countriesServive: CountriesService,
    private faresService: FaresService,
    private typeOfRideService: TypeOfRidesService,
    private typeOfServiceService: TypeOfServicesService,
    private typeOfVehicleService: TypeOfVehiclesService,
    private loaderService: LoaderService,
    private toastr: ToastrService,
    private translate: TranslateService,
    private dialog: MatDialog
  ) {}

  _getCountries() {
    this.countriesServive.getCountries().subscribe(countries => {
      this.countries = countries;
    });
  }

  _getTypeOfVehicles() {
    this.typeOfVehicleService.getTypeOfVehicles(null, true).subscribe(typeOfVehicles => {
      this.typeOfVehicles = typeOfVehicles;
    });
  }

  _getTypeOfServices() {
    this.typeOfServiceService.getTypeOfServices().subscribe(typeOfServices => {
      this.typeOfServices = typeOfServices;
    });
  }

  _getTypeOfRides() {
    this.typeOfRideService.getTypeOfRides().subscribe(typeOfRides => {
      this.typeOfRides = typeOfRides;
    });
  }


  ngOnInit() {
    this.permission = this.permissionService._getFeaturePermission(this.featureCode);
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
    this._getTypeOfRides();
    this._getTypeOfServices();
    this._getTypeOfVehicles();
    this._getCountries();
  }

  _loadItems(firstLoad: boolean = false, isSearch: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
        countryId: this.countryId,
        effectiveFrom: this.effectiveFrom ? moment(this.effectiveFrom).format('YYYY-MM-DD') : null,
        typeOfService: this.typeOfServiceId,
        typeOfRide: this.typeOfRideId,
        typeOfVehicle: this.typeOfVehicleId
      },
      this.sort.direction,
      this.sort.active,
      firstLoad || isSearch ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.faresService.getFares(queryParams).subscribe(fares => {
      this.paginator.length = fares.total;
      this.dataSource = new MatTableDataSource<Fare>(fares.results);
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  search() {
    this._loadItems(null, true);
  }

  reset() {
    this.keyword = '';
    this.countryId = '';
    this.effectiveFrom = '';
    this.typeOfServiceId = '';
    this.typeOfRideId = '';
    this.typeOfVehicleId = '';
  }

  addItem() {
    this._initDialog();
  }

  editItem(item: Fare) {
    // TODO: get typeOfRideId, typeOfServiceId, typeOfVehicleId
    this.getTypeOfId(item);

    this._initDialog(true, item);
  }

  _initDialog(editMode = false, item = null) {
    const dialogRef = this.dialog.open(FareFormDialogComponent, {
      width: DIALOG_SIZE.medium,
      data: { editMode: editMode, item: item }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // update UI
        this._loadItems();

        // show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_SINGLE_FARE'),
            action: item && item.id ? this.translate.instant('ACTION_UPDATED') : this.translate.instant('ACTION_CREATED')
          })
        );
      }
    });
  }

  viewDetails(item: Fare) {
    // TODO: get typeOfRideId, typeOfServiceId, typeOfVehicleId
    this.getTypeOfId(item);

    const dialogRef = this.dialog.open(FareViewDetailDialogComponent, {
      width: DIALOG_SIZE.medium,
      data: { item: item }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result && result.editMode) {
        this._initDialog(true, item);
      }
    });
  }

  deleteItem(item: Fare) {
    const dialogRef = this.dialog.open(FareDeleteDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { editMode: false, item: item.id }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        // update UI
        this._loadItems();

        // show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_SINGLE_FARE'),
            action: this.translate.instant('ACTION_DELETED')
          })
        );
      }
    });
  }

  getTypeOfId(item: Fare) {
    item.typeOfRideId = TYPE_OF_RIDES[item.typeOfRide];
    item.typeOfServiceId = TYPE_OF_SERVICES[item.typeOfService];
    item.typeOfVehicleId = TYPE_OF_VEHICLES[item.typeOfVehicle];
  }
}
