import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { FaresComponent } from './fares.component';
import { FaresService } from '@app/services/fares.service';
import { DesignModule } from '@app/shared/design/design.module';
import { SharedModule } from '@app/shared';
import { FareViewDetailDialogComponent } from './components/fare-view-detail-dialog/fare-view-detail-dialog.component';
import { FareDeleteDialogComponent } from './components/fare-delete-dialog/fare-delete-dialog.component';
import { FareFormDialogComponent } from './components/fare-form-dialog/fare-form-dialog.component';

@NgModule({
  declarations: [
    FaresComponent,
    FareViewDetailDialogComponent,
    FareDeleteDialogComponent,
    FareFormDialogComponent
  ],
  imports: [
    CommonModule,
    DesignModule,
    RouterModule.forChild([
      {
        path: '',
        component: FaresComponent
      }
    ]),
    SharedModule
  ],
  providers: [FaresService],
  entryComponents: [
    FareViewDetailDialogComponent,
    FareDeleteDialogComponent,
    FareFormDialogComponent
  ]
})
export class FaresModule {}
