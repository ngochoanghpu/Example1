import { Component, OnInit, ViewChild } from '@angular/core';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import { MatPaginator, MatSort, MatDialog, MatTableDataSource, MatInput } from '@angular/material';

import { PassengersService } from '@app/services/passengers.service';
import { LoaderService } from '@app/services/loader.service';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { Passenger } from '@app/services/models/passenger.model';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { ViewDetailPassengerComponent } from './components/view-detail/view-detail.component';
import { EditPassengerComponent } from './components/edit/edit.component';
import { UpdateStatusComponent } from './components/deactivate/deactivate.component';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { invokeQuery } from '@angular/animations/browser/src/render/shared';
import { CountriesService } from '@app/services/countries.service';
import { PermissionService } from '@app/services/permission.service';

@Component({
  selector: 'dnf-passengers',
  templateUrl: './passengers.component.html',
  styleUrls: ['./passengers.component.scss']
})
export class PassengersComponent implements OnInit {
  featureCode = 'PAS';
  permission = {
    canRead: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false
  };
  public displayedColumns: string[] = [
    'avatar',
    'firstName',
    'lastName',
    'phoneNumber',
    'email',
    'rating',
    'status',
    'actions'
  ];

  keyword = '';
  typeOfStatusId = '';
  public dataSource: any;
  countries: any = [];
  breadcrumbs = [
    {icon: 'flaticon-customer', text: 'LBL_PASSENGERS'}
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  constructor(
    private permissionService: PermissionService,
    private countriesServive: CountriesService,
    private passengerService: PassengersService,
    private loaderService: LoaderService,
    private toastr: ToastrService,
    private translate: TranslateService,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.permission = this.permissionService._getFeaturePermission(this.featureCode);
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
    this._getCountries();
  }

  _loadItems(firstLoad: boolean = false, isSearch: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
        status: this.typeOfStatusId
      },
      this.sort.direction,
      this.sort.active,
      firstLoad || isSearch ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.passengerService.getPassengers(queryParams).subscribe(passengers => {
      this.paginator.length = passengers.total;
      this.dataSource = new MatTableDataSource<Passenger>(passengers.results);
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  search() {
    this._loadItems(null, true);
  }

  reset() {
    this.keyword = '';
    this.typeOfStatusId = '';

  }

  viewDetails(item: Passenger) {
    const dialogRef = this.dialog.open(ViewDetailPassengerComponent, {
      width: DIALOG_SIZE.medium,
      data: { item: item, parentComponent: this }
    });
  }

  updatePassenger(item: Passenger, isOnlyUpdateStatus = false) {
    const component: any = isOnlyUpdateStatus ? UpdateStatusComponent : EditPassengerComponent;
    const dialogRef = this.dialog.open(component, {
      width: isOnlyUpdateStatus ? DIALOG_SIZE.default : DIALOG_SIZE.medium,
      data: { editMode: false, item: item, dataSource: this.dataSource, countries: this.countries }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this._loadItems();

        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_SINGLE_PASSENGER'),
            action: this.translate.instant('ACTION_UPDATED')
          })
        );
      }
    });
  }

  _getCountries() {
    if (this.countries.length === 0) {
      this.countriesServive.getCountries().subscribe(countries => {
        this.countries = countries;
      });
    }
  }
}
