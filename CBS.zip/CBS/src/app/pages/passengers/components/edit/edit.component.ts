import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog, MatSelectChange, MatOption } from '@angular/material';
import { FormGroup, FormBuilder } from '@angular/forms';

import { Passenger } from '@app/services/models/passenger.model';
import { LoaderService } from '@app/services/loader.service';
import { PassengersService } from '@app/services/passengers.service';
import { SpacesValidator } from '../../../../core/validators/spaces-validator';

@Component({
  selector: 'dnf-passenger-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditPassengerComponent implements OnInit {
  item: Passenger;
  form: FormGroup;
  selectedCountryId: number = null;
  countries: any = [];
  isUploadedAvatar = false;

  constructor(
    public dialogRef: MatDialogRef<EditPassengerComponent>,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private loaderService: LoaderService,
    private passengerService: PassengersService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.item = new Passenger(this.data.item);    
    this._getCountries();
    this._triggerUploadFileInput();

    this.form = this.fb.group({
      id: this.item.id,
      firstName: [this.item.firstName, [SpacesValidator]],
      lastName: [this.item.lastName, [SpacesValidator]],
      phoneCode: this.item.phoneCode,
      phoneNumber: this.item.phoneNumber,
      email: this.item.email,
      countryId: this.item.countryId,
      address: this.item.address
    });
  }

  _getCountries() {
    this.countries = this.data.countries;
    this.selectedCountryId = this.item ? this.item.countryId : null;
  }

  save(){
    this.loaderService.show();
    if(!this.item.profileImage){
      this.form.value.avatar = null;
    }
    else if(this.isUploadedAvatar){
      this.form.value.avatar = this.item.profileImage;
    }    

    this.passengerService.updatePassenger(this.form.value).subscribe((result: any) => {
      this.loaderService.hide();
      this.dialog.closeAll();
      this.dialogRef.close(this.form.value);      
    });
  }

  getPhoneCode (event) {
    this.form.value.phoneCode = event;
  }

  _triggerUploadFileInput() {
    $('#upload-avt').click(function () {
      $('#upload-avt-input').click();
    });
  }

  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = _event => {
        this.item.profileImage = reader.result;   
        this.isUploadedAvatar = true;
      };
    }
  }

  deleteAvatar(image){
    this.item.profileImage = null;
    $('#upload-avt-input').val(null);
  }

  hasError(field, type) {
    return this.form.get(field).hasError(type);
  }
}