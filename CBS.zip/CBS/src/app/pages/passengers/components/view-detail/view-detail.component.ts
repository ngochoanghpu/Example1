import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Passenger } from '@app/services/models/passenger.model';
import { PassengersComponent  } from '../../passengers.component';

@Component({
  selector: 'dnf-passenger-view-detail',
  templateUrl: './view-detail.component.html',
  styleUrls: ['./view-detail.component.scss']
})
export class ViewDetailPassengerComponent implements OnInit {
  item: Passenger;
  constructor(
    public dialogRef: MatDialogRef<PassengersComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.item = new Passenger(this.data.item);
  }

  edit() {
    this.data.parentComponent.updatePassenger(this.item);
  }
}
