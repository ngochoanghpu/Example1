import { Component, OnInit, Inject } from '@angular/core';
import { Passenger } from '@app/services/models/passenger.model';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PassengersService } from '@app/services/passengers.service';
import { LoaderService } from '@app/services/loader.service';
import { STATUS_ENUM } from '@app/shared/constant';
import _ from 'lodash';

@Component({
  selector: 'dnf-deactivate-passenger',
  templateUrl: './deactivate.component.html',
  styleUrls: ['./deactivate.component.scss']
})
export class UpdateStatusComponent implements OnInit {
  item: Passenger;
  form: FormGroup;
  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<UpdateStatusComponent>,
    private passengerService: PassengersService,
    private loaderService: LoaderService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.item = new Passenger(this.data.item);
  }

  updateStatus() {
    let passenger = new Passenger();
    passenger.id = this.data.item.id;
    passenger.status = this.data.item.status === STATUS_ENUM.ACTIVE ? STATUS_ENUM.INACTIVE : STATUS_ENUM.ACTIVE;

    this.passengerService.updatePassenger(passenger).subscribe((result: any) => {
      this.loaderService.hide();                  

      //Update UI
      let currentPassengerId = this.data.item.id
      let passengers: Passenger[] = this.data.dataSource.data;
      let index = _.findIndex(passengers, function(passenger){
        return passenger.id === currentPassengerId;
      });

      if(index != -1){
        passengers[index] = result;
        this.data.dataSource.data = passengers;
        this.dialogRef.close(true);
      }
    });
  }

  hasError(field, type) {
    return this.form.get(field).hasError(type);
  }
}
