import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { PassengersComponent } from './passengers.component';
import { PassengersService } from '@app/services/passengers.service';
import { DesignModule } from '@app/shared/design/design.module';
import { ViewDetailPassengerComponent } from './components/view-detail/view-detail.component';
import { EditPassengerComponent } from './components/edit/edit.component';
import { UpdateStatusComponent } from './components/deactivate/deactivate.component';
import { SharedModule } from '@app/shared';

@NgModule({
  declarations: [
    PassengersComponent,
    ViewDetailPassengerComponent,
    UpdateStatusComponent,
    EditPassengerComponent
  ],
  imports: [
    CommonModule,
    DesignModule,
    RouterModule.forChild([
      {
        path: '',
        component: PassengersComponent
      }
    ]),
    SharedModule
  ],
  providers: [PassengersService],
  entryComponents: [
    ViewDetailPassengerComponent,
    UpdateStatusComponent,
    EditPassengerComponent
  ]
})
export class PassengersModule {}
