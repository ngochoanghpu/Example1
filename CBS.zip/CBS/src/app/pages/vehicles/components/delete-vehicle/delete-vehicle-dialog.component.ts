import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { VehiclesService } from '@app/services/vehicles.service';

@Component({
  selector: 'dnf-delete-vehicle-dialog',
  templateUrl: './delete-users-dialog.component.html',
  styleUrls: ['./delete-users-dialog.component.scss']
})
export class DeleteVehicleDialogComponent implements OnInit {

  constructor(
    private toastr: ToastrService,
    private translate: TranslateService,
    private vehicleService: VehiclesService,
    public dialogRef: MatDialogRef<DeleteVehicleDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    dialogRef.disableClose = true;
  }

  ngOnInit() {}

  delete() {
    this.vehicleService.deleteVehicle(this.data.id).subscribe(() => {
      this.dialogRef.close(true);
    });
  }

}
