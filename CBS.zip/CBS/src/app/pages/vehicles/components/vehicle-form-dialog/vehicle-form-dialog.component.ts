import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import * as moment from 'moment';
import _ from 'lodash';

import { Vehicle } from '@app/services/models/vehicle.model';
import { TypeOfVehiclesService } from '@app/services/type-of-vehicles.service';
import { LoaderService } from '@app/services/loader.service';
import { VehiclesService } from '@app/services/vehicles.service';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { AVATAR } from '@app/shared/constant';
import { DriversService } from '@app/services/drivers.service';
import { Select2TemplateFunction, Select2OptionData } from 'ng2-select2';
import { SpacesValidator } from '../../../../core/validators/spaces-validator';

@Component({
  selector: 'dnf-vehicle-form-dialog',
  templateUrl: './vehicle-form-dialog.component.html',
  styleUrls: []
})

export class VehicleFormDialogComponent implements OnInit {
  form: FormGroup;
  item: Vehicle;
  typeOfVehicles: Array<any>;
  isEdit: Boolean;
  isDisabledStatus = true;
  minDateRegoRenewal = new Date();
  minDateInsuranceExpiry = new Date();
  currentDriverId: string;
  public selectedSeatId: string;
  public drivers: Array<Select2OptionData>;
  public options: Select2Options;

  constructor(
    private fb: FormBuilder,
    private typeOfVehicleService: TypeOfVehiclesService,
    private dialogRef: MatDialogRef<VehicleFormDialogComponent>,
    private loaderService: LoaderService,
    private vehiclesService: VehiclesService,
    private toastr: ToastrService,
    private translate: TranslateService,
    private driverService: DriversService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  _getPassengerSeats() {
    this.typeOfVehicleService.getTypeOfVehicles().subscribe(typeOfVehicles => {
      this.typeOfVehicles = typeOfVehicles;
    });
  }

  ngOnInit() {
    this.selectedSeatId = this.data.item && this.data.item.seats ? this.data.item.seats.toString() : this.data.item;
    this.item = new Vehicle(this.data.item);
    this.isDisabledStatus = !!this.item.driverId;
    this.isEdit = Object.keys(this.item).length > 0 ? true : false;
    if(this.isEdit){
      this.minDateRegoRenewal = this.item.regoRenewalDate ? new Date(this.item.regoRenewalDate) : new Date();
      this.minDateInsuranceExpiry = this.item.insuranceExpiryDate ? new Date(this.item.insuranceExpiryDate) : new Date();
    }

    this._getPassengerSeats();

    this.form = this.fb.group({
      id: this.item.id,
      driverId: this.item.driverId,
      numberPlate: [this.item.numberPlate, [SpacesValidator]],
      model: [this.item.model, [SpacesValidator]],
      vin: [this.item.vin, [SpacesValidator]],
      year: this.item.year,
      validUntil: this.item.validUntil,
      regoRenewalDate: this.item.regoRenewalDate ? new Date(this.item.regoRenewalDate) : null,
      lastServiceKms: this.item.lastServiceKms,
      nextServiceKms: this.item.nextServiceKms,
      currentKms: this.item.currentKms,
      kmsBeforeService: this.item.kmsBeforeService,
      insuranceExpiryDate: this.item.insuranceExpiryDate ? new Date(this.item.insuranceExpiryDate) : null,
      etagNumber: this.item.etagNumber,
      isPremium: this.item.isPremium,
      isServiceMessageSent: this.item.isServiceMessageSent,
      seats: this.item ? this.item.seats : null,
      status: this.item.status      
    });
  }

  save(): void {
    this.loaderService.show();
    this.vehiclesService.updateVehicle(this.form.value).subscribe((result: any) => {
      this.loaderService.hide();
      this.dialogRef.close(this.form.value);
    });
  } 

  hasError(field, type) {
    return this.form.get(field).hasError(type);
  }

  yearSelectedChanged(event): void {
    if (!this.isEdit) {
      this.form.controls['validUntil'].setValue(moment(new Date(event)).format('YYYY'));
    }
  }

  public driverList: Select2TemplateFunction = (
    state: Select2OptionData
  ): JQuery | string => {
    if (!state.id) {
      return state.text;
    }
    const image = `<img class="${AVATAR.SIZE.DEFAULT}" onError="this.src='${
      AVATAR.DEFAULT
    }'" src="${
      state.additional.image ? state.additional.image : AVATAR.DEFAULT
    }"/>`;
    return jQuery(
      `<span class="dnf-avatar">${image} <span>${state.text}</span></span>`
    );
  };

  // function for selection template
  public driverSelection: Select2TemplateFunction = (
    state: Select2OptionData
  ): JQuery | string => {
    if (!state.id) {
      return state.text;
    } 
    return jQuery(`<span>${state.text}</span>`);
  };

}
