import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';

@Component({
  selector: 'dnf-assign-driver-comfirmation-dialog',
  templateUrl: './assign-driver-comfirmation-dialog.component.html',
  styleUrls: []
})
export class AssignDriverComfirmationDialogComponent implements OnInit {
  item: any;
  constructor(
    public dialogRef: MatDialogRef<AssignDriverComfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
    this.item = this.data.item;
  }

  assign() {
    this.dialog.closeAll();
  }
}
