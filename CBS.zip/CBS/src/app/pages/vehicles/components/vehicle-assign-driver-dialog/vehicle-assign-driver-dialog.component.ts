import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
  MatPaginator,
  MatSort,
  MatTableDataSource,
  MatDialog,
  MatInput
} from '@angular/material';

import { LoaderService } from '@app/services/loader.service';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { DriverForAssign } from '@app/services/models/driver-for-assign';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { AssignDriverComfirmationDialogComponent } from './assign-driver-comfirmation-dialog/assign-driver-comfirmation-dialog.component';
import _ from 'lodash';
import { Vehicle } from '@app/services/models/vehicle.model';
import { VehiclesService } from '@app/services/vehicles.service';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { DriversService } from '@app/services/drivers.service';
import { DriverModel } from '@app/services/models/driver.model';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'dnf-vehicle-assign-driver-dialog',
  templateUrl: './vehicle-assign-driver-dialog.component.html',
  styleUrls: []
})
export class VehicleAssignDriverDialogComponent implements OnInit {
  public displayedColumns: string[] = [
    'driver',
    'mobilePhone',
    'actions'
  ];
  keyword = '';
  public dataSource: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  constructor(
    public dialogRef: MatDialogRef<VehicleAssignDriverDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private loaderService: LoaderService,
    private vehiclesService: VehiclesService,
    private toastr: ToastrService,
    private translate: TranslateService,
    private driverService: DriversService,
    private dialog: MatDialog) { }

  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);
  }

  _loadItems(firstLoad: boolean = false, isSearch: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
      },
      this.sort.direction,
      this.sort.active,
      firstLoad || isSearch ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize
    );

    this.driverService.getAvailableDrivers(queryParams).subscribe(drivers => {
      this.paginator.length = drivers.total;
      this.dataSource = new MatTableDataSource<DriverForAssign>(drivers.results);      
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  assign(item: DriverForAssign) {
    let data = this.dialogRef.componentInstance.data.item;   
    item.model = data.model;

    const dialogRef = this.dialog.open(AssignDriverComfirmationDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { editMode: false, item: item }
    });
    
    dialogRef.afterClosed().subscribe(action => {
      if(action === undefined){
        let vehicle = new Vehicle();
        vehicle.id = data.id;
        vehicle.driverId = item.id;
  
        this.vehiclesService.assignDriver(vehicle).subscribe((result: any) => {
          this.loaderService.hide();                  

          let currentVehicleId = this.data.item.id;
          let vehicles: Vehicle[] = this.data.dataSource.data;
          let index = _.findIndex(vehicles, function(vehicle){
            return vehicle.id === currentVehicleId;
          });
    
          if(index != -1){
            vehicles[index] = result;

            //get driver
            let drivers = this.dataSource.data;
            let currentDriver = _.find(drivers, function(driver){
               return driver.id === result.driverId;
            });
            
            vehicles[index].driverInfo = currentDriver;

            this.data.dataSource.data = vehicles;

            //show toast notify
            this.toastr.success(
              this.translate.instant('MSG_SUCCESSFULLY', {
                item: this.translate.instant('LBL_POPUP_ASSIGN_DRIVER'),
                action: ""
              })
            );
          }
        });
      }
    });
  }

  search() {
    this._loadItems(null, true);
  }

  reset() {
    this.keyword = '';
  }
}
