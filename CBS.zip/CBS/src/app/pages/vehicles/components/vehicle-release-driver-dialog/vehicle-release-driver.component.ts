import { Component, OnInit, Inject } from '@angular/core';
import { Vehicle } from '@app/services/models/vehicle.model';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import _ from 'lodash';

import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { VehiclesService } from '@app/services/vehicles.service';
import { LoaderService } from '@app/services/loader.service';

@Component({
  selector: 'dnf-vehicle-release-driver-dialog',
  templateUrl: './vehicle-release-driver.component.html',
  styleUrls: []
})
export class VehicleReleaseDriverDialogComponent implements OnInit {
  item: Vehicle;
  constructor(
    public dialogRef: MatDialogRef<VehicleReleaseDriverDialogComponent>,
    private loaderService: LoaderService,
    private vehiclesService: VehiclesService,
    private toastr: ToastrService,
    private translate: TranslateService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.item = new Vehicle(this.data.item);
  }

  release(item: Vehicle) {
    let vehicle = new Vehicle();
    vehicle.id = item.id;
    vehicle.driverId = null;

    this.vehiclesService.releaseDriver(vehicle).subscribe((result: any) => {
      this.loaderService.hide();                  

      let currentVehicleId = item.id;
      let vehicles: Vehicle[] = this.data.dataSource.data;
      let index = _.findIndex(vehicles, function(vehicle){
        return vehicle.id === currentVehicleId;
      });

      if(index != -1){
        vehicles[index] = result;
        this.data.dataSource.data = vehicles;
        this.dialogRef.close();

        //show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_RELEASE_DRIVER'),
            action: ""
          })
        );
      }
    });
  }
}
