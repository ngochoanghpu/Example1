import { Component, OnInit, Inject } from '@angular/core';
import { Vehicle } from '@app/services/models/vehicle.model';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'dnf-vehicle-view-detail-dialog',
  templateUrl: './vehicle-view-detail-dialog.component.html',
  styleUrls: ['./vehicle-view-detail-dialog.component.scss']
})
export class VehicleViewDetailDialogComponent implements OnInit {
  item: Vehicle;
  constructor(
    public dialogRef: MatDialogRef<VehicleViewDetailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.item = new Vehicle(this.data.item);
  }

  edit() {
    this.dialogRef.close(true);
  }

  save() {
    this.dialogRef.close();
  }
}
