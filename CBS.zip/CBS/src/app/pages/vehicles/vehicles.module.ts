import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { VehiclesComponent } from './vehicles.component';
import { VehiclesService } from '@app/services/vehicles.service';
import { DesignModule } from '@app/shared/design/design.module';
import { VehicleFormDialogComponent } from './components/vehicle-form-dialog/vehicle-form-dialog.component';
import { SharedModule } from '@app/shared';
import { VehicleViewDetailDialogComponent } from './components/vehicle-view-detail-dialog/vehicle-view-detail-dialog.component';
import { VehicleDeactivateDialogComponent } from './components/vehicle-deactivate-dialog/vehicle-deactivate-dialog.component';
import { VehicleReleaseDriverDialogComponent } from './components/vehicle-release-driver-dialog/vehicle-release-driver.component';
import { VehicleAssignDriverDialogComponent } from './components/vehicle-assign-driver-dialog/vehicle-assign-driver-dialog.component';
import { AssignDriverComfirmationDialogComponent } from './components/vehicle-assign-driver-dialog/assign-driver-comfirmation-dialog/assign-driver-comfirmation-dialog.component';
import { DeleteVehicleDialogComponent } from './components/delete-vehicle-dialog/delete-vehicle-dialog.component';

@NgModule({
  declarations: [
    VehiclesComponent,
    VehicleFormDialogComponent,
    VehicleViewDetailDialogComponent,
    VehicleDeactivateDialogComponent,
    VehicleReleaseDriverDialogComponent,
    VehicleAssignDriverDialogComponent,
    AssignDriverComfirmationDialogComponent,
    DeleteVehicleDialogComponent
  ],
  imports: [
    CommonModule,
    DesignModule,
    RouterModule.forChild([
      {
        path: '',
        component: VehiclesComponent
      }
    ]),
    SharedModule
  ],
  providers: [VehiclesService],
  entryComponents: [
    VehicleFormDialogComponent,
    VehicleViewDetailDialogComponent,
    VehicleDeactivateDialogComponent,
    VehicleReleaseDriverDialogComponent,
    VehicleAssignDriverDialogComponent,
    AssignDriverComfirmationDialogComponent,
    DeleteVehicleDialogComponent
  ]
})
export class VehiclesModule {}
