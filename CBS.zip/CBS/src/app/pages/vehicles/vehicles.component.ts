import { Component, OnInit, ViewChild } from '@angular/core';
import {
  MatPaginator,
  MatSort,
  MatTableDataSource,
  MatDialog,
  MatInput
} from '@angular/material';
import { merge } from 'rxjs';
import { tap } from 'rxjs/operators';
import _ from 'lodash';

import { VehiclesService } from '@app/services/vehicles.service';
import { Vehicle } from '@app/services/models/vehicle.model';
import { LoaderService } from '@app/services/loader.service';
import { QueryParamsModel } from '@app/core/models/query-params.model';
import { VehicleFormDialogComponent } from './components/vehicle-form-dialog/vehicle-form-dialog.component';
import { DIALOG_SIZE } from '@app/services/dialog.service';
import { VehicleViewDetailDialogComponent } from './components/vehicle-view-detail-dialog/vehicle-view-detail-dialog.component';
import { VehicleDeactivateDialogComponent } from './components/vehicle-deactivate-dialog/vehicle-deactivate-dialog.component';
import { VehicleReleaseDriverDialogComponent } from './components/vehicle-release-driver-dialog/vehicle-release-driver.component';
import { VehicleAssignDriverDialogComponent } from './components/vehicle-assign-driver-dialog/vehicle-assign-driver-dialog.component';
import { DeleteVehicleDialogComponent } from '@app/pages/vehicles/components/delete-vehicle-dialog/delete-vehicle-dialog.component';
import { TypeOfVehiclesService } from '@app/services/type-of-vehicles.service';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { PermissionService } from '@app/services/permission.service';


@Component({
  selector: 'dnf-vehicles',
  templateUrl: './vehicles.component.html',
  styleUrls: ['./vehicles.component.scss']
})
export class VehiclesComponent implements OnInit {
  featureCode = 'VEH';
  permission = {
    canRead: false,
    canCreate: false,
    canUpdate: false,
    canDelete: false
  };
  public displayedColumns: string[] = [
    'model',
    'numberPlate',
    'seats',
    'year',
    'isPremium',
    'driver',
    'status',
    'actions'
  ];
  public dataSource: any;
  typeOfVehicles: Array<any>;
  typeOfVehicleId = '';
  typeOfPremiumId = '';
  typeOfStatusId = '';
  keyword = '';
  breadcrumbs = [
    { icon: 'flaticon-truck', text: 'LBL_VEHICLES' }
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatInput) q: MatInput;

  constructor(
    private permissionService: PermissionService,
    private typeOfVehicleService: TypeOfVehiclesService,
    private vehiclesService: VehiclesService,
    private loaderService: LoaderService,
    private dialog: MatDialog,
    private toastr: ToastrService,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    this.permission = this.permissionService._getFeaturePermission(this.featureCode);
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));

    /* Data load will be triggered in two cases:
		- when a pagination event occurs => this.paginator.page
		- when a sort event occurs => this.sort.sortChange
		**/
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        tap(() => {
          this._loadItems();
        })
      )
      .subscribe();

    this._loadItems(true);

    this._getPassengerSeats();
  }

  _loadItems(firstLoad: boolean = false, isSearch: boolean = false) {
    this.loaderService.show();

    const queryParams = new QueryParamsModel(
      {
        q: this.keyword,
        seats: this.typeOfVehicleId,
        isPremium: this.typeOfPremiumId,
        status: this.typeOfStatusId
      },
      this.sort.direction,
      this.sort.active,
      firstLoad || isSearch ? this.paginator.pageIndex = 0 : this.paginator.pageIndex + 1,
      firstLoad ? 10 : this.paginator.pageSize,
    );

    this.vehiclesService.getVehicles(queryParams).subscribe(vehicles => {
      this.paginator.length = vehicles.total;
      this.dataSource = new MatTableDataSource<Vehicle>(vehicles.results);
      this.dataSource.sort = this.sort;
      this.loaderService.hide();
    });
  }

  _initDialog(editMode = false, item = null, component, dialogSize, callbackFn) {
    const dialogRef = this.dialog.open(component, {
      width: dialogSize,
      data: { editMode: editMode, item: item, dataSource: this.dataSource }
    });

    dialogRef.afterClosed().subscribe(result => {
      callbackFn(result);
    });
  }

  _getPassengerSeats() {
    this.typeOfVehicleService.getTypeOfVehicles().subscribe(typeOfVehicles => {
      this.typeOfVehicles = typeOfVehicles;
    });
  }

  search() {
    this._loadItems(null, true);
  }

  reset() {
    this.keyword = '';
    this.typeOfVehicleId = '';
    this.typeOfPremiumId = '';
    this.typeOfStatusId = '';
  }

  showFormDialog(item?: Vehicle) {
    this._initDialog(true, item, VehicleFormDialogComponent, DIALOG_SIZE.medium, (result) => {
      // show toast notify
      if (result) {
        this._loadItems();
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_VEHICLE'),
            action: item && item.id ? this.translate.instant('ACTION_UPDATED') : this.translate.instant('ACTION_CREATED')
          })
        );
      }
    });
  }

  updateStatus(item: Vehicle) {
    this._initDialog(false, item, VehicleDeactivateDialogComponent, DIALOG_SIZE.default, () => {
      console.log('After deactivate modal closed!');
    });
  }

  releaseDriver(item: Vehicle) {
    this._initDialog(false, item, VehicleReleaseDriverDialogComponent, DIALOG_SIZE.default, () => {
      console.log('After release driver modal closed!');
    });
  }

  viewDetails(item: Vehicle) {
    this._initDialog(false, item, VehicleViewDetailDialogComponent, DIALOG_SIZE.medium, (result) => {
      console.log('Close modal after view detail!');
      if (result) {
        this._initDialog(true, item, VehicleFormDialogComponent, DIALOG_SIZE.medium, () => {
          console.log('Close modal after edit');
        });
      }
    });
  }

  assignDriver(item?: Vehicle) {
    this._initDialog(true, item, VehicleAssignDriverDialogComponent, DIALOG_SIZE.medium, () => {
      console.log('Close modal after assign driver!');
    });
  }

  deleteItem(id): void {
    const dialogRef = this.dialog.open(DeleteVehicleDialogComponent, {
      width: DIALOG_SIZE.default,
      data: { id }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // update dataSource
        const vehicles: Vehicle[] = this.dataSource.data;
        const index = _.findIndex(vehicles, function(vehicle) {
          return vehicle.id === id;
        });

        if (index !== -1) {
          vehicles.splice(index, 1);
          this.dataSource.data = vehicles;
        }

        // show toast notify
        this.toastr.success(
          this.translate.instant('MSG_SUCCESSFULLY', {
            item: this.translate.instant('LBL_VEHICLE'),
            action: this.translate.instant('ACTION_DELETED')
          })
        );
      }
    });
  }
}
