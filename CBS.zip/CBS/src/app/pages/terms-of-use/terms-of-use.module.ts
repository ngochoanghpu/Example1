import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';

import { TermsOfUseComponent } from './terms-of-use.component';
import { DesignModule } from '@app/shared/design/design.module';
import { EditTermsOfUseDialogComponent } from './components/edit-terms-of-use-dialog/edit-terms-of-use-dialog.component';

@NgModule({
  declarations: [TermsOfUseComponent, EditTermsOfUseDialogComponent ],
  imports: [
    CommonModule,
    DesignModule,
    CKEditorModule,
    RouterModule.forChild([
      {
        path: '',
        component: TermsOfUseComponent
      }
    ])
  ],
  entryComponents: [EditTermsOfUseDialogComponent],
})
export class TermsOfUseModule { }
