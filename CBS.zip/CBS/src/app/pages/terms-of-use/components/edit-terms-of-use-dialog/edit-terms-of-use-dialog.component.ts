import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
  selector: 'dnf-edit-terms-of-use-dialog',
  templateUrl: './edit-terms-of-use-dialog.component.html',
  styleUrls: ['./edit-terms-of-use-dialog.component.scss']
})
export class EditTermsOfUseDialogComponent implements OnInit {
  public Editor = ClassicEditor;
  content: string;

  constructor(
    public dialogRef: MatDialogRef<EditTermsOfUseDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
    this.content = this.data.item;
  }

  save = () => this.dialogRef.close(this.content);

}
