import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { MatDialog } from '@angular/material';

import { DIALOG_SIZE } from '@app/services/dialog.service';
import { SettingsService } from '@app/services/settings.service';
import { EditTermsOfUseDialogComponent } from './components/edit-terms-of-use-dialog/edit-terms-of-use-dialog.component';

@Component({
  selector: 'dnf-terms-of-use',
  templateUrl: './terms-of-use.component.html',
  styleUrls: []
})
export class TermsOfUseComponent implements OnInit {
  content: any;
  @ViewChild('dataContainer') dataContainer: ElementRef;

  breadcrumbs = [
    {icon: 'flaticon-edit-1', text: 'LBL_TERMS_OF_USE'}
  ];

  constructor(
    private settingService: SettingsService,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
    this._getTermOfUse();
  }

  _getTermOfUse() {
    this.settingService.getTermsOfUse().subscribe(terms => {
      this.dataContainer.nativeElement.innerHTML = terms.content;
      this.content = terms.content;
    });
  }

  editTerms(): void {
    const dialogRef = this.dialog.open(EditTermsOfUseDialogComponent, {
      width: DIALOG_SIZE.medium,
      data: { editMode: true, item: this.content }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
    });
  }
}
