/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
	id: string;
}
declare var angular: any;
declare var mMenu: any;
declare var mUtil: any;
declare var mOffcanvas: any;
declare var mScrollTop: any;
declare var mToggle: any;
declare var mPortlet: any;

declare var Morris: any;

declare var $: JQueryStatic;