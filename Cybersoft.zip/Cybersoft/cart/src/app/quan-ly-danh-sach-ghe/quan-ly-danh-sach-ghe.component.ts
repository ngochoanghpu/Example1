import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DanhSachGheComponent } from '../danh-sach-ghe/danh-sach-ghe.component';

@Component({
  selector: 'app-quan-ly-danh-sach-ghe',
  templateUrl: './quan-ly-danh-sach-ghe.component.html',
  styleUrls: ['./quan-ly-danh-sach-ghe.component.css']
})
export class QuanLyDanhSachGheComponent implements OnInit {

  @ViewChild("pID") ele: ElementRef;
  ngOnInit(): void {
    // var s = document.getElementById("pID");
    // console.log(s.innerHTML);
    // var s = this.ele.nativeElement.innerHTML;
    // console.log(s);
  }
  title = 'angular6';
  @ViewChild("appDanhSachGhe") appDanhSachGhe:DanhSachGheComponent
  //Nhận giá trị từ 2 input trên html appComponent
  ThemGhe(soGhe:number, gia:number)
  {
    this.appDanhSachGhe.ThemGhe(soGhe, gia);
  }
}
