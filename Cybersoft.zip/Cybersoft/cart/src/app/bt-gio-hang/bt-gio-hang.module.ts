import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SanPhamComponent } from './san-pham/san-pham.component';
import { DanhSachSanPhamComponent } from './danh-sach-san-pham/danh-sach-san-pham.component';
import { GioHangComponent } from './gio-hang/gio-hang.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [SanPhamComponent, DanhSachSanPhamComponent, GioHangComponent],
  exports: [SanPhamComponent, DanhSachSanPhamComponent, GioHangComponent]
})
export class BtGioHangModule { }
