import { Component, OnInit, ViewChild } from '@angular/core';
import { GioHangComponent } from '../gio-hang/gio-hang.component';

@Component({
  selector: 'app-danh-sach-san-pham',
  templateUrl: './danh-sach-san-pham.component.html',
  styleUrls: ['./danh-sach-san-pham.component.css']
})
export class DanhSachSanPhamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  danhSachSanPham: SanPham[] =   
  [
    {
      "MaSP": 1,
      "TenSP": "HP-3175",
      "DonGia": 12000000,
      "HinhAnh": "http://sv.myclass.vn/images/sanpham/asus_1.jpg",
      "SoLuongTon": 14
    },
    {
        "MaSP": 2,
        "TenSP": "HP-3421s",
        "DonGia": 20000000,
        "HinhAnh": "http://sv.myclass.vn/images/sanpham/asus_1.jpg",
        "SoLuongTon": 14
    },
    {
        "MaSP": 3,
        "TenSP": "HP-3421s.png",
        "DonGia": 20000000,
        "HinhAnh": "http://sv.myclass.vn/images/sanpham/asus_1.jpg",
        "SoLuongTon": 1
    },
    {
        "MaSP": 4,
        "TenSP": "DELL-11721PS",
        "DonGia": 9200000,
        "HinhAnh": "http://sv.myclass.vn/images/sanpham/asus_1.jpg",
        "SoLuongTon": 52
    },
    {
        "MaSP": 5,
        "TenSP": "DELL-9943XL",
        "DonGia": 8500000,
        "HinhAnh": "http://sv.myclass.vn/images/sanpham/asus_1.jpg",
        "SoLuongTon": 34
    },
    {
      "MaSP": 208,
      "TenSP": "Macbook Air",
      "DonGia": 25000000,
      "HinhAnh": "http://sv.myclass.vn/images/sanpham/asus_1.jpg",
      "SoLuongTon": 20
    }
  ];

  gioHang: any[] = [];
  @ViewChild("gioHang") tagGioHang: GioHangComponent;

  ThemGioHang(spGioHang: any) {
    let index = this.gioHang.findIndex(r => r.MaSP == spGioHang.MaSP);
    if(index == -1){ //San pham chua co trong gio hang
      spGioHang.SoLuong = 1;
      spGioHang.ThanhTien = spGioHang.SoLuong * spGioHang.DonGia;
      this.gioHang.push(spGioHang);
    }
    else{ //Cap nhat so luong va don gia cua san pham trong gio hang
      this.gioHang[index].SoLuong += 1;
      this.gioHang[index].ThanhTien = this.gioHang[index].SoLuong * this.gioHang[index].DonGia;
    }
  }
}
