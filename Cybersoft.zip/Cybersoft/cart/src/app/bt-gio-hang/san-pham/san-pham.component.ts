import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-san-pham',
  templateUrl: './san-pham.component.html',
  styleUrls: ['./san-pham.component.css']
})
export class SanPhamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Input("sanpham") sanpham;
  @Output() eventThemGioHang = new EventEmitter();

  ThemGioHang() {
    let spGioHang: SanPham = {
      MaSP: this.sanpham.MaSP,
      TenSP: this.sanpham.TenSP,
      DonGia: this.sanpham.DonGia,
      HinhAnh: this.sanpham.HinhAnh,
      SoLuongTon: this.sanpham.SoLuongTon
    }

    this.eventThemGioHang.emit(spGioHang);
  }

}
