import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-gio-hang',
  templateUrl: './gio-hang.component.html',
  styleUrls: ['./gio-hang.component.css']
})
export class GioHangComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  TinhTongSL_TT() {

  }

}
