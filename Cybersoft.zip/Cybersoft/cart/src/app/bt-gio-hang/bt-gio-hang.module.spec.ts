import { BtGioHangModule } from './bt-gio-hang.module';

describe('BtGioHangModule', () => {
  let btGioHangModule: BtGioHangModule;

  beforeEach(() => {
    btGioHangModule = new BtGioHangModule();
  });

  it('should create an instance', () => {
    expect(btGioHangModule).toBeTruthy();
  });
});
