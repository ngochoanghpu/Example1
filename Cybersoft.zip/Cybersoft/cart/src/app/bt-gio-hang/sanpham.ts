interface SanPham {
    MaSP: number,
    TenSP: string,
    DonGia: number,
    HinhAnh: string,
    SoLuongTon: number
}