import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SinhvienComponent } from './sinhvien/sinhvien.component';
import { GheComponent } from './ghe/ghe.component';
import { DanhSachGheComponent } from './danh-sach-ghe/danh-sach-ghe.component';
import { QuanLyDanhSachGheComponent } from './quan-ly-danh-sach-ghe/quan-ly-danh-sach-ghe.component';
import { BaiTapDatGheModule } from './bai-tap-dat-ghe/bai-tap-dat-ghe.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BtGioHangModule } from './bt-gio-hang/bt-gio-hang.module';
import { NgFormModuleModule } from './ng-form-module/ng-form-module.module';

@NgModule({
  declarations: [
    AppComponent,
    SinhvienComponent,
    GheComponent,
    DanhSachGheComponent,
    QuanLyDanhSachGheComponent,
  ],
  imports: [
    BrowserModule,BaiTapDatGheModule, BrowserAnimationsModule, BtGioHangModule, NgFormModuleModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
