import { NgFormModuleModule } from './ng-form-module.module';

describe('NgFormModuleModule', () => {
  let ngFormModuleModule: NgFormModuleModule;

  beforeEach(() => {
    ngFormModuleModule = new NgFormModuleModule();
  });

  it('should create an instance', () => {
    expect(ngFormModuleModule).toBeTruthy();
  });
});
