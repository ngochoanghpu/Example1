import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgFormComponent } from './ng-form/ng-form.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [NgFormComponent],
  exports: [NgFormComponent]
})
export class NgFormModuleModule { }
