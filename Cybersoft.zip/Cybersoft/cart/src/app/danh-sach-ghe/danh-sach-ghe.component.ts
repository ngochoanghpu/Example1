import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-danh-sach-ghe',
  templateUrl: './danh-sach-ghe.component.html',
  styleUrls: ['./danh-sach-ghe.component.css']
})
export class DanhSachGheComponent implements OnInit {

  public DanhSachGhe:any[] = 
    [
      {SoGhe:1,Gia:10000},
      {SoGhe:2,Gia:20000},
      {SoGhe:3,Gia:30000}
    ];
  public DanhSachGheDuocChon:any[] = [];

  DatGhe(ttGhe:any) //Đối tượng thongTinGhe
  {
      //Dựa vào biến trạng thái xác định ghế đó có được chọn hay không
      if(ttGhe.TrangThai)
      {
        this.DanhSachGheDuocChon.push(ttGhe);
      }
      else
      {
          for(let index in this.DanhSachGheDuocChon)
          {
            if(this.DanhSachGheDuocChon[index].SoGhe == ttGhe.SoGhe)
            {
                this.DanhSachGheDuocChon.splice(Number(index),1);
            }
          }
      }
  }

  ThemGhe(soGhe:number,Gia:number)
  {
      let ghe = {SoGhe:soGhe, Gia:Gia};
      this.DanhSachGhe.push(ghe);
  }
  
  constructor() { }

  ngOnInit() {
  }

}
