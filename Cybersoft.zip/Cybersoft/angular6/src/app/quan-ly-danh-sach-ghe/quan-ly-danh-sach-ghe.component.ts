import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DanhSachGheComponent } from '../danh-sach-ghe/danh-sach-ghe.component';
import { Observer, Observable } from 'rxjs';

@Component({
  selector: 'app-quan-ly-danh-sach-ghe',
  templateUrl: './quan-ly-danh-sach-ghe.component.html',
  styleUrls: ['./quan-ly-danh-sach-ghe.component.css']
})
export class QuanLyDanhSachGheComponent implements OnInit {

  @ViewChild("pID") ele: ElementRef;
  ngOnInit(): void {
    // var s = document.getElementById("pID");
    // console.log(s.innerHTML);
    // var s = this.ele.nativeElement.innerHTML;
    // console.log(s);
  }
  title = 'angular6';
  @ViewChild("appDanhSachGhe") appDanhSachGhe:DanhSachGheComponent
  //Nhận giá trị từ 2 input trên html appComponent
  ThemGhe(soGhe:number,gia:number)
  {
    this.appDanhSachGhe.ThemGhe(soGhe, gia);
  }

  checkLogin() {
    var checkLoginObservable = new Observable((observer: Observer<any>) => {
        //Observer co 3 phuong thuc: next, error, complete
        setTimeout(() => {
          observer.next('da xong 3s');
        },300)
    })

    checkLoginObservable.subscribe(
      (kq) => {
        console.log(kq);
      }
    )

    console.log('truoc 3s');

    return checkLoginObservable;
  }
}
