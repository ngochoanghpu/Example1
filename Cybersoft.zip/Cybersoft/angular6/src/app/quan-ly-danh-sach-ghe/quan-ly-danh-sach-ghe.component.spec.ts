import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuanLyDanhSachGheComponent } from './quan-ly-danh-sach-ghe.component';

describe('QuanLyDanhSachGheComponent', () => {
  let component: QuanLyDanhSachGheComponent;
  let fixture: ComponentFixture<QuanLyDanhSachGheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuanLyDanhSachGheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuanLyDanhSachGheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
