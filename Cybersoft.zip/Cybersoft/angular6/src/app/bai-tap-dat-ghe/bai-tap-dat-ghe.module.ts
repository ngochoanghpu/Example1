import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BtGheComponent } from './bt-ghe/bt-ghe.component';
import { GheBusComponent } from './bt-ghe/ghe-bus/ghe-bus.component';
import { MaterialModule } from '../app.material';

@NgModule({
  imports: [
    CommonModule,MaterialModule
  ],
  declarations: [BtGheComponent, GheBusComponent],
  exports:[BtGheComponent,GheBusComponent]
})
export class BaiTapDatGheModule { }
