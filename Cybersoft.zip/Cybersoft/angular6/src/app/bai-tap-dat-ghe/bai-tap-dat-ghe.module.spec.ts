import { BaiTapDatGheModule } from './bai-tap-dat-ghe.module';

describe('BaiTapDatGheModule', () => {
  let baiTapDatGheModule: BaiTapDatGheModule;

  beforeEach(() => {
    baiTapDatGheModule = new BaiTapDatGheModule();
  });

  it('should create an instance', () => {
    expect(baiTapDatGheModule).toBeTruthy();
  });
});
