import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-ghe-bus',
  templateUrl: './ghe-bus.component.html',
  styleUrls: ['./ghe-bus.component.css']
})
export class GheBusComponent implements OnInit {

  @Output() eventDatGhe = new EventEmitter();
  @Input()ghe:any;
  public TrangThaiDangDat:boolean = false;
  constructor() { }
  DatGhe()
  {
    this.TrangThaiDangDat = !this.TrangThaiDangDat;
    let thongTinGhe = {SoGhe:this.ghe.SoGhe,Gia:this.ghe.Gia,TrangThaiDangDat:this.TrangThaiDangDat}
    this.eventDatGhe.emit(thongTinGhe);
  }
  ngOnInit() {
  }

}
