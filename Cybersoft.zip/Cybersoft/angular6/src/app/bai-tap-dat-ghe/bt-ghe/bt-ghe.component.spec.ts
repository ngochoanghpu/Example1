import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtGheComponent } from './bt-ghe.component';

describe('BtGheComponent', () => {
  let component: BtGheComponent;
  let fixture: ComponentFixture<BtGheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtGheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtGheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
