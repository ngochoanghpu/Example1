import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-ghe',
  templateUrl: './ghe.component.html',
  styleUrls: ['./ghe.component.css']
})
export class GheComponent implements OnInit {

  @Input() ghe:any; //Bên ngoài có thể truyền vào khi sử dụng thẻ này
  @Output() eventDatGhe = new EventEmitter();
  // @Output() eventKhac 
  private trangThai:boolean = false; //Thuộc tính đặt trưng không cho truyền vào
  constructor() { }

  DatGhe(){
    this.trangThai = !this.trangThai;   
    //Đưa dữ liệu ra ngoài khi button DatGhe => Click
    let thongTinGhe:any = {SoGhe:this.ghe.SoGhe, Gia:this.ghe.Gia,TrangThai: this.trangThai};
    this.eventDatGhe.emit(thongTinGhe);
  }
  
  ngOnInit() {
  }

}
