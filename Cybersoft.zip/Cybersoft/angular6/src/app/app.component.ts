import { Component,OnInit, ViewChild, ElementRef } from '@angular/core';
import { DanhSachGheComponent } from './danh-sach-ghe/danh-sach-ghe.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  ngOnInit(): void {

  }
  constructor(){

  }
  
}
