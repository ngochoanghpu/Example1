import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SinhvienComponent } from './sinhvien/sinhvien.component';
import { GheComponent } from './ghe/ghe.component';
import { DanhSachGheComponent } from './danh-sach-ghe/danh-sach-ghe.component';
import { QuanLyDanhSachGheComponent } from './quan-ly-danh-sach-ghe/quan-ly-danh-sach-ghe.component';
import { BaiTapDatGheModule } from './bai-tap-dat-ghe/bai-tap-dat-ghe.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SignInComponent } from './home-layout/sign-in/sign-in.component';
import { SignUpComponent } from './home-layout/sign-up/sign-up.component';

@NgModule({
  declarations: [
    AppComponent,
    SinhvienComponent,
    GheComponent,
    DanhSachGheComponent,
    QuanLyDanhSachGheComponent,
    SignInComponent,
    SignUpComponent,
  ],
  imports: [
    BrowserModule,BaiTapDatGheModule, BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
