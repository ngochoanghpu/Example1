import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-sinhvien]',
  templateUrl: './sinhvien.component.html',
  styleUrls: ['./sinhvien.component.css']
})
export class SinhvienComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
