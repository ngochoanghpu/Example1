import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import { NgModule } from '@angular/core';
import {MatMenuModule} from '@angular/material/menu';
import {MatTabsModule} from '@angular/material/tabs';


@NgModule({
  imports: [MatButtonModule, MatCheckboxModule,MatMenuModule,MatTabsModule],
  exports: [MatButtonModule, MatCheckboxModule,MatMenuModule,MatTabsModule],
})

export class MaterialModule { }