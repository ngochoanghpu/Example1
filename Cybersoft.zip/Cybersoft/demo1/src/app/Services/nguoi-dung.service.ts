import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { NguoiDung } from '../Models/NguoiDung';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class NguoiDungService {
    
  constructor(private _http: Http) { }

  transferSidebar_Phim = new Subject();

  DangKy(user: NguoiDung) {
    var api = `http://sv2.myclass.vn/api/QuanLyNguoiDung/ThemNguoiDung`;
    var headerDK = new Headers();
    headerDK.append('Content-Type', 'application/json;charset=UTF-8');
    var observe: Observable<any> = this._http.post(api, user, {headers: headerDK}).pipe(map((result: Response) => result.json()))
    return observe;
  }
}
