import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-sinh-vien',
  templateUrl: './sinh-vien.component.html',
  styleUrls: ['./sinh-vien.component.css']
})
export class SinhVienComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Input() sinhvienInfo: {Hoten: string, MSSV: string};
  @Output() emitSinhVien = new EventEmitter();

  ChonSinhVien = () => {
    // let object = {
    //   sinhVien: this.sinhvienInfo,
    //   lop: 'CT901'
    // }
    // this.emitSinhVien.emit(object);

    this.emitSinhVien.emit(this.sinhvienInfo);
  }
}
