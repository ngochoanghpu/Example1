import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-danh-sach-sinh-vien',
  templateUrl: './danh-sach-sinh-vien.component.html',
  styleUrls: ['./danh-sach-sinh-vien.component.css']
})
export class DanhSachSinhVienComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  StudentArray: {Hoten: string, MSSV: string} [] = [
    {Hoten: 'hoang nguyen', MSSV: 's01'},
    {Hoten: 'long nguyen', MSSV: 's02'},
    {Hoten: 'yen nguyen', MSSV: 's03'}
  ]

  ChoosenStudent: {Hoten: string, MSSV: string} [] = [];

  ChonSVParent = (value) => {
    var sinhvien =  this.ChoosenStudent.find(r => r.MSSV == value.MSSV);
    if(!sinhvien){
      this.ChoosenStudent.push(value);
    }
  }
}
