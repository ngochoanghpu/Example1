import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b1-header',
  templateUrl: './b1-header.component.html',
  styleUrls: ['./b1-header.component.css']
})
export class B1HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
