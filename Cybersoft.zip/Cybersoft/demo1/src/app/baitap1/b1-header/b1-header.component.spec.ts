import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { B1HeaderComponent } from './b1-header.component';

describe('B1HeaderComponent', () => {
  let component: B1HeaderComponent;
  let fixture: ComponentFixture<B1HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ B1HeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(B1HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
