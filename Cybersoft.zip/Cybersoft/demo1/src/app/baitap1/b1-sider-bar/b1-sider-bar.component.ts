import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b1-sider-bar',
  templateUrl: './b1-sider-bar.component.html',
  styleUrls: ['./b1-sider-bar.component.css']
})
export class B1SiderBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
