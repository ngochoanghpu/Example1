import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { B1SiderBarComponent } from './b1-sider-bar.component';

describe('B1SiderBarComponent', () => {
  let component: B1SiderBarComponent;
  let fixture: ComponentFixture<B1SiderBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ B1SiderBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(B1SiderBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
