import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b1-footer',
  templateUrl: './b1-footer.component.html',
  styleUrls: ['./b1-footer.component.css']
})
export class B1FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
