import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { B1FooterComponent } from './b1-footer.component';

describe('B1FooterComponent', () => {
  let component: B1FooterComponent;
  let fixture: ComponentFixture<B1FooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ B1FooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(B1FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
