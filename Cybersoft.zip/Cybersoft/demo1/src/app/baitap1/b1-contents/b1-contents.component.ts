import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b1-contents',
  templateUrl: './b1-contents.component.html',
  styleUrls: ['./b1-contents.component.css']
})
export class B1ContentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
