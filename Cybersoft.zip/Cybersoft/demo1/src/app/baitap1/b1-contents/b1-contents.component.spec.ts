import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { B1ContentsComponent } from './b1-contents.component';

describe('B1ContentsComponent', () => {
  let component: B1ContentsComponent;
  let fixture: ComponentFixture<B1ContentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ B1ContentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(B1ContentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
