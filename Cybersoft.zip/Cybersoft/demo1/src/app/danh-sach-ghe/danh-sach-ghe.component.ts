import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-danh-sach-ghe',
  templateUrl: './danh-sach-ghe.component.html',
  styleUrls: ['./danh-sach-ghe.component.css']
})
export class DanhSachGheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  public DanhSachGhe: any[] = [
    { SoGhe: 1, Gia: 10000 },
    { SoGhe: 2, Gia: 20000 },
    { SoGhe: 3, Gia: 30000 }
  ];

  public DanhSachGheDuocChon: any[] = [];

  DatGhe(ghe: any){
    var gheDuocChon =  this.DanhSachGheDuocChon.find(r => r.SoGhe == ghe.SoGhe);
    if(!gheDuocChon){
      this.DanhSachGheDuocChon.push(ghe);
    }
    else{
      this.DanhSachGheDuocChon = this.DanhSachGheDuocChon.filter(item => item.SoGhe != ghe.SoGhe);
    }
  }

  ThemGhe(SoGhe: number, Gia: number) {
    this.DanhSachGhe.push({
      SoGhe: SoGhe,
      Gia: Gia
    });
  }

  DatGhe1(ghe: any) {
    
  }

}
