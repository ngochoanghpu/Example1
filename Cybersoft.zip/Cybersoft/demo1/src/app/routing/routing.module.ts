import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SignUpComponent } from '../home-layout/sign-up/sign-up.component';
import { GheComponent } from '../ghe/ghe.component';
import { QuanLyDanhSachGheComponent } from '../quan-ly-danh-sach-ghe/quan-ly-danh-sach-ghe.component';

const appRoute: Routes = [
  { path: 'signup', component: SignUpComponent, children: [
      
     ]
  },
  { path: 'quan-ly-danh-sach-ghe/:id', component: QuanLyDanhSachGheComponent}
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoute)
  ],
  declarations: []
})
export class RoutingModule { }
