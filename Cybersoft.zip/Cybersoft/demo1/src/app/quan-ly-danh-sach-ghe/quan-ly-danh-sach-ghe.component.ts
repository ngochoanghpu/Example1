import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-quan-ly-danh-sach-ghe',
  templateUrl: './quan-ly-danh-sach-ghe.component.html',
  styleUrls: ['./quan-ly-danh-sach-ghe.component.css']
})
export class QuanLyDanhSachGheComponent implements OnInit {

  constructor(private _activatedRoute: ActivatedRoute) { }

  ngOnInit() {    
    this._activatedRoute.params.subscribe(
      (kq: any) => {
        console.log(kq);
      }
    )

    //var s = document.getElementById("pId");
    //console.log(s.innerHTML);

    //var s = this.ele.nativeElement.innerHTML;
    //console.log(s);
  }

  @ViewChild("pId") ele: ElementRef;
  @ViewChild("appDanhSachGhe") appDanhSachGhe: any;

  ThemGhe(soGhe: number, gia: number){
    this.appDanhSachGhe.ThemGhe(soGhe, gia);
  }
}
