
import {Component} from '@angular/core';

@Component({
    // template: `
    //     <h1>Hello World</h1>
    // `,

    templateUrl: './demo.component.html',
    // styles: [
    //     `
    //     h1 {
    //         color: red;
    //         font-size: 50px;
    //     }
    //     `
    // ],

    styleUrls: ['./demo.component.css'],
    selector: 'app-demo'
})
export class DemoComponent {

}