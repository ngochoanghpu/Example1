import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtGheComponentComponent } from './bt-ghe-component.component';

describe('BtGheComponentComponent', () => {
  let component: BtGheComponentComponent;
  let fixture: ComponentFixture<BtGheComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtGheComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtGheComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
