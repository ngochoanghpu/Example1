import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-bt-ghe-component',
  templateUrl: './bt-ghe-component.component.html',
  styleUrls: ['./bt-ghe-component.component.css']
})
export class BtGheComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Input() ghe: any;

  trangThaiDat: boolean = false;
}
