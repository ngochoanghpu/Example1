import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BtGheComponentComponent } from './bt-ghe-component/bt-ghe-component.component';
import { MaterialModule } from '../app.material';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule
  ],
  exports: [MaterialModule],
  declarations: [BtGheComponentComponent]
})
export class BtGheModuleModule { }
