import { BtGheModuleModule } from './bt-ghe-module.module';

describe('BtGheModuleModule', () => {
  let btGheModuleModule: BtGheModuleModule;

  beforeEach(() => {
    btGheModuleModule = new BtGheModuleModule();
  });

  it('should create an instance', () => {
    expect(btGheModuleModule).toBeTruthy();
  });
});
