import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-ghe',
  templateUrl: './ghe.component.html',
  styleUrls: ['./ghe.component.css']
})
export class GheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Input() ghe: any; //Ben ngoai co the truyen vao khi su dung the nay
  @Output() eventDatGhe =new EventEmitter();
  //@Output() eventKhac = new EventEmitter();
  private trangThai: boolean  = false; //Thuoc tinh dac trung ko cho truyen vao

  DatGhe() {
    this.trangThai = !this.trangThai;
    //Dua du lieu ra ngoai khi button DatGhe => click
    let thongTinGhe: any = {SoGhe: this.ghe.SoGhe, Gia: this.ghe.Gia, TrangThai: this.trangThai}
    this.eventDatGhe.emit(thongTinGhe);
  }

}
