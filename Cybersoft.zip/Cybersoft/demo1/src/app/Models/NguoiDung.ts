export class NguoiDung {
    TaiKhoan: string;
    MatKhau: string;
    Email: string;
    HoTen: string;
    MaNhom: string;
}