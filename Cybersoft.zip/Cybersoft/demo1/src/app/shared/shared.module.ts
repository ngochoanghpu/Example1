import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { RoutingModule } from '../routing/routing.module';
import { HttpModule } from '@angular/http';
import { SafePipe } from '../pipe/safe.pipe';

@NgModule({
  imports: [
    CommonModule, RouterModule, FormsModule, RoutingModule, HttpModule
  ],
  exports: [
    CommonModule, RouterModule, FormsModule, RoutingModule, SafePipe
  ],
  declarations: [SafePipe]
})
export class SharedModule { }
