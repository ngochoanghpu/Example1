import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import {NgForm} from '@angular/forms';
import { NguoiDungService } from '../../Services/nguoi-dung.service';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit, OnDestroy {

  constructor(private nguoiDungSV: NguoiDungService, private _router: Router) { }

  GetMovieSub: Subscription;

  ngOnInit() {
    //subscribe gia tri duoc luu trong transferSidebar_Phim
    this.nguoiDungSV.transferSidebar_Phim.subscribe(
      (kq: boolean) => {
        console.log(kq);
      },
      (error: any) => {
        console.log(error);
      }
    )

    //this._router.navigate['/quan-ly-danh-sach-ghe.html']

    // let value: any;
    // this.GetMovieSub = this.nguoiDungSV.DangKy(value).subscribe(
    //   (kq: any) => {
    //     console.log(kq);
    //   },
    //   (error: any) => {
    //     console.log(error);
    //   }
    // )
  }

  ngOnDestroy() {
    //this.GetMovieSub.unsubscribe();
  }

  

  DangKy(value) {
    value.MaNhom = 'GP01';
    this.nguoiDungSV.DangKy(value).subscribe(
      (kq: any) => {
        console.log(kq);
      },
      (error: any) => {
        console.log(error);
      }
    )
  }

  @ViewChild('formDangKy') DKForm: NgForm;

  statusPhim: boolean = true;  
  statusSidebar: boolean = true;

  ToggleText = () => {    
    this.statusSidebar = !this.statusSidebar;
    //let obj: any = { statusPhim: this.statusPhim, statusSidebar: this.statusSidebar};
    this.nguoiDungSV.transferSidebar_Phim.next(this.statusSidebar);
  }

  setValue() {
    this.DKForm.setValue({
      TaiKhoan: 'hoang nguyen'
    });    
  }

}
