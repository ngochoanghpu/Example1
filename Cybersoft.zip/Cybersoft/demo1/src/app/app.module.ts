import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import {DemoComponent} from './demo/demo.component';
import { Baitap1Component } from './baitap1/baitap1.component';
import { B1HeaderComponent } from './baitap1/b1-header/b1-header.component';
import { B1FooterComponent } from './baitap1/b1-footer/b1-footer.component';
import { B1SiderBarComponent } from './baitap1/b1-sider-bar/b1-sider-bar.component';
import { B1ContentsComponent } from './baitap1/b1-contents/b1-contents.component';
import { BusinessLayoutComponent } from './business-layout/business-layout.component';
import { BHeaderComponent } from './business-layout/b-header/b-header.component';
import { BCarouselComponent } from './business-layout/b-carousel/b-carousel.component';
import { BContentsComponent } from './business-layout/b-contents/b-contents.component';
import { BFooterComponent } from './business-layout/b-footer/b-footer.component';
import { BItemComponent } from './business-layout/b-contents/b-item/b-item.component';
import { OneWayComponent } from './one-way/one-way.component';
import { FormComponent } from './form/form.component';
import { MyFormComponent } from './my-form/my-form.component';
import { LoginComponent } from './my-form/login/login.component';
import { RegisterComponent } from './my-form/register/register.component';
import { DanhSachSinhVienComponent } from './danh-sach-sinh-vien/danh-sach-sinh-vien.component';
import { SinhVienComponent } from './danh-sach-sinh-vien/sinh-vien/sinh-vien.component';
import { GheComponent } from './ghe/ghe.component';
import { DanhSachGheComponent } from './danh-sach-ghe/danh-sach-ghe.component';
import { QuanLyDanhSachGheComponent } from './quan-ly-danh-sach-ghe/quan-ly-danh-sach-ghe.component';
import { BtGheModuleModule } from './bt-ghe-module/bt-ghe-module.module';
import { SignUpComponent } from './home-layout/sign-up/sign-up.component';
import { HttpModule } from '@angular/http';
//import { RoutingModule } from './routing/routing.module';
//import { RouterModule, Routes } from '@angular/router';
//import { RoutingModule } from './routing/routing.module';
import { SharedModule } from './shared/shared.module';

@NgModule({
  declarations: [
    AppComponent,
    DemoComponent,
    Baitap1Component,    
    B1HeaderComponent,
    B1FooterComponent,
    B1SiderBarComponent,
    B1ContentsComponent,
    BusinessLayoutComponent,
    BHeaderComponent,
    BCarouselComponent,
    BContentsComponent,
    BFooterComponent,
    BItemComponent,
    OneWayComponent,
    FormComponent,
    MyFormComponent,
    LoginComponent,
    RegisterComponent,
    DanhSachSinhVienComponent,
    SinhVienComponent,
    GheComponent,
    DanhSachGheComponent,
    QuanLyDanhSachGheComponent,
    SignUpComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BtGheModuleModule,
    HttpModule,
    SharedModule
    //RouterModule,
    
    //RoutingModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
