import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-layout',
  templateUrl: './business-layout.component.html',
  styleUrls: ['./business-layout.component.css']
})
export class BusinessLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
