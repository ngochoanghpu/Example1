import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b-carousel',
  templateUrl: './b-carousel.component.html',
  styleUrls: ['./b-carousel.component.css']
})
export class BCarouselComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
