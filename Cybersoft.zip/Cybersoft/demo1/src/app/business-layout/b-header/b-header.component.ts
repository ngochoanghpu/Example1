import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b-header',
  templateUrl: './b-header.component.html',
  styleUrls: ['./b-header.component.css']
})
export class BHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
