import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b-footer',
  templateUrl: './b-footer.component.html',
  styleUrls: ['./b-footer.component.css']
})
export class BFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
