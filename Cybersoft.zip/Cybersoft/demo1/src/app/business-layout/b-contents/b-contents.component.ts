import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b-contents',
  templateUrl: './b-contents.component.html',
  styleUrls: ['./b-contents.component.css']
})
export class BContentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
