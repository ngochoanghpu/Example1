import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BContentsComponent } from './b-contents.component';

describe('BContentsComponent', () => {
  let component: BContentsComponent;
  let fixture: ComponentFixture<BContentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BContentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BContentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
