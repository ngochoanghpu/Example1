import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BItemComponent } from './b-item.component';

describe('BItemComponent', () => {
  let component: BItemComponent;
  let fixture: ComponentFixture<BItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
