import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b-item',
  templateUrl: './b-item.component.html',
  styleUrls: ['./b-item.component.css']
})
export class BItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
