import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-one-way',
  templateUrl: './one-way.component.html',
  styleUrls: ['./one-way.component.css']
})
export class OneWayComponent implements OnInit {
  name:string = "hoang";
  src: string = "https://picsum.photos/200";
  fullName: string;
  age: number;
  newFullName: string;
  isShowDiv: boolean = true;
  Month: number;
  MonthArray: string[] = ['Thang 1', 'Thang 2', 'Thang 3', 'Thang 4', 'Thang 5', 'Thang 6', 'Thang 7', 'Thang 8', 'Thang 9', 'Thang 10', 'Thang 11', 'Thang 12'];
  status: boolean = false;

  constructor() { 
    this.age = 100;
    this.newFullName = "";
  }

  ngOnInit() {

  }

  HienPhimDangChieu = () => {
    this.status = true;
  }

  HienPhimSapChieu = () => {
    this.status = false;
  }

  Toggle() {
    this.isShowDiv = !this.isShowDiv;
  }

  ChooseMonth = (month) => {
      this.Month = month;
  }

  getFullName(name): void {
    this.fullName = name;
  }

  GetAge = (age) => {
    console.log("Age: " + age);
  }

  getNewFullName() {
    //this.newFullName ="hoang nguyen";
    (<HTMLInputElement>document.getElementById('txtFullName')).value = 'Angular 6';
  }
}
