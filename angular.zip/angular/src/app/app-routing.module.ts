import { ABP, AuthGuard, PermissionGuard } from '@abp/ng.core';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicationLayoutComponent } from '@volo/abp.ng.theme.lepton';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./home/home.module').then((m) => m.HomeModule),
    data: {
      routes: {
        name: '::Menu:Home',
        iconClass: 'fa fa-home',
      } as ABP.Route,
    },
  },
  // {
  //   path: 'dashboard',
  //   loadChildren: () => import('./dashboard/dashboard.module').then((m) => m.DashboardModule),
  //   canActivate: [AuthGuard, PermissionGuard],
  //   data: {
  //     routes: {
  //       name: '::Menu:Dashboard',
  //       iconClass: 'fa fa-line-chart',
  //       requiredPolicy: 'kitchen.Dashboard.Host || AbpAccount.SettingManagement',
  //     } as ABP.Route,
  //   },
  // },
  // {
  //   path: 'identity',
  //   loadChildren: () => import('@volo/abp.ng.identity').then((m) => m.IdentityModule),
  // },
  {
    path: 'account',
    loadChildren: () => import('@volo/abp.ng.account').then((m) => m.AccountModule),
  },
  // {
  //   path: 'language-management',
  //   loadChildren: () =>
  //     import('@volo/abp.ng.language-management').then((m) => m.LanguageManagementModule),
  // },
  // {
  //   path: 'saas',
  //   loadChildren: () => import('@volo/abp.ng.saas').then((m) => m.SaasModule),
  // },
  // {
  //   path: 'audit-logs',
  //   loadChildren: () => import('@volo/abp.ng.audit-logging').then((m) => m.AuditLoggingModule),
  // },
  // {
  //   path: 'identity-server',
  //   loadChildren: () => import('@volo/abp.ng.identity-server').then((m) => m.IdentityServerModule),
  // },
  // {
  //   path: 'text-template-management',
  //   loadChildren: () =>
  //     import('@volo/abp.ng.text-template-management').then((m) => m.TextTemplateManagementModule),
  // },
  // {
  //   path: 'setting-management',
  //   loadChildren: () => import('@abp/ng.setting-management').then((m) => m.SettingManagementModule),
  // },
  {
    path: 'kitchen',    
    component: ApplicationLayoutComponent,
    loadChildren: () => import('./kitchen/teaMilk/tea-milk.module').then(m => m.TeaMilkModule),
    canActivate: [AuthGuard],
    data: {
      routes: {
        iconClass: 'fas fa-utensils',
        name: 'Bếp Bar',
        invisible: true,
        children: [
          {
            path: 'tea-milk',
            //requiredPolicy: 'MRP.MRPRuleDetails',
            name: 'Trà Sữa'
          },
          {
            path: 'restaurant',
            //requiredPolicy: 'MRP.MRPRuleDetails',
            name: 'Nhà Hàng'
          }
        ],
      } as ABP.Route,
    },
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
