import { ABP } from '@abp/ng.core';

// tslint:disable-next-line: no-namespace
export namespace ProductMasterData {
  export interface ProductCategory {
    code?: string;
    name?: string;
    id?: number;
  }

  export interface Product {
    id?: number;
    sku?: string;
    name?: string;
    shortName?: string;
    warrantyDay?: number;
    warrantyMonth?: number;
    barCode1?: string;
    barCode2?: string;
    isLot?: boolean;
    isBOM?: boolean;
    isSalable?: boolean;
    isConsumable?: boolean;
    isDirectOnly?: boolean;
    isStockControl?: boolean;
    isSerialControl?: boolean;
    uomCode?: string;
    uomName?: string;
    uosCode?: string;
    uosName?: string;
    uopCode?: string;
    uopName?: string;
    avatarText?: string;
    avatarPath?: string;
    categories?: ProductCategory[];
    productGroupCode?: string;
    productGroupIndex?: number;
  }

  export interface ProductWithPrice extends Product {
    taxPercent?: number;
    extractFromPrice?: boolean;
    unitPrice?: number;
    shortName?: string;
    // Additional
    slug?: string;
    productGroupName?: string;
  }

  export interface ProductResponse {
    totalCount: number;
    items: Product[];
  }

  export interface ProductQueryParams {
    forSalesOnly?: boolean;
    includeCategory?: boolean;
    includeUom?: boolean;
    includeUos?: boolean;
    includeUop?: boolean;
    includeAvatar?: boolean;
    storeCode: string;
    language: string;
  }

  export class ProductAssociate {
    assStatusCode?: string;
    assStatusName?: string;
    assUosCode?: string;
    assUosName?: string;
    productSku?: string;
    productName?: string;
    productBarCode1?: string;
    productBarCode2?: string;
    productUosCode?: string;
    productUosName?: string;
    productUomCode?: string;
    productUomName?: string;
    productIsLot?: boolean;
    productIsBom?: boolean;
    productIsSalable?: boolean;
    productIsConsumable?: boolean;
    productIsStockControl?: boolean;
    productIsSerialControl?: boolean;
    assName?: string;
    assCode?: string;
    isFundamental?: boolean;
    groupIndex?: number;
    itemIndex?: number;
    minQuantity?: number;
    maxQuantity?: number;
    assLayoutCode?: string;
    assLayoutName?: string;
  }

  export interface ProductAssociateWithPrice extends ProductAssociate {
    taxPercent?: number;
    extractFromPrice?: boolean;
    unitPrice?: number;
    shortName?: string;
    // Additional
    slug?: string;
    productGroupName?: string;
  }

  export class ProductAssociateResponse {
    assProducts: ProductAssociate[];
  }
}
