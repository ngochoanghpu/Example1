import { ABP } from '@abp/ng.core';

// tslint:disable-next-line: no-namespace
export namespace MasterData {
  export interface State {
    stores: StoreMasterDataItemResponse;
  }

  export interface StoreMasterDataItemResponse {
    items: StoreMasterDataItem[];
  }

  export interface StoreMasterDataItem {
    id: number;
    code: string;
    name: string;
    warehouses: WareHouseMasterDataItem[];
  }

  export interface WareHouseMasterDataItem {
    code: string;
    name: string;
  }

  export class CurrentUser {
    id: string;
    userName: string;
    email: string;
  }

  export class EmployeeUser {
    id: string;
    userName: string;
    email: string;
  }

  export interface MSaleOrderTypeDto {
    orderTypeCode: string;
    paymentRuleType: boolean;
    paymentMinValue: number;
    bookInventory?: boolean;
    processInventory?: boolean;
    includeIntransit?: boolean;
    invoice?: boolean;
    isActive?: boolean;
    orderTypeName: string;
    lang: string;
  }

  export interface MCustomer {
    code: string;
    fullName: string;
    address: string;
    phone: string;
    debt?: number;
    loyaltyPoint?: number;
  }

  export interface MCustomerModel extends MCustomer {
    displayName: string;
    loyaltyPointOrigin?: number;
  }

  export interface MCustomerResponse {
    totalCount: number;
    items: MCustomer[];
  }

  // --------------------------------------------------------------
  /**
   * Search result from Mdm
   */
  export interface ProductSearchResponse {
    totalCount: number;
    items: ProductItem[];
  }

  export interface ProductSearchResponseFromMProduct {
    totalCount: number;
    items: ProductDto[];
  }
  /**
   * Search result from Mdm
   */
  export interface ProductHierarchyResponse {
    totalCount: number;
    items: ProductHierarchyItem[];
  }
  /**
   * Search result from Mdm
   */
  export class ProductItem {
    barCode1: string;
    barCode2: string;
    sku: string;
    isSerialControl: boolean;
    isLot: boolean;
    code: string;
    name: string;

    displayName: string;
    isStockControl: boolean;
    taxPercent: number;
    extractFromPrice: boolean;

    isCheckedInventory: boolean;
    uom?: MasterData.uom;
  }

  export interface uom {
    code: string;
    shortName: string;
    shortPluralName: string;
    fullName: string;
    fullPluralName: string;
    id: number;
  }

  export interface MProduct {
    barCode1: string;
    barCode2: string;
    itemCode: string;
    isLotControl?: boolean;
    isSerialControl?: boolean;
    isStockControl?: boolean;
    uosCode: string;
    uopCode: string;
    uomCode: string;
    avatarPath: string;
    isActive?: boolean;
    itemName: string;
    lang: string;
    taxPercent?: number;
    extractFromPrice?: boolean;
    unitPrice?: number;

    shortName: string;
    // Additional
    slug?: string; // For search - filter
  }

  export interface MProductReponse {
    totalCount: number;
    items: MProduct[];
  }

  export class ProductDto {
    barCode1: string;
    barCode2: string;
    itemCode: string;
    isSerialControl: boolean;
    isLotControl: boolean;
    isStockControl: string;
    uosCode: string;
    uopCode: string;
    uomCode: string;
    avatarPath: string;
    isActive?: boolean;
    productName: string;
    uomName: string;
    isCheckedInventory: boolean;
    displayName: string;
  }

  /**
   * Search result from Mdm
   */
  export class ProductHierarchyItem {
    parentId: number;
    id: number;
    name: string;
  }

  export interface ProductSearchParams {
    sku?: string;
  }

  export interface ProductSearchQueryParams {
    freeText: string;
  }

  export interface ProductSearchBySKUsParams {
    itemCodes: string[];
  }

  // --------------------------------------------------------------
  // tslint:disable-next-line: no-empty-interface
  export interface StoreQueryParams extends ABP.PageQueryParams, MasterDataCommonParams {
    includeWarehouses: boolean;
  }

  export interface WareHouseQueryParams {
    storeCode: string;
  }

  export interface MasterDataCommonParams {
    language: string;
  }

  export interface MProductSearchParams extends ABP.PageQueryParams {
    filterText?: string;
    barCode1?: string;
    barCode2?: string;
    itemCode?: string;
    isLotControl?: boolean;
    isSerialControl?: boolean;
    isStockControl?: boolean;
    isActive?: boolean;
    itemCodes?: string[];
  }

  export interface UserInfoDto {
    userName: string;
    email: string;
    name: string;
    surname: string;
    emailConfirmed: boolean;
    phoneNumber: string;
  }

  export interface ModifiedResponseDto {
    isSuccess: boolean;
    message: string;
  }

  export interface MSalesChannelResponse {
    totalCount: number;
    items: MSalesChannelDto[];
  }

  export interface MSalesChannelDto {
    channelCode: string;
    isActive: boolean;
    id: string;
    salesChannelLangs: MSalesChannelLangDto;
  }

  export interface MSalesChannelLangDto {
    channelCode: string;
    channelName: string;
    lang: string;
    id: string;
  }

  // ToMinh --------------------------------------------------------------

  export interface SearchProductParam extends ABP.PageQueryParams {
    includeAvatar: boolean;
    includeGallery: boolean;
    includeUom: boolean;
    language;
  }

  export interface ProductReponse {
    totalCount: number;
    items: ProductSearchItem[];
  }

  export interface ProductAvarar {
    text: string;
    path: string;
  }

  export interface ProductUOM {
    code: string;
    shortName: string;
    shortPluralName: string;
    fullName: string;
    fullPluralName: string;
    id: number;
  }

  export interface ProductInterfaceItem {
    type: string;
    filename: string;
    fullpath: string;
    filesize: number;
    mimetype: string;
    id: number;
  }
  export interface ProductSearchItem {
    sku: string;
    name: string;
    shortName: string;
    warrantyDay: number;
    warrantyMonth: number;
    barCode1: string;
    barCode2: string;
    isLot: true;
    isBOM: true;
    isSalable: true;
    isConsumable: true;
    isDirectOnly: true;
    isStockControl: true;
    isSerialControl: true;
    avatar: ProductAvarar;
    uom: ProductUOM;
    gallery: ProductInterfaceItem[];
    id: number;
    unitPrice: number;
  }

  export class CommonGroup {
    itemCode?: string;
    itemName?: string;
    itemIndex?: number;
    groupCode?: string;
  }

  export interface CommonResponse {
    totalCount?: number;
    items?: CommonGroup[];
  }

  export interface BankResponse {
    totalCount: number;
    items: BankItem[];
  }

  export interface BankItem {
    code: string;
    name: string;
  }

  export interface CancelReasonItem {
    itemCode: string;
    itemName: string;
    itemIndex: number;
    groupCode: string;
    id: number;
  }

  export class ProductGroupSortOrder extends MasterData.CommonGroup {
    index: number;
  }
}
