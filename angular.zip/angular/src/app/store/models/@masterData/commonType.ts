import { ABP } from '@abp/ng.core';

// tslint:disable-next-line: no-namespace
export namespace CommonType {
  export class PaymentMethod {
    statusCode?: string;
    statusName?: string;
    allowPointsAccumulation?: boolean;
    code?: string;
    name?: string;
  }

  export class PaymentMethodResponse {
    totalCount?: number;
    items?: PaymentMethod[];
  }

  export class Bank {
    statusCode?: string;
    statusName?: string;
    code?: string;
    name?: string;
  }

  export class BankResponse {
    totalCount?: number;
    items?: Bank[];
  }

  export class BankAccount {
    bankCode: string;
    bankName: string;
    statusCode: string;
    statusName: string;
    accNumber: string;
    accHolder: string;
  }

  export class BankAccountResponse {
    totalCount?: number;
    items?: BankAccount[];
  }
}
