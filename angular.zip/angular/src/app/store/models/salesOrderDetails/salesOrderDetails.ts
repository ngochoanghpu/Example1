import { ABP } from '@abp/ng.core';


export namespace SalesOrderDetails {
    export interface State {
        salesOrderDetails: Response;
    }

    export interface Response {
        items: SalesOrderDetail[];
        totalCount: number;
    }

    

    export interface SalesOrderDetailsQueryParams extends ABP.PageQueryParams {
        filterText?: string;
        salesOrderId?: string;
salesOrderDetailId?: string;
sequentiaNumberMax?: number;
sequentiaNumberMin?: number;
barCode1?: string;
barCode2?: string;
itemCode?: string;
productName?: string;
serialNumber?: string;
lotNumber?: string;
uOSCode?: string;
uOSName?: string;
uOSQuantityMax?: number;
uOSQuantityMin?: number;
uOMCode?: string;
uOMQuantityMax?: number;
uOMQuantityMin?: number;
notes?: string;
isChild?: boolean;
indexNumberMax?: number;
indexNumberMin?: number;
salesOrderDetailStaus?: string;
isOptional?: boolean;
productHierarchyCode?: string;
productHierarchyName?: string;
productHierarchyOrderMax?: number;
productHierarchyOrderMin?: number;
recievedDateTimeMax?: string;
recievedDateTimeMin?: string;
performedById?: string;
performedByName?: string;
performedDateTimeMax?: string;
performedDateTimeMin?: string;
kitchenStaus?: string;

    }

    export interface SalesOrderDetail {
        id: string;
        salesOrderId: string;
salesOrderDetailId: string;
sequentiaNumber: number;
barCode1: string;
barCode2: string;
itemCode: string;
productName: string;
serialNumber: string;
lotNumber: string;
uOSCode: string;
uOSName: string;
uOSQuantity: number;
uOMCode: string;
uOMQuantity: number;
notes: string;
isChild: boolean;
indexNumber: number;
salesOrderDetailStaus: string;
isOptional: boolean;
productHierarchyCode: string;
productHierarchyName: string;
productHierarchyOrder: number;
recievedDateTime: string;
performedById: string;
performedByName: string;
performedDateTime: string;
kitchenStaus: string;

    }

    export interface SalesOrderDetailCreateUpdateDto {
        salesOrderId: string;
salesOrderDetailId: string;
sequentiaNumber: number;
barCode1: string;
barCode2: string;
itemCode: string;
productName: string;
serialNumber: string;
lotNumber: string;
uOSCode: string;
uOSName: string;
uOSQuantity: number;
uOMCode: string;
uOMQuantity: number;
notes: string;
isChild: boolean;
indexNumber: number;
salesOrderDetailStaus: string;
isOptional: boolean;
productHierarchyCode: string;
productHierarchyName: string;
productHierarchyOrder: number;
recievedDateTime: string;
performedById: string;
performedByName: string;
performedDateTime: string;
kitchenStaus: string;

    }
}
