import { ABP } from '@abp/ng.core';


export namespace SalesOrders {
    export interface State {
        salesOrders: Response;
    }

    export interface Response {
        items: SalesOrder[];
        totalCount: number;
    }

    

    export interface SalesOrdersQueryParams extends ABP.PageQueryParams {
        filterText?: string;
        salesOrderId?: string;
storeCode?: string;
storeName?: string;
employeeId?: string;
employeeName?: string;
orderNo?: string;
orderType?: string;
orderTypeName?: string;
orderDateTimeMax?: string;
orderDateTimeMin?: string;
orderStatus?: string;
orderStatusName?: string;
salesChannelCode?: string;
salesChannelName?: string;
hasDelivery?: boolean;
notes?: string;
waitingNumber?: string;
isTakeAway?: boolean;
pickingTimeMax?: string;
pickingTimeMin?: string;
snoozingTimeMax?: string;
snoozingTimeMin?: string;
recievedDateTimeMax?: string;
recievedDateTimeMin?: string;
performedById?: string;
performedByName?: string;
performedDateTimeMax?: string;
performedDateTimeMin?: string;
kitchenStaus?: string;

    }

    export interface SalesOrder {
        id: string;
        salesOrderId: string;
storeCode: string;
storeName: string;
employeeId: string;
employeeName: string;
orderNo: string;
orderType: string;
orderTypeName: string;
orderDateTime: string;
orderStatus: string;
orderStatusName: string;
salesChannelCode: string;
salesChannelName: string;
hasDelivery: boolean;
notes: string;
waitingNumber: string;
isTakeAway: boolean;
pickingTime: string;
snoozingTime: string;
recievedDateTime: string;
performedById: string;
performedByName: string;
performedDateTime: string;
kitchenStaus: string;

    }

    export interface SalesOrderCreateUpdateDto {
        salesOrderId: string;
storeCode: string;
storeName: string;
employeeId: string;
employeeName: string;
orderNo: string;
orderType: string;
orderTypeName: string;
orderDateTime: string;
orderStatus: string;
orderStatusName: string;
salesChannelCode: string;
salesChannelName: string;
hasDelivery: boolean;
notes: string;
waitingNumber: string;
isTakeAway: boolean;
pickingTime: string;
snoozingTime: string;
recievedDateTime: string;
performedById: string;
performedByName: string;
performedDateTime: string;
kitchenStaus: string;

    }
}
