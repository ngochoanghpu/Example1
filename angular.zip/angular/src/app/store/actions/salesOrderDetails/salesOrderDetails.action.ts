import { SalesOrderDetails } from '../../models';

export class GetSalesOrderDetails {
    static readonly type = '[SalesOrderDetails] Get';
    constructor(public payload?: SalesOrderDetails.SalesOrderDetailsQueryParams) { }
}

export class CreateUpdateSalesOrderDetail {
    static readonly type = '[SalesOrderDetails] Create Update SalesOrderDetail';
    constructor(public payload: SalesOrderDetails.SalesOrderDetailCreateUpdateDto, public id?: string) { }
}

export class DeleteSalesOrderDetail {
    static readonly type = '[SalesOrderDetails] Delete';
    constructor(public id: string) { }
}