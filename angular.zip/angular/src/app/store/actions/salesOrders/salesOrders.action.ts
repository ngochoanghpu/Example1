import { SalesOrders } from '../../models';

export class GetSalesOrders {
    static readonly type = '[SalesOrders] Get';
    constructor(public payload?: SalesOrders.SalesOrdersQueryParams) { }
}

export class CreateUpdateSalesOrder {
    static readonly type = '[SalesOrders] Create Update SalesOrder';
    constructor(public payload: SalesOrders.SalesOrderCreateUpdateDto, public id?: string) { }
}

export class DeleteSalesOrder {
    static readonly type = '[SalesOrders] Delete';
    constructor(public id: string) { }
}