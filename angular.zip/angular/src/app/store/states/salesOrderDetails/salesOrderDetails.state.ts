import { Injectable } from '@angular/core';
import { State, Action, StateContext, Selector } from '@ngxs/store';
import { GetSalesOrderDetails, CreateUpdateSalesOrderDetail, DeleteSalesOrderDetail  } from '../../actions/salesOrderDetails/salesOrderDetails.action';
import { SalesOrderDetails } from '../../models/salesOrderDetails/salesOrderDetails';
import { SalesOrderDetailsService } from '../../../salesOrderDetails/salesOrderDetails/salesOrderDetails.service';
import { tap } from 'rxjs/operators';

@State<SalesOrderDetails.State> ({
  name: 'SalesOrderDetailsState',
  defaults: { salesOrderDetails: {} } as SalesOrderDetails.State
})
@Injectable()
export class SalesOrderDetailsState {
    @Selector()
    static getSalesOrderDetails(state: SalesOrderDetails.State) {
        return state.salesOrderDetails.items || [];
    }

	@Selector()
    static getTotalCount(state: SalesOrderDetails.State): number {
        return state.salesOrderDetails.totalCount || 0;
    }

    constructor(private salesOrderDetailsService: SalesOrderDetailsService) { }
		
    @Action(GetSalesOrderDetails)
    get({ patchState }: StateContext<SalesOrderDetails.State>, { payload }: GetSalesOrderDetails) {
        return this.salesOrderDetailsService.get(payload).pipe(
            tap(salesOrderDetailsResponse => {
                patchState({
                    salesOrderDetails: salesOrderDetailsResponse,
                });
            }),
        );
    }

    @Action(CreateUpdateSalesOrderDetail)
    save(ctx: StateContext<SalesOrderDetails.State>, action: CreateUpdateSalesOrderDetail) {
        let request;

        if (action.id) {
            request = this.salesOrderDetailsService.update(action.payload, action.id);
        } else {
            request = this.salesOrderDetailsService.create(action.payload);
        }
		
        return request;
    }

    @Action(DeleteSalesOrderDetail)
    delete(ctx: StateContext<SalesOrderDetails.State>, action: DeleteSalesOrderDetail) {
        return this.salesOrderDetailsService.delete(action.id);
    }
}
