import { Injectable } from '@angular/core';
import { State, Action, StateContext, Selector } from '@ngxs/store';
import { GetSalesOrders, CreateUpdateSalesOrder, DeleteSalesOrder  } from '../../actions/salesOrders/salesOrders.action';
import { SalesOrders } from '../../models/salesOrders/salesOrders';
import { SalesOrdersService } from '../../../salesOrders/salesOrders/salesOrders.service';
import { tap } from 'rxjs/operators';

@State<SalesOrders.State> ({
  name: 'SalesOrdersState',
  defaults: { salesOrders: {} } as SalesOrders.State
})
@Injectable()
export class SalesOrdersState {
    @Selector()
    static getSalesOrders(state: SalesOrders.State) {
        return state.salesOrders.items || [];
    }

	@Selector()
    static getTotalCount(state: SalesOrders.State): number {
        return state.salesOrders.totalCount || 0;
    }

    constructor(private salesOrdersService: SalesOrdersService) { }
		
    @Action(GetSalesOrders)
    get({ patchState }: StateContext<SalesOrders.State>, { payload }: GetSalesOrders) {
        return this.salesOrdersService.get(payload).pipe(
            tap(salesOrdersResponse => {
                patchState({
                    salesOrders: salesOrdersResponse,
                });
            }),
        );
    }

    @Action(CreateUpdateSalesOrder)
    save(ctx: StateContext<SalesOrders.State>, action: CreateUpdateSalesOrder) {
        let request;

        if (action.id) {
            request = this.salesOrdersService.update(action.payload, action.id);
        } else {
            request = this.salesOrdersService.create(action.payload);
        }
		
        return request;
    }

    @Action(DeleteSalesOrder)
    delete(ctx: StateContext<SalesOrders.State>, action: DeleteSalesOrder) {
        return this.salesOrdersService.delete(action.id);
    }
}
