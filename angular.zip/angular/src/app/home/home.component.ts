import { Component } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { MasterDataService } from '../shared/services/mdm/mdm.service';
import { MatSelectChange } from '@angular/material/select';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { GLOBAL } from '../shared/constant/global';
import { ConfigStateService, Config } from '@abp/ng.core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  get hasLoggedIn(): boolean {
    return this.oAuthService.hasValidAccessToken();
  }

  currentUser = "";
  userName = "";
  currentStoreCode = "";
  currentStoreTypeCode = "";
  showStoreDropdownPopup = false;
  isSelectedStoreLine = false;
  selectedStore = null;
  selectedStoreLine = null;
  stores: any = [];
  lines = [];

  constructor(private oAuthService: OAuthService,
    private router: Router,
    private configStateService: ConfigStateService,
    private configService: ConfigStateService,
    private masterDataService: MasterDataService,) {

    this.currentUser = this.configStateService.getOne("currentUser");
    this.userName = this.currentUser['userName'];

    this.getStoresIncludeStoreLines();
  }

  getStoresIncludeStoreLines() {
    if(this.hasLoggedIn) {
      const currentLanguage = this.configService.getDeep('localization.currentCulture.cultureName');
      this.masterDataService.getStoresIncludeStoreLines(this.userName, currentLanguage).subscribe(data => {
        this.stores = data.items.filter(s => s.storeTypeCode.toLowerCase() != GLOBAL.Bakery.toLowerCase()).map(x => {
          return {
             code: x.code,
             name: x.name,
             lines: x.lines,
             storeTypeCode: x.storeTypeCode
          }
        });

        this.showStoreDropdownPopup = true;

        //Auto fill first item store and storeLine
        if(this.stores && this.stores.length > 0) {
          this.selectedStore = this.stores[0].code;
          this.currentStoreCode = this.stores[0].code;
          this.currentStoreTypeCode = this.stores[0].storeTypeCode;
          this.lines = this.stores[0].lines.filter(x => x.lineTypeCode.toLowerCase().indexOf(GLOBAL.Cashier.toLowerCase()) == -1);
          if(this.lines && this.lines.length > 0) {
            this.selectedStoreLine = this.lines[0].code;
            this.isSelectedStoreLine = true;
          }
        }
      });
    }
  }

  changeStore(event: MatSelectChange) {
    this.isSelectedStoreLine = false;    
    const currentStore = this.stores.find(x => x.code == event.source.value);
    this.currentStoreTypeCode = currentStore ? currentStore.storeTypeCode : "";
    this.currentStoreCode = currentStore ? currentStore.code : "";
    this.lines = currentStore ? currentStore.lines.filter(x => x.lineTypeCode.toLowerCase().indexOf(GLOBAL.Cashier.toLowerCase()) == -1) : [];
    if(this.lines && this.lines.length > 0) {
      this.selectedStoreLine = this.lines[0].code;
      this.isSelectedStoreLine = true;
    }
  }

  changeStoreLine(event: MatSelectChange) {
    this.isSelectedStoreLine = true;
    this.selectedStoreLine = event.source.value;
  }

  viewBills() {
    this.masterDataService.getSKUsByStoreLine(this.selectedStoreLine, this.userName).subscribe(data => {
      this.currentUser['SKUs'] = data;
      this.currentUser['storeCode'] = this.currentStoreCode;

      localStorage.setItem(GLOBAL.SKUsStorageName, JSON.stringify(data));
      localStorage.setItem(GLOBAL.StoreCodeStorageName, this.currentStoreCode);
      localStorage.setItem(GLOBAL.StoreLineCodeStorageName, this.selectedStoreLine);
      localStorage.setItem(GLOBAL.StoreTypeCodeStorgeName, this.currentStoreTypeCode);

      let url = `/${environment.application.name}/${GLOBAL.Restaurant}`;

      if(this.currentStoreTypeCode.toLowerCase() == GLOBAL.Beverage.toLowerCase()) {
        url = `/${environment.application.name}/${GLOBAL.TeaMilk}`;
      }
      
      this.router.navigate([url]);
    });
  }
}
