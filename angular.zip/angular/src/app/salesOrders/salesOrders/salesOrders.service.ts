import { Injectable } from '@angular/core';
import { RestService, ABP } from '@abp/ng.core';
import { SalesOrders } from '../../store/models';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SalesOrdersService {
  apiName = 'Default';

    constructor(private restService: RestService) { }

    get(params = {} as SalesOrders.SalesOrdersQueryParams): Observable<SalesOrders.Response> {
        return this.restService.request<void, SalesOrders.Response>({
            method: 'GET',
            url: '/api/app/salesOrder',
            params
        },
        { apiName: this.apiName });
    }

    create(createSalesOrderInput: SalesOrders.SalesOrderCreateUpdateDto): Observable<SalesOrders.SalesOrder> {
        return this.restService.request<SalesOrders.SalesOrderCreateUpdateDto, SalesOrders.SalesOrder>({
            method: 'POST',
            url: '/api/app/salesOrder',
            body: createSalesOrderInput
        },
        { apiName: this.apiName });
    }

    

    getById(id: string): Observable<SalesOrders.SalesOrder> {
        return this.restService.request<void, SalesOrders.SalesOrder>({
            method: 'GET',
            url: `/api/app/salesOrder/${id}`
        },
        { apiName: this.apiName });
    }

    update(createSalesOrderInput: SalesOrders.SalesOrderCreateUpdateDto, id: string): Observable<SalesOrders.SalesOrder> {
        return this.restService.request<SalesOrders.SalesOrderCreateUpdateDto, SalesOrders.SalesOrder>({
            method: 'PUT',
            url: `/api/app/salesOrder/${id}`,
            body: createSalesOrderInput
        },
        { apiName: this.apiName });
    }

    delete(id: string): Observable<void> {
        return this.restService.request<void, void>({
            method: 'DELETE',
            url: `/api/app/salesOrder/${id}`
        },
        { apiName: this.apiName });
    }
}
