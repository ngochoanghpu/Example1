import { ConfirmationService, Confirmation } from '@abp/ng.theme.shared';
import { Component, TemplateRef, TrackByFunction, ViewChild, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { SalesOrdersService } from './salesOrders.service';
import { SalesOrdersState } from '../../store/states';
import { SalesOrders } from '../../store/models';
import { GetSalesOrders, CreateUpdateSalesOrder, DeleteSalesOrder } from '../../store/actions';
import { NgbDateNativeAdapter, NgbDateAdapter } from '@ng-bootstrap/ng-bootstrap';
import snq from 'snq';

@Component({
  selector: 'app-salesOrders',
  providers: [{ provide: NgbDateAdapter, useClass: NgbDateNativeAdapter }],
  templateUrl: './salesOrders.component.html',
  styleUrls: ['./salesOrders.component.scss'],
})

export class SalesOrdersComponent implements OnInit {
  @Select(SalesOrdersState.getSalesOrders)
  data$: Observable<SalesOrders.SalesOrder[]>;

  @Select(SalesOrdersState.getTotalCount)
  totalCount$: Observable<number>;

  @ViewChild('modalContent', { static: false })
  modalContent: TemplateRef<any>;

  form: FormGroup;

  selected: SalesOrders.SalesOrder;

  pageQuery: SalesOrders.SalesOrdersQueryParams = { maxResultCount: 10 };

  isModalVisible: boolean;

  isAdvancedFiltersHidden: boolean = true;

  loading: boolean = false;

  modalBusy: boolean = false;

  sortOrder: string = '';

  sortKey: string = '';

  

  trackByFn: TrackByFunction<AbstractControl> = (index, item) => Object.keys(item)[0] || index;

  get roleGroups(): FormGroup[] {
    return snq(() => (this.form.get('roleNames') as FormArray).controls as FormGroup[], []);
  }

  constructor(
    private confirmationService: ConfirmationService,
    public salesOrdersService: SalesOrdersService,
    private fb: FormBuilder,
    private store: Store,
  ) {}

  ngOnInit() {
    this.get();
  }

  onSearch(value) {
    this.pageQuery.filterText = value;
    this.get();
  }

  buildForm() {
      this.form = this.fb.group({
            salesOrderId: [this.selected.salesOrderId || '', []],
            storeCode: [this.selected.storeCode || '', []],
            storeName: [this.selected.storeName || '', []],
            employeeId: [this.selected.employeeId || '', []],
            employeeName: [this.selected.employeeName || '', []],
            orderNo: [this.selected.orderNo || '', []],
            orderType: [this.selected.orderType || '', []],
            orderTypeName: [this.selected.orderTypeName || '', []],
            orderDateTime: [this.selected.orderDateTime ? new Date(this.selected.orderDateTime) : null, []],
            orderStatus: [this.selected.orderStatus || '', []],
            orderStatusName: [this.selected.orderStatusName || '', []],
            salesChannelCode: [this.selected.salesChannelCode || '', []],
            salesChannelName: [this.selected.salesChannelName || '', []],
            hasDelivery: [this.selected.hasDelivery || false, []],
            notes: [this.selected.notes || '', []],
            waitingNumber: [this.selected.waitingNumber || '', []],
            isTakeAway: [this.selected.isTakeAway || false, []],
            pickingTime: [this.selected.pickingTime ? new Date(this.selected.pickingTime) : null, []],
            snoozingTime: [this.selected.snoozingTime ? new Date(this.selected.snoozingTime) : null, []],
            recievedDateTime: [this.selected.recievedDateTime ? new Date(this.selected.recievedDateTime) : null, []],
            performedById: [this.selected.performedById || '', []],
            performedByName: [this.selected.performedByName || '', []],
            performedDateTime: [this.selected.performedDateTime ? new Date(this.selected.performedDateTime) : null, []],
            kitchenStaus: [this.selected.kitchenStaus || '', []],

      });
  }

  openModal() {
    this.buildForm();
    this.isModalVisible = true;
  }

  onAdd() {
    this.selected = {
    
    } as SalesOrders.SalesOrder;
    this.openModal();
  }

  onEdit(id: string) {
    this.salesOrdersService
      .getById(id)
      .subscribe((state: SalesOrders.SalesOrder) => {
        this.selected = state;
        this.openModal();
      });
  }

  save() {
    if (!this.form.valid) return;
    this.modalBusy = true;

    this.store
      .dispatch(new CreateUpdateSalesOrder({
              ...this.form.value,
            }, this.selected.id)
      )
      .pipe(finalize(() => (this.modalBusy = false)))
      .subscribe(() => {
        this.isModalVisible = false;
		this.get();
      });
  }

  delete(id: string) {
    this.confirmationService
      .warn('::DeleteConfirmationMessage', '::AreYouSure',{})
      .subscribe((status: Confirmation.Status) => {
        if (status === Confirmation.Status.confirm) {
          this.store.dispatch(new DeleteSalesOrder(id)).subscribe(() => this.get())
        }
      });
  }

  onPageChange(page: number) {
    this.pageQuery.skipCount = (page - 1) * this.pageQuery.maxResultCount;

    this.get();
  }

  get() {
    this.loading = true;
	let filter = Object.assign({}, this.pageQuery);
	filter.orderDateTimeMin = filter.orderDateTimeMin ? new Date(filter.orderDateTimeMin).toISOString() : "";
	filter.orderDateTimeMax = filter.orderDateTimeMax ? new Date(filter.orderDateTimeMax).toISOString() : "";
	filter.pickingTimeMin = filter.pickingTimeMin ? new Date(filter.pickingTimeMin).toISOString() : "";
	filter.pickingTimeMax = filter.pickingTimeMax ? new Date(filter.pickingTimeMax).toISOString() : "";
	filter.snoozingTimeMin = filter.snoozingTimeMin ? new Date(filter.snoozingTimeMin).toISOString() : "";
	filter.snoozingTimeMax = filter.snoozingTimeMax ? new Date(filter.snoozingTimeMax).toISOString() : "";
	filter.recievedDateTimeMin = filter.recievedDateTimeMin ? new Date(filter.recievedDateTimeMin).toISOString() : "";
	filter.recievedDateTimeMax = filter.recievedDateTimeMax ? new Date(filter.recievedDateTimeMax).toISOString() : "";
	filter.performedDateTimeMin = filter.performedDateTimeMin ? new Date(filter.performedDateTimeMin).toISOString() : "";
	filter.performedDateTimeMax = filter.performedDateTimeMax ? new Date(filter.performedDateTimeMax).toISOString() : "";

    this.store
      .dispatch(new GetSalesOrders(filter))
      .pipe(finalize(() => (this.loading = false)))
      .subscribe();
  }
}
