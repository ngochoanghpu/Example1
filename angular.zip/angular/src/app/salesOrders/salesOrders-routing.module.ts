import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PermissionGuard } from '@abp/ng.core';
import { SalesOrdersComponent } from './salesOrders/salesOrders.component';

const routes: Routes = [
  {
    path: '',
    children: [{ path: '', component: SalesOrdersComponent }],
    canActivate: [PermissionGuard],
    data: { requiredPolicy: 'kitchen.SalesOrders' },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class SalesOrdersRoutingModule { }
