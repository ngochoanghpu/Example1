import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbDatepickerModule, NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../shared/shared.module';
import { SalesOrdersRoutingModule } from './salesOrders-routing.module';
import { SalesOrdersComponent } from './salesOrders/salesOrders.component';

@NgModule({
  declarations: [SalesOrdersComponent],
  imports: [
    CommonModule,
    SharedModule,
    SalesOrdersRoutingModule,
    NgbCollapseModule,
    NgbDatepickerModule
  ]
})

export class SalesOrdersModule { }
