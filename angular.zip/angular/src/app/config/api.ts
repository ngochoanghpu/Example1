export const ApiConfig = {

    Kitchen: {
      GetConfig: 'kitchenConfiguration/{id}/inforConfig',
      GetBillsTeaMilk: 'salesOrder/billsTeaMilk?storeCode={storeCode}',
      GetBillsRestaurant: 'salesOrder/billsRestaurant?storeCode={storeCode}',
      UpdateStatus: 'salesOrder/changeStatus',
      UpdateSaleOrderDetailStatus: 'salesOrderDetail/{id}/changeStatus?status={status}&storeCode={storeCode}&orderType={orderType}',
      UpdateSaleOrderDetailLock: 'salesOrderDetail/{id}/changeLock?status={status}',
      TestSignalR: 'salesOrder/singalR'
    },

    HR: {
      GetEmployeeJobWorkspace: 'employeeJob/employeeJobWorkspace?EmployeeCode={EmployeeCode}',
    },

    MDM: {
      GetWorkspaces: 'HrData/WorkspaceResources?WorkspaceCodes={WorkspaceCodes}',
      GetStoresIncludeStoreLines: 'Store?IncludeStoreLines=true&UserName={userName}&Language={language}',
      GetProductsByStoreLine: 'Product/SkuByStoreLine?StoreLineCode={storeLineCode}&UserName={userName}'
    }

  };
