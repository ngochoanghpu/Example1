import _ from 'lodash';
declare var $: any;

export class PageUtils {
    public static simulateClickButtonFullScreen(): void {
        const $element = $('#btnFullscreen i');
        if ($element) {
          $element.click();
        }
      }
}