export const Tenant = {    
    ToMinh: {
        Id: "132e6d7a-aec0-11ea-9497-fcaa14401d81",       
    }
 };