export enum ProductType {
    Beverages = "Beverages",
    Cakes = "Cakes",
    Toppings = "Toppings"
}