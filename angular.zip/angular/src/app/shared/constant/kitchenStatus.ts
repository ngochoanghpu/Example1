export enum KitchenStatus {
    Inprogress = "Inprogress",
    Completed = "Completed",
    Cancelled = "Cancelled"
}