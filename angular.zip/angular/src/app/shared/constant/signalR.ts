export interface ISignalRConfigs {
    actionName: string;
}

export const sendBill: ISignalRConfigs = {
    actionName:  'SendBill'  
};
export const sendBillRes: ISignalRConfigs = {
    actionName:  'SendBillRestaurant'  
};

export const cancelBill: ISignalRConfigs = {
    actionName: 'CancelBill'
};

export const chef1: ISignalRConfigs = {
    actionName: 'NoodleDrink'
};
export const chef2: ISignalRConfigs = {
    actionName: 'DimsumRoasted'
};
export const chef3: ISignalRConfigs = {
    actionName: 'PanSoupPrepared'
};

export const store1: ISignalRConfigs = {
    actionName: 'store1'
};
export const store2: ISignalRConfigs = {
    actionName: 'store2'
};
export const store3: ISignalRConfigs = {
    actionName: 'store3'
};
export enum SaleOrderStatus {
    Inprogress = "Inprogress",
    Completed = "Completed",
    Cancelled = "Cancelled",
    InformCancelled = "InformCancelled"    
}

export enum  FoodProductGroup {
    Noodle = 'Noodle', // Missing
    Drink = 'PR.Nuoc',
    Dimsum = 'PR.Dimsum',
    Roasted = 'PR.Quay', // Quay
    Pan = 'PR.Chao',
    Soup = 'PR.Saladsoup',
    Prepared = 'PR.Dubi',
  };

export enum StoreCode {
    TM_MILKTEA1 = "TM_MILKTEA1",
    TM_DIMSUM1 = "TM_DIMSUM1"
}