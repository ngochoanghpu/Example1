import { Injectable } from '@angular/core';
import { RestService } from '@abp/ng.core';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { MasterData } from '../../store/models/@masterData/masterData';
import { CommonType } from 'src/app/store/models/@masterData/commonType';
import { ProductMasterData } from 'src/app/store/models/@masterData/product';
import { ConfigStateService } from '@abp/ng.core';

@Injectable({
  providedIn: 'root',
})
export class MasterDataService {
  apiName = 'Default';
  language: string;
  constructor(private restService: RestService, private configService: ConfigStateService) {
    this.language = this.configService.getDeep('localization.currentCulture.cultureName');
  }
  /**
   * Get list of stores from MDM
   * @param params MasterData.StoreQueryParams
   */
  getStores(
    params = {} as MasterData.StoreQueryParams
  ): Observable<MasterData.StoreMasterDataItemResponse> {
    return this.restService.request<void, MasterData.StoreMasterDataItemResponse>({
      method: 'GET',
      url: '/mdm/api/store',
      params,
    });
  }

  /**
   * Get Bank from MDM
   * No passing parameters
   */
  getBanks(): Observable<MasterData.BankResponse> {
    return this.restService.request<void, MasterData.BankResponse>({
      method: 'GET',
      url: '/api/app/mBankLang',
    });
  }

  /**
   * Search products from MDM
   * No passing parameters
   */
  searchProducts(): Observable<MasterData.ProductSearchResponse> {
    return this.restService.request<void, MasterData.ProductSearchResponse>({
      method: 'GET',
      url: '/mdm/api/Product',
    });
  }

  searchMProducts(
    params = {} as MasterData.MProductSearchParams
  ): Observable<MasterData.ProductSearchResponseFromMProduct> {
    return this.restService.request<void, MasterData.ProductSearchResponseFromMProduct>({
      method: 'GET',
      url: '/api/app/mProduct',
      params,
    });
  }

  // searchMProductBySKUs(params ={} as MasterData.ProductSearchBySKUsParams) : Observable<MasterData.ProductSearchResponseFromMProduct>
  // {
  //   return this.restService.request<void, MasterData.ProductSearchResponseFromMProduct>({
  //     method: 'GET',
  //     url: '/api/app/mProduct/getProductBySKUs',
  //     params
  //   });
  // }

  /**
   * Search Product Hierarchy from MDM
   * No passing parameters
   */
  searchProductHierarchy(): Observable<MasterData.ProductHierarchyResponse> {
    return this.restService.request<void, MasterData.ProductHierarchyResponse>({
      method: 'GET',
      url: '/mdm/api/ProductHierarchy',
    });
  }

  /**
   * Search Product Hierarchy from MDM
   * No passing parameters
   */
  searchSKUByHierarchy(id: number): Observable<string[]> {
    return this.restService.request<void, string[]>({
      method: 'GET',
      url: `/mdm/api/Product/SkuByHierarchy?ProductHierarchyId=${id}`,
    });
  }

  searchProductByHierachyCode(id: number): Observable<MasterData.ProductSearchResponse> {
    return this.restService.request<void, MasterData.ProductSearchResponse>({
      method: 'GET',
      url: `/mdm/api/Product/ByHierarchy?IncludeUOM=true&ProductHierarchyId=${id}`,
    });
  }

  /**
   * Search products from MDM
   * @param params: sku
   */
  searchProductsByValue(
    params = {} as MasterData.ProductSearchParams
  ): Observable<MasterData.ProductSearchResponse> {
    return this.restService.request<void, MasterData.ProductSearchResponse>({
      method: 'GET',
      url: '/mdm/api/Product',
      params,
    });
  }
  /**
   * Search products dummy - Will be deleted
   */
  searchProductsByValueDummy(
    params = {} as MasterData.ProductSearchParams
  ): Observable<MasterData.ProductSearchResponse> {
    const fakeRespones = {
      items: products,
      totalCount: products.length,
    } as MasterData.ProductSearchResponse;
    return of(fakeRespones).pipe(delay(1000));
  }

  getMSaleOrderTypes(): Observable<MasterData.MSaleOrderTypeDto[]> {
    return this.restService.request<void, MasterData.MSaleOrderTypeDto[]>({
      method: 'GET',
      url: '/api/mSalesOrderType?SkipCount=0&MaxResultCount=100',
    });
  }

  searchCustomer(params: any): Observable<MasterData.MCustomerResponse> {
    return this.restService.request<void, MasterData.MCustomerResponse>({
      method: 'GET',
      url: '/api/app/mCustomer',
      params,
    });
  }

  addCustomer(customer: MasterData.MCustomer): Observable<MasterData.MCustomer> {
    return this.restService.request<MasterData.MCustomer, MasterData.MCustomer>({
      method: 'POST',
      url: '/api/app/mCustomer',
      body: customer,
    });
  }

  searchMdmProducts(
    params: MasterData.MProductSearchParams
  ): Observable<MasterData.MProductReponse> {
    return this.restService.request<MasterData.MProductSearchParams, MasterData.MProductReponse>({
      method: 'GET',
      url: '/api/app/mProduct',
      params,
    });
  }

  // TOMINH --------------------------------------------------------------------------------------
  // searchProductsMDM(params: MasterData.SearchProductParam): Observable<MasterData.ProductReponse> {
  //   return this.restService.request<MasterData.SearchProductParam, MasterData.ProductReponse>({
  //     method: 'GET',
  //     url: '/mdm/api/Product',
  //     params,
  //   });
  // }

  /**
   * For ToMinh
   * @param params
   */
  searchProductsMDM(
    params: MasterData.MProductSearchParams
  ): Observable<MasterData.MProductReponse> {
    return this.restService.request<MasterData.MProductSearchParams, MasterData.MProductReponse>({
      method: 'POST',
      url: '/api/app/mProduct/searchProducts',
      params,
    });
  }

  getMenuItem(storeCode: string): Observable<ProductMasterData.ProductResponse> {
    const resquestModel = {
      language: this.language,
      storeCode,
      forSalesOnly: true,
      includeAvatar: true,
      includeCategory: true,
      includeUom: true,
      includeUop: true,
      includeUos: true,
    } as ProductMasterData.ProductQueryParams;
    return this.restService.request<
      ProductMasterData.ProductQueryParams,
      ProductMasterData.ProductResponse
    >({
      url: '/mdm/api/product',
      method: 'GET',
      params: resquestModel,
    });
  }

  getProductAssociate(
    sku: string,
    storeCode: string
  ): Observable<ProductMasterData.ProductAssociateResponse> {
    const requestData = {
      sku,
      storeCode,
      language: this.language,
    };
    return this.restService.request<void, ProductMasterData.ProductAssociateResponse>({
      url: `/mdm/api/Product/Association`,
      method: 'GET',
      params: requestData,
    });
  }

  getPaymentMethods(): Observable<CommonType.PaymentMethodResponse> {
    return this.restService.request<void, CommonType.PaymentMethodResponse>({
      url: '/mdm/api/MasterData/PaymentMethods?Language=' + this.language,
      method: 'GET',
    });
  }

  getCommonGroupItems(groupCode: string): Observable<MasterData.CommonResponse> {
    return this.restService.request<void, MasterData.CommonResponse>({
      url: `/mdm/api/MasterData/CommonList?GroupCode=${groupCode}&Language=` + this.language,
      method: 'GET',
    });
  }

  getBankList(): Observable<CommonType.BankResponse> {
    return this.restService.request<void, CommonType.BankResponse>({
      url: '/mdm/api/MasterData/Banks?Language=' + this.language,
      method: 'GET',
    });
  }
  getBankAccounts(storeCode: string): Observable<CommonType.BankAccountResponse> {
    return this.restService.request<void, CommonType.BankAccountResponse>({
      url: `/mdm/api/Store/BankAccounts?StoreCode=${storeCode}&Language=` + this.language,
      method: 'GET',
    });
  }
}

// DUMMY DATA
const products: MasterData.ProductItem[] = [
  {
    barCode1: 'TPT3443',
    barCode2: 'TPT3443-345',
    sku: 'SKU848590394',
    isSerialControl: true,
    isLot: false,
    code: 'IP-10-2335-55',
    name: 'IPhone X Trắng 64GB',
    displayName: 'SKU848590394 - IPhone X Trắng 64GB',
    isCheckedInventory: false,
    isStockControl: false,
    taxPercent: 5,
    extractFromPrice: true,
  },
  {
    barCode1: 'TPT666384',
    barCode2: 'TPT666-345',
    sku: 'SKU846684859',
    isSerialControl: true,
    isLot: false,
    code: 'IP-10-2335-55',
    name: 'IPhone X Đen 64GB',
    displayName: 'SKU846684859 - IPhone X Đen 64GB',
    isCheckedInventory: false,
    isStockControl: false,
    taxPercent: 5,
    extractFromPrice: true,
  },
  {
    barCode1: 'SKU0000000007',
    barCode2: '',
    sku: 'SKU0000000007',
    isSerialControl: false,
    isLot: true,
    code: '',
    name: 'Gối cao su Hàn Quốc - xám',
    displayName: 'SKU0000000007 - Gối cao su Hàn Quốc - xám',
    isCheckedInventory: true,
    isStockControl: true,
    taxPercent: 5,
    extractFromPrice: false,
  },
  {
    barCode1: 'SKU0000000005',
    barCode2: '',
    sku: 'SKU0000000005',
    isSerialControl: false,
    isLot: true,
    code: '',
    name: 'Gối cao su Hàn Quốc - xanh dương',
    displayName: 'SKU0000000012 - Gối cao su Hàn Quốc - xanh dương',
    isCheckedInventory: true,
    isStockControl: true,
    taxPercent: 5,
    extractFromPrice: false,
  },
];
