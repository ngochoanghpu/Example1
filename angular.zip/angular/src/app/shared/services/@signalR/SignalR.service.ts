import { Injectable, EventEmitter } from '@angular/core';
import * as signalR from '@aspnet/signalr';
import { RestService, ABP } from '@abp/ng.core';
import { ConfigStateService } from '@abp/ng.core';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root',
})
export class SignalRService {
  [x: string]: any;
  apiUrl: string;
  language: string;
  moduleMessage: 'transferdata';
  public data$: any;
  hubConnection: signalR.HubConnection;
  connectionEstablished = new EventEmitter<boolean>();
  messageReceived = new EventEmitter<any>();
  fromUser = new EventEmitter<any>();
  private connectionIsEstablished = false;

  constructor(
    private restService: RestService,
    private configService: ConfigStateService
  ) {
    this.language = this.configService.getDeep('localization.currentCulture.cultureName');
    // this.createConnection();
    // this.registerOnServerEvents();
    // this.startConnection();
  }

  // Bind new message to Hub signalR
  // sendMessage(message: any) {
  //   this.hubConnection.invoke('signalRmessage', message);
  // }

  public createConnection() {
    const signalrUrl = environment.apis.signalR.url;
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(signalrUrl)
      .build();
  }

  public startConnection(): void {
    this.hubConnection
      .start()
      .then(() => {
        this.connectionIsEstablished = true;
        console.log('Hub connection started');
        this.connectionEstablished.emit(true);
      })
      .catch((err) => {
        console.log('Error while establishing connection, retrying...');
        setTimeout(() => {
          this.startConnection();
        }, 5000);
      });
  }
  
  public registerDynamicEvents(actionName: string): void {
    this.hubConnection.on(actionName, (data: any) => {
      this.messageReceived.emit(data);
      // console.log('data', this.messageReceived);
    });
  }

  public disconnect() {
    this.hubConnection.stop();
  }

}
