import { Injectable } from '@angular/core';
import { RestService } from '@abp/ng.core';
import { Observable } from 'rxjs';
import { ApiConfig } from 'src/app/config/api';
import { METHODS } from 'src/app/shared/constant/method';

@Injectable({
  providedIn: 'root'
})
export class HrService {

    apiName = 'hr';

    constructor(private restService: RestService) { }

    getEmployeeJobWorkspace(EmployeeCode: string): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/app/${ApiConfig.HR.GetEmployeeJobWorkspace.replace("{EmployeeCode}", EmployeeCode)}`
        },
        { apiName: this.apiName });
    }
}