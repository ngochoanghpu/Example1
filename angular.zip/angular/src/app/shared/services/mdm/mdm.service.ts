import { Injectable } from '@angular/core';
import { RestService } from '@abp/ng.core';
import { Observable } from 'rxjs';
import { ApiConfig } from 'src/app/config/api';
import { METHODS } from 'src/app/shared/constant/method';

@Injectable({
  providedIn: 'root'
})
export class MasterDataService {

    apiName = 'mdm';

    constructor(private restService: RestService) { }

    getWorkspaces(WorkspaceCodes: string): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/${ApiConfig.MDM.GetWorkspaces.replace("{WorkspaceCodes}", WorkspaceCodes)}`
        },
        { apiName: this.apiName });
    }

    getStoresIncludeStoreLines(userName: string = null, language: string = "en"): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/${ApiConfig.MDM.GetStoresIncludeStoreLines.replace("{userName}", userName).replace("{language}", language)}`
        },
        { apiName: this.apiName });
    }

    getSKUsByStoreLine(storeLineCode: string = null, userName: string = null): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/${ApiConfig.MDM.GetProductsByStoreLine.replace("{storeLineCode}", storeLineCode).replace("{userName}", userName)}`
        },
        { apiName: this.apiName });
    }
}