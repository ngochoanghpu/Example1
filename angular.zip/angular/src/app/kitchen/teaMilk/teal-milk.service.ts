import { Injectable } from '@angular/core';
import { RestService } from '@abp/ng.core';
import { Observable } from 'rxjs';
import { ApiConfig } from 'src/app/config/api';
import { METHODS } from 'src/app/shared/constant/method';
import { GLOBAL } from 'src/app/shared/constant/global';


@Injectable({
  providedIn: 'root'
})
export class TeaMilkService {

    apiName = 'kit';

    constructor(private restService: RestService) { }

    getConfig(id: string): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/app/${ApiConfig.Kitchen.GetConfig.replace("{id}", id)}`
        },
        { apiName: this.apiName });
    }

    getBills(storeCode: string = ""): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/app/${ApiConfig.Kitchen.GetBillsTeaMilk.replace("{storeCode}", storeCode)}`
        },
        { apiName: this.apiName });
    }

    updateStatus(id: string, status: string, saleOrderDetailIds = [], storeCode: string = null, orderType: string = null): Observable<any> {
        const input = { id, orderStatus: status, storeCode: storeCode, saleOrderDetailIds: saleOrderDetailIds, orderType: orderType };
        return this.restService.request<any, any>({
            method: METHODS.PUT,
            body: input,
            url: `/api/app/${ApiConfig.Kitchen.UpdateStatus.replace("{id}", id).replace("{status}", status)}`
        },
        { apiName: this.apiName });
    }
}
