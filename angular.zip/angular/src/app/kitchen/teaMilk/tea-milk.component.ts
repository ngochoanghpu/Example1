import { Component, OnInit, OnDestroy, ElementRef, HostListener, NgZone } from '@angular/core';
import { ConfigStateService } from '@abp/ng.core';
import { TeaMilkService } from './teal-milk.service';
import { Tenant } from 'src/app/shared/constant/tenant';
import { KitchenStatus } from 'src/app/shared/constant/kitchenStatus';
import { ProductType } from 'src/app/shared/constant/productType';
import { SignalRService } from 'src/app/shared/services/@signalR/SignalR.service';
import { GLOBAL } from 'src/app/shared/constant/global';
import { BigScreenService } from 'angular-bigscreen';
import * as moment from 'moment';
import { SaleOrderStatus, sendBill } from 'src/app/shared/constant/signalR';
import { HrService } from 'src/app/shared/services/hr/hr.service';
import { MasterDataService } from 'src/app/shared/services/mdm/mdm.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { KEYCODES } from 'src/app/shared/constant/keyCode';
import { PageUtils } from 'src/app/shared/utilities/page.utils';

declare var $: any;




@Component({
  selector: 'app-kitchen-tea-milk',
  templateUrl: './tea-milk.component.html',
  styleUrls: [
               './tea-milk.component.scss',
               '../../responsive/responsive-max-width-1366.scss',
               '../../responsive/responsive-max-width-1024.scss',
               '../../responsive/responsive-max-width-768.scss'
             ]
})
export class TeaMilkComponent implements OnInit, OnDestroy {

    configState: any = {};
    config: any = {};
    bills: any = [];

    productType = ProductType;
    kitchenConfiguration: any = {};
    isShowItems = false;

    isCompletedBeverageDisk = false;
    isCompletedCakeDisk = false;
    isCompletedToppingDisk = false;


    colorTimer = "";
    underThreshold1BgColor = "";
    underThreshold2BgColor = "";
    overThreshold3BgColor = "";
    beverageCheckBgColor = "";
    cakeCheckBgColor = "";
    toppingCheckBgColor = "";
    itemCheckBgColor = "";
    billCancelledBgColor = "";

    currentTime = "";
    billInterval = null;
    threshold1Value = 5; // minutes
    threshold2Value = 10; // minutes

    // SignalR
    currentUser: "";
    subcribe: any;
    signalrTitle: string = "";

    gridColsNum = 4;
    pArr = [] ;
    shouldBeInOneColsBills = [];
    startCoupleBills = [];

    isFullscreenMode = false;

    currentStoreCode = "";

    constructor(
      private configStateService: ConfigStateService,
      private teaMilkService: TeaMilkService,
      private bigScreenService: BigScreenService,
      private elRef: ElementRef,
      private signalRService : SignalRService,
      private _ngZone: NgZone,
      private hrService: HrService,
      private router: Router,
      private elementRef: ElementRef,
      private masterDataService: MasterDataService,
    ) {
      this.currentStoreCode = localStorage.getItem(GLOBAL.StoreCodeStorageName);
      if(this.currentStoreCode){
        this.signalRService.createConnection();
        this.signalRService.startConnection();
        this.signalrTitle = sendBill.actionName + this.currentStoreCode;
        this.signalRService.registerDynamicEvents(this.signalrTitle);
      }
    }

    @HostListener('document:keydown', ['$event']) onKeydownHandler(event: KeyboardEvent) {
      const keyCode = event.keyCode;
      
      if (keyCode === KEYCODES.F11) {
        PageUtils.simulateClickButtonFullScreen();
        event.preventDefault();
      }
    }

    @HostListener('window:beforeunload', ['$event'])
    public beforeunloadHandler(event) {
      return false;
    }

    ngOnInit(): void {
        this.checkCurrentStore();
        //this.executeFullScreen();
        this.getBills();
        this.handleScreenChange();
        this.subscribeToEvents();
    }

    executeFullScreen() {
      //const this.elementRef.nativeElement
      //this.bigScreenService.request(element);
    }

    checkCurrentStore() {
      const currentStoreTypeCode = localStorage.getItem(GLOBAL.StoreTypeCodeStorgeName);
      if(currentStoreTypeCode && currentStoreTypeCode.toLowerCase() != GLOBAL.Beverage.toLowerCase()) {
        const url = `/${environment.application.name}/${GLOBAL.Restaurant}`;
        this.router.navigate([url]);
      }
    }

    setFullScreen(): void {
      $('abp-logo').addClass('kitchen-hide-logo');
      $('.navbar.navbar-expand-lg').addClass('kitchen-hide-navbar');
      $('#navbarSidebar').addClass('kitchen-hide-left-menu');
      $('body .lp-content.h-100').addClass('kitchen-lp-content-fullscreen');
      $('.lp-footer').hide();
    }

    /**
     * Unset full screen
     */
    unsetFullScreen(): void {
      $('abp-logo').removeClass('kitchen-hide-logo');
      $('.navbar.navbar-expand-lg').removeClass('kitchen-hide-navbar');
      $('#navbarSidebar').removeClass('kitchen-hide-left-menu');
      $('body .lp-content.h-100').removeClass('kitchen-lp-content-fullscreen');
      $('.lp-footer').show();
    }

    handleScreenChange() {
      this.bigScreenService.onChange((res) => {
        let isFullScreen = false;
        if (res.currentTarget && res.currentTarget.fullscreen) {
          isFullScreen = true;
        }

        if (isFullScreen) {
          this.isFullscreenMode = true;
          this.setFullScreen();
        } else {
          this.isFullscreenMode = false;
          this.unsetFullScreen();
        }
      });
    }

    ngOnDestroy() {
        clearInterval(this.billInterval);
        this.subcribe.unsubscribe();
        this.signalRService.disconnect();
    }

    addMoreDataBill(data) {
      data.forEach(element => {
        element.currentTime = "";
        element.second = 0;
        element.minute = 0;
        element.hour = 0;
        element.isDisplayHour = false;
        element.isCancelBill = false;
        element.isInformCancelBill = false;
        element.isCompletedBeverageDisk = false;
        element.cakeCheckBgColor = false;
        element.toppingCheckBgColor = false;
        element.colorTimer = this.colorTimer;
        element.beverageCheckBgColor = "";
        element.cakeCheckBgColor = "";
        element.toppingCheckBgColor = "";

        element.beverages.forEach(beverage => {
          beverage.isCompletedBeverageDisk = false;
          beverage.beverageCheckBgColor = "";
        });

        element.cakes.forEach(cake => {
          cake.isCompletedCakeDisk = false;
          cake.cakeCheckBgColor = "";
        });

        element.toppings.forEach(topping => {
          topping.isCompletedToppingDisk = false;
          topping.toppingCheckBgColor = "";
        });
      });
    }

    getWorkSpace() {
      let workspaceCodes = "";
      let resources = [];

      //Get workspaces from HR Service
      this.hrService.getEmployeeJobWorkspace(this.currentUser['userName']).subscribe(employeeworkSpace => {
        workspaceCodes = employeeworkSpace.items.map(x => x.workspaceCode);
        if(workspaceCodes.length > 0){
          workspaceCodes = workspaceCodes.toString();
        }

        //Get currentStoreCode, productGroupCodes from MDM base on workspaceCode array
        this.masterDataService.getWorkspaces(workspaceCodes).subscribe(workspace => {
          if(workspace && workspace.items.length > 0) {
            workspace.items.forEach(element => {
              resources = element.resources.concat(resources);
            });

            //Get current storeCode
            let firstResources = workspace.items[0].resources;
            const store = firstResources.find(s => s.type == GLOBAL.WorkSpaceStore);
            if (store) {
              const storeCodes = store.values;
              if (storeCodes && storeCodes.length > 0) {
                this.currentStoreCode = storeCodes[0];
              }
            }

            //Get bills base on storeCode, productGroupCodes
            this.getBills();
          }
        });
      });
    }

    prepareBill(data) {
      let skus = localStorage.getItem(GLOBAL.SKUsStorageName);
      skus = skus ? JSON.parse(skus) : [];
      const currentStoreCode = localStorage.getItem(GLOBAL.StoreCodeStorageName);

      data = data.filter(x => x.storeCode == currentStoreCode);
      data.forEach(element => {
        element.beverages = element.beverages.filter(x =>skus.indexOf(x.itemCode) != -1);
        element.cakes = element.cakes.filter(x =>skus.indexOf(x.itemCode) != -1);
        element.toppings = element.toppings.filter(x =>skus.indexOf(x.itemCode) != -1);
      });

      const bills = data.filter(b => {
        return  b.beverages.length > 0 ||
                b.cakes.length > 0 ||
                b.toppings.length > 0;
      });

      return bills;
   }

    getBills() {
      const currentStoreCode = localStorage.getItem(GLOBAL.StoreCodeStorageName);

      this.teaMilkService.getBills(currentStoreCode).subscribe(data => {
        const configuration = data[0].configuration;
        this.kitchenConfiguration = configuration;
        this.threshold1Value = configuration.threshold1Value; //minute
        this.threshold2Value = configuration.threshold2Value; //minute
        this.underThreshold1BgColor = configuration.underThreshold1BgColor;
        this.underThreshold2BgColor = configuration.underThreshold2BgColor;
        this.overThreshold3BgColor = configuration.overThreshold3BgColor;
        this.colorTimer = configuration.underThreshold1BgColor;
        this.itemCheckBgColor = configuration.itemCheckBgColor;
        this.billCancelledBgColor = configuration.billCancelledBgColor;
        this.gridColsNum = parseInt(configuration.displayColumns);
        console.log("Column number: " + this.gridColsNum);

        data = this.prepareBill(data);

        if(data.length > 0 && data[0].saleOrderId != GLOBAL.EmptyGuid){
          this.isShowItems = true;
          this.addMoreDataBill(data);
          this.bills = data;
          this.displayTime(this.bills);

          this.filterBills();
        }
        else{
          this.isShowItems = false;
        }
      });
    }

    updateCancelBillUI(saleOrderId, text) {
      let currentBillDom = $("div[id='"+saleOrderId+"']");
      const currentHeight = currentBillDom.height();
      if(currentHeight <= 100){
        currentBillDom.css({"min-height": 100, "overflow-y": "hidden"});
      }
      currentBillDom.append("<div class='rotateCancelBill'>"+text+"</div>");
      currentBillDom.css({"background-color": this.billCancelledBgColor});
    }

    private calPointForBills(){
      console.group('%c Function ',
        'color: white; background-color: #2274A5',
        'Calculate point for bill');
      // console.table(this.bills);
      //Init point array
      this.pArr = [];

        this.bills.forEach((bill, i) => {
          // if(bill.cakes.length > 0){
          //   console.log('Bill info: ' + bill.cakes.length);
          //   console.table(bill);
          // }
          let x = bill.totalQuantityBeverage + bill.totalQuantityCake + bill.totalQuantityTopping;
          bill.beverages.forEach(b => {
            if(b) {
              x = x + (b.toppings ? b.toppings.length : 0);
              if(b.savor){
                x += Math.round(b.savor.length/2);
              }
              if(b.notes){
                x +=  Math.round(b.notes.length/25);
              }
            }
          });
          bill.cakes.forEach(c => {
            if(c && c.notes){
              x += Math.round(c.notes.length/25);
            }
          });
          bill.toppings.forEach(t => {
            if(t && t.notes){
              x += Math.round(t.notes.length/25);
            }
          });
          // console.log("Bill " + bill.saleOrderNumber + " points: " + x);
          this.pArr.push(x);
        });

      // console.table(this.pArr);
      console.groupEnd();
    }

    private filterBills(){
      //Innitialize value for arrays
      this.shouldBeInOneColsBills = [];
      this.startCoupleBills = [];

      this.calPointForBills();

      for (let index = 1; index < this.bills.length; index++) {
        // console.log("couple: " +  this.pArr[index] + " and " + this.pArr[index-1]);
        if(this.pArr[index] + this.pArr[index-1] < 14){
          this.shouldBeInOneColsBills.push(index);
          this.startCoupleBills.push(index-1);
          index = index + 1;
          // console.log("work!");
        }
      }

      // console.log("Should be in one column:");
      // console.table(this.shouldBeInOneColsBills);
      // console.log("Start couple bills:");
      // console.table(this.startCoupleBills);
    }

    isSkipBill(index){
      let r = this.shouldBeInOneColsBills.find( x => x === index);
      return r === undefined? false : true;
    }

    isStartCoupleBill(index){
      if(index === this.bills.length - 1){
        return false;
      }
      let r = this.startCoupleBills.find( x => x === index);

      return r === undefined? false : true;
    }


    displayTime(bills) {
      this.billInterval = setInterval(() => {
        this.startTime(bills[0].hour, bills[0].minute,  bills[0].second, bills);
      }, 1000);
    }

    changeStatusToCompleted(id) {
      let saleOrderDetailIds = [];
      let currentBill = this.bills.find(b => b.saleOrderId == id);
      if(currentBill) {
        let saleOrderDetails = currentBill.beverages.concat(currentBill.cakes).concat(currentBill.toppings);
        if(saleOrderDetails) {
          saleOrderDetailIds = saleOrderDetails.map(sod => sod.saleOrderDetailId);
        }
      }

      const storeCode = localStorage.getItem(GLOBAL.StoreCodeStorageName);
      const orderType = GLOBAL.TeaMilk;

      this.teaMilkService.updateStatus(id, KitchenStatus.Completed, saleOrderDetailIds, storeCode, orderType).subscribe(data => {
         const index = this.bills.findIndex(b => b.saleOrderId == id);
         if(index != -1){
           this.bills.splice(index, 1);
           this.filterBills();
         }
      });
    }

    completedDisk(indexBill, indexProduct, productType) {
        let currentBill = this.bills[indexBill];
        switch(productType){
          case ProductType.Beverages:
            let currentBeverage = currentBill.beverages[indexProduct];
            if(currentBeverage) {
              currentBeverage.isCompletedBeverageDisk = !currentBeverage.isCompletedBeverageDisk;
              currentBeverage.beverageCheckBgColor = currentBeverage.isCompletedBeverageDisk ? this.itemCheckBgColor : "";
            }

            break;

          case ProductType.Cakes:
            if(currentBill) {
              let currentCake = currentBill.cakes[indexProduct];
              currentCake.isCompletedCakeDisk = !currentCake.isCompletedCakeDisk;
              currentCake.cakeCheckBgColor = currentCake.isCompletedCakeDisk ? this.itemCheckBgColor : "";
            }

            break;

          case ProductType.Toppings:
            if(currentBill) {
              let topping = currentBill.toppings[indexProduct];
              if(topping){
                topping.isCompletedToppingDisk = !topping.isCompletedToppingDisk;
                topping.toppingCheckBgColor = topping.isCompletedToppingDisk ? this.itemCheckBgColor : "";
              }
            }

            break;
        }
    }

    startTime(hour, minute, second, bills) {
      second++;

      bills.forEach(bill => {
        bill.second++;
      });

      if(second == 60){
        minute++;
        second = 0;

        bills.forEach(bill => {
          bill.minute++;
          bill.second = 0;
        });
      }

      if(minute == 60){
        hour++;
        minute = 0;

        bills.forEach(bill => {
          bill.hour++;
          bill.minute = 0;
        });
      }

      let hourString = hour < 10 ? "0" + hour : hour.toString();
      let minuteString = minute < 10 ? "0" + minute : minute.toString();
      let secondString = second < 10 ? "0" + second : second.toString();

      bills.forEach(bill => {
        if(!bill.recievedDateTime){
          if(bill.hour > 0){
            bill.isDisplayHour = true;
            //bill.currentTime = hourString + ":" + minuteString + ":" + secondString;
            bill.currentTime = parseInt(hourString) * 60 + parseInt(minuteString);
            bill.currentTime = bill.currentTime < 10 ? "0" + bill.currentTime : bill.currentTime;

          }
          else{
            //bill.currentTime = minuteString + ":" + secondString;
            bill.currentTime = minuteString;
          }
        }
        else{
          let recievedDateTime = moment.duration(moment().diff(moment(bill.recievedDateTime)));
          bill.hour = recievedDateTime.get('hour');
          bill.minute = recievedDateTime.get('minutes');
          bill.second = recievedDateTime.get('seconds');
          const days = recievedDateTime.get('days');
          if(days > 0) {
            bill.hour += days * 24;
          }

          hourString = bill.hour < 10 ? "0" + bill.hour : bill.hour;
          minuteString = bill.minute < 10 ? "0" + bill.minute : bill.minute;
          secondString = bill.second < 10 ? "0" + bill.second : bill.second;

          if(bill.hour > 0) {
            bill.isDisplayHour = true;
            //bill.currentTime = hourString + ":" + minuteString + ":" + secondString;
            bill.currentTime = parseInt(hourString) * 60 + parseInt(minuteString);
            bill.currentTime = bill.currentTime < 10 ? "0" + bill.currentTime : bill.currentTime;
          }
          else{
            //bill.currentTime = minuteString + ":" + secondString;
            bill.currentTime = minuteString;
          }
        }
      });

      this.setColorTimer();
    }

    setColorTimer() {
      this.bills.forEach(bill => {
        if(bill.hour > 0){
          bill.colorTimer = this.overThreshold3BgColor;
        }
        else{
          if(bill.minute < this.threshold1Value) {
            bill.colorTimer = this.underThreshold1BgColor;
          }
          else if(bill.minute < this.threshold2Value) {
            bill.colorTimer = this.underThreshold2BgColor;
          }
          else {
            bill.colorTimer = this.overThreshold3BgColor;
          }
        }
      });
    }

    isExistedBill(currentBill: any) {
      return this.bills.find(b => b.saleOrderId == currentBill.saleOrderId) != null;
    }

    private subscribeToEvents(): void {
      let self = this;
      this.subcribe = this.signalRService.messageReceived.subscribe((rs: any) => {
        this._ngZone.run(() => {
          let data = rs;

          if(data.orderStatus == SaleOrderStatus.Cancelled) {
            self.updateCancelBillUI(data.saleOrderId, "Hủy");
            return;
          }

          if(data.orderStatus == SaleOrderStatus.InformCancelled) {
            self.updateCancelBillUI(data.saleOrderId, "Báo Hủy");
            return;
          }

          if(self.isExistedBill(data)) {
            return;
          }

          data = self.prepareBill([data]);

          self.isShowItems = true;

          if(data && data.length > 0){
            self.addMoreDataBill(data);
            data[0].saleOrderNumber = data[0].saleOrderNumber ? data[0].saleOrderNumber.substring(data[0].saleOrderNumber.length - self.kitchenConfiguration.billNoDisplayLength) : "";
            self.displayTime(data);
            self.bills = self.bills.concat(data);
            self.filterBills();
          }
        });
      });
    }
}
