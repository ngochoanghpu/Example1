import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbDatepickerModule, NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
import { TeaMilkComponent } from './tea-milk.component';
import { TeaMilkRoutingModule } from './tea-milk-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { RestaurantModule } from '../restaurant/restaurant.module';



@NgModule({
  declarations: [TeaMilkComponent],
  imports: [
    CommonModule,
    SharedModule, 
    TeaMilkRoutingModule,   
    NgbCollapseModule,
    RestaurantModule,
    NgbDatepickerModule    
  ]
})
export class TeaMilkModule { }