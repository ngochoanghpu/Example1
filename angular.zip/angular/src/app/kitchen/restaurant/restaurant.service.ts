import { Injectable } from '@angular/core';
import { RestService } from '@abp/ng.core';
import { Observable } from 'rxjs';
import { ApiConfig } from 'src/app/config/api';
import { METHODS } from 'src/app/shared/constant/method';


@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

    apiName = 'kit';

    constructor(private restService: RestService) { }

    getConfig(id: string): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/app/${ApiConfig.Kitchen.GetConfig.replace("{id}", id)}`
        },
        { apiName: this.apiName });
    }

    getBills(storeCode: string = ""): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/app/${ApiConfig.Kitchen.GetBillsRestaurant.replace("{storeCode}", storeCode)}`
        },
        { apiName: this.apiName });
    }

    updateStatus(id: string, status: string, saleOrderDetailIds = [], storeCode: string = null, orderType: string = null): Observable<any> {
        const input = { id, orderStatus: status, saleOrderDetailIds: saleOrderDetailIds, storeCode: storeCode, orderType: orderType  };
        return this.restService.request<any, any>({
            method: METHODS.PUT,
            body: input,
            url: `/api/app/${ApiConfig.Kitchen.UpdateStatus}`
        },
        { apiName: this.apiName });
    }

    updateSaleOrderDetailStatus(id: string, status: string, storeCode: string, orderType: string = null): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.PUT,
            url: `/api/app/${ApiConfig.Kitchen.UpdateSaleOrderDetailStatus.replace("{id}", id).replace("{status}", status).replace("{storeCode}", storeCode).replace("{orderType}", orderType)}`
        },
        { apiName: this.apiName });
    }

    updateSaleOrderDetailLock(id: string, status: boolean): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.PUT,
            url: `/api/app/${ApiConfig.Kitchen.UpdateSaleOrderDetailLock.replace("{id}", id).replace("{status}", status.toString())}`
        },
        { apiName: this.apiName });
    }

    testSignalR(): Observable<any> {
        return this.restService.request<any, any>({
            method: METHODS.GET,
            url: `/api/app/${ApiConfig.Kitchen.TestSignalR}`
        },
        { apiName: this.apiName });
    }
}
