import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbDatepickerModule, NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
import { RestaurantComponent } from './restaurant.component';
import { RestaurantRoutingModule } from './restaurant-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [RestaurantComponent],
  imports: [
    CommonModule,
    SharedModule, 
    RestaurantRoutingModule,   
    NgbCollapseModule,
    NgbDatepickerModule    
  ]
})
export class RestaurantModule { }