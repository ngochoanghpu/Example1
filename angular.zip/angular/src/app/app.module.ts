import { SalesOrderDetailsState } from './store/states/salesOrderDetails/salesOrderDetails.state';
import { SalesOrdersState } from './store/states/salesOrders/salesOrders.state';
import { CoreModule } from '@abp/ng.core';
import { SettingManagementConfigModule } from '@abp/ng.setting-management.config';
import { ThemeSharedModule } from '@abp/ng.theme.shared';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxsLoggerPluginModule } from '@ngxs/logger-plugin';
import { NgxsModule } from '@ngxs/store';
import { AccountConfigModule } from '@volo/abp.ng.account.config';
import { AuditLoggingConfigModule } from '@volo/abp.ng.audit-logging.config';
import { IdentityServerConfigModule } from '@volo/abp.ng.identity-server.config';
import { IdentityConfigModule } from '@volo/abp.ng.identity.config';
import { LanguageManagementConfigModule } from '@volo/abp.ng.language-management.config';
import { SaasConfigModule } from '@volo/abp.ng.saas.config';
import { TextTemplateManagementConfigModule } from '@volo/abp.ng.text-template-management.config';
import { HttpErrorComponent } from '@volo/abp.ng.theme.lepton';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';

import { BigScreenModule } from 'angular-bigscreen';

const LOGGERS = [NgxsLoggerPluginModule.forRoot({ disabled: false })];
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ThemeSharedModule.forRoot({
      httpErrorConfig: {
        errorScreen: {
          component: HttpErrorComponent,
          forWhichErrors: [401, 403, 404, 500],
          hideCloseIcon: true,
        },
      },
    }),
    CoreModule.forRoot({
      environment,
    }),
    AccountConfigModule.forRoot({ redirectUrl: '/' }),
    IdentityConfigModule,
    LanguageManagementConfigModule,
    SaasConfigModule,
    AuditLoggingConfigModule,
    IdentityServerConfigModule,
    TextTemplateManagementConfigModule,
    SettingManagementConfigModule,
    BigScreenModule,
    NgxsModule.forRoot([SalesOrderDetailsState, SalesOrdersState, ]),
    SharedModule,

    ...(environment.production ? [] : LOGGERS),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
