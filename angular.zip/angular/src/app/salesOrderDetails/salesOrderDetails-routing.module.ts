import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PermissionGuard } from '@abp/ng.core';
import { SalesOrderDetailsComponent } from './salesOrderDetails/salesOrderDetails.component';

const routes: Routes = [
  {
    path: '',
    children: [{ path: '', component: SalesOrderDetailsComponent }],
    canActivate: [PermissionGuard],
    data: { requiredPolicy: 'kitchen.SalesOrderDetails' },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class SalesOrderDetailsRoutingModule { }
