import { Injectable } from '@angular/core';
import { RestService, ABP } from '@abp/ng.core';
import { SalesOrderDetails } from '../../store/models';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SalesOrderDetailsService {
  apiName = 'Default';

    constructor(private restService: RestService) { }

    get(params = {} as SalesOrderDetails.SalesOrderDetailsQueryParams): Observable<SalesOrderDetails.Response> {
        return this.restService.request<void, SalesOrderDetails.Response>({
            method: 'GET',
            url: '/api/app/salesOrderDetail',
            params
        },
        { apiName: this.apiName });
    }

    create(createSalesOrderDetailInput: SalesOrderDetails.SalesOrderDetailCreateUpdateDto): Observable<SalesOrderDetails.SalesOrderDetail> {
        return this.restService.request<SalesOrderDetails.SalesOrderDetailCreateUpdateDto, SalesOrderDetails.SalesOrderDetail>({
            method: 'POST',
            url: '/api/app/salesOrderDetail',
            body: createSalesOrderDetailInput
        },
        { apiName: this.apiName });
    }

    

    getById(id: string): Observable<SalesOrderDetails.SalesOrderDetail> {
        return this.restService.request<void, SalesOrderDetails.SalesOrderDetail>({
            method: 'GET',
            url: `/api/app/salesOrderDetail/${id}`
        },
        { apiName: this.apiName });
    }

    update(createSalesOrderDetailInput: SalesOrderDetails.SalesOrderDetailCreateUpdateDto, id: string): Observable<SalesOrderDetails.SalesOrderDetail> {
        return this.restService.request<SalesOrderDetails.SalesOrderDetailCreateUpdateDto, SalesOrderDetails.SalesOrderDetail>({
            method: 'PUT',
            url: `/api/app/salesOrderDetail/${id}`,
            body: createSalesOrderDetailInput
        },
        { apiName: this.apiName });
    }

    delete(id: string): Observable<void> {
        return this.restService.request<void, void>({
            method: 'DELETE',
            url: `/api/app/salesOrderDetail/${id}`
        },
        { apiName: this.apiName });
    }
}
