import { ConfirmationService, Confirmation } from '@abp/ng.theme.shared';
import { Component, TemplateRef, TrackByFunction, ViewChild, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { SalesOrderDetailsService } from './salesOrderDetails.service';
import { SalesOrderDetailsState } from '../../store/states';
import { SalesOrderDetails } from '../../store/models';
import { GetSalesOrderDetails, CreateUpdateSalesOrderDetail, DeleteSalesOrderDetail } from '../../store/actions';
import { NgbDateNativeAdapter, NgbDateAdapter } from '@ng-bootstrap/ng-bootstrap';
import snq from 'snq';

@Component({
  selector: 'app-salesOrderDetails',
  providers: [{ provide: NgbDateAdapter, useClass: NgbDateNativeAdapter }],
  templateUrl: './salesOrderDetails.component.html',
  styleUrls: ['./salesOrderDetails.component.scss'],
})

export class SalesOrderDetailsComponent implements OnInit {
  @Select(SalesOrderDetailsState.getSalesOrderDetails)
  data$: Observable<SalesOrderDetails.SalesOrderDetail[]>;

  @Select(SalesOrderDetailsState.getTotalCount)
  totalCount$: Observable<number>;

  @ViewChild('modalContent', { static: false })
  modalContent: TemplateRef<any>;

  form: FormGroup;

  selected: SalesOrderDetails.SalesOrderDetail;

  pageQuery: SalesOrderDetails.SalesOrderDetailsQueryParams = { maxResultCount: 10 };

  isModalVisible: boolean;

  isAdvancedFiltersHidden: boolean = true;

  loading: boolean = false;

  modalBusy: boolean = false;

  sortOrder: string = '';

  sortKey: string = '';

  

  trackByFn: TrackByFunction<AbstractControl> = (index, item) => Object.keys(item)[0] || index;

  get roleGroups(): FormGroup[] {
    return snq(() => (this.form.get('roleNames') as FormArray).controls as FormGroup[], []);
  }

  constructor(
    private confirmationService: ConfirmationService,
    public salesOrderDetailsService: SalesOrderDetailsService,
    private fb: FormBuilder,
    private store: Store,
  ) {}

  ngOnInit() {
    this.get();
  }

  onSearch(value) {
    this.pageQuery.filterText = value;
    this.get();
  }

  buildForm() {
      this.form = this.fb.group({
            salesOrderId: [this.selected.salesOrderId || '', []],
            salesOrderDetailId: [this.selected.salesOrderDetailId || '', []],
            sequentiaNumber: [this.selected.sequentiaNumber || '', []],
            barCode1: [this.selected.barCode1 || '', []],
            barCode2: [this.selected.barCode2 || '', []],
            itemCode: [this.selected.itemCode || '', []],
            productName: [this.selected.productName || '', []],
            serialNumber: [this.selected.serialNumber || '', []],
            lotNumber: [this.selected.lotNumber || '', []],
            uOSCode: [this.selected.uOSCode || '', []],
            uOSName: [this.selected.uOSName || '', []],
            uOSQuantity: [this.selected.uOSQuantity || '', []],
            uOMCode: [this.selected.uOMCode || '', []],
            uOMQuantity: [this.selected.uOMQuantity || '', []],
            notes: [this.selected.notes || '', []],
            isChild: [this.selected.isChild || false, []],
            indexNumber: [this.selected.indexNumber || '', []],
            salesOrderDetailStaus: [this.selected.salesOrderDetailStaus || '', []],
            isOptional: [this.selected.isOptional || false, []],
            productHierarchyCode: [this.selected.productHierarchyCode || '', []],
            productHierarchyName: [this.selected.productHierarchyName || '', []],
            productHierarchyOrder: [this.selected.productHierarchyOrder || '', []],
            recievedDateTime: [this.selected.recievedDateTime ? new Date(this.selected.recievedDateTime) : null, []],
            performedById: [this.selected.performedById || '', []],
            performedByName: [this.selected.performedByName || '', []],
            performedDateTime: [this.selected.performedDateTime ? new Date(this.selected.performedDateTime) : null, []],
            kitchenStaus: [this.selected.kitchenStaus || '', []],

      });
  }

  openModal() {
    this.buildForm();
    this.isModalVisible = true;
  }

  onAdd() {
    this.selected = {
    
    } as SalesOrderDetails.SalesOrderDetail;
    this.openModal();
  }

  onEdit(id: string) {
    this.salesOrderDetailsService
      .getById(id)
      .subscribe((state: SalesOrderDetails.SalesOrderDetail) => {
        this.selected = state;
        this.openModal();
      });
  }

  save() {
    if (!this.form.valid) return;
    this.modalBusy = true;

    this.store
      .dispatch(new CreateUpdateSalesOrderDetail({
              ...this.form.value,
            }, this.selected.id)
      )
      .pipe(finalize(() => (this.modalBusy = false)))
      .subscribe(() => {
        this.isModalVisible = false;
		this.get();
      });
  }

  delete(id: string) {
    this.confirmationService
      .warn('::DeleteConfirmationMessage', '::AreYouSure',{})
      .subscribe((status: Confirmation.Status) => {
        if (status === Confirmation.Status.confirm) {
          this.store.dispatch(new DeleteSalesOrderDetail(id)).subscribe(() => this.get())
        }
      });
  }

  onPageChange(page: number) {
    this.pageQuery.skipCount = (page - 1) * this.pageQuery.maxResultCount;

    this.get();
  }

  get() {
    this.loading = true;
	let filter = Object.assign({}, this.pageQuery);
	filter.recievedDateTimeMin = filter.recievedDateTimeMin ? new Date(filter.recievedDateTimeMin).toISOString() : "";
	filter.recievedDateTimeMax = filter.recievedDateTimeMax ? new Date(filter.recievedDateTimeMax).toISOString() : "";
	filter.performedDateTimeMin = filter.performedDateTimeMin ? new Date(filter.performedDateTimeMin).toISOString() : "";
	filter.performedDateTimeMax = filter.performedDateTimeMax ? new Date(filter.performedDateTimeMax).toISOString() : "";

    this.store
      .dispatch(new GetSalesOrderDetails(filter))
      .pipe(finalize(() => (this.loading = false)))
      .subscribe();
  }
}
