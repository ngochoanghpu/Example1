import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbDatepickerModule, NgbCollapseModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '../shared/shared.module';
import { SalesOrderDetailsRoutingModule } from './salesOrderDetails-routing.module';
import { SalesOrderDetailsComponent } from './salesOrderDetails/salesOrderDetails.component';

@NgModule({
  declarations: [SalesOrderDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    SalesOrderDetailsRoutingModule,
    NgbCollapseModule,
    NgbDatepickerModule
  ]
})

export class SalesOrderDetailsModule { }
