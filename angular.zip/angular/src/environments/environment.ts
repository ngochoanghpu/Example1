export const environment = {
  production: false,
  application: {
    name: 'kitchen',
  },
  oAuthConfig: {
    issuer: 'https://localhost:44325',
    clientId: 'KIT_App',
    dummyClientSecret: '1q2w3e*',   
    scope: 'Portal HR kitchen',
    showDebugInformation: true,
    oidc: false,
    requireHttps: true,
  },
  apis: {
    default: {
      url: 'https://localhost:44360'
    },
    mdm: {
      url: 'https://localhost:44360/mdm'
    },
    kit: {
      url: 'https://localhost:44360/kitchen'
    },
    hr: {
      url: 'https://localhost:44360/hr'
    },
    signalR: {
      url: 'https://localhost:44360/kitchen-signalr/GetAsynSignalR'
    },
  },
  localization: {
    defaultResourceName: 'kitchen',
  }
};
