export const environment = {
  production: true,
  application: {
    name: 'kitchen',
  },
  oAuthConfig: {
    issuer: 'http://tominh-qa-authserver.retailhub.vn',
    clientId: 'kitchen_App',
    dummyClientSecret: '1q2w3e*',
    scope: 'Portal kitchen HR',
    showDebugInformation: true,
    oidc: false,
    requireHttps: false,
  },
  apis: {
    default: {
      url: 'http://tominh-qa-portal-api.retailhub.vn'
    },
    kit: {
      url: 'http://tominh-qa-portal-api.retailhub.vn/kitchen'
    },
    mdm: {
      url: 'http://tominh-qa-portal-api.retailhub.vn/mdm'
    },
    hr: {
      url: 'http://tominh-qa-portal-api.retailhub.vn/hr'
    },
    signalR: {
      url: 'http://tominh-qa-portal-api.retailhub.vn/kitchen-signalr/GetAsynSignalR'
    }
  },
  localization: {
    defaultResourceName: 'kitchen',
  },
};
