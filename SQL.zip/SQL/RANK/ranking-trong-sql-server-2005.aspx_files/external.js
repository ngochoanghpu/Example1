var tileSlider = {
		pageSize: 2,
		offset: 104,
		delay: 100,
		sliderObj: { },
		timeout: {},
		count: 0, 
		pos: 0,
		curPos: 0,
		
		init:function(newTileCount, newSliderObj){
			var t;
			this.count = newTileCount;
			this.sliderObj = newSliderObj;
			this.sliderObj.style.width = this.offset + (newTileCount * this.offset) + 'px';			
		},

		prev:function(){
			var curPage = (Math.ceil(Math.abs(this.pos / this.offset)) / this.pageSize) + 1;
			if (curPage > 1) {
				this.curPos = this.pos;
				this.pos += (this.offset * this.pageSize);
				this.timeout = setTimeout('tileSlider.moveTiles(\'right\');',this.delay); 
			}
			return false;
		},

		next:function(){
			var lastPage = (Math.ceil(this.count / this.pageSize));
			var curPage = (Math.ceil(Math.abs(this.pos / this.offset)) / this.pageSize) + 1;
			if (curPage < lastPage) {
				this.curPos = this.pos;
				this.pos = this.pos - (this.offset * this.pageSize);
				this.timeout = setTimeout('tileSlider.moveTiles(\'left\');',this.delay); 			
			}	
			
			return false;
		},
		play:function(){
			
		},
		
		moveTiles:function(direction) {
			var k = false;
			this.curPos = (direction == 'left')?this.curPos - (this.offset/4):this.curPos + (this.offset/4);
			k = (direction == 'left')?this.curPos >= this.pos:this.curPos <= this.pos;
		    if (k)
		    {
				this.sliderObj.style.left = this.curPos + "px";
				this.timeout = setTimeout('tileSlider.moveTiles(\''+direction+'\');',this.delay); 
		    } else {
				this.sliderObj.style.left = this.pos + "px";
			}
		}
	}
	
