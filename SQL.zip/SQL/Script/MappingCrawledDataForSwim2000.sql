
Declare @CrawledSiteId Int
Set @CrawledSiteId = 4

-- Mapping Categories
Insert Into [192.168.1.7].[SO_Crawling].dbo.AQT_CRAWLING_CATEGORY
		([s_Category_Site_Id]
		,[s_CategoryName]
		,[s_CategoryLink]
		,[s_Category_Site_Parent_Id]
		,[s_CrawledSite]
		,[i_CrawledSiteID]
		,[s_Status]
		,[s_ErrorDescription]
		,[s_CrawledDate]
		,[i_TrackingID])
Select	[s_Category_Site_Id]
		,[s_CategoryName]
		,[s_CategoryLink]
		,[s_Category_Site_Parent_Id]
		,[s_CrawledSite]
		,[i_CrawledSiteID]
		,[s_Status]
		,[s_ErrorDescription]
		,[s_CrawledDate]
		,[i_TrackingID]
From	dbo.AQT_CRAWLING_CATEGORY tempC WITH(NOLOCK)
Where	tempC.s_Category_Site_Id Not In (Select s_Category_Site_Id From [192.168.1.7].[SO_Crawling].dbo.AQT_CRAWLING_CATEGORY WITH(NOLOCK) Where i_CrawledSiteID = @CrawledSiteId)

/* Mapping crawled products */
SELECT
@CrawledSiteId AS i_SiteId	
, 'Swim2000' AS s_Site
, ISNULL((SELECT TOP 1 l_Id FROM [72.3.250.20].beta_swimoutlet_com.dbo.AQT_COMPETITOR_BRAND B WITH(NOLOCK) WHERE B.s_BrandName=Swim2000.s_Brand), -1) AS i_BrandId
, CASE WHEN ISNULL(s_Brand,'')='' THEN 'UnAvaiable' ELSE s_Brand END AS s_BrandName
, (Select top 1 l_Id From [192.168.1.7].[SO_Crawling].dbo.AQT_CRAWLING_CATEGORY WITH(NOLOCK) Where s_Category_Site_Id = swim2000.s_Category_Site_Id) As l_CategoryID
, (Select top 1 [dbo].[properCase](REPLACE(REPLACE(REPLACE(REPLACE(s_Categoryname,'/',''),'-',' '),'KidsLearn to Swim','kids learn to swim'),'towels and robes','Towels & Robes')) From [192.168.1.7].[SO_Crawling].dbo.AQT_CRAWLING_CATEGORY WITH(NOLOCK) Where s_Category_Site_Id = swim2000.s_Category_Site_Id) As s_CategoryName
, s_Site_Product_Id AS s_SKU
, s_Site_Product_Id  AS s_ProductCode
, s_Product_Name AS s_ProductName
, s_Product_Image AS s_ProductImage
, '' AS s_ProductRange	
, Swim2000.sizes AS s_Size	 --AQT_SWIM2000_PRODUCT_OPTION.s_Size minimum available
, Swim2000.colors s_Color	 --One  Style of minimum size AQT_SWIM2000_PRODUCT_OPTION.s_Style
, s_Gender AS s_Gender
, s_Site_Prodcut_Detail AS s_ProductLink
, '' s_Price
, s_ListPrice
, 'NA' AS s_UniqueIdentifier
, s_Price_Being_Sold_At AS s_PriceSale
, 'NA' AS s_RegularPrice
, 'NA' AS s_SavingPrice
, s_Bulk_Pricing
, '' AS s_PriceRange
, '' AS s_Style
, 
  (
	SELECT TOP 1 T.s_VersionKey
	FROM dbo.AQT_PRODUCT_CRAWLED_QUEUE Q WITH(NOLOCK) JOIN
		 dbo.AQT_CRAWLING_TRACKING T WITH(NOLOCK) ON Q.i_TrackingId=T.l_Id
	WHERE Q.l_Id = Swim2000.l_QueueID
  ) AS i_Version	--Ref AQT_CRAWLING_TRACKING.s_VersionKey
, s_Product_Descripition AS s_Description
, 
  (
	SELECT TOP 1 T.s_Status
	FROM dbo.AQT_PRODUCT_CRAWLED_QUEUE Q WITH(NOLOCK) JOIN
		 dbo.AQT_CRAWLING_TRACKING T WITH(NOLOCK) ON Q.i_TrackingId=T.l_Id
	WHERE Q.l_Id=Swim2000.l_QueueID
  ) AS s_Status	--Ref AQT_CRAWLING_TRACKING.s_Status
, GETDATE() AS t_AddedDate	--Update later on table  AQT_SWIM2000_CRAWLING_PRODUCT
, 0 AS i_AddedByUserId	--Update later on table  AQT_SWIM2000_CRAWLING_PRODUCT
, GETDATE() AS t_ModifiedDate	--NA
, 0 AS i_ModifiedByUserId	--NA
INTO #TempTable
FROM dbo.AQT_SWIM2000_CRAWLING_PRODUCT Swim2000 WITH(NOLOCK)

-- Insert new products
INSERT INTO dbo.SOT_PRODUCT_COMPETITOR
        ( i_SiteId ,
          s_Site ,
          i_BrandId ,
          s_BrandName ,
          i_CategoryId ,
          s_CategoryName ,
          s_SKU ,
          s_ProductCode ,
          s_ProductName ,
          s_ProductImage ,
          s_ProductRange ,
          s_Size ,
          s_Color ,
          s_Gender ,
          s_ProductLink ,
          s_Price ,
          s_ListPrice,
          s_UniqueIdentifier,
          s_PriceSale,
          s_RegularPrice,
          s_SavingPrice,
          s_BulkPrice,
          s_SoldBy,
          s_PriceRange ,
          s_Style ,
          s_Version ,
          s_Description ,
          s_Status ,
          t_AddedDate ,
          i_AddedByUserId ,
          t_ModifiedDate ,
          i_ModifiedByUserId
        )
SELECT	i_SiteId ,
		s_Site ,
		i_BrandId ,
		s_BrandName ,
		i_CategoryId ,
		s_CategoryName ,
		s_SKU ,
		s_ProductCode ,
		s_ProductName ,
		s_ProductImage ,
		s_ProductRange ,
		s_Size ,
		s_Color ,
		s_Gender ,
		s_ProductLink ,
		s_Price ,
		s_ListPrice,
		s_UniqueIdentifier,
		s_PriceSale,
		s_RegularPrice,
		s_SavingPrice,
		s_Bulk_Pricing,
		'NA' AS s_SoldBy,
		s_PriceRange ,
		s_Style ,
		i_Version ,
		s_Description ,
		s_Status ,
		t_AddedDate ,
		i_AddedByUserId ,
		t_ModifiedDate ,
		i_ModifiedByUserId
FROM	#TempTable t
Where	s_ProductCode Not In (Select s_ProductCode From SOT_PRODUCT_COMPETITOR Where i_SiteId = @CrawledSiteId)

-- Update existing products
Update	SOT_PRODUCT_COMPETITOR Set
		SOT_PRODUCT_COMPETITOR.s_Size = t.s_Size,
		SOT_PRODUCT_COMPETITOR.s_Price = t.s_PriceSale,
		SOT_PRODUCT_COMPETITOR.t_ModifiedDate = GETDATE()
From	#TempTable t
Where	SOT_PRODUCT_COMPETITOR.i_SiteId = @CrawledSiteId And SOT_PRODUCT_COMPETITOR.s_ProductCode = t.s_ProductCode


/* Insert log */
