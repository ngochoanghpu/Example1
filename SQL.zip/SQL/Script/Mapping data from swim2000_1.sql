--Run on 1.8--
SELECT-- TOP 10
4 AS i_SiteId	
, 'Swim2000' AS s_Site
, ISNULL((SELECT TOP 1 l_Id FROM [72.3.250.20].beta_swimoutlet_com.dbo.AQT_COMPETITOR_BRAND B WITH(NOLOCK) WHERE B.s_BrandName=Swim2000.s_Brand),-1) AS i_BrandId
, CASE WHEN ISNULL(s_Brand,'')='' THEN 'UnAvaiable' ELSE s_Brand END AS s_BrandName
, l_CategoryID AS i_CategoryId
, ISNULL((SELECT
[dbo].[properCase](REPLACE(REPLACE(REPLACE(REPLACE(s_Categoryname,'/',''),'-',' '),'KidsLearn to Swim','kids learn to swim'),'towels and robes','Towels & Robes'))
FROM dbo.[AQT_CRAWLING_CATEGORY] C WITH(NOLOCK)
WHERE s_CrawledSite='swim2000.com'
	  AND s_Categoryname <>'Category 1  SwimOutlet'
	  AND C.l_id=swim2000.l_CategoryID
),'') AS s_CategoryName --Ref [AQT_CRAWLING_CATEGORY].s_CategoryName
, s_Site_Product_Id AS s_SKU
, 'NA'  AS s_ProductCode
, s_Product_Name AS s_ProductName
, s_Product_Image AS s_ProductImage
, '' AS s_ProductRange	
, Swim2000.sizes AS s_Size	 --AQT_SWIM2000_PRODUCT_OPTION.s_Size minimum available
, Swim2000.colors s_Color	 --One  Style of minimum size AQT_SWIM2000_PRODUCT_OPTION.s_Style
, s_Gender AS s_Gender
, s_Site_Prodcut_Detail AS s_ProductLink
, '' s_Price
, s_ListPrice
, 'NA' AS s_UniqueIdentifier
, s_Price_Being_Sold_At AS s_PriceSale
, 'NA' AS s_RegularPrice
, 'NA' AS s_SavingPrice
, s_Bulk_Pricing
, '' AS s_PriceRange
, '' AS s_Style
, 
  (
	SELECT TOP 1 T.s_VersionKey
	FROM dbo.AQT_PRODUCT_CRAWLED_QUEUE Q WITH(NOLOCK) JOIN
		 dbo.AQT_CRAWLING_TRACKING T WITH(NOLOCK) ON Q.i_TrackingId=T.l_Id
	WHERE Q.l_Id=Swim2000.l_QueueID
  ) AS i_Version	--Ref AQT_CRAWLING_TRACKING.s_VersionKey
, s_Product_Descripition AS s_Description
, 
  (
	SELECT TOP 1 T.s_Status
	FROM dbo.AQT_PRODUCT_CRAWLED_QUEUE Q WITH(NOLOCK) JOIN
		 dbo.AQT_CRAWLING_TRACKING T WITH(NOLOCK) ON Q.i_TrackingId=T.l_Id
	WHERE Q.l_Id=Swim2000.l_QueueID
  ) AS s_Status	--Ref AQT_CRAWLING_TRACKING.s_Status
, GETDATE() AS t_AddedDate	--Update later on table  AQT_SWIM2000_CRAWLING_PRODUCT
, 0 AS i_AddedByUserId	--Update later on table  AQT_SWIM2000_CRAWLING_PRODUCT
, GETDATE() AS t_ModifiedDate	--NA
, 0 AS i_ModifiedByUserId	--NA
INTO SOT_PRODUCT_COMPETITOR_FLATDATA_08032012
FROM dbo.AQT_SWIM2000_CRAWLING_PRODUCT Swim2000 WITH(NOLOCK)

--Run on .16 server--
INSERT INTO dbo.SOT_PRODUCT_COMPETITOR
        ( i_SiteId ,
          s_Site ,
          i_BrandId ,
          s_BrandName ,
          i_CategoryId ,
          s_CategoryName ,
          s_SKU ,
          s_ProductCode ,
          s_ProductName ,
          s_ProductImage ,
          s_ProductRange ,
          s_Size ,
          s_Color ,
          s_Gender ,
          s_ProductLink ,
          s_Price ,
          s_ListPrice,
          s_UniqueIdentifier,
          s_PriceSale,
          s_RegularPrice,
          s_SavingPrice,
          s_BulkPrice,
          s_SoldBy,
          s_PriceRange ,
          s_Style ,
          s_Version ,
          s_Description ,
          s_Status ,
          t_AddedDate ,
          i_AddedByUserId ,
          t_ModifiedDate ,
          i_ModifiedByUserId
        )
SELECT i_SiteId ,
          s_Site ,
          i_BrandId ,
          s_BrandName ,
          i_CategoryId ,
          s_CategoryName ,
          s_SKU ,
          s_ProductCode ,
          s_ProductName ,
          s_ProductImage ,
          s_ProductRange ,
          s_Size ,
          s_Color ,
          s_Gender ,
          s_ProductLink ,
          s_Price ,
          s_ListPrice,
          s_UniqueIdentifier,
          s_PriceSale,
          s_RegularPrice,
          s_SavingPrice,
          s_Bulk_Pricing,
          'NA' AS s_SoldBy,
          s_PriceRange ,
          s_Style ,
          i_Version ,
          s_Description ,
          s_Status ,
          t_AddedDate ,
          i_AddedByUserId ,
          t_ModifiedDate ,
          i_ModifiedByUserId
FROM [115.78.239.237].[ProductCrawlingTesting].[dbo].[SOT_PRODUCT_COMPETITOR_FLATDATA_08032012]
