WITH tmp as (
   select s_FirstName, s_LastName, count(*) as total from tblTest
   group by s_FirstName, s_LastName
)

delete t
from tblTest t
inner join tmp on t.s_FirstName = tmp.s_FirstName and t.s_LastName = tmp.s_LastName and tmp.total > 1