ALTER procedure [dbo].[PSP_INSERTUSER]
(
	@s_Email nvarchar(128),
	@s_FirstName nvarchar(64),
	@s_Gender nvarchar(1),
	@s_LastName nvarchar(64),
	@s_ScreenName nvarchar(128),
	@s_City nvarchar(64),
	@s_State nvarchar(64),
	@s_PostalCode nvarchar(16),
	@s_Country nvarchar(3),
	@l_LoginId bigint,
	@t_BirthDate datetime
)
AS
Begin
	Insert into PST_USER(s_Email,s_FirstName,s_Gender,s_LastName,s_ScreenName,s_City,s_State,s_PostalCode,s_Country,l_LoginId,t_BirthDate) 
	values (@s_Email,@s_FirstName,@s_Gender,@s_LastName,@s_ScreenName,@s_City,@s_State,@s_PostalCode,@s_Country,@l_LoginId,@t_BirthDate)
	IF @@ERROR = 0
	BEGIN
		Select top 1 * from PST_USER where l_Id = @@IDENTITY order by t_AddedDate desc
	END
End