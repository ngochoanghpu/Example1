select count(*) as total from tblBooks

select count(distinct s_FirstName) as total from tblTest