
ALTER procedure [dbo].[PSP_BLOG_COMMENT_COUNT]  
 @Id bigint,
 @status nvarchar(25)
as  
begin  
 select * from dbo.f_get_nodechirent(@Id, @status)  
end