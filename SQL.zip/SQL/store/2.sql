ALTER Procedure [dbo].[MappingBrand]  
  
	@CompetitorId		int,
	@NumberOfProducts	int,
	@BrandName			varchar(255)

As
Begin

	If Exists (Select top 1 1 From dbo.AQT_COMPETITOR_BRAND Where i_CompetitorId = @CompetitorId And s_BrandName = @BrandName)  
		Begin  

			Update dbo.AQT_COMPETITOR_BRAND Set i_NumberOfProducts = @NumberOfProducts Where i_CompetitorId = @CompetitorId And s_BrandName = @BrandName  

		End  
	Else  
		Begin

			Insert Into dbo.AQT_COMPETITOR_BRAND(s_BrandName, i_CompetitorId, i_NumberOfProducts, t_RecentlyAdded, s_Status, l_AddedByLoginId, t_AddedDate, l_ModifiedByLoginId, t_ModifiedDate) Values(@BrandName, @CompetitorId, @NumberOfProducts, GETDATE(), 'ACTIVE', 0, GETDATE(), 0, GETDATE())  

		End  
  
End