USE [SO_Crawling]
GO
/****** Object:  StoredProcedure [dbo].[job_SynCATEGORYClawlingData]    Script Date: 09/17/2012 09:59:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Nghia Nguyen 
-- Create date: 
-- Description:	Syn the lasted version of Amazon clawling data
-- =============================================
ALTER PROCEDURE [dbo].[job_SynCATEGORYClawlingData]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		
-- Insert Categories
	INSERT INTO AQT_COMPETITOR_CATEGORY
           (s_Category_Site_Id
           ,s_SiteId
           ,s_CategoryName
           ,s_CategoryLink
           ,s_Category_Site_Parent_Id
           ,s_Status
           ,s_ErrorDescription
           ,s_CrawledDate
           ,l_AddedByLoginId
           ,t_AddedDate
           ,l_ModifiedByLoginId
           ,t_ModifiedDate
           ,i_CategoryId
           ,s_CrumbTrails)
	Select	s_Category_Site_Id
		   ,i_CrawledSiteID
           ,s_CategoryName
           ,s_CategoryLink
           ,s_Category_Site_Parent_Id
           ,s_Status
           ,s_ErrorDescription
           ,s_CrawledDate
           ,0
           ,GetDATE()
           ,0
           ,GETDATE()
           ,0
           ,s_CrumbTrails
	FROM	AQT_CRAWLING_CATEGORY t WITH(NOLOCK)
	WHERE	t.s_Category_Site_Id NOT IN (SELECT s_Category_Site_Id 
												FROM AQT_COMPETITOR_CATEGORY c WITH(NOLOCK) WHERE  c.s_SiteId = t.i_CrawledSiteID )
	--Update 
	UPDATE c 
		SET          
           s_CategoryName = t.s_CategoryName
           ,s_CategoryLink = t.s_CategoryLink
           ,s_Category_Site_Parent_Id= t.s_Category_Site_Parent_Id
           ,s_Status= t.s_Status
           ,s_ErrorDescription= t.s_ErrorDescription
           ,s_CrawledDate= t.s_CrawledDate
           ,l_AddedByLoginId=0
           ,t_AddedDate=0
           ,l_ModifiedByLoginId=0
           ,t_ModifiedDate=GetDATE()
           ,i_CategoryId=0
           ,s_CrumbTrails= t.s_CrumbTrails	
	FROM	AQT_CRAWLING_CATEGORY t WITH(NOLOCK)
	INNER JOIN AQT_COMPETITOR_CATEGORY c ON c.s_Category_Site_Id = t.s_Category_Site_Id AND  c.s_SiteId = t.i_CrawledSiteID
	
	;WITH tmp AS (
			SELECT l_id, ROW_NUMBER() OVER (PARTITION BY s_SiteId, s_Category_Site_Id ORDER BY l_id)  AS row
			FROM AQT_COMPETITOR_CATEGORY (NOLOCK)			
			)
	DELETE t
	FROM AQT_COMPETITOR_CATEGORY t
	INNER JOIN tmp ON tmp.l_id = t.l_id
	WHERE tmp.row > 1	
		
END
