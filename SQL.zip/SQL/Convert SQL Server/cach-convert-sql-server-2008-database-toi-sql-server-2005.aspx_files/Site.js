﻿/*------------------------------------------------------------------------
# VietClound Library JS Module
# ------------------------------------------------------------------------
# Copyright 2009 VietCloud, All Rights Reserved.
# Websites:  http://www.vietcloud.com -  Email: Hungnv_it2002@yahoo.com
------------------------------------------------------------------------- */
function getNodeValue(o) {
    if (o.item(0)) {
        if (o.item(0).firstChild) {
            return o.item(0).firstChild.nodeValue;
        }
        else {
            return '';
        }
    }
    else {
        return '';
    }
}

function getNodeValueAll(obj, tag) {    
    return obj.getElementsByTagName(tag)[0].firstChild.nodeValue;
}


// --- Get Data -----------
//function GetMenuTop() {
//    var resual = "";
//    AjaxRequest.get(
//                        {
//                            'url': '/Resources/MenuTop.xml'
//                        , 'onSuccess': function(req) {
//                            resual = getNodeValue(req.responseXML.getElementsByTagName('Root').item(0).getElementsByTagName('Menu'));
//                            document.getElementById("MenuItem").innerHTML = resual;

//                        }
//                        , 'onError': function(req) { }
//                        }
//                    );
//                    }
function GetBlockCustome() {
    var resual = "";
    AjaxRequest.get(
    {
        'url': '/Resources/Advertise/Advertise04.xml'
    , 'onSuccess': function(req) {
        resual = getNodeValue(req.responseXML.getElementsByTagName('Root').item(0).getElementsByTagName('Item'));
        
        document.getElementById("BlockCustome").innerHTML = resual;

    }
    , 'onError': function(req) { }
    }
);
}

function GetContact() {
    var resual = "";
    AjaxRequest.get(
    {
        'url': '/Resources/Contact.xml'
    , 'onSuccess': function(req) {
        resual = getNodeValue(req.responseXML.getElementsByTagName('Root').item(0).getElementsByTagName('Item'));

        document.getElementById("ContentProduct").innerHTML = resual;

    }
    , 'onError': function(req) { }
    }
);
}

function GetCompanyInfo() {
    var resual = "";
    AjaxRequest.get(
    {
        'url': '/Resources/CompanyInfo.xml'
    , 'onSuccess': function(req) {
        resual = getNodeValue(req.responseXML.getElementsByTagName('Root').item(0).getElementsByTagName('Item'));

        document.getElementById("CompanyInfo").innerHTML = resual;

    }
    , 'onError': function(req) { }
    }
);
}

function GetEvent() {
    AjaxRequest.get(
	{
	    "url": "/Resources/Advertise/Advertise03.xml"
		, 'onSuccess': function(req) {
		    var Item = req.responseXML.getElementsByTagName('item');

		    var tem = "";
		    tem += "<ul>";
		    for (var i = 0; i < Item.length; i++) {
		        tem += "<li>";
		        tem += "<a href='" + getNodeValueAll(Item[i], 'url') + "' title='" + getNodeValueAll(Item[i], 'Eventtitle') + "'><img src='" + getNodeValueAll(Item[i], 'image') + "' alt='" + getNodeValueAll(Item[i], 'Eventtitle') + "'/></a>";
		        tem += "</li>";
		    }
		    tem += "</ul>";
		    document.getElementById("home_stories").innerHTML = tem;
		}
	}
	);
}

function GetAdvHomeVip() {
    AjaxRequest.get(
	{
	    "url": "/Resources/Advertise/AdvHomeVip.xml"
		, 'onSuccess': function(req) {
		    var Item = req.responseXML.getElementsByTagName('item');

		    for (var i = 0; i < Item.length; i++) {
		        tem = "<object height='300' border='0' width='930' codebase='http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000'>";
		        tem += "<param value='" + getNodeValueAll(Item[i], 'image') + "' name='movie'/>";
		        tem += "<param value='always' name='AllowScriptAccess'/>";
		        tem += "<param value='High' name='quality'/>";
		        tem += "<param value='transparent' name='wmode'/>";
		        tem += "<embed height='300' width='930' allowscriptaccess='always' wmode='transparent' type='application/x-shockwave-flash' pluginspage='http://www.macromedia.com/go/getflashplayer' src='" + getNodeValueAll(Item[i], 'image') + "'/>";
		        tem += "</object>";
		    }

		    document.getElementById("advHomeVip").innerHTML = tem;
		}
	}
	);
}

function GetAdvHomeNoiBat() {
    AjaxRequest.get(
	{
	    "url": "/Resources/Advertise/AdvHomeNoiBat.xml"
		, 'onSuccess': function(req) {
		    var Item = req.responseXML.getElementsByTagName('item');

		    for (var i = 0; i < Item.length; i++) {
		        tem = "<object height='140' border='0' width='690' codebase='http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000'>";
		        tem += "<param value='" + getNodeValueAll(Item[i], 'image') + "' name='movie'/>";
		        tem += "<param value='always' name='AllowScriptAccess'/>";
		        tem += "<param value='High' name='quality'/>";
		        tem += "<param value='transparent' name='wmode'/>";
		        tem += "<embed height='140' width='690' allowscriptaccess='always' wmode='transparent' type='application/x-shockwave-flash' pluginspage='http://www.macromedia.com/go/getflashplayer' src='" + getNodeValueAll(Item[i], 'image') + "'/>";
		        tem += "</object>";
		    }

		    document.getElementById("AdvHomeNoiBat").innerHTML = tem;
		}
	}
	);
}

function GetAdvHomeRight() {
    AjaxRequest.get(
	{
	    "url": "/Resources/Advertise/AdvHomeRight.xml"
		, 'onSuccess': function(req) {
		    var Item = req.responseXML.getElementsByTagName('item');
		    var tem = "";

		    for (var i = 0; i < Item.length; i++) {
		        tem += "<object border='0' width='200' height='250' codebase='http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000'>";
		        tem += "<param value='" + getNodeValueAll(Item[i], 'image') + "' name='movie'/>";
		        tem += "<param value='always' name='AllowScriptAccess'/>";
		        tem += "<param value='High' name='quality'/>";
		        tem += "<param value='transparent' name='wmode'/>";
		        tem += "<embed width='200' height='250' allowscriptaccess='always' wmode='transparent' type='application/x-shockwave-flash' pluginspage='http://www.macromedia.com/go/getflashplayer' src='" + getNodeValueAll(Item[i], 'image') + "'/>";
		        tem += "</object>";

		        //if (Trim(getNodeValueAll(Item[i], 'url')) == "") {
		          //  tem += "<img src='" + getNodeValueAll(Item[i], 'image') + "' alt='" + getNodeValueAll(Item[i], 'Eventtitle') + "' width='200' border='0'/>";
		        //}
		        //else {
		        //    tem += "<a href='" + getNodeValueAll(Item[i], 'url') + "'><img src='" + getNodeValueAll(Item[i], 'image') + "' alt='" + getNodeValueAll(Item[i], 'Eventtitle') + "' width='200' border='0'/></a>";
		        //}
		    }

		    document.getElementById("AdvHomeRight").innerHTML = tem;
		}
	}
	);
}

function GetHomeNew() {
    AjaxRequest.get(
	{
	    "url": "/Resources/Home_New.xml"
		, 'onSuccess': function(req) {
		    var Item = req.responseXML.getElementsByTagName('item');

		    var tem = "";
		    tem += "<ul>";
		    for (var i = 0; i < Item.length; i++) {
		        tem += "<li>";
		        tem += "<a href='" + getNodeValueAll(Item[i], 'link') + "' title='" + getNodeValueAll(Item[i], 'title') + "'>" + getNodeValueAll(Item[i], 'title') + "</a>";
		        tem += "</li>";
		    }
		    tem += "</ul>";
		    document.getElementById("home_new").innerHTML = tem;
		}
	}
	);
}
function GetHomeFlashLeft() {
    AjaxRequest.get(
	{
	    "url": "/Resources/Advertise/Advertise01.xml"
		, 'onSuccess': function(req) {
		    var Item = req.responseXML.getElementsByTagName('item');

            for (var i = 0; i < Item.length; i++) {
                tem = "<object height='235' border='0' width='392' codebase='http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0' classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000'>";
                tem += "<param value='" + getNodeValueAll(Item[i], 'image') + "' name='movie'/>";
                tem += "<param value='always' name='AllowScriptAccess'/>";
                tem += "<param value='High' name='quality'/>";
                tem += "<param value='transparent' name='wmode'/>";
                tem += "<embed height='235' width='392' allowscriptaccess='always' wmode='transparent' type='application/x-shockwave-flash' pluginspage='http://www.macromedia.com/go/getflashplayer' src='" + getNodeValueAll(Item[i], 'image') + "'/>";
                tem += "</object>";
            }
            		    
		    document.getElementById("home_flashleft").innerHTML = tem;
		}
	}
	);
}

// --- End Get Data -----------------------

function GetContent(objActive, objNoActive, id) {
    for (i = 1; i <= 2; i++) {       
        document.getElementById("Tab0" + i).style.color = 'yellow';
    }
    document.getElementById("Tab0" + id).style.color = 'white';
         
    document.getElementById(objActive).style.display = 'block';
    document.getElementById(objNoActive).style.display = 'none';
}

function CheckFrmSupport(frm) {
    if (frm.txtFullName.value == "") {
        alert("Xin vui lòng nhập vào họ tên!");
        frm.txtFullName.focus();
        return false;
    }
//    if (frm.txtEmail.value == "") {
//        alert("Xin vui lòng nhập vào địa chỉ email!");
//        frm.txtEmail.focus();
//        return false;
//    }
    if ((frm.txtEmail.value != "") && (frm.txtEmail.value != "None")) {
        if ((frm.txtEmail.value.indexOf("@", 0) == -1) || (frm.txtEmail.value.indexOf(".", 0) == -1)) {
            alert("Email không hợp lệ");
            frm.txtEmail.focus();
            return false;
        }
    }
    if (frm.txtEmail.value.length > 100) {
        alert("Địa chỉ E-mail được dài quá 100 ký tự");
        frm.txtEmail.focus();
        return false;
    }
    if ((frm.txtEmail.value != "") && (frm.txtEmail.value != "None") && (frm.txtEmail.value != "@yahoo.com")) {
        if ((frm.txtEmail.value.indexOf("@", 0) == -1) || (frm.txtEmail.value.indexOf(".", 0) == -1)) {
            alert("Email không hợp lệ");
            frm.txtEmail.focus();
            return false;
        }
    }
    for (var i = 0; i < frm.txtEmail.value.length; i++) {
        var ch = frm.txtEmail.value.substring(i, i + 1);
        if (((ch < "a" || "z" < ch) && (ch < "A" || "Z" < ch) && (ch < "0" || "9" < ch)) && ch != '-' && ch != '.' && ch != '@' && ch != '_') {
            alert("Địa chỉ e-mail không đúng!");
            frm.txtEmail.focus();
            return false;
        }
    }
    if (frm.txtTel.value != "") {
        for (var i = 0; i < frm.txtTel.value.length; i++) {
            var ch = frm.txtTel.value.substring(i, i + 1);
            if (((ch < "0" || "9" < ch)) && ch != '(' && ch != ')' && ch != '.' && ch != ' ') {
                alert("Số điện thoại không đúng!");
                frm.txtTel.focus();
                return false;
            }
        }
        if (frm.txtTel.value.length > 20 || frm.txtTel.value.length < 9) {
            alert("Số điện thoại không được nhỏ hơn 9 và lớn hơn 20 ký tự");
            frm.txtTel.focus();
            return false;
        }
    }
    if (frm.txtTitle.value == "") {
        alert("Xin vui lòng nhập vào tiêu đề câu hỏi!");
        frm.txtTitle.focus();
        return false;
    }
    if (frm.txtQuestion.value == "") {
        alert("Xin vui lòng nhập vào nội dung câu hỏi!");
        frm.txtQuestion.focus();
        return false;
    }
    else {
        if (frm.txtQuestion.value == "Mọi thắc mắc về sản phẩm bạn có thể đặt câu hỏi tại đây...") {
            alert("Xin vui lòng nhập vào nội dung câu hỏi!");
            frm.txtQuestion.focus();
            return false;
        }
    }
    frm.hddAction.value = "true";
    //frm.action = "/MD/Support/";
    frm.submit();
}

function Search() {
    if (document.aspnetForm.txtKey.value != "" && document.aspnetForm.txtKey.value  != "Từ khóa tìm kiếm") {
        document.aspnetForm.action = "/MD/Search/default.aspx";
        document.aspnetForm.submit();
    }
    else {
        alert("Vui lòng nhập vào từ khóa cần tìm kiếm!");
        return false;
    }
}

function SearchOnFocus(obj) {
    if (Trim(obj.value) == "Từ khóa tìm kiếm") { obj.value = ''; }
}

function SearchOnBlur(obj) {
    if (Trim(obj.value) == '') { obj.value = 'Từ khóa tìm kiếm'; }
}

function ActiveOnclick(url, menuID) {
    //setCookie("MenuActiveID", "", "", menuID);
    window.location.href = url;
}

function ActiveOnOver(obj, action) {
    if (action == false) {
        document.getElementById("MenuActiveBg" + obj).className = "MenuActiveBg";
        document.getElementById("MenuActiveIcon" + obj).className = "MenuActiveIcon";
    }
}

function ActiveOnOut(obj, action) {
    if (action == false) {
        document.getElementById("MenuActiveBg" + obj).className = "MenuNoActiveBg";
        document.getElementById("MenuActiveIcon" + obj).className = "MenuNoActiveIcon";
    }
}