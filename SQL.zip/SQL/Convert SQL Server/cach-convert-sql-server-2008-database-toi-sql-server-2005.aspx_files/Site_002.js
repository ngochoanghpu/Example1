﻿/*------------------------------------------------------------------------
# VietClound Library JS Module
# ------------------------------------------------------------------------
# Copyright 2009 VietCloud, All Rights Reserved.
# Websites:  http://www.vietcloud.com -  Email: Hungnv_it2002@yahoo.com
------------------------------------------------------------------------- */
function Trim(iStr) {
    while (iStr.charCodeAt(0) <= 32) {
        iStr = iStr.substr(1);
    }

    while (iStr.charCodeAt(iStr.length - 1) <= 32) {
        iStr = iStr.substr(0, iStr.length - 1);
    }

    return iStr;
}
function ltrim(str, chars) {
    chars = chars || "\\s";
    return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
}
function rtrim(str, chars) {
    chars = chars || "\\s";
    return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}

function GoPage(url) {
    window.location.href = url;
}

function GoBack() {
    window.history.back();
}

function Rundate() {
    var now = new Date();
    var hrs = now.getHours();
    var min = now.getMinutes();
    var sec = now.getSeconds();
    var day = now.getDate();
    var ngay = now.getDay();
    var month = now.getMonth() + 1;
    var year = now.getFullYear();
    var strDate = "";
    var don = "AM";

    if (hrs >= 12) { don = "PM" }
    if (hrs > 12) { hrs -= 12 }
    if (hrs == 0) { hrs = 12 }
    if (hrs < 10) { hrs = "0" + hrs }
    if (min < 10) { min = "0" + min }
    if (sec < 10) { sec = "0" + sec }
    switch (ngay) {
        case 0: strDate = "Chủ nhật, "; break; case 1: strDate = "Thứ hai, "; break; case 2: strDate = "Thứ 3, "; break; case 3: strDate = "Thứ 4, "; break; case 4: strDate = "Thứ 5, "; break; case 5: strDate = "Thứ 6, "; break; case 6: strDate = "Thứ 7, ";
    }
    document.getElementById('todaydate').innerHTML = strDate + day + "/" + month + "/" + year + " | " + hrs + ":" + min + ":" + sec + " " + don;
    setTimeout("Rundate()", 1000);
}

function SetAccResizePos(ID) {
    var _clientWidth = document.body.clientWidth;

    if (_clientWidth <= 800) {
        document.getElementById(ID).style.left = 800;
    }
    if (_clientWidth > 800 && _clientWidth <= 1024) {
        document.getElementById(ID).style.left = 800;
    }
    if (_clientWidth > 1024 && _clientWidth <= 1280) {
        document.getElementById(ID).style.left = 925;
    }
    if (_clientWidth >= 1028) {
        document.getElementById(ID).style.left = 768;
    }
}

function parseXML() {
    try //Internet Explorer
  {
        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
    }
    catch (e) {
        try //Firefox, Mozilla, Opera, etc.
    {
            xmlDoc = document.implementation.createDocument("", "", null);
        }
        catch (e) {
            alert(e.message);
            return;
        }
    }
    xmlDoc.async = false;
    xmlDoc.load("/Resource/catalog.xml");
    var html = "";
    html += "<div class='Catalog'>";
    for (var i = 0; i < xmlDoc.getElementsByTagName("item").length; i++) {
        html += "<div class='Catalog1'>";
        html += "<div class='icon'>";
        html += "<img src='" + trim(xmlDoc.getElementsByTagName("icon")[i].childNodes[0].nodeValue) + "'/>";
        html += "</div>";
        html += "<div class='title'>";
        //html += "<a href='" + trim(xmlDoc.getElementsByTagName("Link")[i].childNodes[0].nodeValue)+"'>";
        html += trim(xmlDoc.getElementsByTagName("NameItem")[i].childNodes[0].nodeValue);
        html += "</div>";
        //html += "</a>"
        html += "</div>";
        if (xmlDoc.getElementsByTagName("Name" + [i]).length > 0) {
            var spe = 0;
            for (var j = 0; j < xmlDoc.getElementsByTagName("Name" + [i]).length; j++) {
                spe += 1;
                html += "<div class='Catalog2'>";
                html += "   <div class='iconchild'></div>";
                html += "   <div class='child'>";
                html += "       <a href=" + trim(xmlDoc.getElementsByTagName("LinkChildID" + [i])[j].childNodes[0].nodeValue) + " onclick='SetSearchAll(\"-1\");' hidefocus='' onfocus='this.blur();'>"
                html += trim(xmlDoc.getElementsByTagName("Name" + [i])[j].childNodes[0].nodeValue);
                html += "       </a>";
                html += "   </div>";
                html += "</div>";
                if (spe < xmlDoc.getElementsByTagName("Name" + [i]).length) {
                    html += "<div class='spe'></div>"
                }
            }
        }
    }
    html += "</div>";
    //alert(html);
    document.getElementById("catalog").innerHTML = html;
}

function SupportOnFocus(obj) {
    //alert("focus");
    if (Trim(obj.value) == "Mọi thắc mắc về sản phẩm bạn có thể đặt câu hỏi tại đây...") { obj.value = ''; }
}

function SupportOnBlur(obj) {
    //alert("bur");
    if (Trim(obj.value) == '') { obj.value = 'Mọi thắc mắc về sản phẩm bạn có thể đặt câu hỏi tại đây...'; }
}

function CheckSubmit(o) {
    if (Trim(o.value) == 'Từ khóa tìm kiếm' || Trim(o.value) == '') {
        o.value = '';
        o.focus();
        return false;
    }
    else {
        if (document.form1.hidShoppingType.value == 0) {
            document.form1.action = "/baycao/buy/?ID=" + document.form1.hidSearch.value;
        }
        else {
            document.form1.action = "/baycao/catalog/?ID=" + document.form1.hidSearch.value;
        }
        document.form1.submit();
        return true;
    }
}

function CheckEnter(e) {
    var flag = false;
    if (window.event) {
        if (e.keyCode == 13) {
            flag = true;            
        }
    }
    else if (e.which) {
        if (e.which == 13) {
            flag = true;
        }
    }
    if (flag) {
        Search();
    }
    else {
        return false;
    }
}

function SetMenuActive() {
    ActiveMenu(getCookie("MenuActiveID"), false);
    alert(getCookie("MenuActiveID"));
}

function setCookie(Name, Path, Expires, Value) {
    var cstr = Name.concat('=').concat(Value);
    if (Path == '')
        Path = '/';
    cstr = cstr.concat(';path=').concat(Path);
    if (Expires == '')
        Expires = (new Date(2020, 11, 14)).toGMTString();
    document.cookie = cstr.concat(';expires=').concat(Expires);
}

function getCookie1(Name, Default) {
    var cookie = document.cookie;
    var ir = 0, ie = 0, sf = '', i = 0, j = 0;
    Name = Name.toLowerCase();
    if (typeof (Default) == 'undefined')
        Default = '';
    if (cookie.length == 0)
        return Default;
    if ((ir = Name.indexOf('.')) == -1) {
        if (cookie.substr(0, Name.length + 1).toLowerCase() == Name.concat('=')) {
            if ((ie = cookie.indexOf(';')) != -1) {
                cookie = cookie.substr(0, ie);
            }
        }
        else {
            if ((ie = cookie.toLowerCase().indexOf('; '.concat(Name).concat('='))) == -1)
                return Default;
            cookie = cookie.substr(ie + 2);
            if ((ie = cookie.indexOf(';')) != -1) {
                cookie = cookie.substr(0, ie);
            }
        }
        sf = ';';
    }
    else {
        if ((i = cookie.toLowerCase().indexOf(Name.concat('='))) != -1) {
            if ((j = cookie.indexOf(';', i)) > i + Name.length + 1) {
                return ReplaceAll(unescape(cookie.substr(i + Name.length + 1, j - i - Name.length - 1)), '+', ' ');
            }
            else {
                j = cookie.length;
                return ReplaceAll(unescape(cookie.substr(i + Name.length + 1, j - i - Name.length - 1)), '+', ' ');
            }
        }

        var Root = Name.substr(0, ir);
        Name = Name.substr(ir + 1);
        if (cookie.substr(0, Root.length + 1).toLowerCase() == Root.concat('=')) {
            if ((ie = cookie.indexOf(';')) != -1) {
                cookie = cookie.substr(0, ie);
            }
        }
        else {
            if ((ie = cookie.toLowerCase().indexOf('; '.concat(Root).concat('='))) == -1)
                return Default;

            cookie = cookie.substr(ie + 2);

            if ((ie = cookie.indexOf(';')) != -1) {
                cookie = cookie.substr(0, ie);
            }
        }
        cookie = cookie.substr(Root.length + 1);
        sf = '&';
    }

    if (cookie.substr(0, Name.length + 1).toLowerCase() == Name.concat('=')) {
        ir = Name.length + 1;
    }
    else {
        if ((ir = cookie.toLowerCase().indexOf('&'.concat(Name).concat('='))) == -1)
            return Default;
        ir += Name.length + 2;
    }
    if ((ie = cookie.indexOf(sf, ir)) == -1) {
        return ReplaceAll(unescape(cookie.substr(ir)), '+', ' ');
    }
    else {
        return ReplaceAll(unescape(cookie.substring(ir, ie)), '+', ' ');
    }
}
//================================
function checkCookie() {
    if (!(getCookie1('fl') != null && getCookie1('fl') != "")) {
        setCookie1('fl', 0, 365);
    }

    fl = parseInt(getCookie1('fl')) + 1;
    if (fl != null && fl != "") {
        //alert(fl);
        setCookie1('fl', fl, 365);
    }
}
function getCookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) c_end = document.cookie.length;
            return unescape(document.cookie.substring(c_start, c_end));
        }
    }
    return "";
}

function AjaxProcess(url, divName) {
    AjaxRequest.get(
            {
                'url': url
            , 'onSuccess': function(req) {
                gmobj(divName).innerHTML = req.responseText;
            }
            , 'onError': function(req) { }
            }
        )
}