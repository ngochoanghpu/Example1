ALTER PROCEDURE [dbo].[PSP_MYPHOTO_INSERT] 
	@FILE_NAME NVARCHAR(128),
	@FILE_SIZE FLOAT,
	@STATUS NVARCHAR(16),
	@TYPE NVARCHAR(1),
	@USER_ID BIGINT,
	@FACEBOOK_ID NVARCHAR(512)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT PST_MYPHOTO(s_Filename, f_Size, s_Status, s_Type, l_UserId, s_FacebookId)
		VALUES(@FILE_NAME, @FILE_SIZE, @STATUS, @TYPE, @USER_ID, @FACEBOOK_ID);
		
	SELECT SCOPE_IDENTITY();
END