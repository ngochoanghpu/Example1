WITH tmp as (
   select s_FirstName, count(*) as total from tblTest
   group by s_FirstName, s_LastName
)
select * from tmp where total > 1