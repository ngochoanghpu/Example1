;WITH tmp as (
   select s_FirstName from tblTest
   group by s_FirstName, s_LastName
)
select count(*) from tmp