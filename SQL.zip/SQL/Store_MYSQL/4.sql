DELIMITER $$

CREATE DEFINER=`sa`@`%` PROCEDURE `tmp_getAlbumList_EVENT`(TeamId BIGINT,EventId BIGINT , PageSize INT, l_IdAlbumUndo BIGINT)
BEGIN
	   SELECT  a.l_Id, 
            a.s_Title,
            a.t_AddedDate,
            a.b_isWall,
            a.s_Status,
            (SELECT s_FileName FROM tmt_media_item WHERE l_Album_ID = a.l_Id AND (s_Status = 'ACTIVE' OR l_Album_ID = l_IdAlbumUndo) LIMIT 0, 1) AS s_FirstPhoto,
            (SELECT s_Type FROM tmt_media_item WHERE l_Album_ID = a.l_Id AND (s_Status = 'ACTIVE' OR l_Album_ID = l_IdAlbumUndo) LIMIT 0, 1) AS s_Type,
            (SELECT COUNT(*) FROM tmt_media_item WHERE l_Album_ID = a.l_Id AND (s_Status = 'ACTIVE' OR l_Album_ID = l_IdAlbumUndo)) AS TotalItem,
            (SELECT COUNT(*) FROM tmt_media_item WHERE l_Album_ID = a.l_Id AND (s_Status = 'ACTIVE' OR l_Album_ID = l_IdAlbumUndo) AND s_Type = 'Photo') AS TotalPhoto,
            (SELECT COUNT(*) FROM tmt_media_item WHERE l_Album_ID = a.l_Id AND (s_Status = 'ACTIVE' OR l_Album_ID = l_IdAlbumUndo) AND s_Type = 'Video') AS TotalVideo,
            e.s_EventName,
            e.t_StartDate,
            e.t_EndDate
    FROM    tmt_album a
            LEFT JOIN tmt_event e 
            ON e.l_EventID = a.l_Event_ID
    WHERE   a.l_Team_ID = TeamId
            AND (a.s_Status = 'ACTIVE' OR a.l_Id = l_IdAlbumUndo)
            AND a.l_Event_ID =EventId
    ORDER BY a.i_SortOrder, a.t_AddedDate DESC
    LIMIT   0, PageSize;
    
    SELECT COUNT(*) AS TotalAlbum FROM tmt_album WHERE l_Team_ID = TeamId AND l_Event_ID =EventId AND  s_Status = 'ACTIVE';
    END