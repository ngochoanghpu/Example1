DELIMITER $$

CREATE DEFINER=`sa`@`%` PROCEDURE `tmp_getImagesInAlbum`(AlbumId BIGINT, PageSize INT)
BEGIN
    Declare TotalMediaItem INT;
    SELECT  COUNT(*)
    INTO    TotalMediaItem
    FROM    tmt_media_item 
    WHERE   l_Album_ID = AlbumId 
            AND s_Status = 'ACTIVE';
    Select  a.l_Id, 
            a.s_FileName, 
            a.s_Caption,  
            a.s_Type,
            a.s_Original_Name,
            a.l_AuthorAccountID,
            a.l_AuthorSubProfileID,
            a.i_SortOrder,
            (Select s_Title From tmt_album Where l_Id = AlbumId And s_Status = 'ACTIVE') as AlbumTitle,
            l_Album_ID as AlbumId,
            TotalMediaItem As TotalItem
    From    tmt_media_item a            
    Where   a.l_Album_ID = AlbumId
            And a.s_Status = 'ACTIVE'
    Order By a.i_SortOrder, a.t_AddedDate Desc
    Limit   0, PageSize;  
    
    Select    l_Id,
              s_Title                                            
    From      tmt_album            
    Where     l_Id != AlbumId
	      And l_Team_ID = (Select l_Team_ID From tmt_album Where l_Id = AlbumId)
	      And s_Status = 'ACTIVE'            
    Order By  s_Title;
END