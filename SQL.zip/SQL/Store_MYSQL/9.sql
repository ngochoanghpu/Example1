DELIMITER $$

CREATE DEFINER=`sa`@`%` PROCEDURE `tmp_getInboxList`(ToSubProfileId BIGINT, StartIndex INT ,PageSize INT)
BEGIN

    SELECT 	distinct mess.l_Id,
            mess.s_Subject,
            mess.b_HaveAttachment,
            mess.l_FromSubProfileID,
            (
                Select  b_Read
                From    tmt_message_recipients
                Where   l_ToSubProfileId = ToSubProfileId
                        And (l_MessageId = mess.l_Id Or l_MessageId IN (Select l_Id From tmt_messages Where l_RepliedFromMsgId = mess.l_Id))
                ORder By l_MessageId Desc
                Limit   0, 1
            ) As b_Read,
            (
                SELECT  sub.l_AccountId
                FROM    tmt_messages m1 
                        INNER JOIN tmt_subprofile sub ON sub.l_ID = m1.l_FromSubProfileID
                WHERE 	m1.l_Id = mess.l_Id OR m1.l_RepliedFromMsgId = mess.l_Id
                ORDER BY m1.l_Id DESC
                LIMIT	0, 1
            ) AS AccountIdSender,
            (
                SELECT	sub.s_FirstName
                FROM    tmt_messages m1 
                        INNER JOIN tmt_subprofile sub ON sub.l_ID = m1.l_FromSubProfileID
                WHERE 	m1.l_Id = mess.l_Id OR m1.l_RepliedFromMsgId = mess.l_Id
                ORDER BY m1.l_Id DESC
                LIMIT	0, 1
            ) AS s_FirstName,
            (
                SELECT	sub.s_LastName
                FROM    tmt_messages m1 
                        INNER JOIN tmt_subprofile sub ON sub.l_ID = m1.l_FromSubProfileID
                WHERE 	m1.l_Id = mess.l_Id OR m1.l_RepliedFromMsgId = mess.l_Id
                ORDER BY m1.l_Id DESC
                LIMIT	0, 1
            ) AS s_LastName,
            (
                SELECT	m1.s_SenderName
                FROM    tmt_messages m1
                WHERE 	m1.l_Id = mess.l_Id OR m1.l_RepliedFromMsgId = mess.l_Id
                ORDER BY m1.l_Id DESC
                LIMIT	0, 1
            ) AS s_SenderName, 
            (
                SELECT	m1.s_Message_Text
                FROM    tmt_messages m1
                WHERE 	(m1.l_Id = mess.l_Id OR m1.l_RepliedFromMsgId = mess.l_Id) and exists (select * from tmt_message_recipients m2 where m2.l_MessageId = m1.l_Id and m2.l_ToSubprofileId=ToSubProfileId)
                ORDER BY m1.l_Id DESC
                LIMIT	0, 1
            ) AS s_Message_Text,
            (				
                SELECT	m1.t_AddedDate
                FROM    tmt_messages m1
                WHERE 	(m1.l_Id = mess.l_Id OR m1.l_RepliedFromMsgId = mess.l_Id) 
                ORDER BY m1.l_Id DESC
                LIMIT	0, 1
            ) AS t_AddedDate
	
    FROM    tmt_messages mess
            INNER JOIN tmt_message_recipients rec ON (rec.l_MessageId = mess.l_Id Or rec.l_MessageId IN (Select l_Id From tmt_messages Where s_Status = 'ACTIVE' And l_RepliedFromMsgId = mess.l_Id))
    WHERE   mess.s_Status = 'ACTIVE'
            And rec.s_Status = 'ACTIVE'
            And (mess.l_RepliedFromMsgId IS NULL Or (mess.l_FromSubProfileID = ToSubProfileId And mess.b_HaveReply = 1))
            And rec.l_ToSubProfileId = ToSubProfileId
    Order By rec.t_AddedDate Desc
    Limit   StartIndex, PageSize;
    
    SELECT	COUNT(*) AS totalMessageInbox
    FROM    tmt_messages mess
            INNER JOIN tmt_message_recipients rec ON (rec.l_MessageId = mess.l_Id Or rec.l_MessageId IN (Select l_Id From tmt_messages Where s_Status = 'ACTIVE' And l_RepliedFromMsgId = mess.l_Id))
    WHERE   mess.s_Status = 'ACTIVE'
            And rec.s_Status = 'ACTIVE'
            And (mess.l_RepliedFromMsgId IS NULL Or (mess.l_FromSubProfileID = ToSubProfileId And mess.b_HaveReply = 1))
            And rec.l_ToSubProfileId = ToSubProfileId;

END