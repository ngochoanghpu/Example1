DELIMITER $$

CREATE DEFINER=`sa`@`%` PROCEDURE `tmp_getImagesInAlbum_EVENT`(
	AlbumId BIGINT, 
	PageSize INT, 
	StartIndex INT,
	EventId BIGINT 
    )
BEGIN
		    DECLARE TotalMediaItem INT;
		    SELECT  COUNT(*) INTO    TotalMediaItem FROM    tmt_media_item 
		    WHERE   l_Album_ID = AlbumId AND s_Status = 'ACTIVE';
			 
		    SELECT  a.l_Id, 
			    a.s_FileName, 
			    a.s_Caption,  
			    a.s_Type,
			    a.s_Original_Name,
			    a.l_AuthorAccountID,
			    a.l_AuthorSubProfileID,
			    a.i_SortOrder,
			    (SELECT s_Title FROM tmt_album WHERE l_Id = AlbumId AND s_Status = 'ACTIVE') AS AlbumTitle,
			    a.l_Album_ID AS AlbumId,
			    TotalMediaItem AS TotalItem
		    FROM    tmt_media_item a
		    JOIN (SELECT * FROM tmt_album WHERE l_Event_ID = EventId) AS b   
		    WHERE  (a.l_Album_ID = b.l_Id ) AND a.s_Status = 'ACTIVE'
		    ORDER BY a.i_SortOrder, a.t_AddedDate DESC
		    LIMIT   0, PageSize;  
		    
		    SELECT    l_Id,
			          s_Title                                            
		    FROM      tmt_album            
		    WHERE     l_Id != AlbumId
			      AND l_Team_ID = (SELECT l_Team_ID FROM tmt_album WHERE l_Id = AlbumId)
			      AND s_Status = 'ACTIVE'            
		    ORDER BY  s_Title;
END