DELIMITER $$

CREATE DEFINER=`sa`@`%` PROCEDURE `tmp_getAlbumList`(TeamId BIGINT, PageSize INT)
BEGIN
    Select  a.l_Id, 
            a.s_Title,
            a.t_AddedDate,
            a.b_isWall,
            (Select s_FileName From tmt_media_item Where l_Album_ID = a.l_Id And s_Status = 'ACTIVE' Limit 0, 1) As s_FirstPhoto,
            (Select s_Type From tmt_media_item Where l_Album_ID = a.l_Id And s_Status = 'ACTIVE' Limit 0, 1) As s_Type,
            (Select Count(*) From tmt_media_item Where l_Album_ID = a.l_Id And s_Status = 'ACTIVE') As TotalItem,
            (Select Count(*) From tmt_media_item Where l_Album_ID = a.l_Id And s_Status = 'ACTIVE' and s_Type = 'Photo') As TotalPhoto,
            (Select Count(*) From tmt_media_item Where l_Album_ID = a.l_Id And s_Status = 'ACTIVE' and s_Type = 'Video') As TotalVideo,
            e.s_EventName,
            e.t_StartDate,
            e.t_EndDate
    From    tmt_album a
            Left Join tmt_event e On e.l_EventID = a.l_Event_ID
    Where   a.l_Team_ID = TeamId AND a.b_isMainEvent IS NOT TRUE
            And a.s_Status = 'ACTIVE'
    Order By a.i_SortOrder, a.t_AddedDate Desc
    Limit   0, PageSize;
    
    Select Count(*) As TotalAlbum From tmt_album Where l_Team_ID = TeamId And s_Status = 'ACTIVE';
END