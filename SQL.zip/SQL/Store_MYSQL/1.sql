DELIMITER $$

CREATE DEFINER=`sa`@`%` PROCEDURE `tmp_deleteItemInbox`(ToSubProfileId BIGINT, DeletedMessageId BIGINT)
BEGIN
    Update  tmt_message_recipients 
    Set     s_Status = 'DELETED'
    Where   (l_MessageId = DeletedMessageId Or l_MessageId In (Select l_Id From tmt_messages Where l_RepliedFromMsgId = DeletedMessageId))
            And l_ToSubProfileId = ToSubProfileId;
END