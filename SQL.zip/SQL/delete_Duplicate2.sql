WITH tmp as (
   select ROW_NUMBER () OVER (PARTITION BY s_FirstName,s_LastName order by (select 1))
   as [row], i_Id, s_FirstName, s_LastName
   from tblTest
)

delete t
from tblTest t
inner join tmp on t.i_Id = tmp.i_Id and tmp.row > 1