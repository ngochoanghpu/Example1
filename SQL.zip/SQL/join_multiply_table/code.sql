ALTER proc [dbo].[PS_GETSPORT]
@sportTypeTeam nvarchar(128),
@sportTypePool nvarchar(128),
@l_userid bigint
as
begin
select distinct 
  A.l_id
, isnull(A.s_state,'') as s_state
, C.s_Code2 as s_country
, A.s_Name
, A.s_city
, B.s_type
, isnull(D.s_value,'') as imagepath
, isnull(F.s_name,'') as sportname
, E.i_categoryid
, E.l_sportid
from swim_directory.dbo.PSV_DIRECTORY_with_address A with(nolock) inner join 
	 swim_directory.dbo.pst_relationship B with(nolock) on A.l_id = B.l_FromID left outer join 
	 swim_directory.dbo.PST_DIRECTORY_PROFILE D with(nolock) on A.l_id = D.l_DirectoryId and D.i_PropertyId = 258 inner join
	 swim_system.dbo.QTT_COUNTRY C with(nolock) on A.s_Country = C.s_Code3 inner join
	 dbo.PST_CATEGORY_SPORT E with(nolock) on E.i_categoryid = A.i_CategoryId inner join
	 dbo.PST_SPORT F with(nolock) on F.l_id = E.l_sportid
where B.l_ToId = @l_userid AND A.s_status in (N'ACTIVE', N'NEW') and B.s_status not in ('DELETED')  and B.s_type in (@sportTypeTeam,@sportTypePool) 
end