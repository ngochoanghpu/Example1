select s_FirstName, count(*) as total from tblTest 
group by s_FirstName
order by total